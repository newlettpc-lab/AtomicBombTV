@echo off
title Javi DJ - Atomic Bomb TV - Version Build 1.5 (Noviembre 2026) - TV en Vivo gratis VIP
chcp 65001 >nul
cd /d "%~dp0"
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0discord-rpc.ps1"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0refresh-playlist.ps1"
pause
