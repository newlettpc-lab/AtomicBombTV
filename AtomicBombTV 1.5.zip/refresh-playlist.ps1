﻿# Javi DJ - Atomic Bomb TV (Version Build 1.5 - Noviembre 2026)
# Encoding: UTF-8 con BOM

param(
    [string]$ModoVpn = $null,
    [string]$Accion = $null,
    [switch]$ShowDetails
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
[System.Net.ServicePointManager]::DefaultConnectionLimit = 128
[System.Net.ServicePointManager]::Expect100Continue = $false
[System.Net.ServicePointManager]::UseNagleAlgorithm = $false
$ProgressPreference = 'SilentlyContinue'
$Host.UI.RawUI.WindowTitle = "Javi DJ - Atomic Bomb TV - Version Build 1.5 (Noviembre 2026)"

$script:ScanTimer = [System.Diagnostics.Stopwatch]::StartNew()
$global:BlockedHosts = [System.Collections.Concurrent.ConcurrentDictionary[string, bool]]::new([System.StringComparer]::OrdinalIgnoreCase)
$global:ActiveStreamxHost = "streamx723.sbs"
$script:ParallelPool = $null
$script:CandyShopActiveCount = 0
$script:SkippedSportsCount = 0
$script:InStreamsStatus = "STANDBY"
$script:FutbolLibreApiStatus = "OFFLINE"
$script:EmbedMeStatus = "OFFLINE"
$script:SpanishVipStatus = "STANDBY"
$script:StreamXhdStatus = "OFFLINE"
$script:WebOracleStatus = "OFFLINE"
$script:WebAiStatus = "STANDBY"
$script:IptvStatus = "STANDBY"
$script:WebOracleEvents = [System.Collections.Generic.List[object]]::new()
$script:AiApiKey = if ($env:GEMINI_API_KEY) { $env:GEMINI_API_KEY } else { "" }
$script:AiModel = "gemini-2.5-flash"
try {
    $cfgP = Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) "discord-config.json"
    if (Test-Path $cfgP) {
        $cfgObj = [System.IO.File]::ReadAllText($cfgP, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
        if ($cfgObj.ai_api_key -and -not $script:AiApiKey) { $script:AiApiKey = [string]$cfgObj.ai_api_key }
        if ($cfgObj.ai_model) { $script:AiModel = [string]$cfgObj.ai_model }
    }
} catch {}

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$OutputFile = Join-Path $ScriptDir "playlist.m3u"
$ApiStatusFile = Join-Path $ScriptDir "events-status.json"
$HtmlPlayer = Join-Path $ScriptDir "Javi-DJ-Player.html"
$IptvConfigFile = Join-Path $ScriptDir "iptv-sources.json"
$UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"

Write-Host ""
Write-Host "  ================================================================" -ForegroundColor Red
Write-Host "   JAVI DJ - ATOMIC BOMB TV" -NoNewline -ForegroundColor Yellow
Write-Host "  |  " -NoNewline -ForegroundColor DarkGray
Write-Host "Version Build 1.5" -NoNewline -ForegroundColor Green
Write-Host " (Noviembre 2026)" -ForegroundColor Gray
Write-Host "   TV en Vivo gratis VIP" -ForegroundColor Green
Write-Host "  ================================================================" -ForegroundColor Red
Write-Host ""

function Get-ActiveVpnConnection {
    <# Detecta cualquier VPN de internet activa en Windows evitando falsos positivos de redes LAN virtuales. #>
    $ignoreDesc = '(?i)Radmin|Hamachi|ZeroTier|Tailscale|Hyper-V|VirtualBox|VMware|KM-TEST|Loopback|Bluetooth|Wi-Fi Direct'
    $vpnPattern = '(?i)Proton|WireGuard|Wintun|OpenVPN|TAP-Windows|NordLynx|NordVPN|Surfshark|Mullvad|ExpressVPN|CyberGhost|UrbanVPN|Windscribe|Private\s*Internet|\bPIA\b|HideMyAss|TunnelBear|Hotspot\s*Shield|Cisco\s*AnyConnect|Fortinet|Pulse\s*Secure|GlobalProtect|Cloudflare\s*WARP|WAN\s*Miniport.*(?:IKEv2|L2TP|PPTP|SSTP)|\bVPN\b|\bTun\b|\bTunnel\b'
    try {
        $adapter = Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object {
            $_.Status -eq 'Up' -and
            $_.Name -notmatch $ignoreDesc -and
            $_.InterfaceDescription -notmatch $ignoreDesc -and
            ($_.Name -match $vpnPattern -or $_.InterfaceDescription -match $vpnPattern)
        } | Select-Object -First 1
        if ($adapter) {
            return [PSCustomObject]@{ Connected = $true; AdapterName = [string]$adapter.Name; Description = [string]$adapter.InterfaceDescription }
        }
    } catch {}
    try {
        $ras = Get-VpnConnection -ErrorAction SilentlyContinue | Where-Object { $_.ConnectionStatus -eq 'Connected' } | Select-Object -First 1
        if ($ras) {
            return [PSCustomObject]@{ Connected = $true; AdapterName = [string]$ras.Name; Description = 'Windows VPN (RAS)' }
        }
    } catch {}
    return [PSCustomObject]@{ Connected = $false; AdapterName = ''; Description = '' }
}

function Read-InteractiveKeyNonBlocking {
    if ([Console]::IsInputRedirected) { return $null }
    try {
        if ([Console]::KeyAvailable) { return [Console]::ReadKey($true) }
    } catch {}
    return $null
}

function Wait-VpnDisconnectForPhase1 {
    $vpnNow = Get-ActiveVpnConnection
    if (-not $vpnNow.Connected) {
        Write-Host "  [+] Sin VPN detectada -> Iniciando Fase 1/2 (Canales sin VPN)..." -ForegroundColor Cyan
        Write-Host ""
        return
    }
    Write-Host "  +--------------------------------------------------------------+" -ForegroundColor DarkCyan
    Write-Host "  |  [FASE 1/2] CANALES SIN VPN                                  |" -ForegroundColor Cyan
    Write-Host "  +--------------------------------------------------------------+" -ForegroundColor DarkCyan
    Write-Host ("  [!] VPN detectada activa: {0} ({1})" -f $vpnNow.AdapterName, $vpnNow.Description) -ForegroundColor Yellow
    Write-Host "  [>] Desconectate de la VPN ahora para cargar canales sin VPN sin bloqueos." -ForegroundColor White
    Write-Host "      Esperando desconexion de la VPN automaticamente..." -ForegroundColor DarkCyan
    Write-Host "      [Pulsa 'S' si prefieres omitir este paso y continuar asi]" -ForegroundColor DarkGray
    if ([Console]::IsInputRedirected) {
        [void][Console]::In.ReadLine()
        Write-Host ""
        return
    }
    while ($true) {
        Start-Sleep -Milliseconds 350
        $chk = Get-ActiveVpnConnection
        if (-not $chk.Connected) {
            Write-Host "`n  [+] VPN desconectada. Estabilizando red e iniciando Fase 1/2..." -ForegroundColor Green
            Start-Sleep -Milliseconds 900
            Write-Host ""
            return
        }
        $k = Read-InteractiveKeyNonBlocking
        if ($k -and ($k.Key -eq 'Enter' -or $k.KeyChar -match '^(?i)s$')) {
            Write-Host "`n  [!] Continuando Fase 1 con la conexion actual..." -ForegroundColor Yellow
            Write-Host ""
            return
        }
    }
}

function Wait-VpnConnectForPhase2 {
    $vpnNow = Get-ActiveVpnConnection
    if ($vpnNow.Connected) {
        Write-Host ("  [+] VPN detectada ({0}) -> Iniciando Fase 2/2 (Canales que necesitan VPN)..." -f $vpnNow.AdapterName) -ForegroundColor Green
        return $true
    }
    Write-Host ""
    Write-Host "  +--------------------------------------------------------------+" -ForegroundColor DarkCyan
    Write-Host "  |  [FASE 2/2] CANALES QUE NECESITAN VPN                        |" -ForegroundColor Cyan
    Write-Host "  +--------------------------------------------------------------+" -ForegroundColor DarkCyan
    Write-Host "  [!] No se detecta ninguna VPN conectada. (Recomendado: Paises Bajos)" -ForegroundColor Yellow
    Write-Host "  [!] AVISO: Si no escaneas con VPN, NO se mostraran todos los" -ForegroundColor DarkYellow
    Write-Host "      canales ni servidores VIP (M+ LaLiga, DAZN, F1, Agendas)." -ForegroundColor DarkYellow
    Write-Host ""
    Write-Host "  >> ¿Quieres continuar con el escaneo completo CON VPN?" -ForegroundColor White
    Write-Host "     Conectate en tu app VPN (Paises Bajos) para avanzar automaticamente," -ForegroundColor Gray
    Write-Host "     o elige [" -NoNewline -ForegroundColor Gray
    Write-Host "S" -NoNewline -ForegroundColor Green
    Write-Host " = Esperar VPN (ENTER) | " -NoNewline -ForegroundColor Gray
    Write-Host "N" -NoNewline -ForegroundColor Magenta
    Write-Host " = Abrir programa sin VPN]: " -NoNewline -ForegroundColor Gray
    if ([Console]::IsInputRedirected) {
        $ans = [Console]::In.ReadLine()
        if ($ans -match '^(?i)s(?:i|í)?$') {
            return (Get-ActiveVpnConnection).Connected
        }
        return $false
    }
    $waitingPrinted = $false
    while ($true) {
        Start-Sleep -Milliseconds 350
        $chk = Get-ActiveVpnConnection
        if ($chk.Connected) {
            Write-Host ("`n  [+] VPN detectada ({0}). Estabilizando conexion e iniciando Fase 2/2..." -f $chk.AdapterName) -ForegroundColor Green
            Start-Sleep -Milliseconds 1200
            return $true
        }
        $k = Read-InteractiveKeyNonBlocking
        if ($k) {
            if ($k.KeyChar -match '^(?i)n$') {
                Write-Host "N"
                Write-Host "`n  [!] Omitiendo canales que necesitan VPN: continuando solo con canales sin VPN..." -ForegroundColor Yellow
                return $false
            }
            if ($k.Key -eq 'Enter' -or $k.KeyChar -match '^(?i)s$') {
                if (-not $waitingPrinted) {
                    Write-Host "S"
                    Write-Host "  [i] Esperando conexion VPN (Paises Bajos recomendado)... [Pulsa 'N' para cancelar]" -ForegroundColor Cyan
                    $waitingPrinted = $true
                }
            }
        }
    }
}

# Modo automatico portátil en 2 fases si no se fuerza -ModoVpn N/S
$isTwoPhaseAuto = [string]::IsNullOrWhiteSpace($ModoVpn)
if ($isTwoPhaseAuto) {
    $esModoVpn = $false
    Wait-VpnDisconnectForPhase1
} else {
    $esModoVpn = ($ModoVpn -match '^(?i)s(?:i|í)?$')
    if ($esModoVpn) {
        Write-Host "`n  [+] Modo Completo CON VPN activado: Escaneando todas las agendas y servidores..." -ForegroundColor Green
    } else {
        Write-Host "`n  [+] Modo Estricto SIN VPN activado: Sincronizando SOLAMENTE canales abiertos..." -ForegroundColor Cyan
    }
    Write-Host ""
}

function Get-HostKey([string]$url) {
    if ($url -match '^https?://([^/:]+)') { return $Matches[1].ToLower() }
    return ""
}

function Get-Utf8Content {
    param(
        [string]$Uri,
        [string]$Referer = $null,
        [int]$TimeoutSec = 3
    )
    $hKey = Get-HostKey $Uri
    if ($hKey -and $global:BlockedHosts -and $global:BlockedHosts.ContainsKey($hKey)) { return $null }

    $hdrs = @{}
    if ($Referer) { $hdrs["Referer"] = $Referer }
    try {
        $resp = Invoke-WebRequest -Uri $Uri -UserAgent $UserAgent -Headers $hdrs -UseBasicParsing -TimeoutSec $TimeoutSec -ErrorAction Stop
        if ($resp.RawContentStream) {
            return [System.Text.Encoding]::UTF8.GetString($resp.RawContentStream.ToArray())
        }
        if ($resp.Content -is [byte[]]) {
            return [System.Text.Encoding]::UTF8.GetString($resp.Content)
        }
        return [string]$resp.Content
    } catch [System.Net.WebException] {
        # Solo marcar host bloqueado si es fallo de red/DNS/TLS sin respuesta HTTP (no por simple timeout)
        if ($null -eq $_.Exception.Response -and $_.Exception.Status -ne [System.Net.WebExceptionStatus]::Timeout -and $hKey -and $global:BlockedHosts) {
            $global:BlockedHosts[$hKey] = $true
        }
        return $null
    } catch {
        return $null
    }
}

function Test-HlsLive {
    param(
        [string]$Uri,
        [string]$Referer = $null,
        [int]$TimeoutSec = 3
    )
    $hKey = Get-HostKey $Uri
    if ($hKey -and $global:BlockedHosts -and $global:BlockedHosts.ContainsKey($hKey)) { return $false }

    $hdrs = @{}
    if ($Referer) { $hdrs["Referer"] = $Referer }
    try {
        $r = Invoke-WebRequest -Uri $Uri -UserAgent $UserAgent -Headers $hdrs -UseBasicParsing -TimeoutSec $TimeoutSec -ErrorAction Stop
        if ($r.StatusCode -eq 200) {
            $txt = if ($r.Content -is [byte[]]) { [System.Text.Encoding]::UTF8.GetString($r.Content) } else { [string]$r.Content }
            return ($txt -match '#EXTM3U')
        }
        return $false
    } catch [System.Net.WebException] {
        if ($null -eq $_.Exception.Response -and $_.Exception.Status -ne [System.Net.WebExceptionStatus]::Timeout -and $hKey -and $global:BlockedHosts) {
            $global:BlockedHosts[$hKey] = $true
        }
        return $false
    } catch {
        return $false
    }
}

function Test-HlsDeepLive {
    param(
        [string]$Uri,
        [string]$Referer = $null,
        [string]$Origin = "null",
        [int]$TimeoutSec = 3,
        [switch]$SkipBlockCache
    )
    if ([string]::IsNullOrWhiteSpace($Uri) -or $Uri -notmatch '^https?://') { return $false }
    $hKey = Get-HostKey $Uri
    if (-not $SkipBlockCache -and $hKey -and $global:BlockedHosts -and $global:BlockedHosts.ContainsKey($hKey)) { return $false }

    $hdrs = @{}
    if ($Origin) { $hdrs["Origin"] = $Origin }
    if ($Referer) { $hdrs["Referer"] = $Referer }

    try {
        $r = Invoke-WebRequest -Uri $Uri -Headers $hdrs -UserAgent $UserAgent -UseBasicParsing -TimeoutSec $TimeoutSec -ErrorAction Stop
        if ($r.StatusCode -ne 200) { return $false }
        $txt = if ($r.RawContentStream) { [System.Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray()) } elseif ($r.Content -is [byte[]]) { [System.Text.Encoding]::UTF8.GetString($r.Content) } else { [string]$r.Content }
        if ($txt -notmatch '#EXTM3U') { return $false }
        $drmRe = '(?i)METHOD=SAMPLE-AES|skd://|com\.apple\.streamingkeydelivery|edef8ba9-79d6-4ace-a3c8-27dcd51d21ed|com\.microsoft\.playready'
        if ($txt -match $drmRe) { return $false }

        $childUrl = $Uri
        $txt2 = $txt
        if ($txt -match '#EXT-X-STREAM-INF') {
            $firstChild = ($txt -split "`r?`n" | Where-Object { $_ -and $_ -notmatch '^#' -and $_ -notmatch '(?i)_audio.*\.m3u8' } | Select-Object -First 1)
            if (-not $firstChild) { $firstChild = ($txt -split "`r?`n" | Where-Object { $_ -and $_ -notmatch '^#' } | Select-Object -First 1) }
            if (-not $firstChild) { return $false }
            $childUrl = [Uri]::new([Uri]$Uri, $firstChild.Trim()).AbsoluteUri
            $r2 = Invoke-WebRequest -Uri $childUrl -Headers $hdrs -UserAgent $UserAgent -UseBasicParsing -TimeoutSec $TimeoutSec -ErrorAction Stop
            if ($r2.StatusCode -ne 200) { return $false }
            $txt2 = if ($r2.RawContentStream) { [System.Text.Encoding]::UTF8.GetString($r2.RawContentStream.ToArray()) } elseif ($r2.Content -is [byte[]]) { [System.Text.Encoding]::UTF8.GetString($r2.Content) } else { [string]$r2.Content }
            if ($txt2 -notmatch '#EXTM3U') { return $false }
            if ($txt2 -match $drmRe) { return $false }
        }

        $seg = ($txt2 -split "`r?`n" | Where-Object { $_ -and $_ -notmatch '^#' } | Select-Object -Last 1)
        if (-not $seg -and $txt2 -match '#EXT-X-MAP:URI="([^"]+)"') { $seg = $Matches[1] }
        if (-not $seg) { return $false }
        $segUrl = [Uri]::new([Uri]$childUrl, $seg.Trim()).AbsoluteUri

        $resp = $null; $st = $null
        try {
            $req = [System.Net.HttpWebRequest]::Create($segUrl)
            $req.Method = "GET"
            $req.Timeout = $TimeoutSec * 1000
            $req.UserAgent = $UserAgent
            if ($Referer) { $req.Referer = $Referer }
            if ($Origin) { $req.Headers.Add("Origin", $Origin) }
            $resp = $req.GetResponse()
            $st = $resp.GetResponseStream()
            $buf = New-Object byte[] 16
            $n = $st.Read($buf, 0, 16)
            return ([int]$resp.StatusCode -eq 200 -and $n -gt 0)
        } finally {
            if ($st) { try { $st.Close() } catch {} }
            if ($resp) { try { $resp.Close() } catch {} }
        }
    } catch [System.Net.WebException] {
        if ($null -eq $_.Exception.Response -and $_.Exception.Status -ne [System.Net.WebExceptionStatus]::Timeout -and $hKey -and $global:BlockedHosts) {
            $global:BlockedHosts[$hKey] = $true
        }
        return $false
    } catch {
        return $false
    }
}

function Resolve-CapoCandyShop {
    param(
        [string]$IframeUrl,
        [string]$Referer = "https://cdplay.live/"
    )
    $targetUrl = $IframeUrl
    $innerReferer = $Referer

    # Soportar doble salto 104game.click/player/capo2/<N> -> sofayshop.st/hlsspanich.php?stream=H<N>
    if ($IframeUrl -match '104game\.click/player/capo2/(\d+)') {
        $capoNum = $Matches[1]
        $hopHtml = Get-Utf8Content -Uri $IframeUrl -Referer $Referer -TimeoutSec 4
        $innerReferer = $IframeUrl
        if ($hopHtml -and $hopHtml -match '(?:https?:)?//(sofayshop\.st/hlsspanich\.php\?stream=H\d+)') {
            $targetUrl = "https://" + $Matches[1]
        } else {
            $targetUrl = "https://sofayshop.st/hlsspanich.php?stream=H$capoNum"
        }
    }

    $html = Get-Utf8Content -Uri $targetUrl -Referer $innerReferer -TimeoutSec 4
    # Si el nodo origen (ej. xstream.st) está bloqueado sin VPN, espejar en sofayshop.st
    if (-not $html -and $targetUrl -match '^https?://[^/]+/(capopro\.php\?stream=CA\d+|livetvfx\.php\?stream=SSF\d+|hlsspanich\.php\?stream=H\d+)') {
        $mirrorUrl = "https://sofayshop.st/" + $Matches[1]
        $html = Get-Utf8Content -Uri $mirrorUrl -Referer $innerReferer -TimeoutSec 4
    }
    if (-not $html) { return $null }

    $candidates = [regex]::Matches($html, 'https://[^"''\\]+(?:index|master)\.m3u8[^\s"''<>\\]*') |
        ForEach-Object { $_.Value -replace '\\u0026', '&' -replace '\\/', '/' } |
        Select-Object -Unique

    if (-not $candidates -or $candidates.Count -eq 0) {
        $candidates = [regex]::Matches($html, 'https?://[^\s"''<>\\]+\.m3u8[^\s"''<>\\]*') |
            ForEach-Object { $_.Value -replace '\\u0026', '&' -replace '\\/', '/' } |
            Select-Object -Unique
    }
    if (-not $candidates -or $candidates.Count -eq 0) { return $null }

    # Colapsar espejos del mismo cluster: mantener 1 /live/ + 1 /live3/ en CandyShop (preferir edge2) + 1 respaldo distinto (instreams/gate4)
    $orderedAll = @($candidates | Sort-Object {
        if ($_ -match 'edge2\.candyshop\.st') { 0 }
        elseif ($_ -match 'candyshop\.st') { 1 }
        elseif ($_ -match 'instreams\.') { 2 }
        elseif ($_ -match 'gate4\.st') { 3 }
        else { 4 }
    })
    $candyLive1 = $orderedAll | Where-Object { $_ -match 'candyshop\.st.*/live/' } | Select-Object -First 1
    $candyLive3 = $orderedAll | Where-Object { $_ -match 'candyshop\.st.*/live3/' } | Select-Object -First 1
    $candyAny = if (-not $candyLive1 -and -not $candyLive3) { $orderedAll | Where-Object { $_ -match 'candyshop\.st' } | Select-Object -First 1 } else { $null }
    $altCdn = $orderedAll | Where-Object { $_ -notmatch 'candyshop\.st' } | Select-Object -First 1
    $fastCands = @($candyLive1, $candyLive3, $candyAny, $altCdn | Where-Object { $_ })

    foreach ($cand in $fastCands) {
        if (Test-HlsDeepLive -Uri $cand -Referer $targetUrl -TimeoutSec 2) {
            return $cand
        }
    }
    return $null
}

function Resolve-Tvf90Url {
    param(
        [string]$StreamSlug,
        [string]$Referer = "https://tvf90.com/"
    )
    if ([string]::IsNullOrWhiteSpace($StreamSlug)) { return $null }
    $html = Get-Utf8Content -Uri ("https://tvf90.com/5.php?stream=" + $StreamSlug) -Referer $Referer -TimeoutSec 3
    if ($html -and $html -match '(https?://[^\s"''<>]+\.m3u8[^\s"''<>]*)') {
        $m3u = $Matches[1]
        if (Test-HlsDeepLive -Uri $m3u -Referer "https://tvf90.com/" -TimeoutSec 3) {
            return $m3u
        }
    }
    return $null
}

function Resolve-StreamxNodeUrl {
    param(
        [string]$ChannelSlug,
        [string]$HostDomain = $null,
        [string]$Referer = "https://cdplay.live/"
    )
    if ([string]::IsNullOrWhiteSpace($ChannelSlug)) { return $null }
    if (-not $HostDomain) { $HostDomain = $global:ActiveStreamxHost }
    if (-not $HostDomain -or ($global:BlockedHosts -and $global:BlockedHosts.ContainsKey($HostDomain))) { return $null }

    $wrapUrl = "https://$HostDomain/global3.php?channel=$ChannelSlug"
    $wrapBody = Get-Utf8Content -Uri $wrapUrl -Referer $Referer -TimeoutSec 3
    if ($wrapBody -and $wrapBody -match '"src"\s*:\s*"([^"]+)"') {
        $m3uProbe = $Matches[1]
        if (Test-HlsDeepLive -Uri $m3uProbe -Referer $wrapUrl -TimeoutSec 4) {
            return $m3uProbe
        }
    }
    return $null
}

function Resolve-StreamXhdUrl {
    param(
        [string]$LivePageUrl,
        [string]$Referer = "https://streamxhd.click/"
    )
    $html = Get-Utf8Content -Uri $LivePageUrl -Referer $Referer -TimeoutSec 4
    if (-not $html) { return $null }

    $i = $html.IndexOf("var playbackURL")
    if ($i -lt 0) { return $null }
    $j = $html.IndexOf("var adsPayload", $i)
    if ($j -lt 0) { $j = $html.IndexOf("var reloadDelay", $i) }
    if ($j -lt 0) { return $null }

    $blk = $html.Substring($i, $j - $i)
    $sa = $blk.IndexOf("[[")
    $ea = $blk.IndexOf("]];", $sa)
    if ($sa -lt 0 -or $ea -le $sa) { return $null }

    # Conservar corchetes externos de elementos 0 y N-1 para decodificacion integra de los 142+ caracteres
    $arrStr = $blk.Substring($sa + 1, $ea - $sa)
    $mK = [regex]::Match($blk.Substring($ea), 'function\s+[a-zA-Z0-9_]+\(\)\{return\s+(\d+);\}\s*function\s+[a-zA-Z0-9_]+\(\)\{return\s+(\d+);\}')
    if (-not $mK.Success) { return $null }

    $k = [int]$mK.Groups[1].Value + [int]$mK.Groups[2].Value
    $elems = $arrStr -split '(?<=\]),(?=\[)'
    $chars = foreach ($el in $elems) {
        if ($el -match '^\[(\d+),"([^"]+)"\]$') {
            try {
                $rawDec = [System.Text.Encoding]::ASCII.GetString([Convert]::FromBase64String($Matches[2]))
                $numOnly = $rawDec -replace '\D', ''
                if ($numOnly) {
                    [PSCustomObject]@{ idx = [int]$Matches[1]; ch = [char]([int]$numOnly - $k) }
                }
            } catch {}
        }
    }
    $decoded = (($chars | Sort-Object idx).ch -join '')
    if ($decoded -match '^https?://.*\.m3u8') {
        if (Test-HlsDeepLive -Uri $decoded -Referer $LivePageUrl -TimeoutSec 4) {
            return $decoded
        }
    }
    return $null
}

function Resolve-EmbdlolWatchUrl {
    param([string]$WatchId)
    if ([string]::IsNullOrWhiteSpace($WatchId)) { return $null }
    try {
        $watchBody = '{"watchId":"' + $WatchId + '"}'
        $wResp = Invoke-RestMethod -Uri "https://api.embdlol.st/watch" -Method POST -Body $watchBody -ContentType "application/json" -TimeoutSec 3 -ErrorAction Stop
        if ($wResp -and $wResp.url) {
            if (Test-HlsDeepLive -Uri $wResp.url -Referer "https://embdlol.st/" -Origin "https://embdlol.st" -TimeoutSec 3) {
                return $wResp.url
            }
        }
    } catch {}
    return $null
}

function Resolve-EmbedAnyUrl {
    param(
        [string]$Url,
        [string]$Referer = "https://cdplay.live/",
        [int]$Depth = 0
    )
    if ([string]::IsNullOrWhiteSpace($Url) -or $Depth -gt 2) { return $null }
    if ($Url -match '\.m3u8(?:\?|$)') {
        if (Test-HlsDeepLive -Uri $Url -Referer $Referer -TimeoutSec 4) { return $Url }
        return $null
    }
    if ($Url -match 'embdlol\.st/embed/([a-zA-Z0-9-]+)') {
        return (Resolve-EmbdlolWatchUrl -WatchId $Matches[1])
    }
    if ($Url -match '104game\.click/player/capo2/\d+|capopro\.php\?stream=|livetvfx\.php\?stream=|hlsspanich\.php\?stream=|xstream\.st/') {
        return (Resolve-CapoCandyShop -IframeUrl $Url -Referer $Referer)
    }
    if ($Url -match 'streamxhd\.click/live\d*\.php\?stream=') {
        return (Resolve-StreamXhdUrl -LivePageUrl $Url -Referer $Referer)
    }
    if ($Url -match 'streamxhd\.click/channel/\?id=([^&\s]+)') {
        return (Resolve-StreamXhdUrl -LivePageUrl ("https://streamxhd.click/live1.php?stream=" + $Matches[1]) -Referer $Referer)
    }
    if ($Url -match 'streamx[a-z0-9]+\.sbs/global[13]\.php\?channel=([^&\s]+)') {
        $chSlug = $Matches[1]
        $res = Resolve-StreamxNodeUrl -ChannelSlug $chSlug -Referer $Referer
        if (-not $res) {
            $res = Resolve-StreamXhdUrl -LivePageUrl "https://streamxhd.click/live1.php?stream=$chSlug" -Referer $Referer
        }
        if (-not $res) {
            $res = Resolve-Tvf90Url -StreamSlug $chSlug -Referer $Referer
        }
        return $res
    }
    if ($Url -match 'tvf90\.com/(?:[a-z0-9_-]+\.php|online/canal\.php)\?stream=([^&\s]+)') {
        $tvfSlug = $Matches[1]
        $resT = Resolve-Tvf90Url -StreamSlug $tvfSlug -Referer $Referer
        if (-not $resT) {
            $resT = Resolve-StreamXhdUrl -LivePageUrl "https://streamxhd.click/live1.php?stream=$tvfSlug" -Referer $Referer
        }
        return $resT
    }
    if ($Url -match 'embedme\.st/(?:play|player)/|cdplay\.live/|futbollibregol\.org/') {
        $baseRef = if ($Url -match '^(https?://[^/]+/)') { $Matches[1] } else { $Referer }
        $emHtml = Get-Utf8Content -Uri $Url -Referer $baseRef -TimeoutSec 3
        if ($emHtml -and $emHtml -match '(https?://[^\s"''<>\\]+\.m3u8[^\s"''<>\\]*)') {
            $dirM3u = $Matches[1] -replace '\\/', '/' -replace '\\u0026', '&'
            if (Test-HlsDeepLive -Uri $dirM3u -Referer $Url -TimeoutSec 3) { return $dirM3u }
        }
        if ($emHtml -and $emHtml -match '<iframe[^>]+src=["'']([^"'']+)["'']') {
            $subSrc = $Matches[1].Trim()
            if ($subSrc -notmatch '^https?://') { $subSrc = $baseRef + $subSrc.TrimStart('/') }
            return (Resolve-EmbedAnyUrl -Url $subSrc -Referer $Url -Depth ($Depth + 1))
        }
    }
    return $null
}

function Translate-ToSpanish($name) {
    if ([string]::IsNullOrWhiteSpace($name)) { return "" }
    $t = ($name -replace '\s+', ' ').Trim()

    # Detección y normalización precisa de canales españoles de deportes, TDT y motor
    if ($t -match '(?i)^formula\s*1(?:\s*hd)?$') { return "DAZN F1 España" }
    if ($t -match '(?i)^motogp(?:\s*hd)?$') { return "DAZN MotoGP España HD" }
    if ($t -match '(?i)^dazn\s*f1(?:\s*hd)?$') { return "DAZN F1 España" }
    if ($t -match '(?i)^dazn\s*motogp(?:\s*hd)?$') { return "DAZN MotoGP España HD" }
    if ($t -match '(?i)^dazn\s*([1-4])(?:\s*es|\s*espa[ñn]a)?(?:\s*hd)?$') { return "DAZN $($Matches[1]) España HD" }
    if ($t -match '(?i)^(?:movistar\+?|m\+)\s*deportes(?:\s*(\d+))?(?:\s*hd)?$') {
        $num = if ($Matches[1]) { " $($Matches[1])" } else { "" }
        return "Movistar+ Deportes$num España HD"
    }
    if ($t -match '(?i)^(?:movistar\+?|m\+|#)\s*vamos(?:\s*hd)?$') { return "Movistar+ Vamos España HD" }
    if ($t -match '(?i)^(?:movistar\+?|m\+)\s*golf(?:\s*hd)?$') { return "Movistar+ Golf España HD" }
    if ($t -match '(?i)^(?:movistar\+?|m\+)\s*laliga(?:\s*(\d+))?(?:\s*hd)?$') {
        $num = if ($Matches[1]) { " $($Matches[1])" } else { "" }
        return "M+ LaLiga$num España HD"
    }
    if ($t -match '(?i)^dazn\s*laliga(?:\s*(\d+))?(?:\s*hd)?$') {
        $num = if ($Matches[1]) { " $($Matches[1])" } else { "" }
        return "DAZN LaLiga$num España HD"
    }
    if ($t -match '(?i)^(?:movistar\+?|m\+)\s*(?:liga\s*de\s*campeones|champions)(?:\s*(\d+))?(?:\s*hd)?$') {
        $num = if ($Matches[1]) { " $($Matches[1])" } else { "" }
        return "M+ Liga de Campeones$num España HD"
    }
    if ($t -match '(?i)^eurosport\s*([12])\s*(?:es|esp|espa[ñn]a|spanish)(?:\s*hd)?$') { return "Eurosport $($Matches[1]) España HD" }
    if ($t -match '(?i)^gol\s*(?:play|tv)(?:\s*es|\s*espa[ñn]a)?$') { return "Gol Play España (TDT)" }
    if ($t -match '(?i)^teledeporte(?:\s*hd|\s*uhd)?$') { return "Teledeporte RTVE UHD / HD" }
    if ($t -match '(?i)^la\s*1(?:\s*uhd|\s*hd)?$') { return "RTVE La 1 UHD / HD" }
    if ($t -match '(?i)^la\s*2(?:\s*hd|\s*uhd)?$') { return "RTVE La 2 UHD / HD" }
    if ($t -match '(?i)^(?:canal\s*)?24\s*h(?:oras)?(?:\s*hd)?$') { return "RTVE Canal 24 Horas HD" }
    if ($t -match '(?i)^capo\s*deportes$') { return "Capo Deportes HD (España / Deportes)" }
    if ($t -match '(?i)^capo\s*deportes\s*2') { return "Capo Deportes 2 HD (Eventos En Vivo)" }
    if ($t -match '(?i)^spanish$') { return "DAZN F1 España" }

    $t = $t -replace '(?i)\bF1\s*-\s*Interlagos.*DAZN\b', 'DAZN F1 España'
    $t = $t -replace '(?i)\bMoto\d*/\d*/GP\s*-\s*Lusail.*DAZN\b', 'DAZN MotoGP España HD'
    $t = $t -replace '(?i)\b(\d+)\s*Hours of\b', '$1 Horas de'
    $t = $t -replace '(?i)\bHours of\b', 'Horas de'
    $t = $t -replace '(?i)\bSprint Shootout\b', 'Clasificación Sprint'
    $t = $t -replace '(?i)\bSprint Race\b', 'Carrera Sprint'
    $t = $t -replace '(?i)\bRace\b', 'Carrera'
    $t = $t -replace '(?i)\bQualifying\b', 'Clasificación'
    $t = $t -replace '(?i)\bPractice\b', 'Entrenamientos Libres'
    $t = $t -replace '(?i)\bSunday\b', 'Domingo'
    $t = $t -replace '(?i)\bSaturday\b', 'Sábado'
    $t = $t -replace '(?i)\bFriday\b', 'Viernes'
    $t = $t -replace '(?i)\bWorld\b', 'Internacional'
    $t = $t -replace '(?i)\bDrivers track\b', 'Cámara de Pilotos (Onboard)'
    $t = $t -replace '(?i)\bData Channel\b', 'Canal de Datos y Telemetría'
    $t = $t -replace '(?i)\bPit Lane\b', 'Calle de Boxes (Pitlane)'
    $t = $t -replace '(?i)\bWarmup\b', 'Calentamiento'
    $t = $t -replace '(?i)\bPre-Race\b', 'Previo de Carrera'
    $t = $t -replace '(?i)\bPost-Race\b', 'Post Carrera'
    $t = $t -replace '(?i)\bMulti Lang\b', 'Multi Idioma'
    $t = $t -replace '(?i)\bFC Cologne\b', 'FC Colonia'
    $t = $t -replace '(?i)\bSpanish\b', 'Español'
    $t = $t -replace '(?i)\bItalian\b', 'Italiano'
    $t = $t -replace '(?i)\bGerman\b', 'Alemán'
    $t = $t -replace '(?i)\bFrench\b', 'Francés'
    $t = $t -replace '(?i)\bEnglish\b', 'Inglés'
    $t = $t -replace '(?i)\bHighlights\b', 'Resumen'
    $t = $t -replace '(?i)\s+at\s+', ' vs '
    $t = $t -replace '(?i)\s+v\s+', ' vs '
    $t = $t -replace '<[^>]+>', ''
    return $t.Trim()
}

function Get-ChannelGroup($name, $sourceHint = "") {
    # 1. F1 España (DAZN F1 España y señales de Fórmula 1 en español)
    if ($sourceHint -eq 'IPTV_F1_ES' -or $name -match '(?i)DAZN\s*F1|Formula\s*1.*Espa[ñn]|F1.*Espa[ñn]|F1.*DAZN|Movistar.*F1|Carrera.*DAZN|Race.*DAZN|GP\s*(?:de\s*)?Espa[ñn]a.*F1|F1.*GP\s*(?:de\s*)?Espa[ñn]a') {
        return 'F1 España'
    }
    # 2. MotoGP España (DAZN MotoGP España y señales de MotoGP en español)
    if ($name -match '(?i)DAZN\s*MotoGP|Moto\s*GP.*Espa[ñn]|Moto\s*GP.*DAZN|Moto[23].*DAZN|Moto[23].*Espa[ñn]|Movistar.*MotoGP|GP\s*(?:de\s*)?Espa[ñn]a.*Moto|GP\s*(?:de\s*)?(?:Jerez|Catalu[ñn]a|Arag[oó]n|Valencia).*Moto') {
        return 'MotoGP España'
    }
    # 3. Canales deportivos españoles TV específicos (antes de clubes para evitar colisiones como Real Madrid TV)
    if ($name -match '(?i)Real\s*Madrid\s*TV|Bar[çc]a\s*TV') {
        return 'Deportes España'
    }
    # 3b. Pistas explicitas de IPTV Lineal (Cine/Cultura/Infantil-Musica) antes de TDT/Clubes
    if ($sourceHint -eq 'IPTV_CINE') { return 'Cine y Series España' }
    if ($sourceHint -eq 'IPTV_CULTURA') { return 'Documentales y Cultura España' }
    if ($sourceHint -eq 'IPTV_INFANTIL_MUSICA') { return 'Infantil y Música España' }
    # 4. TDT España (solo emisoras lineales, evitando robar partidos "vs" que mencionen un canal como La 1 o Teledeporte)
    if ($name -notmatch '(?i)\bvs\.?\b' -and ($sourceHint -eq 'IPTV_TDT' -or $name -match '(?i)RTVE|\bLa 1\b|\bLa 2\b|Teledeporte|24 Horas|Clan|\bTVE\b|Gol\s*Play|Antena\s*3|Cuatro|Telecinco|La\s*Sexta|LaSexta|Mega|Neox|Nova|Energy|Be\s*Mad|Atresplayer|Atreseries|A3Series|\bFDF\b|Factor[ií]a\s*de\s*Ficci[oó]n|\bDivinity\b|\bDKISS\b|^TEN(?:\s|$)|Squirrel(?:\s*2)?|La\s*S[eé]ptima|3\/?24(?:\s*CAT)?|Super\s*3|Bon\s*Dia|Onda\s*C[aá]diz|Teleonuba|Canal\s*Parlamento|7TV\s*[A-Z]|Hit\s*TV|Mitele|Telemadrid|LaOtra|La\s*Otra|DMAX|\bTRECE\b|El Toro TV|Negocios TV|Canal Sur|\bTV3\b|El 33|TV3CAT|[ÀA]\s*Punt|\bETB\s*[12]|\bTVG\b|Galicia TV|Arag[oó]n|IB3|\bTPA\b|CyLTV|7RM|Navarra TV|TeleValencia|\bCMM\b|Canal Extremadura|TV\s*Canaria|\bTDT\b|Sol\s*M[uú]sica|France\s*24\s*Espa')) {
        return 'TDT España'
    }
    # 5. Emisoras IPTV de Deportes España con nombre de evento variable (p. ej. DAZN Eventos con partidos NBA/internacionales)
    if ($name -match '(?i)^(?:DAZN\s*Eventos|LaLiga\+\s*Eventos?|FootballClub|2RFEF)\b') {
        if ($name -match '(?i)LaLiga\+|FootballClub|2RFEF') { return 'Fútbol España' }
        return 'Deportes España'
    }
    # 5b. Respetar pista explicita de Baloncesto o NFL antes de comprobar clubes/países
    if ($sourceHint -eq "Basketball") { return 'Baloncesto' }
    if ($sourceHint -eq "NFL") { return 'NFL' }
    # 6. Fútbol España (M+ LaLiga, DAZN LaLiga, Hypermotion, M+ Liga de Campeones, Selección y clubes españoles)
    if ($name -notmatch '(?i)Talleres\s+de\s+C[oó]rdoba|Am[eé]rica\s+de\s+Cali' -and $name -match '(?i)LaLiga|Movistar\s*LaLiga|M\+\s*LaLiga|MLaLiga|DAZN\s*LaLiga|DLaLiga|Hypermotion|M\+\s*Liga\s*(?:de\s*)?Campeones|MCampeones|Movistar.*Campeones|Primera\s*Federaci[oó]n|1ª\s*Federaci[oó]n|Segunda\s*Federaci[oó]n|2ª?\s*RFEF|FootballClub|FanPlay\s*TV|LaLiga\+|Top\s*Bar[çc]a\s*TV|Betis\s*TV|DAZN\s*Liga\s*F|Copa\s*del\s*Rey|Supercopa\s*de\s*Espa|Liga\s*F\b|\bRFEF\b|Selecci[oó]n\s*Espa[ñn]ola|\bEspa[ñn]a\b|\bSpain\b|Celta|Levante|Barcelona|Bar[çc]a|Real\s*Madrid|Atl[eé]tico(?:\s+de)?\s+Madrid|Atl[eé]tico\s+Baleares|Sevilla|Betis|Valencia|Girona|(?<!Wigan\s|Charlton\s|Oldham\s|Forfar\s|Dunfermline\s)Athletic|Villarreal|Real\s*Sociedad|Mallorca|Osasuna|Getafe|Espanyol|Alav[eé]s|Legan[eé]s|Valladolid|Las\s*Palmas|Rayo\s*Vallecano|Oviedo|Real\s*Sporting|Sporting\s*Gij|Zaragoza|Racing\s*Santander|Racing\s*Ferrol|Deportivo\s+(?:de\s+La\s+)?Coru[ñn]a|\bRC\s*Deportivo\b|M[aá]laga|C[aá]diz|Almer[ií]a|Granada|Elche|Tenerife|Sabadell|Eldense|Mirand[eé]s|Castell[oó]n|C[oó]rdoba|Burgos|Huesca|Eibar|Cartagena|Badalona|Albacete|Cultural\s*Leonesa|Real\s*Murcia|Algeciras') {
        return 'Fútbol España'
    }
    # 7. Emisoras fijas y eventos de Deportes España (ACB, tenis español, ciclismo español, canales M+/DAZN sin partido internacional)
    if ($name -match '(?i)\bACB\b|DAZN\s*Baloncesto|Liga\s*Endesa|Unicaja|Baskonia|UCAM\s*Murcia|Manresa|Obradoiro|Joventut|Alcaraz|Badosa|Davidovich|Alonso\s*(?:vs|F1)?|Carlos\s*Sainz|Marc\s*M[aá]rquez|La\s*Vuelta|Vuelta\s*a\s*Espa|Masters\s*(?:de\s*)?Madrid|Mutua\s*Madrid|Capo\s*Deportes|Esport\s*3|Esport3|UFC.*\(ES\)|UFC\s*(?:Fight\s*Pass|Network|Evento)') {
        return 'Deportes España'
    }
    if ($name -notmatch '(?i)\bvs\.?\b' -and $name -match '(?i)Movistar\+\s*Deportes|M\+\s*Deportes?|Movistar\s*Deportes?|MDeportes|Movistar\+\s*Vamos|Movistar\s*Vamos|Movistar\s*Plus\+|M\+\s*Vamos|MVamos|MPlus|#?Vamos|Movistar\+\s*Golf|M\+\s*Golf|Movistar\+\s*Ellas|M\+\s*Ellas|DAZN\s*[1-4]|DAZN\s*Futsal|DAZN\s*Eventos|One\s*Toro|OneToro|Torol[eé]|M\+\s*Multideporte|Multideporte|Ubeat|MyPadel|DBike|Surf\s*Channel|Rally\s*TV|Tennis\s*Channel|Moto\s*Adv|Garage\s*TV|Eurosport.*Espa[ñn]|Deportes.*Espa[ñn]|Espa[ñn]a.*Deportes') {
        return 'Deportes España'
    }
    if ($name -notmatch '(?i)\b(?:UK|FR|DE|IT|PL|NL|US|International)\b' -and $name -match '(?i)^Eurosport\s*[12]\b') {
        return 'Deportes España'
    }
    # 8. Formula 1 Internacional
    if ($name -match '(?i)Formula\s*1|\bF1\b|\bF1TV\b|^(?:TRACKER|DATA)$|Interlagos|Sky\s*Sports\s*F1|Sky\s*F1|Sky\s*Sport\s*F1|Fox\s*Sports\s*F1|F1\s*TV|Carrera.*Sky|Carrera.*Apple|Carrera.*UHD|Race.*Sky|Race.*UHD|Nexa|Pilotos|Onboard|Telemetr|Pit\s*Lane|Pitlane') {
        return 'Formula 1 Internacional'
    }
    # 9. MotoGP y Motor Internacional
    if ($name -match '(?i)MotoGP|Moto\s*GP|Lusail|Moto2|Moto3|WEC|Endurance|Horas\s*de|Autodromo|Rally|NASCAR|IndyCar|Superbike|WSBK|Motorsport|Garage\s*TV') {
        return 'MotoGP y Motor Internacional'
    }
    # 10. Fútbol Internacional (partidos/ligas extranjeros incluso si se emiten en DAZN/Castellano)
    if ($name -match '(?i)Premier\s*League|EFL\s*Championship|FA\s*Cup|Serie\s*A|Serie\s*B|Bundesliga|Ligue\s*1|Ligue\s*2|Primeira\s*Liga|Eredivisie|Champions\s*League|UEFA\s*Women(?:\x27s)?\s*Champions|Europa\s*League|Conference\s*League|Libertadores|Sudamericana|Brasileir|Liga\s*MX|LigaPro|\bMLS\b|Nations\s*League|World\s*Cup|Mundial|Eliminatorias|Brighton|Brentford|Crystal\s*Palace|Liverpool|Ipswich|Bournemouth|Sunderland|Chelsea|Arsenal|Manchester|Tottenham|Newcastle|Aston\s*Villa|West\s*Ham|Everton|Fulham|Wolves|Nottingham|Leicester|Southampton|Plymouth|Berkhamsted|Stafford|Grimsby|Stockport|Napoli|Lazio|\bGenoa\b|\bMilan\b|\bMonza\b|Atalanta|Fiorentina|Juventus|\bInter\b|\bRoma\b|Bologna|Torino|Cologne|Colonia|Leverkusen|Bayern|Dortmund|Leipzig|Stuttgart|Frankfurt|\bPSG\b|Marseille|\bLyon\b|Monaco|\bLille\b|Benfica|\bPorto\b|Sporting|\bAjax\b|\bPSV\b|Feyenoord|\bBoca\b|\bRiver\b|Flamengo|Palmeiras|Corinthians|Monterrey|Quer[eé]taro|Chivas|Cruz\s*Azul|Tigres|Galatasaray|Fenerbah[cç]e|\bCeltic\b|(?<!New\s+York\s+)\bRangers\b|\bSoccer\b|F[uú]tbol') {
        return 'Fútbol Internacional'
    }
    if ($sourceHint -eq "Football") {
        return 'Fútbol Internacional'
    }
    if ($sourceHint -eq 'IPTV_FUTBOL_ES') {
        return 'Fútbol España'
    }
    # 11. Eventos no futbolísticos emitidos en español castellano / cadenas España
    if ($name -match '(?i)Movistar|M\+\s*Deportes|MDeportes|#?Vamos|MPlus|DAZN\s*[1-4]|Eurosport.*Espa[ñn]|Castellano|Teledeporte|\bEspa[ñn]ol\b') {
        return 'Deportes España'
    }
    # 12. Baloncesto (NBA, NCAA, Euroliga)
    if ($name -match '(?i)\b(?:NBA|Baloncesto|Basketball|League\s*Pass|Euroliga|Euroleague|Bulls|76ers|Celtics|Lakers|Warriors|Nets|Knicks|Heat|Mavericks|Nuggets|Suns|Bucks|Pelicans|Clippers|Timberwolves|Jazz|Hawks|Cavaliers|Hornets|Wizards|Pistons|Grizzlies|Raptors|Pacers|Rockets|Spurs|Thunder|Blazers|Kings|Magic|Huskies|Longhorns|Volunteers|Hurricanes|Crimson\s*Tide|UConn)\b') {
        return 'Baloncesto'
    }
    # 13. NFL (Fútbol Americano)
    if ($name -match '(?i)\bNFL\b|Bills|Vikings|Bengals|Falcons|Texans|Chargers|Cardinals|Seahawks|Patriots|Chiefs|Cowboys|Packers|Eagles|Steelers|49ers|Ravens|Lions|Dolphins|Jets|Giants|Commanders|Bears|Saints|Buccaneers|Panthers|Rams|Broncos|Raiders|Colts|Jaguars|Titans|Browns') {
        return 'NFL'
    }
    # 13b. Cine y Series España
    if ($name -match '(?i)M\+\s*(?:Estrenos|Acci[oó]n|Comedia|Drama|Originales|Cine\s*Espa|Cl[aá]sico|Hits|Musicales|Pop\s*Up|Series)|Estrenos\s*M\+|FlixOl[eé]|(?:Canal\s+)?Hollywood|\bTCM\b|Sundance|Somos|Warner\s*TV|\bAXN\b|Calle\s*13|SYFY|COSMO|\bAMC\b(?!\s*(?:Break|Crime|Living|Western))|XTRM|\bDark\b|Star\s*Channel|Comedy\s*Central|Run\s*Time|FREE\s*TV\s*SAS|Taquilla|OnePlay|1Play|Netflix|Apple\s*TV\+\s*Series|PrimeVideo|Paramount\s*(?:Channel|Network)|Bom\s*Cine|Cines\s*Verdi|Cine\s*Feel\s*Good|Cine\s*Cl[aá]sico|Acontra\+|BBC\s*(?:Drama|Series)|Canal\s*Las\s*Estrellas|Kanal\s*D\s*Drama|Coraz[oó]n|Rakuten\s*Tv\s*Top') {
        return 'Cine y Series España'
    }
    # 13c. Documentales y Cultura España
    if ($name -match '(?i)M\+\s*Documentales|Discovery\s*Channel|Odisea|National\s*Geo(?:graphic|grafic)|BBC\s*(?:Earth|History|TopGear|Food|LifeStyle)|\bHistoria\b|Caza\s*y\s*Pesca|Cazavisi[oó]n|Iberalia|Canal\s*Cocina|Decasa|AMC\s*(?:Break|Crime|Living|Western)|Crimen\s*(?:\+|Mas).*Investigaci|Cr[ií]menes\s*Reales|Escapa\s*TV|Love\s*The\s*Planet|Tastemade|M\+\s*Cero|Gran\s*Hermano|My\s*Zen') {
        return 'Documentales y Cultura España'
    }
    # 13d. Infantil y Música España
    if ($name -match '(?i)DreamWorks|Disney\s*Jr|Boing|Canal\s*Panda|Baby\s*TV|Nickelodeon|Nick\s*Jr|EnFamilia|Duck\s*TV|Rakuten\s*Tv\s*Family|\bMTV\b|Sol\s*M[uú]sica|Sol\s*Music|Mezzo|VH1|Classica|All\s*Flamenco|Molahits|Cadena\s*Elite|Vega\s*Fibra') {
        return 'Infantil y Música España'
    }
    if ($sourceHint -eq 'IPTV_DEPORTES_ES') {
        return 'Deportes España'
    }
    # 14. Canales TV y 24/7 Internacionales (incluye CNN, Fox News, Fox Cricket/Footy, Willow, ESPN, Sky, Disney+, WTA/ATP, Golf, etc.)
    if ($name -match '(?i)24\/?7|ESPN|DSPORTS|DirecTV|TUDN|Win\s*Sports|TNT\s*Sports|Telemundo|Universo|Liga\s*1|Sky\s*Sport|\bNBC\b|Fox\s*Sports|Fox\s*Soccer|FOX\s*Deportes|Fox\s*News|Fox\s*Cricket|Fox\s*Footy|Fox\s*League|Fox\s*One|Willow|\bCNN\b|\bTBS\b|truTV|\bABC\b|\bCBS\b|\bFOX\b|Paramount\+|Peacock|Prime\s*Video|Apple\s*TV|Disney\+|\bWTA\b|\bATP\b|\bTenis\b|\bTennis\b|\bGolf\b|PGA\s*Tour|DP\s*(?:World|Internacional)|Ryder\s*Cup|Golf\s*Channel|Tennis\s*Channel|Canal\+|Sport\s*TV|Red\s*Bull\s*TV|Ziggo|Viaplay|Optus|Stan\s*Sport|Setanta|Eleven\s*Sports|SuperSport|Match\s*TV|Arena\s*Sport|SportKlub|DAZN\b|Polsat|\bFS[12]\b|\bTSN\d*\b|\bTNT\b|USA\s*Net|ACC\s*Network|Big\s*Ten\s*Network|CBS\s*Sports|ThreeNow|Premier\s*Sports|BeIN|TyC\s*Sports|Eurosport|Racing\s*TV|At\s*The\s*Races|FIFA\+|Historia|BBC\s*Drama|Cine\s*Friki|Cine\s*Western|Todo\s*Novelas|Rakuten\s*TV|MyTime|Pet\s*Collective|Plus|\bAEW\b|\bWWE\b|\bUFC\b|\bTNA\b') {
        return 'Canales TV Internacionales'
    }
    return 'Otros'
}

# -------------------------------------------------------------
# FILTRO RAPIDO DE DEPORTES EXCLUIDOS Y MOTOR PARALELO (RUNSPACES)
# -------------------------------------------------------------
function Test-IsExcludedSport {
    param(
        [string]$Name,
        [string]$LeagueOrCategory = "",
        [string]$SportId = ""
    )
    if ($SportId -match '(?i)^(?:basketball|nba|nhl|cfb|ncaa|cbb|nfl|hockey|ice.?hockey|american.?football)$') { return $true }
    if ($LeagueOrCategory -match '(?i)(?:copa\s*colombia|liga\s*(?:de\s*)?colombia|liga\s*betplay|categor[ií]a\s*primera\s*a|f[uú]tbol\s*colombiano|dimayor|primera\s*b|torneo\s*proyecci[oó]n|\bNBA\b|\bNCAA\b|\bCBB\b|\bWNBA\b|\bNFL\b|\bNHL\b|basketball|baloncesto|american\s*football|ice\s*hockey|\bhockey\b)') { return $true }
    $grp = Get-ChannelGroup $Name ""
    if ($grp -in @('Baloncesto', 'NFL')) { return $true }
    if ($Name -match '(?i)(?:NBA\s*League\s*Pass|NFL\s*RedZone|NFL\s*Network|\bRed\s*Zone\b|\bNHL\b|\bIowa\s*@\s*UConn\b|Maple\s*Leafs|Canadiens|Red\s*Wings|Bruins|Blackhawks|Oilers|Penguins|Flyers|Canucks|Islanders|Avalanche|Panthers\s*vs|Blue\s*Jackets|Senators|Capitals|Devils|Golden\s*Knights|Kraken|Predators|Ducks|Mammoth|Envigado|Deportivo\s*Pasto|Boyac[aá]\s*Chic[oó]|Llaneros|Jag[uü]ares\s*de\s*C[oó]rdoba|Patriotas\s*vs|Rionegro|[AÁ]guilas\s*Doradas|Fortaleza\s*CEIF|La\s*Equidad|Once\s*Caldas|Atl[eé]tico\s*Bucaramanga|Deportivo\s*Pereira|Independiente\s*Medell[ií]n|Independiente\s*Santa\s*Fe|Millonarios|Deportes\s*Tolima|Atl[eé]tico\s*Nacional|Am[eé]rica\s*de\s*Cali|Deportivo\s*Cali|\bJunior\s*vs|vs\s*Junior\b)') {
        return $true
    }
    return $false
}

# -------------------------------------------------------------
# MOTOR DE PURGA INTELIGENTE ENTRENADO CON AGENDAS WEB Y FILTRO IA
# -------------------------------------------------------------
function Normalize-EventText([string]$Text) {
    if ([string]::IsNullOrWhiteSpace($Text)) { return "" }
    $formD = $Text.Normalize([System.Text.NormalizationForm]::FormD)
    $sb = [System.Text.StringBuilder]::new($formD.Length)
    foreach ($ch in $formD.ToCharArray()) {
        if ([System.Globalization.CharUnicodeInfo]::GetUnicodeCategory($ch) -ne [System.Globalization.UnicodeCategory]::NonSpacingMark) {
            [void]$sb.Append($ch)
        }
    }
    $clean = $sb.ToString().ToLowerInvariant()
    $clean = $clean -replace 'feberbache', 'fenerbahce' -replace '\bol\s+lyonnes\b', 'ol lyonnes' -replace '\bm[uü]nchen\b', 'munich' -replace '\bman\s+utd\b', 'manchester united' -replace '\bman\s+city\b', 'manchester city'
    $clean = ($clean -replace '[&/\-\|:\.\(\)\[\],]+', ' ' -replace '[^a-z0-9\s]', ' ' -replace '\s{2,}', ' ').Trim()
    return $clean
}

function Get-EventBaseTitle([string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Name)) { return "" }
    $t = $Name.Trim()
    $t = $t -replace '\s*\[[^\]]+\]', ''
    $t = $t -replace '\s*\([^)]*(?:Castellano|Latino|Opci[oó]n|HD\s*\||SD\s*\||NOWTV|TBS|CW\s+on|Sky\s+Sports|ESPN[^)]*|M\+[^)]*|Movistar[^)]*|DAZN[^)]*|Disney\+[^)]*|TUDN[^)]*|Win\s*Sports[^)]*|Gol\s*Play[^)]*|Vamos[^)]*)[^)]*\)', ''
    $t = $t -replace '\s*-\s*(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+\d{1,2}(?:,?\s*\d{4})?$', ''
    $t = $t -replace '\s{2,}', ' '
    return $t.Trim()
}

function Get-CoreTeamTokens([string]$TeamRaw) {
    $norm = Normalize-EventText $TeamRaw
    if (-not $norm) { return @() }
    $stop = @('fc','cf','sc','ac','cd','ud','rc','ca','sd','if','sk','fk','bk','sv','vfl','vfb','tsg','fsv','rb','real','club','city','united','utd','town','athletic','atletico','sporting','deportivo','women','wom','femenino','femenil','ladies','san','santa','saint','st','de','la','el','los','las','del','al','fc','sc','ii')
    $all = @($norm -split '\s+' | Where-Object { $_ -and $_.Length -ge 2 })
    $core = @($all | Where-Object { $_ -notin $stop -and $_.Length -ge 3 })
    if ($core.Count -gt 0) { return $core }
    return @($all | Where-Object { $_.Length -ge 3 })
}

function Get-EventTeamPair([string]$Title) {
    $base = Get-EventBaseTitle $Title
    if ($base -match ':\s*(.+)$') {
        $afterColon = $Matches[1].Trim()
        if ($afterColon -match '(?i)\b(?:vs\.?|versus)\b|\s+at\s+|\s+-\s+') {
            $base = $afterColon
        }
    }
    if ($base -match '^(?i)(.+?)\s+(?:vs\.?|versus|v)\s+(.+)$') {
        return @($Matches[1].Trim(), $Matches[2].Trim())
    }
    if ($base -cmatch '^(.+?)\s+at\s+([A-Z].+)$') {
        return @($Matches[1].Trim(), $Matches[2].Trim())
    }
    if ($base -notmatch '(?i)Nov\s+\d|Round|Stage|Day\s*#' -and $base -match '^(.+?)\s+-\s+(.+)$') {
        return @($Matches[1].Trim(), $Matches[2].Trim())
    }
    return @()
}

function Test-SideTokenOverlap([string[]]$TokensA, [string[]]$TokensB) {
    if (-not $TokensA -or -not $TokensB -or $TokensA.Count -eq 0 -or $TokensB.Count -eq 0) { return $false }
    foreach ($a in $TokensA) {
        foreach ($b in $TokensB) {
            if ($a -eq $b) { return $true }
            if ($a.Length -ge 5 -and $b.Length -ge 5 -and ($a.StartsWith($b) -or $b.StartsWith($a))) { return $true }
        }
    }
    return $false
}

function Test-IsLinearChannel([string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Name)) { return $false }
    if ($Name -match '(?i)\b24/7\b') { return $true }
    # Si contiene marcas inequívocas de partido o fecha de evento puntual, NO es canal lineal 24/7
    if ($Name -match '(?i)\b(?:vs\.?|versus)\b|\[(?:\d{1,2}/)?\d{1,2}:\d{2}\]|\((?:[^)]*(?:Castellano|Latino|Opci[oó]n))' -or
        $Name -cmatch '\s+at\s+[A-Z]' -or
        $Name -match '(?i)\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+\d{1,2}(?:,?\s*20\d{2})\b' -or
        $Name -match '(?i)^(?:Torneo|Copa\s+de|Liga\s+MX|Liga\s+de|Premier\s+P[aá]del|UEFA|Champions\s+League|ATP\s*-|WTA\s*-|AEW|WWE|UFC)\b') {
        # Excepción: canales lineales puros con "Opción X" como "DAZN F1 (Opción 2)" sin "vs" ni fecha
        if ($Name -match '(?i)\(Opci[oó]n\s*\d+\)$' -and $Name -notmatch '(?i)\bvs\.?\b|\[') {
            return $true
        }
        return $false
    }
    if ($Name -match '(?i)(?:RTVE|\bLa 1\b|\bLa 2\b|Teledeporte|24 Horas|24h|Clan|\bTVE\b|\bTDT\b|M\+\s*LaLiga|DAZN\s*LaLiga|Hypermotion|TV Bar|Liga\s*(?:de\s*)?Campeones|DAZN\s*[1-4]|DAZN\s*F1|DAZN\s*MotoGP|DAZN\s*Eventos|DAZN\s*Liga\s*F|Movistar.*Deportes|M\+\s*Deportes?|M\+\s*Multideporte|\bVamos\b|M\+\s*Golf|M\+\s*Ellas|Eurosport|Gol\s*Play|Capo Deportes|Real Madrid TV|Bar[cç]a TV|\bESPN\b|\bESPN\d|\bESPNU\b|DSPORTS|DirecTV|TUDN|TNT Sports|TNT\b|Win Sports|Liga 1 Max|Telemundo|Universo|Sky Sports|\bNBC\b|ThreeNow|Premier Sports|Formula 1 HD|F1 TV|\bF1TV\b|^(?:TRACKER|DATA)$|Fox Sports|Fox Soccer|FOX Deportes|ACC Network|Big Ten Network|CBS Sports|USA Net|TSN\d*|Señal|Nexa|Pilotos|Onboard|Telemetr|Antena 3|Cuatro|Telecinco|La\s*Sexta|DMAX|TRECE|Telemadrid|Canal Sur|TV3|ETB|TVG|À Punt|M\+\s*(?:Estrenos|Acci[oó]n|Comedia|Drama|Originales|Cine|Cl[aá]sico|Hits|Musicales|Pop\s*Up|Series|Documentales|Cero)|Estrenos\s*M\+|FlixOl[eé]|Hollywood|\bTCM\b|Sundance|Warner\s*TV|\bAXN\b|Calle\s*13|SYFY|COSMO|\bAMC\b|XTRM|\bDark\b|Star\s*Channel|Comedy\s*Central|Run\s*Time|FREE\s*TV|Taquilla|OnePlay|Netflix|PrimeVideo|Apple\s*TV\+|Discovery|Odisea|National\s*Geo|Historia|Classica|Iberalia|Canal\s*Cocina|Decasa|DreamWorks|Disney\s*Jr|Boing|Nickelodeon|Nick\s*Jr|EnFamilia|Canal\s*Panda|Baby\s*TV|Duck\s*TV|\bMTV\b|Mezzo|VH1|LaLiga\+|FanPlay|\bRFEF\b|FootballClub|Primera\s*Federaci[oó]n|Segunda\s*Federaci[oó]n|2ª\s*RFEF|DKISS|Paramount\s*(?:Channel|Network)|Somos|Squirrel|\bFDF\b|Atreseries|Divinity|^TEN\b|La\s*S[eé]ptima|3\/?24|BBC\s*(?:Drama|Series)|Cines\s*Verdi|Bom\s*Cine|Cine\s*Feel\s*Good|Cine\s*Cl[aá]sico|Acontra\+|One\s*Toro|Torol[eé]|Super\s*3|Bon\s*Dia|Onda\s*C[aá]diz|Teleonuba|Canal\s*Parlamento|7TV|Hit\s*TV)') {
        return $true
    }
    return $false
}

function Test-IsSafeHttpUrl([string]$Url) {
    if ([string]::IsNullOrWhiteSpace($Url)) { return $false }
    if ($Url -match '[\x00-\x1F\x7F"''<>]') { return $false }
    return ($Url -match '^https?://[^\s"''<>]+$')
}

function Test-IptvStreamLive {
    param(
        [string]$Url,
        [string]$UserAgentStr = "TiviMate/4.7.0",
        [int]$Hop1TimeoutMs = 2200,
        [int]$Hop2TimeoutMs = 2500
    )
    if (-not (Test-IsSafeHttpUrl $Url)) { return $false }
    $hop1Url = $Url
    $hop2Url = $null
    $resp1 = $null
    try {
        $req1 = [System.Net.HttpWebRequest]::Create($hop1Url)
        $req1.UserAgent = $UserAgentStr
        $req1.Timeout = $Hop1TimeoutMs
        $req1.ReadWriteTimeout = $Hop1TimeoutMs
        $req1.AllowAutoRedirect = $false
        $resp1 = [System.Net.HttpWebResponse]$req1.GetResponse()
        $code1 = [int]$resp1.StatusCode
        if ($code1 -ge 300 -and $code1 -lt 400) {
            $loc = $resp1.Headers['Location']
            if (-not [string]::IsNullOrWhiteSpace($loc)) {
                $baseUri = [System.Uri]$hop1Url
                $resolvedUri = [System.Uri]::new($baseUri, $loc.Trim())
                if (Test-IsSafeHttpUrl $resolvedUri.AbsoluteUri) { $hop2Url = $resolvedUri.AbsoluteUri }
            }
        } elseif ($code1 -eq 200) {
            $sr1 = [System.IO.StreamReader]::new($resp1.GetResponseStream(), [System.Text.Encoding]::UTF8)
            try {
                $buf1 = New-Object char[] 512
                $n1 = $sr1.Read($buf1, 0, $buf1.Length)
                $head1 = if ($n1 -gt 0) { [string]::new($buf1, 0, $n1) } else { "" }
                return ($head1 -match '#EXTM3U|#EXTINF')
            } finally {
                $sr1.Dispose()
            }
        }
    } catch [System.Net.WebException] {
        $er1 = $_.Exception.Response
        if ($er1) {
            try {
                $sc1 = [int]([System.Net.HttpWebResponse]$er1).StatusCode
                if ($sc1 -ge 300 -and $sc1 -lt 400) {
                    $loc = $er1.Headers['Location']
                    if (-not [string]::IsNullOrWhiteSpace($loc)) {
                        $baseUri = [System.Uri]$hop1Url
                        $resolvedUri = [System.Uri]::new($baseUri, $loc.Trim())
                        if (Test-IsSafeHttpUrl $resolvedUri.AbsoluteUri) { $hop2Url = $resolvedUri.AbsoluteUri }
                    }
                }
            } finally {
                try { $er1.Dispose() } catch {}
            }
        }
    } catch {
        return $false
    } finally {
        if ($resp1) { try { $resp1.Dispose() } catch {} }
    }

    if (-not $hop2Url) { return $false }
    $resp2 = $null
    try {
        $req2 = [System.Net.HttpWebRequest]::Create($hop2Url)
        $req2.UserAgent = $UserAgentStr
        $req2.Timeout = $Hop2TimeoutMs
        $req2.ReadWriteTimeout = $Hop2TimeoutMs
        $req2.AllowAutoRedirect = $true
        $resp2 = [System.Net.HttpWebResponse]$req2.GetResponse()
        if ([int]$resp2.StatusCode -eq 200) {
            $sr2 = [System.IO.StreamReader]::new($resp2.GetResponseStream(), [System.Text.Encoding]::UTF8)
            try {
                $buf2 = New-Object char[] 512
                $n2 = $sr2.Read($buf2, 0, $buf2.Length)
                $head2 = if ($n2 -gt 0) { [string]::new($buf2, 0, $n2) } else { "" }
                return ($head2 -match '#EXTM3U|#EXTINF')
            } finally {
                $sr2.Dispose()
            }
        }
    } catch {
        return $false
    } finally {
        if ($resp2) { try { $resp2.Dispose() } catch {} }
    }
    return $false
}

function Test-EventTitlePastDate([string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Name)) { return $false }
    if (Test-IsLinearChannel $Name) { return $false }
    $nowUtc = [DateTime]::UtcNow
    $monthMap = @{
        'jan'=1;'ene'=1;'feb'=2;'mar'=3;'apr'=4;'abr'=4;'may'=5;'jun'=6;
        'jul'=7;'aug'=8;'ago'=8;'sep'=9;'oct'=10;'nov'=11;'dec'=12;'dic'=12
    }
    # 1. Etiqueta de hora explícita [dd/MM HH:mm]
    if ($Name -match '\[(\d{1,2})/(\d{1,2})\s+(\d{1,2}):(\d{2})\]') {
        try {
            $dd = [int]$Matches[1]; $mm = [int]$Matches[2]; $hh = [int]$Matches[3]; $mi = [int]$Matches[4]
            $yr = (Get-Date).Year
            $dtLocal = [DateTime]::new($yr, $mm, $dd, $hh, $mi, 0, [DateTimeKind]::Local)
            if (($dtLocal - (Get-Date)).TotalDays -gt 180) { $dtLocal = $dtLocal.AddYears(-1) }
            elseif (((Get-Date) - $dtLocal).TotalDays -gt 180) { $dtLocal = $dtLocal.AddYears(1) }
            if ([DateTime]::Now -gt $dtLocal.AddHours(3.5)) { return $true }
        } catch {}
    }
    # 2. Fecha calendario inglesa explícita (ej. "Nov 10, 2026" o "November 10")
    if ($Name -match '(?i)\b(Jan|Feb|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|January|February|March|April|June|July|August|September|October|November|December)\.?\s+(\d{1,2})(?:,?\s*(20\d{2}))?\b') {
        try {
            $mon = $monthMap[$Matches[1].Substring(0,3).ToLower()]
            $day = [int]$Matches[2]
            $yr = if ($Matches[3]) { [int]$Matches[3] } else { $nowUtc.Year }
            $dUtc = [DateTime]::new($yr, $mon, $day, 0, 0, 0, [DateTimeKind]::Utc)
            if ($nowUtc -gt $dUtc.AddDays(1).AddHours(10)) { return $true }
        } catch {}
    }
    # 3. Fecha calendario española/mixta estricta (ej. "10 de noviembre", "10 noviembre 2026" - nunca "1 Mar Menor")
    if ($Name -match '(?i)\b(\d{1,2})\s+(?:de\s+(enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|octubre|noviembre|diciembre|ene|feb|mar|abr|may|jun|jul|ago|sep|oct|nov|dic)|(enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|octubre|noviembre|diciembre|january|february|march|april|june|july|august|september|october|november|december))\b(?:\s+(?:de\s+)?(20\d{2}))?') {
        try {
            $day = [int]$Matches[1]
            $monRaw = if ($Matches[2]) { $Matches[2] } else { $Matches[3] }
            $mon = $monthMap[$monRaw.Substring(0,3).ToLower()]
            $yr = if ($Matches[4]) { [int]$Matches[4] } else { $nowUtc.Year }
            $dUtc = [DateTime]::new($yr, $mon, $day, 0, 0, 0, [DateTimeKind]::Utc)
            if ($nowUtc -gt $dUtc.AddDays(1).AddHours(10)) { return $true }
        } catch {}
    }
    if ($Name -match '\b(20\d{2})-(\d{2})-(\d{2})\b') {
        try {
            $dUtc = [DateTime]::new([int]$Matches[1], [int]$Matches[2], [int]$Matches[3], 0, 0, 0, [DateTimeKind]::Utc)
            if ($nowUtc -gt $dUtc.AddDays(1).AddHours(10)) { return $true }
        } catch {}
    }
    return $false
}

function Get-EstimatedEventDurationMinutes([string]$Title, [string]$SportHint = "") {
    $ctx = "$SportHint $Title"
    if ($ctx -match '(?i)\b(?:ufc|mma|boxing|boxeo|wwe|aew|tna|wrestl|fight|combate|dynamite|smackdown|collision|raw|nxt)\b') { return 210 }
    if ($ctx -match '(?i)\b(?:tennis|tenis|padel|p[aá]del|atp|wta|roland|wimbledon|open)\b') { return 165 }
    if ($ctx -match '(?i)\b(?:f1|formula\s*1|motogp|moto\s*gp|rally|nascar|indycar|wec|grand\s*prix)\b') { return 150 }
    if ($ctx -match '(?i)\b(?:football|soccer|f[uú]tbol|liga|cup|copa|champions|europa|trophy|libertadores|sudamericana|reserva)\b' -or $Title -match '(?i)\bvs\.?\b') { return 135 }
    return 150
}

function Find-WebOracleMatchStatus([string]$EventTitle, [Nullable[DateTime]]$ApproxStartUtc = $null) {
    if (-not $script:WebOracleEvents -or $script:WebOracleEvents.Count -eq 0) { return $null }
    $pair = Get-EventTeamPair $EventTitle
    $nowUtc = [DateTime]::UtcNow

    if ($pair.Count -eq 2) {
        $tA = Get-CoreTeamTokens $pair[0]
        $tB = Get-CoreTeamTokens $pair[1]
        if ($tA.Count -gt 0 -and $tB.Count -gt 0) {
            foreach ($ov in $script:WebOracleEvents) {
                if ($ApproxStartUtc -and $ov.StartUtc) {
                    if ([Math]::Abs(($ov.StartUtc - $ApproxStartUtc).TotalHours) -gt 40) { continue }
                }
                if (-not $ov.TokensA -or -not $ov.TokensB) { continue }
                $direct = (Test-SideTokenOverlap $tA $ov.TokensA) -and (Test-SideTokenOverlap $tB $ov.TokensB)
                $flipped = (Test-SideTokenOverlap $tA $ov.TokensB) -and (Test-SideTokenOverlap $tB $ov.TokensA)
                if ($direct -or $flipped) {
                    $verdict = if ($ov.Completed -or $ov.State -eq 'post' -or $ov.Detail -match '(?i)Postponed|Canceled|Cancelled|Abandoned|Suspended|FT|Final') { 'POST' }
                               elseif ($ov.State -eq 'in') { 'IN' }
                               else { 'PRE' }
                    return [PSCustomObject]@{ Verdict = $verdict; Source = $ov.Source; Detail = $ov.Detail; StartUtc = $ov.StartUtc; MatchName = $ov.Title }
                }
            }
        }
    }

    # Coincidencia por nombre único en torneos de motor / UFC / tenis acabado
    $normTitle = Normalize-EventText (Get-EventBaseTitle $EventTitle)
    foreach ($ov in $script:WebOracleEvents) {
        if ($ov.Kind -eq 'event' -and $ov.NormTitle) {
            if ($ov.EndUtc -and $nowUtc -gt $ov.EndUtc -and ($normTitle -like "*$($ov.NormTitle)*" -or $ov.NormTitle -like "*$normTitle*")) {
                return [PSCustomObject]@{ Verdict = 'POST'; Source = $ov.Source; Detail = $ov.Detail; StartUtc = $ov.StartUtc; MatchName = $ov.Title }
            }
        }
    }
    return $null
}

function Get-AgendaEventWindowEvaluation {
    param(
        [string]$Title,
        [Nullable[DateTime]]$StartUtc = $null,
        [Nullable[DateTime]]$ReportedEndUtc = $null,
        [int]$ReportedDurationMinutes = 0,
        [string]$SportHint = "",
        [string]$RawStatus = ""
    )
    $nowUtc = [DateTime]::UtcNow
    if ($RawStatus -and ($RawStatus -match '(?i)^(?:finished|final.*|post|postponed|complete.*|closed|cancel.*|suspend.*|abandoned|awarded|ft|aet|pen|finalizado|terminado|suspendido|aplazado|cancelado)$')) {
        return [PSCustomObject]@{ IsConcluded = $true; Reason = "Estado oficial finalizado ($RawStatus)"; KickTag = ""; Upcoming = $false; StartsAtUtcStr = ""; EndsAtUtcStr = "" }
    }
    if (Test-EventTitlePastDate $Title) {
        return [PSCustomObject]@{ IsConcluded = $true; Reason = "Fecha de evento vencida"; KickTag = ""; Upcoming = $false; StartsAtUtcStr = ""; EndsAtUtcStr = "" }
    }
    $durMin = Get-EstimatedEventDurationMinutes -Title $Title -SportHint $SportHint
    if ($ReportedDurationMinutes -gt 0) {
        $durMin = [Math]::Min($ReportedDurationMinutes, $durMin)
    }
    $estEndUtc = if ($ReportedEndUtc -and $StartUtc) {
        $cap = $StartUtc.AddMinutes($durMin)
        if ($ReportedEndUtc -lt $cap) { $ReportedEndUtc } else { $cap }
    } elseif ($ReportedEndUtc) {
        $ReportedEndUtc
    } elseif ($StartUtc) {
        $StartUtc.AddMinutes($durMin)
    } else { $null }

    $oracle = Find-WebOracleMatchStatus -EventTitle $Title -ApproxStartUtc $StartUtc
    if ($oracle -and $oracle.Verdict -eq 'POST') {
        return [PSCustomObject]@{ IsConcluded = $true; Reason = "Oráculo Web ($($oracle.Source)): $($oracle.Detail)"; KickTag = ""; Upcoming = $false; StartsAtUtcStr = ""; EndsAtUtcStr = "" }
    }
    $oracleLive = ($oracle -and $oracle.Verdict -eq 'IN')
    if ($oracleLive -and $estEndUtc -and $estEndUtc -lt $nowUtc.AddMinutes(30)) {
        $estEndUtc = $nowUtc.AddMinutes(30)
    }
    if (-not $oracleLive -and $estEndUtc -and $nowUtc -gt $estEndUtc) {
        return [PSCustomObject]@{ IsConcluded = $true; Reason = "Horario concluido ($($estEndUtc.ToLocalTime().ToString('HH:mm')))"; KickTag = ""; Upcoming = $false; StartsAtUtcStr = ""; EndsAtUtcStr = "" }
    }

    $upcoming = ($null -ne $StartUtc -and $StartUtc -gt $nowUtc)
    $kickTag = ""
    if ($upcoming) {
        $localKick = $StartUtc.ToLocalTime()
        $kickTag = if ($localKick.Date -eq (Get-Date).Date) { " [$($localKick.ToString('HH:mm'))]" } else { " [$($localKick.ToString('dd/MM HH:mm'))]" }
    }
    $stIso = if ($StartUtc) { $StartUtc.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ") } else { "" }
    $enIso = if ($estEndUtc) { $estEndUtc.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ") } else { "" }
    return [PSCustomObject]@{ IsConcluded = $false; Reason = ""; KickTag = $kickTag; Upcoming = $upcoming; StartsAtUtcStr = $stIso; EndsAtUtcStr = $enIso }
}

$script:QuietScanActive = (-not $ShowDetails)
$script:QuietWriteHostHooked = $false
$script:ScanStageStart = 0
$script:ScanStageEnd = 100
$script:LastShownPct = -1
$script:LastMilestonePct = -1
$script:ScanBarLabel = if ($isTwoPhaseAuto) { "Buscando canales sin VPN (Fase 1/2)" } else { "Buscando canales en todos los servidores" }
$script:IsPhase2Only = $false

function Reset-ScanProgressState([string]$Label) {
    if (-not [string]::IsNullOrWhiteSpace($Label)) { $script:ScanBarLabel = $Label }
    $script:ScanStageStart = 0
    $script:ScanStageEnd = 100
    $script:LastShownPct = -1
    $script:LastMilestonePct = -1
}

function Show-ScanProgressBar([int]$Percent) {
    <# Dibuja una unica barra de progreso limpia mientras el escaneo corre en background. #>
    if (-not $script:QuietScanActive) { return }
    $clamped = [Math]::Max(0, [Math]::Min(100, $Percent))
    if ($clamped -lt $script:LastShownPct) { $clamped = $script:LastShownPct }
    if ($clamped -eq $script:LastShownPct) { return }
    $script:LastShownPct = $clamped
    $barWidth = 28
    $filled = [int][Math]::Round(($clamped / 100.0) * $barWidth)
    $empty = $barWidth - $filled
    $bar = ([string]::new([char]0x2588, $filled)) + ([string]::new([char]0x2591, $empty))
    $line = "  [+] {0}... [{1}] {2,3}%" -f $script:ScanBarLabel, $bar, $clamped
    if ([Console]::IsOutputRedirected) {
        $milestone = if ($clamped -eq 0) { 0 } elseif ($clamped -ge 100) { 100 } else { [int]([Math]::Floor($clamped / 25) * 25) }
        if ($milestone -gt $script:LastMilestonePct) {
            $script:LastMilestonePct = $milestone
            [Console]::WriteLine($line)
        }
        return
    }
    $prevColor = $null
    try {
        $prevColor = [Console]::ForegroundColor
        [Console]::ForegroundColor = if ($clamped -ge 100) { [ConsoleColor]::Green } else { [ConsoleColor]::Cyan }
    } catch {}
    try {
        [Console]::Write("`r$line   ")
        if ($clamped -ge 100) { [Console]::WriteLine("") }
    } finally {
        if ($null -ne $prevColor) { try { [Console]::ForegroundColor = $prevColor } catch {} }
    }
}

function Set-ScanStage([int]$StartPct, [int]$EndPct) {
    $script:ScanStageStart = [Math]::Max(0, [Math]::Min(100, $StartPct))
    $script:ScanStageEnd = [Math]::Max($script:ScanStageStart, [Math]::Min(100, $EndPct))
    Show-ScanProgressBar $script:ScanStageStart
}

function Enter-ScanPhase([string]$PhaseName, [bool]$IsVpnMode) {
    $mapVpnFull = @{
        'Oracle'   = @(0, 8);   'Prefetch' = @(8, 16);  'Embdlol'   = @(16, 24); 'F1Net'    = @(24, 31)
        'Ppv'      = @(31, 39); 'RtveTdt'  = @(39, 55); 'Iptv'      = @(55, 68); 'CdPlay'   = @(68, 72)
        'EsStageA' = @(72, 75); 'EsStageB' = @(75, 77); 'EsStageC'  = @(77, 79); 'FutbolLb' = @(79, 83)
        'StreamXhd'= @(83, 86); 'CastVip'  = @(86, 89); 'EmbedMe'   = @(89, 92); 'DepLibre' = @(92, 94)
        'CandySS'  = @(94, 96); 'WebPurge' = @(96, 99); 'Save'      = @(99, 100)
    }
    $mapPhase2 = @{
        'Prefetch2'= @(0, 10);  'CdPlay'   = @(10, 22); 'EsStageA' = @(22, 34); 'EsStageB' = @(34, 42)
        'EsStageC' = @(42, 48); 'FutbolLb' = @(48, 58); 'StreamXhd'= @(58, 68); 'CastVip'  = @(68, 78)
        'EmbedMe'  = @(78, 86); 'DepLibre' = @(86, 92); 'CandySS'  = @(92, 96); 'WebPurge' = @(96, 99)
        'Save'     = @(99, 100)
    }
    $mapOpen = @{
        'Oracle'   = @(0, 12);  'Prefetch' = @(12, 24); 'Embdlol'   = @(24, 36); 'F1Net'    = @(36, 46)
        'Ppv'      = @(46, 58); 'RtveTdt'  = @(58, 84); 'Iptv'      = @(84, 95); 'WebPurge' = @(95, 99)
        'Save'     = @(99, 100)
    }
    $tbl = if ($script:IsPhase2Only) { $mapPhase2 } elseif ($IsVpnMode) { $mapVpnFull } else { $mapOpen }
    if ($tbl.ContainsKey($PhaseName)) {
        $pair = $tbl[$PhaseName]
        Set-ScanStage $pair[0] $pair[1]
    }
}

function Enable-QuietScanMode {
    if (-not $script:QuietScanActive -or $script:QuietWriteHostHooked) { return }
    try {
        Set-Item -Path 'Function:\script:Write-Host' -Value {
            param(
                [Parameter(Position = 0, ValueFromPipeline = $true, ValueFromRemainingArguments = $true)][object]$Object,
                [switch]$NoNewline,
                [object]$ForegroundColor,
                [object]$BackgroundColor,
                [object]$Separator
            )
            process {}
        } -ErrorAction Stop
        $script:QuietWriteHostHooked = $true
    } catch {}
}

function Disable-QuietScanMode {
    if ($script:QuietWriteHostHooked) {
        Remove-Item -Path 'Function:\Write-Host' -ErrorAction SilentlyContinue
        $script:QuietWriteHostHooked = $false
    }
}

$script:HelperFunctionNames = @(
    'Get-HostKey', 'Get-Utf8Content', 'Test-HlsLive', 'Test-HlsDeepLive',
    'Resolve-CapoCandyShop', 'Resolve-Tvf90Url', 'Resolve-StreamxNodeUrl',
    'Resolve-StreamXhdUrl', 'Resolve-EmbdlolWatchUrl', 'Resolve-EmbedAnyUrl',
    'Translate-ToSpanish', 'Get-ChannelGroup', 'Test-IsEventFinalized', 'Test-IsExcludedSport',
    'Normalize-EventText', 'Get-EventBaseTitle', 'Get-CoreTeamTokens', 'Get-EventTeamPair',
    'Test-SideTokenOverlap', 'Test-IsLinearChannel', 'Test-IsSafeHttpUrl', 'Test-IptvStreamLive',
    'Test-EventTitlePastDate', 'Get-EstimatedEventDurationMinutes', 'Find-WebOracleMatchStatus',
    'Get-AgendaEventWindowEvaluation', 'Invoke-WebSearchAiClassifier'
)

function Initialize-ParallelPool([int]$MaxThreads = 48) {
    if ($script:ParallelPool) { return }
    $iss = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
    foreach ($fnName in $script:HelperFunctionNames) {
        $cmd = Get-Command $fnName -CommandType Function -ErrorAction SilentlyContinue
        if ($cmd) {
            $iss.Commands.Add([System.Management.Automation.Runspaces.SessionStateFunctionEntry]::new($fnName, $cmd.Definition))
        }
    }
    $iss.Variables.Add([System.Management.Automation.Runspaces.SessionStateVariableEntry]::new('UserAgent', $UserAgent, $null))
    $iss.Variables.Add([System.Management.Automation.Runspaces.SessionStateVariableEntry]::new('ProgressPreference', 'SilentlyContinue', $null))
    $iss.Variables.Add([System.Management.Automation.Runspaces.SessionStateVariableEntry]::new('BlockedHosts', $global:BlockedHosts, $null))
    $iss.Variables.Add([System.Management.Automation.Runspaces.SessionStateVariableEntry]::new('ActiveStreamxHost', $global:ActiveStreamxHost, $null))
    $iss.Variables.Add([System.Management.Automation.Runspaces.SessionStateVariableEntry]::new('WebOracleEvents', $script:WebOracleEvents, $null))
    $iss.Variables.Add([System.Management.Automation.Runspaces.SessionStateVariableEntry]::new('AiApiKey', $script:AiApiKey, $null))
    $iss.Variables.Add([System.Management.Automation.Runspaces.SessionStateVariableEntry]::new('AiModel', $script:AiModel, $null))
    if ($script:QuietScanActive) {
        $iss.Commands.Add([System.Management.Automation.Runspaces.SessionStateFunctionEntry]::new(
            'Write-Host',
            'param([Parameter(Position=0,ValueFromPipeline=$true,ValueFromRemainingArguments=$true)]$Object,[switch]$NoNewline,$ForegroundColor,$BackgroundColor,$Separator) process {}'
        ))
    }
    $script:ParallelPool = [runspacefactory]::CreateRunspacePool(1, $MaxThreads, $iss, $Host)
    $script:ParallelPool.ApartmentState = [System.Threading.ApartmentState]::MTA
    $script:ParallelPool.Open()
}

function Invoke-ParallelItems {
    param(
        [array]$Items,
        [scriptblock]$ScriptBlock
    )
    if (-not $Items -or $Items.Count -eq 0) { return @() }
    Initialize-ParallelPool 48
    $scriptStr = $ScriptBlock.ToString()
    $jobs = [System.Collections.Generic.List[PSCustomObject]]::new()
    foreach ($it in $Items) {
        $ps = [powershell]::Create()
        $ps.RunspacePool = $script:ParallelPool
        [void]$ps.AddScript($scriptStr)
        [void]$ps.AddArgument($it)
        $handle = $ps.BeginInvoke()
        $jobs.Add([PSCustomObject]@{ Ps = $ps; Handle = $handle })
    }
    if ($script:QuietScanActive -and $jobs.Count -gt 0) {
        $totalJobs = $jobs.Count
        $stageSpan = [Math]::Max(0, $script:ScanStageEnd - $script:ScanStageStart)
        while ($true) {
            $completed = 0
            foreach ($j in $jobs) {
                if ($j.Handle.IsCompleted) { $completed++ }
            }
            if ($stageSpan -gt 0) {
                $pct = $script:ScanStageStart + [int][Math]::Floor(($completed / [double]$totalJobs) * $stageSpan)
                Show-ScanProgressBar $pct
            }
            if ($completed -ge $totalJobs) { break }
            Start-Sleep -Milliseconds 90
        }
    } elseif ($script:QuietScanActive) {
        Show-ScanProgressBar $script:ScanStageEnd
    }
    $results = [System.Collections.Generic.List[object]]::new()
    foreach ($job in $jobs) {
        try {
            $out = $job.Ps.EndInvoke($job.Handle)
            foreach ($o in $out) {
                if ($null -ne $o) { $results.Add($o) }
            }
        } catch {} finally {
            $job.Ps.Dispose()
        }
    }
    return @($results)
}

function Initialize-WebAgendaOracle {
    Write-Host " [+] Sincronizando Oráculo Web de Agendas Deportivas (ESPN + Marcadores Reales)..." -ForegroundColor Cyan
    $nowUtc = [DateTime]::UtcNow
    $dYest = $nowUtc.AddDays(-1).ToString('yyyyMMdd')
    $dToday = $nowUtc.ToString('yyyyMMdd')
    $dTom = $nowUtc.AddDays(1).ToString('yyyyMMdd')
    $tsToday = $nowUtc.ToString('yyyy-MM-dd')
    $tsYest = $nowUtc.AddDays(-1).ToString('yyyy-MM-dd')

    $endpoints = @(
        [PSCustomObject]@{ Kind = 'espn_soccer'; Url = "https://site.api.espn.com/apis/site/v2/sports/soccer/all/scoreboard?dates=$dYest" },
        [PSCustomObject]@{ Kind = 'espn_soccer'; Url = "https://site.api.espn.com/apis/site/v2/sports/soccer/all/scoreboard?dates=$dToday" },
        [PSCustomObject]@{ Kind = 'espn_soccer'; Url = "https://site.api.espn.com/apis/site/v2/sports/soccer/all/scoreboard?dates=$dTom" },
        [PSCustomObject]@{ Kind = 'espn_tennis'; Url = "https://site.api.espn.com/apis/site/v2/sports/tennis/atp/scoreboard" },
        [PSCustomObject]@{ Kind = 'espn_tennis'; Url = "https://site.api.espn.com/apis/site/v2/sports/tennis/wta/scoreboard" },
        [PSCustomObject]@{ Kind = 'espn_other';  Url = "https://site.api.espn.com/apis/site/v2/sports/racing/f1/scoreboard" },
        [PSCustomObject]@{ Kind = 'espn_other';  Url = "https://site.api.espn.com/apis/site/v2/sports/mma/ufc/scoreboard" },
        [PSCustomObject]@{ Kind = 'tsdb';        Url = "https://www.thesportsdb.com/api/v1/json/123/eventsday.php?d=$tsToday" },
        [PSCustomObject]@{ Kind = 'tsdb';        Url = "https://www.thesportsdb.com/api/v1/json/123/eventsday.php?d=$tsYest" }
    )

    $fetched = Invoke-ParallelItems -Items $endpoints -ScriptBlock {
        param($ep)
        try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
        $raw = Get-Utf8Content -Uri $ep.Url -Referer "https://www.espn.com/" -TimeoutSec 4
        if ($raw) { [PSCustomObject]@{ Kind = $ep.Kind; Json = $raw } }
    }

    $seenKeys = [System.Collections.Generic.HashSet[string]]::new()
    if ($script:WebOracleEvents -is [System.Collections.Generic.List[object]]) {
        $script:WebOracleEvents.Clear()
    } else {
        $script:WebOracleEvents = [System.Collections.Generic.List[object]]::new()
    }

    foreach ($res in $fetched) {
        try {
            $obj = $res.Json | ConvertFrom-Json
            if ($res.Kind -eq 'espn_soccer' -and $obj.events) {
                foreach ($ev in $obj.events) {
                    $idKey = "espn_" + [string]$ev.id
                    if (-not $seenKeys.Add($idKey)) { continue }
                    $st = if ($ev.status -and $ev.status.type) { $ev.status.type } else { $null }
                    $pair = Get-EventTeamPair ([string]$ev.name)
                    $stDt = $null
                    try { $stDt = [DateTime]::Parse([string]$ev.date, [System.Globalization.CultureInfo]::InvariantCulture).ToUniversalTime() } catch {}
                    if ($pair.Count -eq 2) {
                        $script:WebOracleEvents.Add([PSCustomObject]@{
                            Kind      = 'match'
                            Source    = 'ESPN-Soccer'
                            Title     = [string]$ev.name
                            NormTitle = Normalize-EventText ([string]$ev.name)
                            TokensA   = @(Get-CoreTeamTokens $pair[0])
                            TokensB   = @(Get-CoreTeamTokens $pair[1])
                            StartUtc  = $stDt
                            EndUtc    = $null
                            State     = if ($st) { [string]$st.state } else { '' }
                            Completed = if ($st) { [bool]$st.completed } else { $false }
                            Detail    = if ($st) { [string]$st.shortDetail } else { '' }
                        })
                    }
                }
            } elseif ($res.Kind -eq 'espn_tennis' -and $obj.events) {
                foreach ($ev in $obj.events) {
                    $endDt = $null
                    try { if ($ev.endDate) { $endDt = [DateTime]::Parse([string]$ev.endDate, [System.Globalization.CultureInfo]::InvariantCulture).ToUniversalTime() } } catch {}
                    if ($endDt -and $nowUtc -gt $endDt) {
                        $script:WebOracleEvents.Add([PSCustomObject]@{
                            Kind      = 'event'
                            Source    = 'ESPN-Tennis'
                            Title     = [string]$ev.name
                            NormTitle = Normalize-EventText ([string]$ev.name)
                            TokensA   = @(); TokensB = @()
                            StartUtc  = $null; EndUtc = $endDt
                            State     = 'post'; Completed = $true; Detail = 'Torneo concluido'
                        })
                    }
                    if ($ev.groupings) {
                        foreach ($gp in $ev.groupings) {
                            foreach ($cp in $gp.competitions) {
                                $st = if ($cp.status -and $cp.status.type) { $cp.status.type } else { $null }
                                if ($cp.competitors -and $cp.competitors.Count -ge 2) {
                                    $p1 = [string]$cp.competitors[0].athlete.displayName
                                    $p2 = [string]$cp.competitors[1].athlete.displayName
                                    if ($p1 -and $p2) {
                                        $cpDt = $null
                                        try { if ($cp.date) { $cpDt = [DateTime]::Parse([string]$cp.date, [System.Globalization.CultureInfo]::InvariantCulture).ToUniversalTime() } } catch {}
                                        $script:WebOracleEvents.Add([PSCustomObject]@{
                                            Kind      = 'match'
                                            Source    = 'ESPN-Tennis'
                                            Title     = "$p1 vs $p2"
                                            NormTitle = Normalize-EventText "$p1 vs $p2"
                                            TokensA   = @(Get-CoreTeamTokens $p1)
                                            TokensB   = @(Get-CoreTeamTokens $p2)
                                            StartUtc  = $cpDt; EndUtc = $null
                                            State     = if ($st) { [string]$st.state } else { '' }
                                            Completed = if ($st) { [bool]$st.completed } else { $false }
                                            Detail    = if ($st) { [string]$st.shortDetail } else { '' }
                                        })
                                    }
                                }
                            }
                        }
                    }
                }
            } elseif ($res.Kind -eq 'espn_other' -and $obj.events) {
                foreach ($ev in $obj.events) {
                    $st = if ($ev.status -and $ev.status.type) { $ev.status.type } else { $null }
                    $endDt = $null
                    try { if ($ev.endDate) { $endDt = [DateTime]::Parse([string]$ev.endDate, [System.Globalization.CultureInfo]::InvariantCulture).ToUniversalTime() } elseif ($ev.date) { $endDt = [DateTime]::Parse([string]$ev.date, [System.Globalization.CultureInfo]::InvariantCulture).ToUniversalTime().AddHours(4) } } catch {}
                    $isOver = ($st -and ($st.completed -or $st.state -eq 'post'))
                    if ($isOver) {
                        $script:WebOracleEvents.Add([PSCustomObject]@{
                            Kind      = 'event'
                            Source    = 'ESPN-Sport'
                            Title     = [string]$ev.name
                            NormTitle = Normalize-EventText ([string]$ev.name)
                            TokensA   = @(); TokensB = @()
                            StartUtc  = $null; EndUtc = if ($endDt) { $endDt } else { $nowUtc.AddMinutes(-1) }
                            State     = 'post'; Completed = $true; Detail = [string]$st.shortDetail
                        })
                    }
                }
            } elseif ($res.Kind -eq 'tsdb' -and $obj.events) {
                foreach ($ev in $obj.events) {
                    $stTxt = [string]$ev.strStatus
                    $isDone = ($stTxt -match '(?i)^(?:FT|AET|AP|Finished|Postponed|Cancelled|Abandoned)$')
                    $isIn = ($stTxt -match '(?i)^(?:1H|2H|HT|ET|Live|Playing)$')
                    if (-not $isDone -and -not $isIn) { continue }
                    $pair = Get-EventTeamPair ([string]$ev.strEvent)
                    if ($pair.Count -eq 2) {
                        $script:WebOracleEvents.Add([PSCustomObject]@{
                            Kind      = 'match'
                            Source    = 'TheSportsDB'
                            Title     = [string]$ev.strEvent
                            NormTitle = Normalize-EventText ([string]$ev.strEvent)
                            TokensA   = @(Get-CoreTeamTokens $pair[0])
                            TokensB   = @(Get-CoreTeamTokens $pair[1])
                            StartUtc  = $null; EndUtc = $null
                            State     = if ($isDone) { 'post' } else { 'in' }
                            Completed = $isDone
                            Detail    = $stTxt
                        })
                    }
                }
            }
        } catch {}
    }

    if ($script:WebOracleEvents.Count -gt 0) {
        $script:WebOracleStatus = "ONLINE ($($script:WebOracleEvents.Count) eventos)"
        Write-Host "   [+] Oráculo Web sincronizado: $($script:WebOracleEvents.Count) partidos/eventos oficiales cargados." -ForegroundColor DarkGreen
    }
}

# -------------------------------------------------------------
# DETECCION AUTOMATIZADA Y EN TIEMPO REAL DE EVENTOS CONCLUIDOS
# -------------------------------------------------------------
function Test-IsEventFinalized($url, $name, $watchId) {
    if ([string]::IsNullOrWhiteSpace($name)) { return $true }

    # Canales 24/7 lineales genuinos (sin cruce vs/fecha de partido) NUNCA se descartan
    if (Test-IsLinearChannel $name) {
        return $false
    }

    # 0. Fechas explícitas pasadas en el título del evento (ej. "WWE NXT - Nov 10, 2026")
    if (Test-EventTitlePastDate $name) {
        return $true
    }

    # 0b. Oráculo Web oficial en tiempo real (ESPN / TheSportsDB)
    $oracleMatch = Find-WebOracleMatchStatus -EventTitle $name
    if ($oracleMatch) {
        if ($oracleMatch.Verdict -eq 'POST') { return $true }
        if ($oracleMatch.Verdict -eq 'IN' -or $oracleMatch.Verdict -eq 'PRE') { return $false }
    }

    $checkTarget = "$name $url"

    # 1. Eventos concluidos identificados por nombre/URL históricos
    if ($checkTarget -match '(?i)(?:Interlagos|S[aã]o Paulo|so-paulo|Lusail|Qatar|Monza|6 Horas|6 Hours|Horas de Monza|brazil/race|01a1ba3d|01a1b7cb|Antonelli|Max ver|Lerclec)') {
        return $true
    }

    # 2. Partidos concluidos históricos
    if ($checkTarget -match '(?i)(?:Napoli vs Lazio|Brighton.*Brentford|Crystal Palace.*Liverpool|Ipswich.*Bournemouth|Sunderland.*Chelsea|Stafford.*Grimsby|LaligaPremier|Genoa.*Milan|Monza.*Atalanta|Cray Wanderers.*Stockport|Celta.*Levante|Cologne.*Leverkusen|Colonia.*Leverkusen|Fiorentina.*Juventus|intercomo|Bengals.*Falcons)') {
        return $true
    }

    # 3. Días pasados en eventos no fijos
    if ($name -match '(?i)(?:Sunday|Saturday|Friday|Domingo|Sábado|Viernes)' -and $name -notmatch '(?i)(?:Formula|F1|DAZN|TV|Directa)') {
        return $true
    }

    # 4. Chequeo automatizado de emisión HLS en vivo (VOD / #EXT-X-ENDLIST o PDT antiguo)
    if ($watchId) {
        try {
            $bodyJson = '{"watchId":"' + $watchId + '"}'
            $wReq = Invoke-RestMethod -Uri "https://api.embdlol.st/watch" -Method POST -Body $bodyJson -ContentType "application/json" -TimeoutSec 3 -ErrorAction SilentlyContinue
            if ($wReq -and $wReq.url) {
                $m3uResp = Invoke-WebRequest -Uri $wReq.url -Headers @{"Referer"="https://embdlol.st/"; "Origin"="https://embdlol.st"} -TimeoutSec 3 -UseBasicParsing -ErrorAction SilentlyContinue
                if ($m3uResp -and $m3uResp.Content) {
                    $m3uText = [System.Text.Encoding]::UTF8.GetString($m3uResp.Content)
                    if ($m3uText -match '#EXT-X-ENDLIST') { return $true }
                    $subMatch = [regex]::Match($m3uText, '(?m)^(/.*m3u8.*)$')
                    if ($subMatch.Success) {
                        $base = [regex]::Match($wReq.url, '^(https?://[^/]+)').Groups[1].Value
                        $mediaUrl = $base + $subMatch.Groups[1].Value
                        $mediaResp = Invoke-WebRequest -Uri $mediaUrl -Headers @{"Referer"="https://embdlol.st/"; "Origin"="https://embdlol.st"} -TimeoutSec 3 -UseBasicParsing -ErrorAction SilentlyContinue
                        if ($mediaResp -and $mediaResp.Content) {
                            $mediaText = [System.Text.Encoding]::UTF8.GetString($mediaResp.Content)
                            if ($mediaText -match '#EXT-X-ENDLIST') { return $true }
                            $pdtMatch = [regex]::Match($mediaText, '#EXT-X-PROGRAM-DATE-TIME:([^\r\n]+)')
                            if ($pdtMatch.Success) {
                                $streamUtc = [DateTime]::Parse($pdtMatch.Groups[1].Value).ToUniversalTime()
                                $diffHours = ([DateTime]::UtcNow - $streamUtc).TotalHours
                                if ($diffHours -gt 1.5) {
                                    return $true
                                }
                            }
                        }
                    }
                }
            }
        } catch {}
    }

    # 5. Comprobación HTTP si la URL devuelve estado offline o fin
    if ($url -and $url -notmatch '\.m3u8(?:\?|$)') {
        try {
            $checkReq = [System.Net.HttpWebRequest]::Create($url)
            $checkReq.Method = "GET"
            $checkReq.Timeout = 1200
            $checkReq.UserAgent = $UserAgent
            $response = $checkReq.GetResponse()
            $stream = $response.GetResponseStream()
            $reader = New-Object System.IO.StreamReader($stream)
            $buffer = New-Object char[] 2048
            $readCount = $reader.Read($buffer, 0, 2048)
            $snippet = New-Object string($buffer, 0, $readCount)
            $reader.Close()
            $response.Close()

            if ($snippet -match '(?i)(?:MET_FTB_FINISH|MET_FTB_EVENT_END|SS_OVER|STREAM IS OFFLINE|Evento Finalizado|Transmisión finalizada|Partido terminado|404 Not Found)') {
                return $true
            }
        } catch [System.Net.WebException] {
            $errResp = $_.Exception.Response
            if ($errResp) {
                $code = [int]$errResp.StatusCode
                if ($code -ge 400 -and $code -le 410) { return $true }
            }
        } catch {}
    }

    return $false
}

function Invoke-WebSearchAiClassifier {
    param(
        [string]$EventTitle,
        [Nullable[DateTime]]$StartsAtUtc = $null,
        [string]$SportHint = ""
    )
    $nowUtc = [DateTime]::UtcNow
    $base = Get-EventBaseTitle $EventTitle
    $pair = Get-EventTeamPair $base
    $queryCore = if ($pair.Count -eq 2) { "`"$($pair[0])`" `"$($pair[1])`"" } else { "`"$base`"" }
    $dateHint = $nowUtc.ToString('MMMM yyyy', [System.Globalization.CultureInfo]::InvariantCulture)
    $q = "$queryCore $dateHint result OR postponed"

    $headlines = [System.Collections.Generic.List[PSCustomObject]]::new()
    $feeds = @(
        "https://news.google.com/rss/search?q=$([Uri]::EscapeDataString($q))&hl=en-US&gl=US&ceid=US:en",
        "https://news.google.com/rss/search?q=$([Uri]::EscapeDataString("$queryCore resultado OR aplazado"))&hl=es-419&gl=ES&ceid=ES:es"
    )
    foreach ($fUrl in $feeds) {
        $xmlTxt = Get-Utf8Content -Uri $fUrl -Referer "https://news.google.com/" -TimeoutSec 4
        if (-not $xmlTxt) { continue }
        try {
            [xml]$x = $xmlTxt
            foreach ($it in ($x.rss.channel.item | Select-Object -First 8)) {
                $hTitle = [string]$it.title
                if ([string]::IsNullOrWhiteSpace($hTitle)) { continue }
                $pubUtc = $null
                try { $pubUtc = [DateTimeOffset]::Parse([string]$it.pubDate).UtcDateTime } catch {}
                if ($pubUtc -and ($nowUtc - $pubUtc).TotalHours -gt 48) { continue }

                # Filtrar para asegurar relevancia estricta con los dos equipos o evento
                $hNorm = Normalize-EventText $hTitle
                $hTokens = @($hNorm -split '\s+' | Where-Object { $_.Length -ge 3 })
                $relevant = $false
                if ($pair.Count -eq 2) {
                    $tA = Get-CoreTeamTokens $pair[0]
                    $tB = Get-CoreTeamTokens $pair[1]
                    if ((Test-SideTokenOverlap $tA $hTokens) -and (Test-SideTokenOverlap $tB $hTokens)) { $relevant = $true }
                } else {
                    $tEvt = Get-CoreTeamTokens $base
                    if ($tEvt.Count -ge 2) {
                        $hits = @($tEvt | Where-Object { Test-SideTokenOverlap @($_) $hTokens }).Count
                        if ($hits -ge [Math]::Min(2, $tEvt.Count)) { $relevant = $true }
                    } elseif ($tEvt.Count -eq 1) {
                        $relevant = Test-SideTokenOverlap $tEvt $hTokens
                    }
                }
                if ($relevant) {
                    $headlines.Add([PSCustomObject]@{ Title = $hTitle; PubUtc = $pubUtc })
                }
            }
        } catch {}
        if ($headlines.Count -ge 4) { break }
    }

    if ($headlines.Count -eq 0) {
        return [PSCustomObject]@{ Verdict = 'KEEP'; Reason = 'Sin noticias concluyentes' }
    }

    # Modo opcional LLM real (Gemini API si el usuario configuró gemini/ai_api_key)
    if ($script:AiApiKey -and $script:AiModel) {
        try {
            $snipLines = ($headlines | Select-Object -First 5 | ForEach-Object { "- [$($_.PubUtc)] $($_.Title)" }) -join "`n"
            $promptTxt = "Current UTC: $($nowUtc.ToString('u')). Event: `"$base`" (StartUTC: $(if($StartsAtUtc){$StartsAtUtc.ToString('u')}else{'Unknown'})). News:`n$snipLines`nReply ONLY JSON: {`"decision`":`"PURGE`"|`"KEEP`",`"reason`":`"...`"}. PURGE only if clearly finished/final result or postponed/canceled."
            $reqBody = @{ contents = @(@{ parts = @(@{ text = $promptTxt }) }); generationConfig = @{ temperature = 0; responseMimeType = "application/json" } } | ConvertTo-Json -Depth 6
            $gemUri = "https://generativelanguage.googleapis.com/v1beta/models/$($script:AiModel):generateContent?key=$($script:AiApiKey)"
            $gemResp = Invoke-RestMethod -Uri $gemUri -Method POST -Body $reqBody -ContentType "application/json" -TimeoutSec 5 -ErrorAction Stop
            $rawAi = $gemResp.candidates[0].content.parts[0].text
            $aiJson = $rawAi | ConvertFrom-Json
            if ($aiJson.decision -eq 'PURGE') {
                return [PSCustomObject]@{ Verdict = 'PURGE'; Reason = "IA Gemini Web: $($aiJson.reason)" }
            }
            if ($aiJson.decision -eq 'KEEP') {
                return [PSCustomObject]@{ Verdict = 'KEEP'; Reason = "IA Gemini Web: $($aiJson.reason)" }
            }
        } catch {}
    }

    # Clasificador IA/NLP autónomo basado en pruebas web en vivo (cero claves requeridas)
    $allowConcluded = ($null -eq $StartsAtUtc) -or ($nowUtc -ge $StartsAtUtc.AddMinutes(85))
    foreach ($hl in $headlines) {
        $ht = $hl.Title
        # 1. Aplazado o suspendido (aplica incluso antes del pitido inicial)
        if ($ht -match '(?i)\b(?:postponed|aplazado|suspendido|reprogramado|rescheduled|cancelled|canceled|called off)\b' -and
            $ht -notmatch '(?i)\b(?:if|could|might|may be|risk of)\s+(?:postponed|cancelled|canceled)\b') {
            return [PSCustomObject]@{ Verdict = 'PURGE'; Reason = "Web Search (Aplazado/Suspendido): $ht" }
        }
        # 2. Marcador final o crónica post-partido verificada
        if ($allowConcluded) {
            if ($ht -match '(?i)(?:live updates|w/\s*live|live score|live stream|how to watch|donde ver|d[oó]nde ver|a qu[eé] hora|horario|match time|preview|previa|prediction|pron[oó]stico|en vivo|en directo|alineaciones|lineups|minuto a minuto|follow live)') {
                continue
            }
            if ($StartsAtUtc -and $hl.PubUtc -and $hl.PubUtc -lt $StartsAtUtc.AddMinutes(80)) {
                continue
            }
            if ($ht -match '(?i)(?:\b\d+\s*[-–:]\s*\d+\b|\b(?:crushes?|routs?|thrashes?|defeats?|beats?|edges?|tops?|win[s]?\b|wins title|golea|vence|derrota|remonta|empata|cae ante|full[- ]?time|\bFT\b|final score|resumen|highlights|cr[oó]nica|recap|post[- ]?match|results.*winners|winners.*results))') {
                return [PSCustomObject]@{ Verdict = 'PURGE'; Reason = "Filtro IA Web (Finalizado): $ht" }
            }
        }
    }
    return [PSCustomObject]@{ Verdict = 'KEEP'; Reason = 'Web sin confirmación de cierre' }
}

function Test-IsProtectedLinearChannel($ch) {
    if (-not $ch) { return $false }
    if ($ch.PSObject.Properties['IsIptv'] -and $ch.IsIptv) { return $true }
    if ($ch.PSObject.Properties['Slug'] -and $ch.Slug -match '^(?:iptv|tdt|rtve)') { return $true }
    if ($ch.PSObject.Properties['Id'] -and $ch.Id -match '^(?:iptv|tdt|rtve)_') { return $true }
    if ($ch.PSObject.Properties['IsLinear'] -and $ch.IsLinear) { return $true }
    if ($ch.Group -in @('TDT España', 'Cine y Series España', 'Documentales y Cultura España', 'Infantil y Música España')) { return $true }
    return (Test-IsLinearChannel $ch.Name)
}

function Invoke-WebAiEventPurge {
    Write-Host "`n [+] Filtro IA Web: Auditando eventos residuales en agendas y búsqueda web..." -ForegroundColor Cyan
    $nowUtc = [DateTime]::UtcNow
    $surviving = [System.Collections.Generic.List[PSCustomObject]]::new()
    $purgedByBase = @{}
    $aiCandidates = @{}

    # Pasada A: Horarios estrictos + Fechas en título + Oráculo ESPN/TSDB
    foreach ($ch in $script:allChannels) {
        if (Test-IsProtectedLinearChannel $ch) {
            $surviving.Add($ch)
            continue
        }
        $baseKey = (Get-EventBaseTitle $ch.Name).ToLowerInvariant()
        $stUtc = if ($ch.PSObject.Properties['StartsAtUtc'] -and $ch.StartsAtUtc) {
            try { [DateTime]::Parse([string]$ch.StartsAtUtc, [System.Globalization.CultureInfo]::InvariantCulture).ToUniversalTime() } catch { $null }
        } else { $null }
        $endUtc = if ($ch.PSObject.Properties['EndsAtUtc'] -and $ch.EndsAtUtc) {
            try { [DateTime]::Parse([string]$ch.EndsAtUtc, [System.Globalization.CultureInfo]::InvariantCulture).ToUniversalTime() } catch { $null }
        } else { $null }

        $oracle = Find-WebOracleMatchStatus -EventTitle $ch.Name -ApproxStartUtc $stUtc
        if ($oracle -and $oracle.Verdict -eq 'POST') {
            $script:finalizedEvents += [PSCustomObject]@{ Name = $ch.Name; Url = $ch.MasterUrl; Reason = "Oráculo Web ($($oracle.Source)): $($oracle.Detail)" }
            Write-Host "   [PURGADO WEB] $($ch.Name) ($($oracle.Source): $($oracle.Detail))" -ForegroundColor DarkYellow
            continue
        }
        $oracleLive = ($oracle -and $oracle.Verdict -eq 'IN')
        if (-not $oracleLive -and $endUtc -and $nowUtc -gt $endUtc) {
            $script:finalizedEvents += [PSCustomObject]@{ Name = $ch.Name; Url = $ch.MasterUrl; Reason = "Horario estimado concluido" }
            Write-Host "   [PURGADO HORA] $($ch.Name)" -ForegroundColor DarkYellow
            continue
        }
        if (Test-EventTitlePastDate $ch.Name) {
            $script:finalizedEvents += [PSCustomObject]@{ Name = $ch.Name; Url = $ch.MasterUrl; Reason = "Fecha de evento vencida" }
            Write-Host "   [PURGADO FECHA] $($ch.Name)" -ForegroundColor DarkYellow
            continue
        }

        $surviving.Add($ch)
        if (-not $oracle -and $baseKey -and -not $aiCandidates.ContainsKey($baseKey)) {
            if ($null -eq $stUtc -or $nowUtc -ge $stUtc.AddMinutes(-120)) {
                $aiCandidates[$baseKey] = [PSCustomObject]@{ Key = $baseKey; Title = (Get-EventBaseTitle $ch.Name); StartsAtUtc = $stUtc; Group = $ch.Group }
            }
        }
    }

    # Pasada B: Búsqueda web + Clasificador IA/NLP sobre eventos ambiguos
    $candList = @($aiCandidates.Values | Select-Object -First 30)
    if ($candList.Count -gt 0) {
        $script:WebAiStatus = "ONLINE ($($candList.Count) consultados)"
        $aiRes = Invoke-ParallelItems -Items $candList -ScriptBlock {
            param($c)
            try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
            $dec = Invoke-WebSearchAiClassifier -EventTitle $c.Title -StartsAtUtc $c.StartsAtUtc -SportHint $c.Group
            [PSCustomObject]@{ Key = $c.Key; Title = $c.Title; Decision = $dec }
        }
        foreach ($ar in $aiRes) {
            if ($ar.Decision -and $ar.Decision.Verdict -eq 'PURGE') {
                $purgedByBase[$ar.Key] = $ar.Decision.Reason
            }
        }
    } else {
        $script:WebAiStatus = "ONLINE (0 ambiguos)"
    }

    if ($purgedByBase.Count -gt 0) {
        $filteredFinal = [System.Collections.Generic.List[PSCustomObject]]::new()
        foreach ($ch in $surviving) {
            if (-not (Test-IsProtectedLinearChannel $ch)) {
                $bk = (Get-EventBaseTitle $ch.Name).ToLowerInvariant()
                if ($purgedByBase.ContainsKey($bk)) {
                    $rsn = $purgedByBase[$bk]
                    $script:finalizedEvents += [PSCustomObject]@{ Name = $ch.Name; Url = $ch.MasterUrl; Reason = $rsn }
                    Write-Host "   [PURGADO IA-WEB] $($ch.Name) ($rsn)" -ForegroundColor Yellow
                    continue
                }
            }
            $filteredFinal.Add($ch)
        }
        $script:allChannels = @($filteredFinal)
    } else {
        $script:allChannels = @($surviving)
    }
}

$allChannels = @()
$daznF1Feeds = [System.Collections.Generic.List[PSCustomObject]]::new()
$finalizedEvents = @()
$script:Prefetched = @{}
$script:VipSlugCache = @{}
$script:IptvSources = @()
if (Test-Path $IptvConfigFile) {
    try {
        $iptvCfg = [System.IO.File]::ReadAllText($IptvConfigFile, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
        if ($iptvCfg -and $iptvCfg.sources) {
            $script:IptvSources = @($iptvCfg.sources | Where-Object { $_.enabled -and $_.url -and (Test-IsSafeHttpUrl ([string]$_.url)) })
        }
    } catch {}
}
$script:ScanTimer.Restart()
Enable-QuietScanMode
trap { Disable-QuietScanMode; break }
Enter-ScanPhase 'Oracle' $esModoVpn
Initialize-WebAgendaOracle

function Get-VpnPrefetchTargets {
    return @(
        [PSCustomObject]@{ Key = "ProbeSx723";  Url = "https://streamx723.sbs/global3.php?channel=mlaliga"; Ref = "https://cdplay.live/"; Orig = ""; Timeout = 2; MarkDead = $true; Ua = "" },
        [PSCustomObject]@{ Key = "ProbeSx061";  Url = "https://streamx061.sbs/global3.php?channel=mlaliga"; Ref = "https://cdplay.live/"; Orig = ""; Timeout = 2; MarkDead = $true; Ua = "" },
        [PSCustomObject]@{ Key = "ProbeLa16";   Url = "https://la16hd.com/dsportsar.php"; Ref = "https://cdplay.live/"; Orig = ""; Timeout = 2; MarkDead = $true; Ua = "" },
        [PSCustomObject]@{ Key = "CdHtml";      Url = "https://cdplay.live/"; Ref = ""; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" },
        [PSCustomObject]@{ Key = "Diaries";     Url = "https://api.wqxag.com/diaries.json"; Ref = "https://futbollibregol.org/"; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" },
        [PSCustomObject]@{ Key = "XhdEv";       Url = "https://streamxhd.click/eventos.json"; Ref = "https://streamxhd.click/"; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" },
        [PSCustomObject]@{ Key = "Ag888";       Url = "https://streamx723.sbs/json/agenda888.json"; Ref = "https://streamx723.sbs/"; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" },
        [PSCustomObject]@{ Key = "FlHtml";      Url = "https://futbollibregol.org/"; Ref = ""; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" },
        [PSCustomObject]@{ Key = "EmHtml";      Url = "https://embedme.st/"; Ref = ""; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" },
        [PSCustomObject]@{ Key = "DlAgenda";    Url = "https://deportelibre.top/agenda-deportiva/agenda.json"; Ref = "https://deportelibre.top/agenda-deportiva/"; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" },
        [PSCustomObject]@{ Key = "CandyHealth"; Url = "https://edge2.candyshop.st/health"; Ref = ""; Orig = ""; Timeout = 2; MarkDead = $false; Ua = "" }
    )
}

function Invoke-PrefetchBatch([array]$Targets) {
    if (-not $Targets -or $Targets.Count -eq 0) { return }
    $pfRes = Invoke-ParallelItems -Items $Targets -ScriptBlock {
        param($t)
        try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
        $hdrs = @{}
        if ($t.Ref) { $hdrs["Referer"] = $t.Ref }
        if ($t.Orig) { $hdrs["Origin"] = $t.Orig }
        $uaUse = if ($t.PSObject.Properties['Ua'] -and $t.Ua) { [string]$t.Ua } else { $UserAgent }
        $txt = $null
        try {
            $resp = Invoke-WebRequest -Uri $t.Url -UserAgent $uaUse -Headers $hdrs -UseBasicParsing -TimeoutSec $t.Timeout -ErrorAction Stop
            if ($resp.RawContentStream) { $txt = [System.Text.Encoding]::UTF8.GetString($resp.RawContentStream.ToArray()) }
            elseif ($resp.Content -is [byte[]]) { $txt = [System.Text.Encoding]::UTF8.GetString($resp.Content) }
            else { $txt = [string]$resp.Content }
        } catch {}
        [PSCustomObject]@{ Key = $t.Key; Url = $t.Url; Text = $txt; MarkDead = $t.MarkDead }
    }
    foreach ($pr in $pfRes) {
        if ($pr.Text) {
            $script:Prefetched[$pr.Key] = $pr.Text
        } elseif ($pr.MarkDead) {
            $dk = Get-HostKey $pr.Url
            if ($dk -and $global:BlockedHosts) { $global:BlockedHosts[$dk] = $true }
        }
    }
}

# Pre-descarga paralela simultánea de TODOS los índices y comprobación anticipada de nodos muertos (acelera el escaneo)
Enter-ScanPhase 'Prefetch' $esModoVpn
Write-Host " [+] Pre-descargando índices globales y agendas multi-servidor en paralelo..." -ForegroundColor Cyan
$preFetchTargets = [System.Collections.Generic.List[PSCustomObject]]::new()
$preFetchTargets.Add([PSCustomObject]@{ Key = "Embdlol";   Url = "https://api.embdlol.st/struct"; Ref = "https://embdlol.st/"; Orig = ""; Timeout = 5; MarkDead = $false; Ua = "" })
$preFetchTargets.Add([PSCustomObject]@{ Key = "F1Net";     Url = "https://f1net1.dpdns.org/source.txt"; Ref = ""; Orig = ""; Timeout = 5; MarkDead = $false; Ua = "" })
$preFetchTargets.Add([PSCustomObject]@{ Key = "Ppv";       Url = "https://api.ppv.st/api/streams"; Ref = "https://ppv.st/"; Orig = "https://ppv.st"; Timeout = 5; MarkDead = $false; Ua = "" })
$preFetchTargets.Add([PSCustomObject]@{ Key = "TdtJson";   Url = "https://www.tdtchannels.com/lists/tv.json"; Ref = ""; Orig = ""; Timeout = 5; MarkDead = $false; Ua = "" })
$preFetchTargets.Add([PSCustomObject]@{ Key = "IptvEs";    Url = "https://iptv-org.github.io/iptv/countries/es.m3u"; Ref = ""; Orig = ""; Timeout = 5; MarkDead = $false; Ua = "" })
for ($si = 0; $si -lt $script:IptvSources.Count; $si++) {
    $sObj = $script:IptvSources[$si]
    $sUa = if ($sObj.PSObject.Properties['user_agent'] -and $sObj.user_agent) { [string]$sObj.user_agent } else { "TiviMate/4.7.0" }
    $preFetchTargets.Add([PSCustomObject]@{ Key = "IptvSrc_$si"; Url = [string]$sObj.url; Ref = ""; Orig = ""; Timeout = 8; MarkDead = $false; Ua = $sUa })
}
if ($esModoVpn) {
    foreach ($vt in (Get-VpnPrefetchTargets)) { $preFetchTargets.Add($vt) }
}
Invoke-PrefetchBatch @($preFetchTargets)

# -------------------------------------------------------------
# 1. EMISIONES EN DIRECTO - SERVIDOR DE EVENTOS 1 (EMBDLOL - PARALELO)
# -------------------------------------------------------------
Enter-ScanPhase 'Embdlol' $esModoVpn
Write-Host " [+] Analizando servidor de emisiones deportivas en directo..." -ForegroundColor Cyan

try {
    $embRaw = $script:Prefetched["Embdlol"]
    if (-not $embRaw) {
        $response = Invoke-WebRequest -Uri "https://api.embdlol.st/struct" -UserAgent $UserAgent -UseBasicParsing -TimeoutSec 5
        $embRaw = $response.Content
    }
    $data = $embRaw | ConvertFrom-Json
    $embdWorkItems = [System.Collections.Generic.List[PSCustomObject]]::new()

    foreach ($ch in $data.channels) {
        $spanishName = Translate-ToSpanish $ch.channelname
        if (Test-IsExcludedSport -Name $spanishName) {
            $script:SkippedSportsCount++
            continue
        }
        $embedCheckUrl = "https://embdlol.st/embed/$($ch.id)"
        if (Test-IsEventFinalized $embedCheckUrl $spanishName $null) {
            $finalizedEvents += [PSCustomObject]@{ Name = $spanishName; Url = $embedCheckUrl; Reason = "Evento concluido" }
            continue
        }
        $embdWorkItems.Add([PSCustomObject]@{ Id = $ch.id; Name = $spanishName; EmbedUrl = $embedCheckUrl })
    }

    $embdRes = Invoke-ParallelItems -Items @($embdWorkItems) -ScriptBlock {
        param($item)
        try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
        $watchUrl = "https://api.embdlol.st/watch"
        $streamMaster = $null
        $isExpired = $false
        $watchBody = '{"watchId":"' + $item.Id + '"}'
        try {
            $wResp = Invoke-RestMethod -Uri $watchUrl -Method POST -Body $watchBody -ContentType "application/json" -TimeoutSec 3 -ErrorAction Stop
            if ($wResp -and $wResp.url) {
                if (Test-HlsDeepLive -Uri $wResp.url -Referer "https://embdlol.st/" -Origin "https://embdlol.st" -TimeoutSec 3) {
                    $streamMaster = $wResp.url
                }
            }
        } catch {}

        if (-not $streamMaster) {
            if ((Test-IsEventFinalized $item.EmbedUrl $item.Name $item.Id) -or -not (Test-IsLinearChannel $item.Name)) {
                $isExpired = $true
            } else {
                $pageCheck = Get-Utf8Content -Uri $item.EmbedUrl -Referer "https://embdlol.st/" -TimeoutSec 2
                if ($pageCheck) { $streamMaster = $item.EmbedUrl } else { $isExpired = $true }
            }
        } elseif (-not (Test-IsLinearChannel $item.Name) -and (Test-IsEventFinalized $streamMaster $item.Name $item.Id)) {
            $isExpired = $true
        }
        [PSCustomObject]@{ Item = $item; MasterUrl = $streamMaster; Expired = $isExpired }
    }

    foreach ($er in $embdRes) {
        if ($er.Expired -or -not $er.MasterUrl) {
            $finalizedEvents += [PSCustomObject]@{ Name = $er.Item.Name; Url = $er.Item.EmbedUrl; Reason = "Emisión Embdlol sin segmentos activos" }
            continue
        }
        if (-not ($allChannels | Where-Object { $_.Name -eq $er.Item.Name })) {
            $allChannels += [PSCustomObject]@{
                Id          = "embd_" + $er.Item.Id
                Name        = $er.Item.Name
                Group       = Get-ChannelGroup $er.Item.Name
                Slug        = $er.Item.Id
                MasterUrl   = $er.MasterUrl
                FallbackUrl = $er.Item.EmbedUrl
                VpnRequired = $false
            }
            Write-Host "   [+] $($er.Item.Name) " -NoNewline -ForegroundColor Green
            if ($er.MasterUrl -match '\.m3u8') {
                Write-Host "[HLS Verificado | VPN No Necesaria]" -ForegroundColor DarkGreen
            } else {
                Write-Host "[Embed Activo | VPN No Necesaria]" -ForegroundColor DarkGreen
            }
        }
    }
} catch {
    Write-Host "   [-] Servidor de emisiones temporalmente no disponible: $($_.Exception.Message)" -ForegroundColor Yellow
}

# -------------------------------------------------------------
# 2. EMISIONES DE MOTOR Y DEPORTES - SERVIDOR 2 (F1NET - PARALELO)
# -------------------------------------------------------------
Enter-ScanPhase 'F1Net' $esModoVpn
Write-Host "`n [+] Analizando red de emisiones de motor y deportes..." -ForegroundColor Cyan

try {
    $f1Raw = $script:Prefetched["F1Net"]
    if (-not $f1Raw) {
        $f1Resp = Invoke-WebRequest -Uri "https://f1net1.dpdns.org/source.txt" -UserAgent $UserAgent -UseBasicParsing -TimeoutSec 5
        if ($f1Resp.StatusCode -eq 200) { $f1Raw = $f1Resp.Content }
    }
    if ($f1Raw -and $f1Raw.Length -gt 100) {
        $f1WorkItems = [System.Collections.Generic.List[PSCustomObject]]::new()
        foreach ($line in ($f1Raw -split "`n")) {
            $parts = $line -split '\|'
            if ($parts.Count -ge 3) {
                $rawName = $parts[0].Trim()
                $slug = $parts[1].Trim()
                $streamUrl = $parts[2].Trim()
                $normName = switch -Regex ($rawName) {
                    '(?i)Spanish'         { "DAZN F1 España" }
                    '(?i)Stream 1'        { "F1 - Señal 1 HD" }
                    '(?i)Stream 2'        { "F1 - Señal 2 HD" }
                    '(?i)Stream 3'        { "Sky Sports F1 HD" }
                    '(?i)Full\s*HD\s*1'   { "F1 - Señal Full HD 1 (Internacional)" }
                    '(?i)Full\s*Hd\s*3'   { "F1 - Señal Full HD 3 (Internacional)" }
                    '(?i)4k\s*UHD'        { "F1 - Señal 4K UHD (Internacional)" }
                    '(?i)Italian'         { "Sky Sport F1 Italia HD (Italiano)" }
                    '(?i)German'          { "Sky Sport F1 Alemania HD (Alemán)" }
                    '(?i)F1 TV'           { "F1 TV Internacional HD" }
                    '(?i)Fox Sports HD'   { "Fox Sports F1 HD" }
                    '(?i)Full Hd 4'       { "F1 - Señal Nexa HD" }
                    '(?i)HD Stream'       { "Sky F1 1080p HD" }
                    '(?i)Apple Tv 2'      { "F1 - Señal Apple TV" }
                    '(?i)Multi Lang 4k'   { "F1 - Señal 4K Multi-Idioma" }
                    '(?i)Sky Sports HD'   { "Sky Sports HD" }
                    '(?i)Drivers track'   { "F1 - Cámara de Pilotos (Onboard)" }
                    '(?i)Data Channel'    { "F1 - Canal de Datos y Telemetría" }
                    default               { Translate-ToSpanish $rawName }
                }
                if (Test-IsEventFinalized $streamUrl $normName $null) {
                    $finalizedEvents += [PSCustomObject]@{ Name = $normName; Url = $streamUrl; Reason = "Evento concluido" }
                    continue
                }
                $f1WorkItems.Add([PSCustomObject]@{ Name = $normName; Slug = $slug; Url = $streamUrl })
            }
        }

        $f1Results = Invoke-ParallelItems -Items @($f1WorkItems) -ScriptBlock {
            param($it)
            try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
            $ok = Test-HlsDeepLive -Uri $it.Url -TimeoutSec 3
            [PSCustomObject]@{ Item = $it; Ok = $ok }
        }
        $f1LiveCount = 0
        foreach ($fr in $f1Results) {
            if (-not $fr.Ok) {
                $finalizedEvents += [PSCustomObject]@{ Name = $fr.Item.Name; Url = $fr.Item.Url; Reason = "Señal F1Net sin segmentos activos (403/404)" }
                continue
            }
            $f1LiveCount++
            if ($fr.Item.Name -match '(?i)DAZN\s*F1') {
                $daznF1Feeds.Add([PSCustomObject]@{ Url = $fr.Item.Url; Source = "f1net" })
            } elseif (-not ($allChannels | Where-Object { $_.Name -eq $fr.Item.Name })) {
                $allChannels += [PSCustomObject]@{
                    Id          = "f1net_" + ($fr.Item.Name -replace '[^a-zA-Z0-9]','')
                    Name        = $fr.Item.Name
                    Group       = Get-ChannelGroup $fr.Item.Name
                    Slug        = $fr.Item.Slug
                    MasterUrl   = $fr.Item.Url
                    VpnRequired = $false
                }
                Write-Host "   [+] $($fr.Item.Name) [HLS Verificado | VPN No Necesaria]" -ForegroundColor DarkGreen
            }
        }
        if ($f1LiveCount -eq 0 -and $f1WorkItems.Count -gt 0) {
            Write-Host "   [-] F1Net: $($f1WorkItems.Count) señales sin emisión activa ahora (omitidas)." -ForegroundColor DarkGray
        }
    }
} catch {
    Write-Host "   [-] Red de emisiones de motor no accesible directamente." -ForegroundColor DarkGray
}

# -------------------------------------------------------------
# 3. AGENDA Y EMISIONES EN VIVO DINAMICAS - SERVIDOR 3 (PPV.ST - PARALELO)
# -------------------------------------------------------------
Enter-ScanPhase 'Ppv' $esModoVpn
Write-Host "`n [+] Analizando red de eventos y canales 24/7 (PPV.ST)..." -ForegroundColor Cyan

try {
    $ppvResp = if ($script:Prefetched["Ppv"]) { $script:Prefetched["Ppv"] | ConvertFrom-Json } else {
        Invoke-RestMethod -Uri "https://api.ppv.st/api/streams" -UserAgent $UserAgent -Headers @{
            "Origin" = "https://ppv.st";
            "Referer" = "https://ppv.st/"
        } -TimeoutSec 5
    }

    if ($ppvResp -and $ppvResp.streams) {
        $nowEpoch = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        $ppvWorkItems = [System.Collections.Generic.List[PSCustomObject]]::new()
        foreach ($cat in $ppvResp.streams) {
            $ppvCatHint = if ($cat.category -match '(?i)^(?:Football|Soccer|F[uú]tbol)$') { "Football" }
                          elseif ($cat.category -match '(?i)American\s*Football|NFL') { "NFL" }
                          elseif ($cat.category -match '(?i)Basketball') { "Basketball" }
                          else { "" }
            foreach ($st in $cat.streams) {
                $is247 = ($st.always_live -eq 1)
                if (-not $st.iframe) { continue }
                $chName = Translate-ToSpanish $st.name
                if (Test-IsExcludedSport -Name $chName -LeagueOrCategory ([string]$cat.category)) {
                    $script:SkippedSportsCount++
                    continue
                }
                $evWin = $null
                $isUpcoming = $false
                if (-not $is247) {
                    $stUtc = if ($st.starts_at -gt 0) { [DateTimeOffset]::FromUnixTimeSeconds([long]$st.starts_at).UtcDateTime } else { $null }
                    $repEndUtc = if ($st.ends_at -gt 0) { [DateTimeOffset]::FromUnixTimeSeconds([long]$st.ends_at).UtcDateTime } else { $null }
                    if ($stUtc -and $stUtc -gt [DateTime]::UtcNow.AddHours(24)) { continue }
                    $evWin = Get-AgendaEventWindowEvaluation -Title $chName -StartUtc $stUtc -ReportedEndUtc $repEndUtc -SportHint ([string]$cat.category)
                    if ($evWin.IsConcluded) {
                        $finalizedEvents += [PSCustomObject]@{ Name = $st.name; Url = $st.iframe; Reason = $evWin.Reason }
                        continue
                    }
                    $isUpcoming = $evWin.Upcoming
                }
                if ($st.source_tag -and $st.source_tag -notmatch '24/7') {
                    $chName += " ($($st.source_tag))"
                }
                if ($isUpcoming -and $evWin.KickTag) {
                    $chName += $evWin.KickTag
                }
                $ppvWorkItems.Add([PSCustomObject]@{
                    Name        = $chName
                    Slug        = $st.uri_name
                    Iframe      = $st.iframe
                    Upcoming    = $isUpcoming
                    Hint        = $ppvCatHint
                    StartsAtUtc = if ($evWin) { $evWin.StartsAtUtcStr } else { "" }
                    EndsAtUtc   = if ($evWin) { $evWin.EndsAtUtcStr } else { "" }
                })
            }
        }

        $ppvRes = Invoke-ParallelItems -Items @($ppvWorkItems) -ScriptBlock {
            param($it)
            try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
            $masterStream = $it.Iframe
            $keep = $true
            if ($it.Iframe -match 'embdlol\.st/embed/([a-zA-Z0-9-]+)') {
                $verifiedPpvHls = Resolve-EmbdlolWatchUrl -WatchId $Matches[1]
                if ($verifiedPpvHls) {
                    $masterStream = $verifiedPpvHls
                } elseif (-not $it.Upcoming) {
                    $keep = $false
                }
            } elseif ($it.Iframe -match '\.m3u8(?:\?|$)') {
                if (-not (Test-HlsDeepLive -Uri $it.Iframe -Referer "https://ppv.st/" -TimeoutSec 3)) {
                    $keep = $false
                }
            }
            [PSCustomObject]@{ Item = $it; MasterUrl = $masterStream; Keep = $keep }
        }

        foreach ($pr in $ppvRes) {
            if (-not $pr.Keep) {
                $finalizedEvents += [PSCustomObject]@{ Name = $pr.Item.Name; Url = $pr.Item.Iframe; Reason = "Stream PPV sin segmentos activos" }
                continue
            }
            if (-not ($allChannels | Where-Object { $_.Name -eq $pr.Item.Name })) {
                $allChannels += [PSCustomObject]@{
                    Id          = "ppv_" + ($pr.Item.Slug -replace '[^a-zA-Z0-9]','')
                    Name        = $pr.Item.Name
                    Group       = Get-ChannelGroup $pr.Item.Name $pr.Item.Hint
                    Slug        = $pr.Item.Slug
                    MasterUrl   = $pr.MasterUrl
                    FallbackUrl = $pr.Item.Iframe
                    VpnRequired = $false
                    StartsAtUtc = $pr.Item.StartsAtUtc
                    EndsAtUtc   = $pr.Item.EndsAtUtc
                }
                Write-Host "   [+] $($pr.Item.Name) " -NoNewline -ForegroundColor Green
                if ($pr.MasterUrl -match '\.m3u8') {
                    Write-Host "[HLS Verificado | VPN No Necesaria]" -ForegroundColor DarkGreen
                } else {
                    Write-Host "[Programado / Embed | VPN No Necesaria]" -ForegroundColor DarkGreen
                }
            }
        }
    }
} catch {
    Write-Host "   [-] Servidor PPV.ST no accesible directamente: $($_.Exception.Message)" -ForegroundColor DarkGray
}

# -------------------------------------------------------------
# 4. EMISIONES OFICIALES RTVE Y TODA LA TDT ESPANA (PARALELO)
# -------------------------------------------------------------
Enter-ScanPhase 'RtveTdt' $esModoVpn
Write-Host "`n [+] Analizando y verificando toda la TDT España (RTVE, Generalistas y Autonómicas)..." -ForegroundColor Cyan

function Get-NormalizedTdtKey {
    <# Normaliza nombres de canales TDT españoles para deduplicar variantes entre fuentes. #>
    param([string]$RawName)
    if ([string]::IsNullOrWhiteSpace($RawName)) { return "" }
    $x = $RawName.ToLowerInvariant()
    $x = $x -replace '\s*\[[^\]]*\]', ''
    $x = $x -replace '\s*\((?:1080p|720p|576p|480p|360p|404p|416p|spain|originals|es|hd|sd|uhd|4k)\)', ''
    $x = $x -replace '\s*\([^)]*\)', ''
    $formD = $x.Normalize([System.Text.NormalizationForm]::FormD)
    $sb = [System.Text.StringBuilder]::new()
    foreach ($ch in $formD.ToCharArray()) {
        if ([System.Globalization.CharUnicodeInfo]::GetUnicodeCategory($ch) -ne [System.Globalization.UnicodeCategory]::NonSpacingMark) {
            [void]$sb.Append($ch)
        }
    }
    $clean = ($sb.ToString() -replace '\b(full|hd|sd|uhd|4k|tv|television|telebista|originals)\b', '' -replace '[^a-z0-9]', '')
    $clean = $clean -replace '^(?:rtveplay|rtve)(?=.{3,})', ''
    switch -Regex ($clean) {
        '^24h$|^24horas$|^canal24horas$' { return '24horas' }
        '^24hcatalunya$|^24horascatalunya$' { return '24horascatalunya' }
        '^24hcanarias$|^24horascanarias$' { return '24horascanarias' }
        '^la1$' { return 'la1' }
        '^la2$' { return 'la2' }
        '^la1catalunya$' { return 'la1catalunya' }
        '^la1canarias$' { return 'la1canarias' }
        '^la2canarias$' { return 'la2canarias' }
        '^teledeporte$|^tdp$' { return 'teledeporte' }
        '^clan$' { return 'clan' }
        '^7tv$|^7tvandalucia$' { return '7tvandalucia' }
        '^canalsurandalucia$|^canalsur$' { return 'canalsurandalucia' }
        '^canalsur2(?:accesible)?$' { return 'canalsur2' }
        '^canalsurmasnoticias$|^canalsurnoticias$' { return 'canalsurnoticias' }
        '^canal7televalencia$|^7televalencia$' { return '7televalencia' }
        '^tvg2$' { return 'tvg2' }
        '^cmm$|^castillalamanchamedia$' { return 'cmm' }
        '^tvcanaria$|^canaria$' { return 'tvcanaria' }
        '^eltoro$' { return 'eltoro' }
        '^apunt$' { return 'apunt' }
        '^telemadrid$' { return 'telemadrid' }
        '^punt3(?:valluixo)?$' { return 'punt3' }
        '^realmadrid(?:espanol|espanaabiertodeportes|english)?$' { return 'realmadrid' }
        '^larevuelta$' { return 'larevuelta' }
        '^somoscine$' { return 'somoscine' }
        '^70anos$' { return 'rtve70anos' }
        '^conciertosradio3$|^radio3$' { return 'conciertosradio3' }
        '^12(?:alicante)?$' { return '12tvalicante' }
        default { return $clean }
    }
}

$tdtDynamicMap = @{}
$tdtCatalog = [ordered]@{}

function Add-TdtCatalogEntry {
    <# Registra o combina candidatos HLS en el catálogo TDT filtrando radios y ruido extranjero. #>
    param([string]$DisplayName, [string]$GroupName, [string]$AmbitLabel, [string[]]$Urls, [bool]$AllowNew = $true)
    if ([string]::IsNullOrWhiteSpace($DisplayName) -or -not $Urls -or $Urls.Count -eq 0) { return }
    if ($DisplayName -match '(?i)^(?:Radio\s+(?:Nacional|5|4|3|Cl[aá]sica|Exterior|Castilla)|R[aà]dio\s+\d+|Canal\s+Fiesta\s+Radio|Onda\s+Madrid\b|RNE\s+para\s+todos|Castilla-La\s+Mancha\s+Radio|Euskadi\s+Irratia|Radio\s+Euskadi|Radio\s+Galega(?:\s|$))') { return }
    if (Test-IsExcludedSport $DisplayName) { return }
    if ($DisplayName -match '\((?:Germany|France|UK|US|USA|Italy|Portugal|Netherlands|LATAM|Poland|Brazil|Russia)\)') { return }

    $key = Get-NormalizedTdtKey $DisplayName
    if (-not $key) { return }
    if (-not $AllowNew -and -not $tdtCatalog.Contains($key)) { return }

    if (-not $tdtDynamicMap.ContainsKey($DisplayName.Trim())) {
        $tdtDynamicMap[$DisplayName.Trim()] = $Urls
    }
    if (-not $tdtCatalog.Contains($key)) {
        $tdtCatalog[$key] = [PSCustomObject]@{
            Key   = $key
            Name  = $DisplayName.Trim()
            Group = $GroupName
            Ambit = $AmbitLabel
            Urls  = [System.Collections.Generic.List[string]]::new()
        }
    }
    foreach ($rawU in $Urls) {
        $cleanU = ($rawU -replace '&avod=.*$', '').Trim()
        # Omitir plantillas SSAI con macros sin resolver (ej. [CACHEBUSTER], [IP]) que devuelven 400
        if ($cleanU -match '^https?://' -and $cleanU -notmatch '\[[A-Z0-9_]{2,}\]' -and $cleanU -notmatch '\.(?:mpd|mp4|mkv)(?:\?|$)' -and -not $tdtCatalog[$key].Urls.Contains($cleanU)) {
            $tdtCatalog[$key].Urls.Add($cleanU)
        }
    }
}

# 4.1 Fuente oficial TDTChannels (Nacionales, Generalistas, Informativos, Infantiles, Deportivos y 19 Autonómicas)
try {
    $tdtJsonTxt = if ($script:Prefetched["TdtJson"]) { $script:Prefetched["TdtJson"] } else { Get-Utf8Content -Uri "https://www.tdtchannels.com/lists/tv.json" -TimeoutSec 5 }
    if ($tdtJsonTxt) {
        $tdtParsed = $tdtJsonTxt | ConvertFrom-Json
        $spainCountry = $tdtParsed.countries | Where-Object { $_.name -eq "Spain" }
        foreach ($amb in $spainCountry.ambits) {
            foreach ($tc in $amb.channels) {
                $m3uOpts = @($tc.options | Where-Object { $_.format -eq "m3u8" -and $_.url -match '^https?://' } | ForEach-Object { $_.url -replace '&avod=.*$', '' })
                if ($m3uOpts.Count -gt 0 -and $tc.name) {
                    $cName = $tc.name.Trim()
                    $cGroup = if ($cName -match '(?i)Real\s*Madrid\s*TV') { "Deportes España" } else { "TDT España" }
                    Add-TdtCatalogEntry -DisplayName $cName -GroupName $cGroup -AmbitLabel $amb.name -Urls $m3uOpts -AllowNew $true
                }
            }
        }
    }
} catch {}

# 4.2 Respaldo y ampliación desde IPTV-Org España (desbloquea Telemadrid HD, DMAX, El 33, Esport3 int, TVG Europa, etc.)
try {
    $iptvEsTxt = if ($script:Prefetched["IptvEs"]) { $script:Prefetched["IptvEs"] } else { Get-Utf8Content -Uri "https://iptv-org.github.io/iptv/countries/es.m3u" -TimeoutSec 5 }
    if ($iptvEsTxt) {
        $curName = $null; $curGrp = ""
        foreach ($rawLine in ($iptvEsTxt -split "`r?`n")) {
            $ln = $rawLine.Trim()
            if ($ln -match '^#EXTINF:.*group-title="([^"]*)"[^,]*,(.*)$') {
                $curGrp = $Matches[1]; $curName = $Matches[2].Trim()
            } elseif ($ln -match '^#EXTINF:[^,]*,(.*)$') {
                $curGrp = ""; $curName = $Matches[1].Trim()
            } elseif ($ln -match '^https?://' -and $curName) {
                $dispName = ($curName -replace '\s*\[[^\]]*\]', '' -replace '\s*\((?:1080p|720p|576p|480p|360p|404p|416p|Spain|Originals)\)', '' -replace '\s{2,}', ' ').Trim()
                $dispName = $dispName -replace '(?i)\bFrance 24 Spanish\b', 'France 24 Español' -replace '(?i)\bEurosport (\d) Spain\b', 'Eurosport $1 España (HD)'
                $isSpainTdtExtra = $dispName -match '(?i)Telemadrid|LaOtra|DMAX|El 33|TV3CAT|Galicia TV|Arag[oó]n|IB3|\bTPA\b|CyLTV|7RM|Navarra TV|Sol M[uú]sica|Historia|BBC Drama|Cine Friki|Cine Western|Todo Novelas|France 24|FIFA\+|Red Bull|MyTime|Rakuten TV|The Pet Collective|En el punto de mira|Eurosport|Gol Play|TeleValencia'
                $tGroup = if ($dispName -match '(?i)Eurosport|Real\s*Madrid\s*TV') { "Deportes España" } else { "TDT España" }
                Add-TdtCatalogEntry -DisplayName $dispName -GroupName $tGroup -AmbitLabel ("TDT/" + $(if ($curGrp) { $curGrp } else { "España" })) -Urls @($ln) -AllowNew $isSpainTdtExtra
                $curName = $null
            }
        }
    }
} catch {}

$rtveStreams = @(
    @{ Name = "RTVE La 1 Full HD (1080p · Señal Oficial)"; Group = "TDT España"; TdtKey = "La 1"; Urls = @("https://lge-lgla2.otteravision.com/lge/lgla1/lgla1.m3u8", "https://stream.ads.ottera.tv/playlist.m3u8?network_id=15619", "https://rtvelivestream.rtve.es/rtvesec/la1/la1_main_dvr.m3u8") },
    @{ Name = "RTVE La 1 HD (Señal Oficial Multi-Audio)"; Group = "TDT España"; TdtKey = ""; Urls = @("https://rtvelivestream.rtve.es/rtvesec/la1/la1_main_dvr.m3u8", "https://ztnr.rtve.es/ztnr/1688877.m3u8") },
    @{ Name = "Teledeporte RTVE Full HD (1080p · Deportes)"; Group = "TDT España"; TdtKey = "Teledeporte"; Urls = @("https://lge-lgla2.otteravision.com/lge/lgtdp/lgtdp.m3u8", "https://stream.ads.ottera.tv/playlist.m3u8?network_id=15601", "https://rtvelivestream.rtve.es/rtvesec/tdp/tdp_main_dvr.m3u8") },
    @{ Name = "Teledeporte RTVE Full HD (Espejo Oficial Ottera)"; Group = "TDT España"; TdtKey = ""; Urls = @("https://stream.ads.ottera.tv/playlist.m3u8?network_id=15601") },
    @{ Name = "RTVE La 2 Full HD (1080p · España Directo)"; Group = "TDT España"; TdtKey = "La 2"; Urls = @("https://lge-lgla2.otteravision.com/lge/lgla2/lgla2.m3u8", "https://stream.ads.ottera.tv/playlist.m3u8?network_id=15618", "https://rtvelivestream.rtve.es/rtvesec/la2/la2_main_dvr.m3u8") },
    @{ Name = "RTVE La 2 HD (Señal Oficial Multi-Audio)"; Group = "TDT España"; TdtKey = ""; Urls = @("https://rtvelivestream.rtve.es/rtvesec/la2/la2_main_dvr.m3u8", "https://ztnr.rtve.es/ztnr/1688885.m3u8") },
    @{ Name = "RTVE Canal 24 Horas Full HD (1080p · Noticias)"; Group = "TDT España"; TdtKey = "24h"; Urls = @("https://lge-lgla2.otteravision.com/lge/lg24h/lg24h.m3u8", "https://stream.ads.ottera.tv/playlist.m3u8?network_id=15621", "https://rtvelivestream.rtve.es/rtvesec/24h/24h_main_dvr.m3u8") },
    @{ Name = "RTVE Clan Full HD (1080p · España Directo)"; Group = "TDT España"; TdtKey = "Clan"; Urls = @("https://lge-lgla2.otteravision.com/lge/lgcla/lgcla.m3u8", "https://stream.ads.ottera.tv/playlist.m3u8?network_id=15620", "https://rtvelivestream.rtve.es/rtvesec/clan/clan_main_dvr.m3u8") },
    @{ Name = "RTVE La 1 Catalunya HD"; Group = "TDT España"; TdtKey = "La 1 Catalunya"; Urls = @("https://rtvelivestream.rtve.es/rtvesec/cat/la1_cat_main_dvr.m3u8", "https://ztnr.rtve.es/ztnr/3293681.m3u8") },
    @{ Name = "RTVE 24h Catalunya HD"; Group = "TDT España"; TdtKey = "24h Catalunya"; Urls = @("https://rtvelivestream.rtve.es/rtvesec/cat/24h_cat_main_dvr.m3u8", "https://ztnr.rtve.es/ztnr/4952053.m3u8") },
    @{ Name = "RTVE La 2 Canarias HD"; Group = "TDT España"; TdtKey = "La 2 Canarias"; Urls = @("https://rtvelivestream.rtve.es/rtvesec/can/la2_can_main_dvr.m3u8", "https://ztnr.rtve.es/ztnr/5468585.m3u8") },
    @{ Name = "RTVE 24h Canarias HD"; Group = "TDT España"; TdtKey = "24h Canarias"; Urls = @("https://rtvelivestream.rtve.es/rtvesec/can/24h_can_main_dvr.m3u8", "https://ztnr.rtve.es/ztnr/5473142.m3u8") },
    @{ Name = "RTVE La 1 Canarias HD"; Group = "TDT España"; TdtKey = "La 1 Canarias"; Urls = @("https://rtvelivestream.rtve.es/rtvesec/can/la1_can_main_dvr.m3u8", "https://ztnr.rtve.es/ztnr/5190066.m3u8") },
    @{ Name = "Star TVE HD (1080p · RTVE)"; Group = "TDT España"; TdtKey = ""; Urls = @("https://rtvelivestream-rtveplayplus.rtve.es/rtvesec/int/star_main_1080.m3u8", "https://rtvelivestream.rtve.es/rtvesec/int/star_main.m3u8") },
    @{ Name = "TVE Internacional Europa HD (1080p · RTVE)"; Group = "TDT España"; TdtKey = ""; Urls = @("https://rtvelivestream-rtveplayplus.rtve.es/rtvesec/int/tvei_eu_main_1080.m3u8", "https://rtvelivestream.rtve.es/rtvesec/int/tvei_eu_main.m3u8") },
    @{ Name = "RTVE Play: Señal Eventual Directo (OCA / Eventos)"; Group = "TDT España"; TdtKey = ""; Urls = @("https://ztnr.rtve.es/ztnr/17303384.m3u8", "https://rtvelivestream.rtve.es/eventual/gofast/playm29_main_dvr.m3u8") },
    @{ Name = "RTVE Play: La Revuelta 24h HD"; Group = "TDT España"; TdtKey = "La Revuelta (RTVE)"; Urls = @("https://ztnr.rtve.es/ztnr/16464388.m3u8", "https://rtvelivestream.rtve.es/eventual/gofast/playm5_main_dvr.m3u8") },
    @{ Name = "RTVE Play: Somos Cine HD"; Group = "TDT España"; TdtKey = "Somos Cine (RTVE)"; Urls = @("https://ztnr.rtve.es/ztnr/6909845.m3u8", "https://rtvelivestream.rtve.es/eventual/gofast/playm6_main_dvr.m3u8") },
    @{ Name = "RTVE Play: RTVE 70 Años HD"; Group = "TDT España"; TdtKey = "RTVE 70 años (RTVE)"; Urls = @("https://ztnr.rtve.es/ztnr/17232941.m3u8", "https://rtvelivestream.rtve.es/eventual/gofast/playm28_main_dvr.m3u8") },
    @{ Name = "RTVE Play: Conciertos Radio 3 HD"; Group = "TDT España"; TdtKey = "Conciertos Radio 3 (RTVE)"; Urls = @("https://ztnr.rtve.es/ztnr/6924117.m3u8", "https://rtvelivestream.rtve.es/eventual/gofast/playm11_main_dvr.m3u8") },
    @{ Name = "Real Madrid TV España HD (Abierto TDT / Deportes)"; Group = "Deportes España"; TdtKey = "Real Madrid TV"; Urls = @("https://rmtv.akamaized.net/hls/live/2043153/rmtv-es-web/master.m3u8") }
)

$coveredTdtKeys = @{}
$rtveWorkItems = [System.Collections.Generic.List[PSCustomObject]]::new()

foreach ($rtve in $rtveStreams) {
    $candidates = [System.Collections.Generic.List[string]]::new()
    foreach ($u in $rtve.Urls) { if (-not $candidates.Contains($u)) { $candidates.Add($u) } }
    $kName = Get-NormalizedTdtKey $rtve.Name
    if ($kName) { $coveredTdtKeys[$kName] = $true }
    if ($rtve.TdtKey) {
        $kTdt = Get-NormalizedTdtKey $rtve.TdtKey
        if ($kTdt) {
            $coveredTdtKeys[$kTdt] = $true
            if ($tdtCatalog.Contains($kTdt)) {
                foreach ($du in $tdtCatalog[$kTdt].Urls) { if (-not $candidates.Contains($du)) { $candidates.Add($du) } }
            }
        }
        if ($tdtDynamicMap.ContainsKey($rtve.TdtKey)) {
            foreach ($du in $tdtDynamicMap[$rtve.TdtKey]) { if (-not $candidates.Contains($du)) { $candidates.Add($du) } }
        }
    }
    $rtveWorkItems.Add([PSCustomObject]@{
        Name       = $rtve.Name
        Group      = $rtve.Group
        IsCurated  = $true
        Ambit      = "RTVE/Curado"
        Candidates = @($candidates)
    })
}

foreach ($entry in $tdtCatalog.Values) {
    if ($coveredTdtKeys.ContainsKey($entry.Key) -or $entry.Urls.Count -eq 0) { continue }
    $coveredTdtKeys[$entry.Key] = $true
    $sortedUrls = @($entry.Urls | Sort-Object { if ($_ -match 'getpublica\.com|ads\.ottera\.tv') { 1 } else { 0 } } | Select-Object -First 2)
    $rtveWorkItems.Add([PSCustomObject]@{
        Name       = $entry.Name
        Group      = $entry.Group
        IsCurated  = $false
        Ambit      = $entry.Ambit
        Candidates = $sortedUrls
    })
}

Write-Host ("   [*] Validando segmentos reales en {0} canales RTVE + TDT España..." -f $rtveWorkItems.Count) -ForegroundColor DarkCyan

$rtveRes = Invoke-ParallelItems -Items @($rtveWorkItems) -ScriptBlock {
    param($it)
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
    $workingUrl = $null
    $timeout = if ($it.IsCurated) { 3 } else { 2 }
    foreach ($cand in $it.Candidates) {
        $isLive = if ($it.IsCurated) { Test-HlsDeepLive -Uri $cand -TimeoutSec $timeout -SkipBlockCache } else { Test-HlsDeepLive -Uri $cand -TimeoutSec $timeout }
        if ($isLive) {
            $workingUrl = $cand
            break
        }
    }
    [PSCustomObject]@{ Item = $it; Url = $workingUrl }
}

$tdtAddedCount = 0
$seenTdtOutNames = @{}
foreach ($rr in $rtveRes) {
    if ($rr.Url) {
        $chKey = $rr.Item.Name.ToLowerInvariant()
        if (-not $seenTdtOutNames.ContainsKey($chKey) -and -not ($allChannels | Where-Object { $_.Name -eq $rr.Item.Name })) {
            $seenTdtOutNames[$chKey] = $true
            $prefix = if ($rr.Item.IsCurated) { "rtve_" } else { "tdt_" }
            $allChannels += [PSCustomObject]@{
                Id          = $prefix + ($rr.Item.Name -replace '[^a-zA-Z0-9]','')
                Name        = $rr.Item.Name
                Group       = $rr.Item.Group
                Slug        = if ($rr.Item.IsCurated) { "rtve" } else { "tdt" }
                MasterUrl   = $rr.Url
                VpnRequired = $false
            }
            if ($rr.Item.IsCurated) {
                Write-Host "   [+] $($rr.Item.Name) [200 OK - Segmentos Verificados | Sin VPN]" -ForegroundColor DarkGreen
            } else {
                $tdtAddedCount++
                if ($rr.Item.Ambit -in @('Generalistas', 'Informativos', 'Deportivos', 'Infantiles', 'Eventuales') -or $rr.Item.Name -match '(?i)Telemadrid|DMAX|Canal Sur|TV3|El 33|Esport3|À Punt|ETB|TVG|Galicia TV|CMM|Canaria|Extremadura|Sol M[uú]sica|Historia') {
                    Write-Host "   [+] $($rr.Item.Name) [$($rr.Item.Ambit) · 200 OK | TDT España]" -ForegroundColor DarkGreen
                }
            }
        }
    } elseif ($rr.Item.IsCurated) {
        $finalizedEvents += [PSCustomObject]@{
            Name   = $rr.Item.Name
            Url    = $rr.Item.Candidates[0]
            Reason = "Señal RTVE con restricción 403 en segmentos desde esta IP"
        }
        Write-Host "   [-] $($rr.Item.Name) [Segmentos bloqueados (403 CDN) - Omitido]" -ForegroundColor DarkGray
    }
}
Write-Host ("   [OK] Toda la TDT España integrada: +{0} canales adicionales abiertos y autonómicos con segmentos verificados." -f $tdtAddedCount) -ForegroundColor Green

# -------------------------------------------------------------
# 3.9 SINCRONIZACION Y VERIFICACION DE LISTAS IPTV (iptv-sources.json)
# -------------------------------------------------------------
function Clean-IptvMetadataText([string]$Text) {
    if ([string]::IsNullOrWhiteSpace($Text)) { return "" }
    $t = $Text -replace '[\x00-\x1F\x7F<>''"]', ' '
    return ($t -replace '\s{2,}', ' ').Trim()
}

function Test-IsIptvEntryExcluded([string]$RawName, [string]$GroupTitle) {
    if ([string]::IsNullOrWhiteSpace($RawName)) { return $true }
    if ($RawName -match '[░▒▓█▼●]' -or $RawName -match '(?i)\binfo(?:\s*[ᴴH]?[ᴰD]?)?\s*$' -or $RawName -match '^(?:\*{2,}|={2,}|-{3,})') {
        return $true
    }
    if ($GroupTitle -match '(?i)^ES\s*-\s*(?:REPLAY|REPECTICI[OÓ]N)') {
        return $true
    }
    if ($RawName -match '(?i)^Replay\b') { return $true }
    if ($RawName -match '(?i)\bF1TV\s+LIVE\s+AUDIO\s+(?:ENG|FR|NL|PT|DE|IT)\b') { return $true }
    return $false
}

function Format-ClearChannelTitleCase([string]$Text) {
    if ([string]::IsNullOrWhiteSpace($Text)) { return "" }
    $upperAcronyms = @('M+','DAZN','F1','F1TV','TV','TVE','RTVE','TDT','VIP','HD','FHD','UHD','SD','HEVC','H.265','HDR','4K','1080P','720P','576P','480P','360P','2RFEF','RFEF','FEF','BBC','AMC','AXN','SYFY','COSMO','TCM','XTRM','VH1','MTV','DMAX','DKISS','FDF','TEN','WWE','AEW','UFC','WRC','WTA','ATP','CNN','ESPN','TSN','USA','FOX','TBS','CBS','NBC','ABC','NBA','NFL','NHL','ACB','UEFA','FIFA','TUDN','DSPORTS','TNT','3/24','7TV','7RM','IB3','TPA','CMM','ETB','TVG','TV3','CAT','ES','UK','FR','DE','IT','PT','TV3CAT')
    $lowerWords = @('de','del','la','las','el','los','y','e','en','a','con','por','para','vs','al')
    $isAllCaps = ($Text -ceq $Text.ToUpperInvariant()) -or ($Text -match '^[A-Z0-9\s\+\-\(\)\/&\.]+$')
    if ($isAllCaps) {
        $tokens = $Text -split '(\s+)'
        $out = [System.Text.StringBuilder]::new()
        $wordIdx = 0
        foreach ($tok in $tokens) {
            if ($tok -match '^\s+$' -or -not $tok) { [void]$out.Append($tok); continue }
            $wordIdx++
            $core = $tok.Trim('(',')','[',']',',','.')
            if ($upperAcronyms -contains $core.ToUpperInvariant()) {
                [void]$out.Append($tok.ToUpperInvariant())
            } elseif ($core -match '^(?i)LALIGA\+?$') {
                $rep = if ($core -match '\+$') { 'LaLiga+' } else { 'LaLiga' }
                [void]$out.Append(($tok -replace '(?i)LALIGA\+?', $rep))
            } elseif ($core -match '^(?i)M\+$') {
                [void]$out.Append(($tok -replace '(?i)M\+', 'M+'))
            } elseif ($wordIdx -gt 1 -and ($lowerWords -contains $core.ToLowerInvariant())) {
                [void]$out.Append($tok.ToLowerInvariant())
            } else {
                $lo = $tok.ToLowerInvariant()
                if ($lo -match '^([^a-záéíóúñ]*)([a-záéíóúñ])(.*)$') {
                    [void]$out.Append($Matches[1] + $Matches[2].ToUpperInvariant() + $Matches[3])
                } else {
                    [void]$out.Append($lo)
                }
            }
        }
        $Text = $out.ToString()
    }
    return $Text
}

function Clean-IptvChannelName([string]$RawName) {
    $c = Clean-IptvMetadataText $RawName
    if (-not $c) { return "" }
    $c = $c -replace '^(?:\|?[A-Z]{2,3}\|\s*|ES◈\s*|◈\s*|F1TV\s*\|\s*|ZZ\s*\|\s*)', ''
    $c = $c -replace '^(?:ES|LAT)\s*\|\s*', ''
    $c = $c -replace '(?i)^\(\s*EN\s+PRUEBAS\s*\)\s*', ''
    $c = $c -replace '\s*-\s*En\s+pruebas\s*$', ''
    $c = $c -replace 'ᴴᴰ', 'HD'
    $c = $c -replace '(?i)\(\s*(?:SOLO\s*EVENTOS|ES|ESP|LINEAL|IPTV)\s*\)', ''
    $c = $c -replace '(?i)\s*\b(?:IPTV|LINEAL)\b(?=\s|$|\))', ''
    $c = $c -replace '(?i)\s*-\s*(HEVC|H\.?265)\s*$', ' ($1)'
    $c = $c -replace '(?i)^NFL\(B\)0*(\d+)\s*:?\s*(.*)$', 'NFL $1 $2'
    $c = $c -replace '\(\s*([^)]+?)\s*\)', '($1)'
    $c = $c -replace '\s*\(\s*\)\s*', ' '
    $c = ($c -replace '\s{2,}', ' ').Trim(' ', '-', '|', ':')
    if (-not $c) { return "" }
    $c = Format-ClearChannelTitleCase $c
    $c = [regex]::Replace($c, '(?i)\b(HEVC|H\.?265|FHD|UHD|HDR|HD|SD|4K|1080P|720P|576P|480P)\b', { param($m) $m.Value.ToUpperInvariant() })
    $c = $c -replace '(?i)\bMovistar\s+Plus\+', 'Movistar+'
    $c = $c -replace '(?i)\bM\+\s*LaLiga\s*TV\b', 'M+ LaLiga'
    $c = $c -replace '(?i)\bM\+\s*LaLiga\b', 'M+ LaLiga'
    $c = $c -replace '(?i)\bDAZN\s*LaLiga\b', 'DAZN LaLiga'
    $c = $c -replace '(?i)\bDAZN\s*Baloncesto\b', 'DAZN Baloncesto'
    $c = $c -replace '(?i)\bLaLiga\s*TV\s*Bar\b', 'LaLiga TV Bar'
    $c = $c -replace '(?i)\bM\+\s*Liga\s+(?:de\s+)?Campeones\b', 'M+ Liga de Campeones'
    $c = $c -replace '(?i)\bM\+\s*Deporte(?:s)?\s*(\d+)\b', 'M+ Deportes $1'
    $c = $c -replace '(?i)\bM\+\s*Deporte(?:s)?\b', 'M+ Deportes'
    $c = $c -replace '(?i)\bM\+\s*Acci[oó]n\b', 'M+ Acción'
    $c = $c -replace '(?i)\bM\+\s*Cine\s*Espanol\b', 'M+ Cine Español'
    $c = $c -replace '(?i)\bM\+\s*Cl[aá]sicos?\b', 'M+ Clásicos'
    $c = $c -replace '(?i)\bDAZN\s*Eventos?\s*0*(\d+)\b', 'DAZN Eventos $1'
    $c = $c -replace '(?i)\bLaLiga\+\s*Eventos?\s*0*(\d+)\b', 'LaLiga+ Eventos $1'
    $c = $c -replace '(?i)\bNBA\s*TV\s*0*(\d+)\b', 'NBA TV $1'
    $c = $c -replace '(?i)\bFANPLAYTV\b', 'FanPlayTV'
    $c = $c -replace '(?i)\b2RFEF\b', '2RFEF'
    $c = $c -replace '(?i)\bCanal\s*FlixOl[eé]\b', 'FlixOlé'
    $c = $c -replace '(?i)\bFlixOl[eé]\b', 'FlixOlé'
    $c = $c -replace '(?i)\bTorol[eé]\b', 'Torolé'
    $c = $c -replace '(?i)\bCazavisi[oó]n\b', 'Cazavisión'
    $c = $c -replace '(?i)\bSol\s*M[uú]sica\b', 'Sol Música'
    $c = $c -replace '(?i)\bLa\s*S[eé]ptima\b', 'La Séptima'
    $c = $c -replace '(?i)\bA3Series\b', 'Atreseries'
    $c = $c -replace '(?i)\bParamount\s*Channel\b', 'Paramount Network'
    $c = $c -replace '(?i)\bGol\s*Play\b', 'Gol Play'
    $c = $c -replace '(?i)\bTeledeporte\b', 'Teledeporte'
    $c = $c -replace '(?i)\bEsport\s*3\b', 'Esport3'
    $c = $c -replace '(?i)\bExtremadura\s*TV\b', 'Canal Extremadura'
    $c = $c -replace '(?i)\bDAZN\s*MotoGP\b', 'DAZN MotoGP'
    $c = $c -replace '(?i)\bEurosport\s*(\d+)\b', 'Eurosport $1'
    $c = $c -replace '(?i)\bDazn\s*Liga\s*F\b', 'DAZN Liga F'
    $c = $c -replace '(?i)\bOne\s*Toro\b', 'OneToro'
    $c = $c -replace '(?i)^Multideporte\b', 'M+ Multideporte'
    return ($c -replace '\s{2,}', ' ').Trim()
}

function Get-IptvQualityScore([string]$CleanName) {
    if ($CleanName -match '(?i)\b(?:4K|UHD)\b') { return 50 }
    if ($CleanName -match '(?i)\b(?:FHD|1080P?)\b') { return 40 }
    if ($CleanName -match '(?i)\b(?:HD|720P?)\b') { return 30 }
    if ($CleanName -match '(?i)\bSD\b') { return 10 }
    return 20
}

function Get-IptvSourceHint([string]$GroupTitle) {
    if ($GroupTitle -match '(?i)^ES\s*-\s*FORMULA\s*1') { return 'IPTV_F1_ES' }
    if ($GroupTitle -match '(?i)^ES\s*-\s*TDT') { return 'IPTV_TDT' }
    if ($GroupTitle -match '(?i)^ES\s*-\s*(?:FUTBOL|FEF\s*TV|LALIGA\+|SEGUNDA\s*FEDERACION)') { return 'IPTV_FUTBOL_ES' }
    if ($GroupTitle -match '(?i)^ES\s*-\s*(?:DAZN\s*(?:PREMIER|BUNDESLIGA|SERIE\s*A|LIGUE\s*1)|Liga\s*de\s*Campeones\s*Femenina)') { return 'Football' }
    if ($GroupTitle -match '(?i)^ES\s*-\s*(?:CINE|TAQUILLAS|NETFLIX|ESTRENOS|MoviStar\+?\s*(?:Estrenos|Series)|Netflix\s*(?:Estrenos|Series)|OnePlay|Apple\s*TV|PrimeVideo)') { return 'IPTV_CINE' }
    if ($GroupTitle -match '(?i)^ES\s*-\s*(?:CULTURA|ESTILO\s*DE\s*VIDA)') { return 'IPTV_CULTURA' }
    if ($GroupTitle -match '(?i)^ES\s*-\s*(?:NINOS|MUSICA)') { return 'IPTV_INFANTIL_MUSICA' }
    if ($GroupTitle -match '(?i)^ES\s*-\s*(?:DEPORTES|DAZN\s*EVENTOS|UFC|DAZN\s*FUTSAL|LIGA\s*ACB|DAZN\s*BALONCESTO)') { return 'IPTV_DEPORTES_ES' }
    if ($GroupTitle -match '(?i)^ES\s*-\s*NBA$') { return 'Basketball' }
    if ($GroupTitle -match '(?i)^(?:ES\s*-\s*)?NFL$') { return 'NFL' }
    return ''
}

function Invoke-IptvSourcesSync {
    if (-not $script:IptvSources -or $script:IptvSources.Count -eq 0) {
        $script:IptvStatus = "STANDBY"
        return
    }
    Write-Host "`n [+] Analizando y verificando fuentes externas sin VPN..." -ForegroundColor Cyan
    $totalLiveAdded = 0
    $totalRawParsed = 0
    $totalExcluded = 0
    $blockedByVpn403 = $false
    $globalSeenUrls = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    $existingNames = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($ex in $script:allChannels) { [void]$existingNames.Add($ex.Name) }

    for ($si = 0; $si -lt $script:IptvSources.Count; $si++) {
        $src = $script:IptvSources[$si]
        $srcLabel = if ($src.PSObject.Properties['name'] -and $src.name) { [string]$src.name } else { "Fuente_$si" }
        $uaStr = if ($src.PSObject.Properties['user_agent'] -and $src.user_agent) { [string]$src.user_agent } else { "TiviMate/4.7.0" }
        $isVpnReq = ($src.PSObject.Properties['vpn_required'] -and [bool]$src.vpn_required)
        if ($isVpnReq -and -not $esModoVpn) { continue }

        $m3uText = $script:Prefetched["IptvSrc_$si"]
        $httpStatus = 0
        if (-not $m3uText) {
            try {
                $resp = Invoke-WebRequest -Uri ([string]$src.url) -UserAgent $uaStr -UseBasicParsing -TimeoutSec 10 -ErrorAction Stop
                $httpStatus = [int]$resp.StatusCode
                if ($resp.RawContentStream) { $m3uText = [System.Text.Encoding]::UTF8.GetString($resp.RawContentStream.ToArray()) }
                elseif ($resp.Content -is [byte[]]) { $m3uText = [System.Text.Encoding]::UTF8.GetString($resp.Content) }
                else { $m3uText = [string]$resp.Content }
            } catch {
                try {
                    if ($_.Exception.Response) { $httpStatus = [int]([System.Net.HttpWebResponse]$_.Exception.Response).StatusCode }
                } catch {}
            }
        }
        if ([string]::IsNullOrWhiteSpace($m3uText) -or $m3uText -notmatch '#EXTINF') {
            if ($httpStatus -eq 403) {
                $blockedByVpn403 = $true
                Write-Host "   [!] Fuente '$srcLabel' bloqueada (HTTP 403): se requiere IP española residencial sin VPN." -ForegroundColor Yellow
            } else {
                Write-Host "   [!] Lista '$srcLabel' no disponible o vacía en este arranque." -ForegroundColor DarkYellow
            }
            continue
        }

        $groupedCandidates = @{}
        $curGroupTitle = ""
        $curRawName = ""
        $lines = $m3uText -split "`r?`n"
        foreach ($rawLine in $lines) {
            $line = $rawLine.Trim()
            if (-not $line) { continue }
            if ($line.StartsWith('#EXTINF', [System.StringComparison]::OrdinalIgnoreCase)) {
                $curGroupTitle = ""
                $curRawName = ""
                if ($line -match 'group-title="([^"]*)"') { $curGroupTitle = Clean-IptvMetadataText $Matches[1] }
                if ($line -match '^#EXTINF:[^,"]*(?:"[^"]*"[^,"]*)*,(.*)$') {
                    $curRawName = $Matches[1].Trim()
                } elseif ($line -match '^#EXTINF:[^,]*,(.*)$') {
                    $curRawName = $Matches[1].Trim()
                }
                continue
            }
            if ($line.StartsWith('#')) { continue }
            if (-not $curRawName) { continue }

            $totalRawParsed++
            $streamUrl = $line
            $entryGroup = $curGroupTitle
            $entryName = $curRawName
            $curGroupTitle = ""
            $curRawName = ""

            if (-not (Test-IsSafeHttpUrl $streamUrl)) { continue }
            if (-not $globalSeenUrls.Add($streamUrl)) { continue }

            if (Test-IsIptvEntryExcluded -RawName $entryName -GroupTitle $entryGroup) {
                $totalExcluded++
                continue
            }

            $cleanName = Clean-IptvChannelName $entryName
            if (-not $cleanName) { continue }
            $hint = Get-IptvSourceHint $entryGroup
            $mappedGroup = Get-ChannelGroup $cleanName $hint
            $qScore = Get-IptvQualityScore $entryName
            $baseNorm = ($cleanName -replace '\s{2,}', ' ').Trim().ToLowerInvariant()
            if (-not $baseNorm) { $baseNorm = $cleanName.ToLowerInvariant() }
            $dedupKey = "$mappedGroup|$baseNorm"

            if (-not $groupedCandidates.ContainsKey($dedupKey)) {
                $groupedCandidates[$dedupKey] = [PSCustomObject]@{
                    Group       = $mappedGroup
                    IsLinear    = $true
                    VpnRequired = $isVpnReq
                    UserAgent   = $uaStr
                    RawCands    = [System.Collections.Generic.List[object]]::new()
                }
            }
            $groupedCandidates[$dedupKey].RawCands.Add([PSCustomObject]@{
                CleanName = $cleanName
                Url       = $streamUrl
                Score     = $qScore
            })
        }

        $srcAdded = 0
        foreach ($kv in $groupedCandidates.GetEnumerator()) {
            $gItem = $kv.Value
            $sortedCands = @($gItem.RawCands | Sort-Object Score -Descending)
            $primary = $sortedCands[0]
            $fbUrl = $primary.Url
            foreach ($alt in $sortedCands) {
                if ($alt.Url -ne $primary.Url) { $fbUrl = $alt.Url; break }
            }

            $outName = $primary.CleanName
            if (-not $existingNames.Add($outName)) {
                $optIdx = 2
                $addedOpt = $false
                while ($optIdx -le 15) {
                    $candOptName = "$($primary.CleanName) (Opción $optIdx)"
                    if ($existingNames.Add($candOptName)) {
                        $outName = $candOptName
                        $addedOpt = $true
                        break
                    }
                    $optIdx++
                }
                if (-not $addedOpt) { continue }
            }
            $idClean = ($outName -replace '[^a-zA-Z0-9]', '')
            if ($idClean.Length -gt 24) { $idClean = $idClean.Substring(0, 24) }
            $srcAdded++
            $script:allChannels += [PSCustomObject]@{
                Id          = "iptv_${si}_${srcAdded}_$idClean"
                Name        = $outName
                Group       = $gItem.Group
                Slug        = "iptv_solana"
                MasterUrl   = $primary.Url
                FallbackUrl = $fbUrl
                VpnRequired = $gItem.VpnRequired
                IsLinear    = $true
                IsIptv      = $true
            }
        }
        $totalLiveAdded += $srcAdded
        Write-Host ("   [OK] '{0}': {1} entradas -> +{2} canales unicos conservando calidades/codecs (sin purga)" -f $srcLabel, $totalRawParsed, $srcAdded) -ForegroundColor Green
    }

    $script:IptvStatus = if ($totalLiveAdded -gt 0) { "ONLINE (+$totalLiveAdded directos)" } elseif ($blockedByVpn403) { "BLOCKED_VPN_OR_403" } else { "OFFLINE" }
}

Enter-ScanPhase 'Iptv' $esModoVpn
Invoke-IptvSourcesSync

$usedPhase2Scan = $false
if ($isTwoPhaseAuto) {
    Show-ScanProgressBar 100
    Disable-QuietScanMode
    $script:ScanTimer.Stop()
    $p1Total = $allChannels.Count
    Write-Host ("  [OK] Fase 1 completada: {0} canales sin VPN." -f $p1Total) -ForegroundColor Green

    $wantPhase2 = Wait-VpnConnectForPhase2
    if ($wantPhase2) {
        $esModoVpn = $true
        $usedPhase2Scan = $true
        if ($global:BlockedHosts) { $global:BlockedHosts.Clear() }
        $script:IsPhase2Only = $true
        Reset-ScanProgressState "Buscando canales que necesitan VPN (Fase 2/2)"
        Enable-QuietScanMode
        $script:ScanTimer.Start()
        Enter-ScanPhase 'Prefetch2' $true
        Invoke-PrefetchBatch @(Get-VpnPrefetchTargets)
    } else {
        $esModoVpn = $false
        Enable-QuietScanMode
    }
}

# -------------------------------------------------------------
# 4. ESCANEO DE SERVIDORES Y CANALES EXCLUSIVOS DE VPN
# -------------------------------------------------------------
if ($esModoVpn) {
    Write-Host "`n [+] Sincronizando servidores y canales que requieren VPN..." -ForegroundColor Cyan

    # Descubrimiento anticipado de host VIP España activo (desde pre-descarga paralela)
    $workingStreamxHost = $null
    if ($script:Prefetched["ProbeSx723"]) {
        $workingStreamxHost = "streamx723.sbs"
        $global:ActiveStreamxHost = "streamx723.sbs"
    } elseif ($script:Prefetched["ProbeSx061"]) {
        $workingStreamxHost = "streamx061.sbs"
        $global:ActiveStreamxHost = "streamx061.sbs"
    } else {
        $streamxCandidates = @("streamx723.sbs", $global:ActiveStreamxHost, "streamx061.sbs") | Select-Object -Unique
        foreach ($candHost in $streamxCandidates) {
            if (-not $candHost -or ($global:BlockedHosts -and $global:BlockedHosts.ContainsKey($candHost))) { continue }
            $probeTxt = Get-Utf8Content -Uri "https://$candHost/global3.php?channel=mlaliga" -Referer "https://cdplay.live/" -TimeoutSec 2
            if ($probeTxt) {
                $workingStreamxHost = $candHost
                $global:ActiveStreamxHost = $candHost
                break
            }
        }
    }

    # 3.1 Servidor Capo Deportes / CDPlay + Extracción Directa CandyShop CDN (PARALELO)
    Enter-ScanPhase 'CdPlay' $esModoVpn
    Write-Host "   [*] Explorando servidor raíz de televisión deportiva y tokens CandyShop (CA / H)..." -ForegroundColor DarkCyan
    $cdHtml = if ($script:Prefetched["CdHtml"]) { $script:Prefetched["CdHtml"] } else { Get-Utf8Content -Uri "https://cdplay.live/" -TimeoutSec 4 }
    if ($cdHtml) {
        $cdWorkItems = [System.Collections.Generic.List[PSCustomObject]]::new()
        $blocks = [regex]::Matches($cdHtml, '(?s)<li><a href="#">([^<]+)<\/a>\s*<ul>([\s\S]*?)<\/ul>\s*<\/li>')
        foreach ($blk in $blocks) {
            $categoryTitle = $blk.Groups[1].Value.Trim()
            $optionsHtml = $blk.Groups[2].Value
            $optMatches = [regex]::Matches($optionsHtml, '<a href="([^"]+\.php)">([^<]+)<\/a>')

            foreach ($om in $optMatches) {
                $relPath = $om.Groups[1].Value.Trim()
                $optLabel = $om.Groups[2].Value.Trim()
                $finalUrl = "https://cdplay.live" + $relPath

                $chName = $null
                if ($categoryTitle -match '(?i)Formula\s*1') {
                    $chName = "__DAZN_F1__"
                } elseif ($categoryTitle -match '(?i)Capo\s*Deportes\s*2') {
                    $chName = "Capo Deportes 2 HD (Eventos En Vivo)"
                } elseif ($categoryTitle -match '(?i)Capo\s*Deportes') {
                    $chName = "Capo Deportes HD (España / Deportes)"
                } elseif ($categoryTitle -match '(?i)DSPORTS\s*2') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "DSPORTS 2 HD" } else { "DSPORTS 2 SD" }
                } elseif ($categoryTitle -match '(?i)DSPORTS\s*\+') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "DSPORTS + HD" } else { "DSPORTS + SD" }
                } elseif ($categoryTitle -match '(?i)DSPORTS') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "DSPORTS HD (DirecTV Sports)" } else { "DSPORTS SD (DirecTV Sports)" }
                } elseif ($categoryTitle -match '(?i)ESPN\s*Premium') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "ESPN Premium HD (Argentina)" } else { "ESPN Premium SD (Argentina)" }
                } elseif ($categoryTitle -match '(?i)ESPN\s*Deportes') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "ESPN Deportes HD" } else { "ESPN Deportes SD" }
                } elseif ($categoryTitle -match '(?i)ESPN\s*(\d+)') {
                    $num = [regex]::Match($categoryTitle, '(?i)ESPN\s*(\d+)').Groups[1].Value
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "ESPN $num HD" } else { "ESPN $num SD" }
                } elseif ($categoryTitle -match '(?i)ESPN') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "ESPN HD" } else { "ESPN SD" }
                } elseif ($categoryTitle -match '(?i)Liga\s*1\s*Max') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "Liga 1 Max HD" } else { "Liga 1 Max SD" }
                } elseif ($categoryTitle -match '(?i)TNT\s*Sports.*Argentina') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "TNT Sports HD (Argentina)" } else { "TNT Sports SD (Argentina)" }
                } elseif ($categoryTitle -match '(?i)TNT\s*Sports.*Chile') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "TNT Sports HD (Chile)" } else { "TNT Sports SD (Chile)" }
                } elseif ($categoryTitle -match '(?i)TUDN') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "TUDN HD" } else { "TUDN SD" }
                } elseif ($categoryTitle -match '(?i)Telemundo') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "Telemundo USA HD" } else { "Telemundo USA SD" }
                } elseif ($categoryTitle -match '(?i)Universo') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "Universo USA HD" } else { "Universo USA SD" }
                } elseif ($categoryTitle -match '(?i)Win\s*Sports\s*\+') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "Win Sports + HD" } else { "Win Sports + SD" }
                } elseif ($categoryTitle -match '(?i)Win\s*Sports') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "Win Sports HD" } else { "Win Sports SD" }
                } else {
                    $chName = Translate-ToSpanish $categoryTitle
                    if ($relPath -match 'hd' -or $optLabel -match 'HD') { $chName += " HD" }
                }
                if ($chName -ne "__DAZN_F1__" -and (Test-IsExcludedSport -Name $chName)) {
                    $script:SkippedSportsCount++
                    continue
                }
                $cdWorkItems.Add([PSCustomObject]@{
                    FinalUrl = $finalUrl
                    ChName   = $chName
                    WxHost   = $workingStreamxHost
                })
            }
        }

        $cdResults = Invoke-ParallelItems -Items @($cdWorkItems) -ScriptBlock {
            param($it)
            try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
            if ($it.WxHost) { $global:ActiveStreamxHost = $it.WxHost }
            $resolvedMaster = $it.FinalUrl
            $hlsVerified = $false
            $skipDead = $false
            $isCandy = $false

            $pageHtml = Get-Utf8Content -Uri $it.FinalUrl -Referer "https://cdplay.live/" -TimeoutSec 3
            if ($pageHtml -and $pageHtml -match '<iframe[^>]+src=["'']([^"'']+)["'']') {
                $innerIframe = $Matches[1].Trim()
                if ($innerIframe -match 'capopro\.php\?stream=|104game\.click/player/capo2/|hlsspanich\.php\?stream=|livetvfx\.php\?stream=|xstream\.st/') {
                    $candyHls = Resolve-CapoCandyShop -IframeUrl $innerIframe -Referer "https://cdplay.live/"
                    if ($candyHls) {
                        $resolvedMaster = $candyHls; $hlsVerified = $true; $isCandy = $true
                    } else { $skipDead = $true }
                } elseif ($innerIframe -match 'streamx[a-z0-9]+\.sbs/global[13]\.php\?channel=([^&\s]+)') {
                    $sxSlug = $Matches[1]
                    $sxHls = $null
                    if ($it.WxHost) { $sxHls = Resolve-StreamxNodeUrl -ChannelSlug $sxSlug -HostDomain $it.WxHost -Referer "https://cdplay.live/" }
                    if (-not $sxHls) { $sxHls = Resolve-StreamXhdUrl -LivePageUrl "https://streamxhd.click/live1.php?stream=$sxSlug" -Referer "https://cdplay.live/" }
                    if (-not $sxHls) { $sxHls = Resolve-Tvf90Url -StreamSlug $sxSlug -Referer "https://cdplay.live/" }
                    if ($sxHls) { $resolvedMaster = $sxHls; $hlsVerified = $true } else { $skipDead = $true }
                } elseif ($innerIframe -match 'streamxhd\.click/channel/\?id=([a-zA-Z0-9_-]+)') {
                    $idSlug = $Matches[1]
                    $xhdHls = Resolve-StreamXhdUrl -LivePageUrl "https://streamxhd.click/live1.php?stream=$idSlug" -Referer "https://cdplay.live/"
                    if (-not $xhdHls) { $xhdHls = Resolve-Tvf90Url -StreamSlug $idSlug -Referer "https://cdplay.live/" }
                    if ($xhdHls) { $resolvedMaster = $xhdHls; $hlsVerified = $true } else { $resolvedMaster = $innerIframe }
                } elseif ($innerIframe -match 'tvf90\.com/|embedme\.st/(?:play|player)/') {
                    $emHls = Resolve-EmbedAnyUrl -Url $innerIframe -Referer "https://cdplay.live/"
                    if ($emHls) { $resolvedMaster = $emHls; $hlsVerified = $true } else { $resolvedMaster = $innerIframe }
                } elseif ($innerIframe -match '^https?://') {
                    $innerHost = Get-HostKey $innerIframe
                    if ($innerHost -and $global:BlockedHosts -and $global:BlockedHosts.ContainsKey($innerHost)) {
                        $skipDead = $true
                    } elseif ($innerHost) {
                        $resolvedMaster = $innerIframe
                    }
                }
            }
            [PSCustomObject]@{ Item = $it; MasterUrl = $resolvedMaster; HlsVerified = $hlsVerified; SkipDead = $skipDead; IsCandy = $isCandy }
        }

        foreach ($cr in $cdResults) {
            if ($cr.SkipDead) {
                $finalizedEvents += [PSCustomObject]@{ Name = $cr.Item.ChName; Url = $cr.Item.FinalUrl; Reason = "Canal CDPlay sin segmentos activos (404)" }
                continue
            }
            if ($cr.IsCandy) { $script:CandyShopActiveCount++ }
            if ($cr.Item.ChName -eq "__DAZN_F1__") {
                $f1Source = if ($cr.MasterUrl -match 'candyshop\.st') { "candyshop" } else { "cdplay" }
                $daznF1Feeds.Add([PSCustomObject]@{ Url = $cr.MasterUrl; Fallback = $cr.Item.FinalUrl; Source = $f1Source; Verified = $cr.HlsVerified })
                continue
            }
            if (-not ($allChannels | Where-Object { $_.Name -eq $cr.Item.ChName })) {
                $allChannels += [PSCustomObject]@{
                    Id          = "cd_" + ($cr.Item.ChName -replace '[^a-zA-Z0-9]','')
                    Name        = $cr.Item.ChName
                    Group       = Get-ChannelGroup $cr.Item.ChName
                    Slug        = "cdplay"
                    MasterUrl   = $cr.MasterUrl
                    FallbackUrl = $cr.Item.FinalUrl
                    VpnRequired = $true
                }
                Write-Host "   [+] $($cr.Item.ChName) " -NoNewline -ForegroundColor Green
                if ($cr.HlsVerified -and $cr.MasterUrl -match 'candyshop\.st') {
                    Write-Host "[HLS Verificado CandyShop | Necesita VPN]" -ForegroundColor DarkGreen
                } elseif ($cr.HlsVerified) {
                    Write-Host "[HLS Verificado | Necesita VPN]" -ForegroundColor DarkGreen
                } else {
                    Write-Host "[Embed Verificado | Necesita VPN]" -ForegroundColor Red
                }
            }
        }
    } else {
        Write-Host "       (Servidor raíz de TV deportiva no accesible en esta red)." -ForegroundColor DarkGray
    }

    # 3.2 Canales Oficiales de Televisión y Deportes de España (Sondeo Multi-Servidor PARALELO)
    Write-Host "`n   [*] Sincronizando canales VIP España multi-servidor (streamx / streamxhd / tvf90-ftlly)..." -ForegroundColor DarkCyan
    if ($workingStreamxHost) {
        $script:SpanishVipStatus = "ONLINE ($workingStreamxHost + streamxhd + ftlly)"
        Write-Host "       [+] Nodo VIP España conectado: $workingStreamxHost (respaldos: streamxhd.click, tvf90.com)" -ForegroundColor DarkGreen
    } else {
        $script:SpanishVipStatus = "FALLBACK_MIRRORS (streamxhd + ftlly)"
        Write-Host "       [!] Nodo principal $($global:ActiveStreamxHost) no accesible; sondeando respaldos streamxhd y tvf90..." -ForegroundColor Yellow
    }

    $spanishChannels = @(
        @{ Name = "DAZN MotoGP España"; Code = "daznmotogp"; Aliases = @("daznmotogp", "motogp"); Group = "MotoGP España" },
        @{ Name = "M+ LaLiga"; Code = "mlaliga"; Aliases = @("mlaliga"); Group = "Fútbol España" },
        @{ Name = "DAZN LaLiga"; Code = "daznlaliga"; Aliases = @("daznlaliga"); Group = "Fútbol España" },
        @{ Name = "M+ LaLiga 2"; Code = "mlaliga2"; Aliases = @("mlaliga2"); Group = "Fútbol España" },
        @{ Name = "M+ LaLiga 3"; Code = "mlaliga3"; Aliases = @("mlaliga3"); Group = "Fútbol España" },
        @{ Name = "DAZN LaLiga 2"; Code = "daznlaliga2"; Aliases = @("daznlaliga2"); Group = "Fútbol España" },
        @{ Name = "LaLiga Hypermotion"; Code = "hypermotion"; Aliases = @("hypermotion", "laligahypermotion"); Group = "Fútbol España" },
        @{ Name = "LaLiga TV Bar"; Code = "laligabar"; Aliases = @("laligabar", "laligatvbar"); Group = "Fútbol España" },
        @{ Name = "M+ Liga de Campeones"; Code = "champions"; Aliases = @("champions", "mligadecampeones", "mcampeones"); Group = "Fútbol España" },
        @{ Name = "M+ Liga de Campeones 2"; Code = "mligadecampeones2"; Aliases = @("mligadecampeones2", "mcampeones2"); Group = "Fútbol España" },
        @{ Name = "M+ Liga de Campeones 3"; Code = "mligadecampeones3"; Aliases = @("mligadecampeones3", "mcampeones3"); Group = "Fútbol España" },
        @{ Name = "DAZN 1 España"; Code = "dazn1"; Aliases = @("dazn1"); Group = "Deportes España" },
        @{ Name = "DAZN 2 España"; Code = "dazn2"; Aliases = @("dazn2"); Group = "Deportes España" },
        @{ Name = "DAZN 3 España"; Code = "dazn3"; Aliases = @("dazn3"); Group = "Deportes España" },
        @{ Name = "DAZN 4 España"; Code = "dazn4"; Aliases = @("dazn4"); Group = "Deportes España" },
        @{ Name = "Movistar Plus+"; Code = "mplus"; Aliases = @("mplus", "movistarplus"); Group = "Deportes España" },
        @{ Name = "Movistar+ Deportes"; Code = "mdeportes"; Aliases = @("mdeportes"); Group = "Deportes España" },
        @{ Name = "Movistar+ Deportes 2"; Code = "mdeportes2"; Aliases = @("mdeportes2"); Group = "Deportes España" },
        @{ Name = "Movistar+ Vamos"; Code = "vamos"; Aliases = @("vamos", "mvamos"); Group = "Deportes España" },
        @{ Name = "Movistar+ Golf"; Code = "mgolf"; Aliases = @("mgolf"); Group = "Deportes España" },
        @{ Name = "Eurosport 1 España"; Code = "eurosport1"; Aliases = @("eurosport1", "eurosport"); Group = "Deportes España" },
        @{ Name = "Eurosport 2 España"; Code = "eurosport2"; Aliases = @("eurosport2"); Group = "Deportes España" },
        @{ Name = "Gol Play España (TDT)"; Code = "gol"; Aliases = @("gol", "golplay"); Group = "TDT España" }
    )

    $vipResultMap = @{}
    foreach ($sc in $spanishChannels) {
        $vipResultMap[$sc.Code] = [PSCustomObject]@{
            Sc           = $sc
            DirectStream = $null
            WrapUrl      = "https://$($global:ActiveStreamxHost)/global3.php?channel=$($sc.Code)"
            HitBackend   = ""
        }
    }

    # Etapa A: StreamX (alias primario y secundario en paralelo entre 48 hilos)
    Enter-ScanPhase 'EsStageA' $esModoVpn
    if ($workingStreamxHost) {
        $stageAItems = @($spanishChannels | ForEach-Object { [PSCustomObject]@{ Sc = $_; WxHost = $workingStreamxHost } })
        $stageARes = Invoke-ParallelItems -Items $stageAItems -ScriptBlock {
            param($it)
            try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
            foreach ($alias in $it.Sc.Aliases) {
                $uSx = Resolve-StreamxNodeUrl -ChannelSlug $alias -HostDomain $it.WxHost
                if ($uSx) {
                    return [PSCustomObject]@{
                        Code         = $it.Sc.Code
                        DirectStream = $uSx
                        WrapUrl      = "https://$($it.WxHost)/global3.php?channel=$alias"
                        HitBackend   = $it.WxHost
                    }
                }
            }
            return $null
        }
        foreach ($r in $stageARes) {
            if ($r -and $r.DirectStream -and $vipResultMap.ContainsKey($r.Code)) {
                $cur = $vipResultMap[$r.Code]
                $cur.DirectStream = $r.DirectStream
                $cur.WrapUrl      = $r.WrapUrl
                $cur.HitBackend   = $r.HitBackend
            }
        }
    }

    # Etapa B: StreamXHD (solo los canales no resueltos en Etapa A)
    Enter-ScanPhase 'EsStageB' $esModoVpn
    $missingAfterA = @($spanishChannels | Where-Object { -not $vipResultMap[$_.Code].DirectStream })
    if ($missingAfterA.Count -gt 0) {
        $stageBItems = @($missingAfterA | ForEach-Object { [PSCustomObject]@{ Sc = $_ } })
        $stageBRes = Invoke-ParallelItems -Items $stageBItems -ScriptBlock {
            param($it)
            try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
            foreach ($alias in $it.Sc.Aliases) {
                $xhdPage1 = "https://streamxhd.click/live1.php?stream=$alias"
                $uXhd = Resolve-StreamXhdUrl -LivePageUrl $xhdPage1
                if ($uXhd) {
                    return [PSCustomObject]@{
                        Code         = $it.Sc.Code
                        DirectStream = $uXhd
                        WrapUrl      = $xhdPage1
                        HitBackend   = "streamxhd/live1"
                    }
                }
            }
            return $null
        }
        foreach ($r in $stageBRes) {
            if ($r -and $r.DirectStream -and $vipResultMap.ContainsKey($r.Code)) {
                $cur = $vipResultMap[$r.Code]
                $cur.DirectStream = $r.DirectStream
                $cur.WrapUrl      = $r.WrapUrl
                $cur.HitBackend   = $r.HitBackend
            }
        }
    }

    # Etapa C: TVF90 alias primario (solo los canales aun sin resolver)
    Enter-ScanPhase 'EsStageC' $esModoVpn
    $missingAfterB = @($spanishChannels | Where-Object { -not $vipResultMap[$_.Code].DirectStream })
    if ($missingAfterB.Count -gt 0) {
        $stageCItems = @($missingAfterB | ForEach-Object { [PSCustomObject]@{ Sc = $_ } })
        $stageCRes = Invoke-ParallelItems -Items $stageCItems -ScriptBlock {
            param($it)
            try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
            $primaryAlias = $it.Sc.Aliases[0]
            $uTvf = Resolve-Tvf90Url -StreamSlug $primaryAlias
            if ($uTvf) {
                return [PSCustomObject]@{
                    Code         = $it.Sc.Code
                    DirectStream = $uTvf
                    WrapUrl      = "https://tvf90.com/5.php?stream=$primaryAlias"
                    HitBackend   = "tvf90/ftlly"
                }
            }
            return $null
        }
        foreach ($r in $stageCRes) {
            if ($r -and $r.DirectStream -and $vipResultMap.ContainsKey($r.Code)) {
                $cur = $vipResultMap[$r.Code]
                $cur.DirectStream = $r.DirectStream
                $cur.WrapUrl      = $r.WrapUrl
                $cur.HitBackend   = $r.HitBackend
            }
        }
    }

    $vipResults = @($spanishChannels | ForEach-Object { $vipResultMap[$_.Code] })

    foreach ($vr in $vipResults) {
        $sc = $vr.Sc
        if ($vr.DirectStream) {
            foreach ($al in $sc.Aliases) { $script:VipSlugCache[$al.ToLowerInvariant()] = $vr.DirectStream }
            $script:VipSlugCache[$sc.Code.ToLowerInvariant()] = $vr.DirectStream
            if (-not ($allChannels | Where-Object { $_.Name -eq $sc.Name })) {
                $allChannels += [PSCustomObject]@{
                    Id          = "es_" + ($sc.Name -replace '[^a-zA-Z0-9]','')
                    Name        = $sc.Name
                    Group       = $sc.Group
                    Slug        = "es_" + $sc.Code
                    MasterUrl   = $vr.DirectStream
                    FallbackUrl = $vr.WrapUrl
                    VpnRequired = $true
                }
                Write-Host "   [+] $($sc.Name) [HLS Verificado ($($vr.HitBackend)) | Necesita VPN]" -ForegroundColor DarkGreen
            }
        } else {
            $finalizedEvents += [PSCustomObject]@{
                Name   = $sc.Name
                Url    = $vr.WrapUrl
                Reason = "Canal VIP sin emisión activa (404 off-air) - Se activará automáticamente al iniciar evento y re-ejecutar .bat"
            }
            Write-Host "   [-] $($sc.Name) [Sin emisión activa ahora (404 off-air) - Omitido]" -ForegroundColor DarkGray
        }
    }

    $f1Parallel = Invoke-ParallelItems -Items @("streamx", "streamxhd", "ftlly") -ScriptBlock {
        param($src)
        try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
        if ($src -eq "streamx" -and $global:ActiveStreamxHost) {
            $u = Resolve-StreamxNodeUrl -ChannelSlug "daznf1" -HostDomain $global:ActiveStreamxHost
            if ($u) { return [PSCustomObject]@{ Url = $u; Fallback = "https://$($global:ActiveStreamxHost)/global3.php?channel=daznf1"; Source = "streamx"; Verified = $true } }
        } elseif ($src -eq "streamxhd") {
            $u = Resolve-StreamXhdUrl -LivePageUrl "https://streamxhd.click/live1.php?stream=daznf1"
            if ($u) { return [PSCustomObject]@{ Url = $u; Fallback = "https://streamxhd.click/live1.php?stream=daznf1"; Source = "streamxhd"; Verified = $true } }
        } elseif ($src -eq "ftlly") {
            $u = Resolve-Tvf90Url -StreamSlug "daznf1"
            if ($u) { return [PSCustomObject]@{ Url = $u; Fallback = "https://tvf90.com/5.php?stream=daznf1"; Source = "ftlly"; Verified = $true } }
        }
        return $null
    }
    foreach ($f1f in $f1Parallel) {
        if ($f1f) { $daznF1Feeds.Add($f1f) }
    }

    # 3.3 Agenda Fútbol Libre (API JSON en tiempo real + Canales Base con Resolución de Iframe)
    Enter-ScanPhase 'FutbolLb' $esModoVpn
    Write-Host "`n   [*] Consultando API oficial de agenda de fútbol (diaries.json) y canales Fútbol Libre..." -ForegroundColor DarkCyan
    try {
        $flApiJson = if ($script:Prefetched["Diaries"]) { $script:Prefetched["Diaries"] } else { Get-Utf8Content -Uri "https://api.wqxag.com/diaries.json" -Referer "https://futbollibregol.org/" -TimeoutSec 5 }
        if ($flApiJson) {
            $script:FutbolLibreApiStatus = "ONLINE"
            $flParsed = $flApiJson | ConvertFrom-Json
            $flEvents = if ($flParsed -is [array]) { $flParsed } elseif ($flParsed.data) { $flParsed.data } else { @() }
            $limaTz = [TimeZoneInfo]::FindSystemTimeZoneById("SA Pacific Standard Time")
            $nowUtc = [DateTime]::UtcNow
            $addedDiaries = 0

            $flWorkItems = [System.Collections.Generic.List[PSCustomObject]]::new()
            foreach ($evItem in $flEvents) {
                $attr = if ($evItem.attributes) { $evItem.attributes } else { $evItem }
                $rawDate = if ($attr.date_diary) { [string]$attr.date_diary } elseif ($attr.date) { [string]$attr.date } elseif ($attr.fecha) { [string]$attr.fecha } else { "" }
                $rawHour = if ($attr.diary_hour) { [string]$attr.diary_hour } elseif ($attr.hour) { [string]$attr.hour } elseif ($attr.hora) { [string]$attr.hora } else { "" }
                $rawDesc = if ($attr.diary_description) { [string]$attr.diary_description } elseif ($attr.description) { [string]$attr.description } elseif ($attr.title) { [string]$attr.title } elseif ($attr.nombre) { [string]$attr.nombre } else { "" }
                if ([string]::IsNullOrWhiteSpace($rawDesc)) { continue }

                $cleanMatch = Translate-ToSpanish $rawDesc
                if (Test-IsExcludedSport -Name $cleanMatch -LeagueOrCategory $rawDesc) {
                    $script:SkippedSportsCount++
                    continue
                }
                $kickLocalTag = ""
                $eventExpired = $false
                $parsedUtc = $null

                if ($rawHour) {
                    try {
                        if ($rawHour -match 'T|Z') {
                            $parsedUtc = [DateTime]::Parse($rawHour).ToUniversalTime()
                        } elseif ($rawHour -match '^(\d{1,2}):(\d{2})') {
                            $hh = [int]$Matches[1]; $mm = [int]$Matches[2]
                            $baseLimaDate = [TimeZoneInfo]::ConvertTimeFromUtc($nowUtc, $limaTz).Date
                            if ($rawDate -match '^\d{4}-\d{2}-\d{2}') {
                                $baseLimaDate = [DateTime]::ParseExact($Matches[0], "yyyy-MM-dd", $null)
                            }
                            $todayLima = $baseLimaDate.AddHours($hh).AddMinutes($mm)
                            $parsedUtc = [TimeZoneInfo]::ConvertTimeToUtc($todayLima, $limaTz)
                            if (-not ($rawDate -match '^\d{4}-\d{2}-\d{2}')) {
                                if (($nowUtc - $parsedUtc).TotalHours -gt 16) {
                                    $parsedUtc = [TimeZoneInfo]::ConvertTimeToUtc($todayLima.AddDays(1), $limaTz)
                                } elseif (($parsedUtc - $nowUtc).TotalHours -gt 18) {
                                    $parsedUtc = [TimeZoneInfo]::ConvertTimeToUtc($todayLima.AddDays(-1), $limaTz)
                                }
                            }
                        }
                    } catch {}
                }

                $evWin = Get-AgendaEventWindowEvaluation -Title $cleanMatch -StartUtc $parsedUtc -SportHint $rawDesc
                if ($evWin.IsConcluded) {
                    $finalizedEvents += [PSCustomObject]@{ Name = $cleanMatch; Url = "https://futbollibregol.org/agenda"; Reason = $evWin.Reason }
                    continue
                }
                if ($parsedUtc -and $parsedUtc -gt $nowUtc.AddHours(24)) { continue }
                $kickLocalTag = $evWin.KickTag

                $embedsList = @()
                if ($attr.embeds) {
                    if ($attr.embeds.PSObject.Properties['data']) {
                        $embedsList = @($attr.embeds.data | Where-Object { $_ })
                    } else {
                        $embedsList = @($attr.embeds | Where-Object { $_ })
                    }
                }

                $optNum = 1
                foreach ($emb in $embedsList) {
                    $embAttr = if ($emb.attributes) { $emb.attributes } else { $emb }
                    $embUrl = if ($embAttr.embed_iframe) { [string]$embAttr.embed_iframe } elseif ($embAttr.url) { [string]$embAttr.url } elseif ($embAttr.link) { [string]$embAttr.link } else { "" }
                    $embName = if ($embAttr.embed_name) { [string]$embAttr.embed_name } elseif ($embAttr.name) { [string]$embAttr.name } elseif ($embAttr.nombre) { [string]$embAttr.nombre } else { "Opción $optNum" }
                    if ([string]::IsNullOrWhiteSpace($embUrl) -or $embUrl -eq "#") { continue }
                    if ($embName -match '(?i)espn|disney|tnt\s*sports|win\s*sports|vix|fox\s*sports|tudn|tyc|telemundo' -and $embName -notmatch 'Latino') {
                        $embName = "$embName · Latino"
                    } elseif ($embName -match '(?i)movistar|mlaliga|dazn\s*(?:es|laliga|[1-4]|f1)|vamos|campeones|hypermotion|gol\s*play' -and $embName -notmatch 'Castellano') {
                        $embName = "$embName · Castellano"
                    }

                    if ($embUrl -match '[?&]r=([A-Za-z0-9+/=\s]+)') {
                        try {
                            $b64Clean = ($Matches[1] -replace '\s', '')
                            $decoded = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($b64Clean))
                            if ($decoded -match '^https?://') { $embUrl = $decoded }
                        } catch {}
                    }
                    if ($embUrl -match '/drm/') { continue }
                    $isLiveNow = (-not $parsedUtc -or $parsedUtc -le $nowUtc)
                    $flWorkItems.Add([PSCustomObject]@{
                        MatchDisplay = "$cleanMatch$kickLocalTag ($embName)"
                        CleanMatch   = $cleanMatch
                        EmbUrl       = $embUrl
                        LiveNow      = $isLiveNow
                        StartsAtUtc  = $evWin.StartsAtUtcStr
                        EndsAtUtc    = $evWin.EndsAtUtcStr
                    })
                    $optNum++
                }
            }

            $flResolved = Invoke-ParallelItems -Items @($flWorkItems) -ScriptBlock {
                param($it)
                try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
                $resolved = $it.EmbUrl
                $drop = $false
                if ($it.EmbUrl -match '104game\.click/player/capo2/|capopro\.php\?stream=|livetvfx\.php\?stream=|hlsspanich\.php\?stream=|xstream\.st/|streamxhd\.click/|streamx[a-z0-9]+\.sbs/global[13]\.php|tvf90\.com/|embedme\.st/|\.m3u8(?:\?|$)') {
                    $deep = Resolve-EmbedAnyUrl -Url $it.EmbUrl -Referer "https://futbollibregol.org/"
                    if ($deep) { $resolved = $deep }
                    elseif ($it.EmbUrl -match '\.m3u8(?:\?|$)' -or $it.LiveNow) {
                        $drop = $true
                    }
                }
                [PSCustomObject]@{ Item = $it; Resolved = $resolved; Drop = $drop }
            }

            foreach ($fr in $flResolved) {
                if ($fr.Drop) { continue }
                if (-not ($allChannels | Where-Object { $_.Name -eq $fr.Item.MatchDisplay })) {
                    $flHint = if ($fr.Item.CleanMatch -match '(?i)\b(?:Tenis|Tennis|WTA|ATP|UFC|Boxeo|Golf|F1|MotoGP)\b') { "" } else { "Football" }
                    $allChannels += [PSCustomObject]@{
                        Id          = "fl_ev_" + ($fr.Item.MatchDisplay -replace '[^a-zA-Z0-9]','')
                        Name        = $fr.Item.MatchDisplay
                        Group       = Get-ChannelGroup $fr.Item.CleanMatch $flHint
                        Slug        = "futbollibre_event"
                        MasterUrl   = $fr.Resolved
                        FallbackUrl = $fr.Item.EmbUrl
                        VpnRequired = $true
                        StartsAtUtc = $fr.Item.StartsAtUtc
                        EndsAtUtc   = $fr.Item.EndsAtUtc
                    }
                    Write-Host "   [+] [Fútbol En Vivo] $($fr.Item.MatchDisplay) " -NoNewline -ForegroundColor Cyan
                    if ($fr.Resolved -match '\.m3u8') {
                        Write-Host "[HLS Verificado | Necesita VPN]" -ForegroundColor DarkGreen
                    } else {
                        Write-Host "[Necesita VPN]" -ForegroundColor Red
                    }
                    $addedDiaries++
                }
            }
            Write-Host "       [+] Agenda Fútbol Libre API: $($flEvents.Count) eventos analizados, $addedDiaries señales añadidas." -ForegroundColor DarkGreen
        }
    } catch {
        Write-Host "       [-] Aviso consultando API Fútbol Libre (L$($_.InvocationInfo.ScriptLineNumber)): $($_.Exception.Message)" -ForegroundColor DarkGray
    }

    # 3.3b Agenda Deportiva y Fútbol en Tiempo Real (streamxhd.click/eventos.json - PARALELO Y FILTRADO)
    Enter-ScanPhase 'StreamXhd' $esModoVpn
    Write-Host "`n   [*] Consultando agenda de fútbol y deportes (streamxhd.click/eventos.json)..." -ForegroundColor DarkCyan
    try {
        $xhdEvJson = if ($script:Prefetched["XhdEv"]) { $script:Prefetched["XhdEv"] } else { Get-Utf8Content -Uri "https://streamxhd.click/eventos.json" -Referer "https://streamxhd.click/" -TimeoutSec 5 }
        if ($xhdEvJson) {
            $script:StreamXhdStatus = "ONLINE"
            $xhdObj = $xhdEvJson | ConvertFrom-Json
            $limaTzX = [TimeZoneInfo]::FindSystemTimeZoneById("SA Pacific Standard Time")
            $nowUtcX = [DateTime]::UtcNow
            $xhdCandidateEvents = [System.Collections.Generic.List[PSCustomObject]]::new()
            $uniqueSrvUrls = [System.Collections.Generic.HashSet[string]]::new()

            foreach ($sp in $xhdObj.sports) {
                $spHint = switch ([string]$sp.id) {
                    "football"   { "Football" }
                    "basketball" { "Basketball" }
                    "nfl"        { "NFL" }
                    default      { "" }
                }
                foreach ($lg in $sp.leagues) {
                    foreach ($ev in $lg.events) {
                        $rawTitle = [string]$ev.title
                        if ([string]::IsNullOrWhiteSpace($rawTitle)) { continue }
                        $cleanEvTitle = Translate-ToSpanish $rawTitle

                        if (Test-IsExcludedSport -Name $cleanEvTitle -LeagueOrCategory ([string]$lg.name) -SportId ([string]$sp.id)) {
                            $script:SkippedSportsCount++
                            continue
                        }

                        $startUtcX = $null
                        $rawTime = [string]$ev.time
                        if ($rawTime) {
                            try {
                                if ($rawTime -match '[Zz]|[+-]\d{2}:\d{2}$') {
                                    $startUtcX = [DateTimeOffset]::Parse($rawTime, [System.Globalization.CultureInfo]::InvariantCulture).UtcDateTime
                                } elseif ($rawTime -match '^\d{4}-\d{2}-\d{2}\s+\d{1,2}:\d{2}') {
                                    $localEvDt = [DateTime]::Parse($rawTime, [System.Globalization.CultureInfo]::InvariantCulture)
                                    $startUtcX = [TimeZoneInfo]::ConvertTimeToUtc($localEvDt, $limaTzX)
                                }
                            } catch {}
                        }

                        $durMin = if ($ev.duration -and [int]$ev.duration -gt 0) { [int]$ev.duration } else { 0 }
                        if ($startUtcX -and $startUtcX -gt $nowUtcX.AddHours(24)) { continue }
                        $rawStX = if ($ev.status) { [string]$ev.status } else { "" }
                        $evWinX = Get-AgendaEventWindowEvaluation -Title $cleanEvTitle -StartUtc $startUtcX -ReportedDurationMinutes $durMin -SportHint ([string]$sp.id + " " + [string]$lg.name) -RawStatus $rawStX
                        if ($evWinX.IsConcluded) {
                            $finalizedEvents += [PSCustomObject]@{ Name = $cleanEvTitle; Url = "https://streamxhd.click/"; Reason = $evWinX.Reason }
                            continue
                        }

                        $kickTagX = $evWinX.KickTag
                        $isUpcomingX = $evWinX.Upcoming

                        foreach ($srv in $ev.servers) {
                            $srvUrl = [string]$srv.url
                            $srvName = [string]$srv.name
                            if ([string]::IsNullOrWhiteSpace($srvUrl)) { continue }
                            $srvLabel = $srvName.Trim()
                            if ($srvLabel -match '(?i)mlaliga|movistar|m\+\s*|dlaliga|dazn|hypermotion|gol\s*play|vamos|eurosport.*esp' -and $srvLabel -notmatch 'Castellano') {
                                $srvLabel += " · Castellano"
                            } elseif ($srvLabel -match '(?i)espn|disney|tnt\s*sports|win\s*sports|vix|fox\s*one|tudn|tyc|telemundo' -and $srvLabel -notmatch 'Latino') {
                                $srvLabel += " · Latino"
                            }
                            $null = $uniqueSrvUrls.Add($srvUrl)
                            $xhdCandidateEvents.Add([PSCustomObject]@{
                                Title       = $cleanEvTitle
                                DispName    = "$cleanEvTitle$kickTagX ($srvLabel)"
                                League      = [string]$lg.name
                                Hint        = $spHint
                                SrvUrl      = $srvUrl
                                Upcoming    = $isUpcomingX
                                StartsAtUtc = $evWinX.StartsAtUtcStr
                                EndsAtUtc   = $evWinX.EndsAtUtcStr
                            })
                        }
                    }
                }
            }

            $xhdStreamCache = @{}
            $resolvedSrv = Invoke-ParallelItems -Items @($uniqueSrvUrls) -ScriptBlock {
                param($u)
                try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
                $m3u = Resolve-StreamXhdUrl -LivePageUrl $u -Referer "https://streamxhd.click/"
                if (-not $m3u) { $m3u = Resolve-EmbedAnyUrl -Url $u -Referer "https://streamxhd.click/" }
                $pageOk = if (-not $m3u) { [bool](Get-Utf8Content -Uri $u -Referer "https://streamxhd.click/" -TimeoutSec 2) } else { $true }
                [PSCustomObject]@{ Url = $u; M3u = $m3u; PageOk = $pageOk }
            }
            foreach ($rs in $resolvedSrv) {
                $xhdStreamCache[$rs.Url] = $rs
            }

            $addedXhdEv = 0
            foreach ($ce in $xhdCandidateEvents) {
                $cached = $xhdStreamCache[$ce.SrvUrl]
                $masterXhd = if ($cached -and $cached.M3u) { $cached.M3u } elseif ($ce.Upcoming -and $cached -and $cached.PageOk) { $ce.SrvUrl } else { $null }
                if ($masterXhd -and -not ($allChannels | Where-Object { $_.Name -eq $ce.DispName })) {
                    $allChannels += [PSCustomObject]@{
                        Id          = "xhd_" + ($ce.DispName -replace '[^a-zA-Z0-9]','')
                        Name        = $ce.DispName
                        Group       = Get-ChannelGroup $ce.Title $ce.Hint
                        Slug        = "streamxhd_event"
                        MasterUrl   = $masterXhd
                        FallbackUrl = $ce.SrvUrl
                        VpnRequired = $true
                        StartsAtUtc = $ce.StartsAtUtc
                        EndsAtUtc   = $ce.EndsAtUtc
                    }
                    Write-Host "   [+] [Agenda StreamXHD · $($ce.League)] $($ce.DispName) " -NoNewline -ForegroundColor Cyan
                    if ($cached.M3u) { Write-Host "[HLS Verificado | Necesita VPN]" -ForegroundColor DarkGreen } else { Write-Host "[Programado | Necesita VPN]" -ForegroundColor Yellow }
                    $addedXhdEv++
                }
            }
            Write-Host "       [+] Agenda StreamXHD: $addedXhdEv señales activas/programadas sincronizadas." -ForegroundColor DarkGreen
        }
    } catch {
        Write-Host "       [-] Agenda StreamXHD no disponible: $($_.Exception.Message)" -ForegroundColor DarkGray
    }

    # 3.3c Agenda Castellano VIP (streamx723.sbs/json/agenda888.json -> Copa del Rey / LaLiga / Castellano directo HLS)
    Enter-ScanPhase 'CastVip' $esModoVpn
    Write-Host "`n   [*] Consultando agenda española Castellano (streamx agenda888.json)..." -ForegroundColor DarkCyan
    try {
        $sxHost888 = if ($global:ActiveStreamxHost) { $global:ActiveStreamxHost } else { "streamx723.sbs" }
        $ag888Txt = if ($sxHost888 -eq "streamx723.sbs" -and $script:Prefetched["Ag888"]) { $script:Prefetched["Ag888"] } else { Get-Utf8Content -Uri "https://$sxHost888/json/agenda888.json" -Referer "https://$sxHost888/" -TimeoutSec 5 }
        if ($ag888Txt) {
            $ag888List = $ag888Txt | ConvertFrom-Json
            $limaTz8 = [TimeZoneInfo]::FindSystemTimeZoneById("SA Pacific Standard Time")
            $nowUtc8 = [DateTime]::UtcNow
            $slugLabelMap = @{
                "mlaliga"       = "M+ LaLiga · Castellano"
                "mlaliga2"      = "M+ LaLiga 2 · Castellano"
                "dlaliga"       = "DAZN LaLiga · Castellano"
                "daznlaliga"    = "DAZN LaLiga · Castellano"
                "daznlaliga2"   = "DAZN LaLiga 2 · Castellano"
                "hypermotion"   = "LaLiga HyperMotion · Castellano"
                "mcampeones"    = "M+ Liga de Campeones · Castellano"
                "vamos"         = "#Vamos · Castellano"
                "mdeportes"     = "M+ Deportes · Castellano"
                "dazn1"         = "DAZN 1 España · Castellano"
                "dazn2"         = "DAZN 2 España · Castellano"
                "daznf1"        = "DAZN F1 España · Castellano"
                "gol"           = "Gol Play · Castellano"
                "espn"          = "ESPN · Latino"
                "espn2"         = "ESPN 2 · Latino"
                "espnplus1"     = "ESPN+ · Latino"
                "espnplus2"     = "ESPN+ 2 · Latino"
                "espndeportes"  = "ESPN Deportes · Latino"
                "disney1"       = "Disney+ · Latino"
                "disney2"       = "Disney+ 2 · Latino"
                "tntar"         = "TNT Sports AR · Latino"
                "tntsports"     = "TNT Sports · Latino"
            }
            $a8Cand = [System.Collections.Generic.List[PSCustomObject]]::new()
            $a8UniqueLinks = [System.Collections.Generic.HashSet[string]]::new()

            foreach ($ev in $ag888List) {
                $rawTitle = [string]$ev.title
                $rawLink = [string]$ev.link
                if ([string]::IsNullOrWhiteSpace($rawTitle) -or [string]::IsNullOrWhiteSpace($rawLink)) { continue }
                $cleanTitle8 = Translate-ToSpanish $rawTitle
                if (Test-IsExcludedSport -Name $cleanTitle8 -LeagueOrCategory ([string]$ev.category)) {
                    $script:SkippedSportsCount++
                    continue
                }
                $startUtc8 = $null
                if ($ev.date -and $ev.time) {
                    try {
                        $dtStr = "$($ev.date) $($ev.time)"
                        $local8 = [DateTime]::Parse($dtStr, [System.Globalization.CultureInfo]::InvariantCulture)
                        $startUtc8 = [TimeZoneInfo]::ConvertTimeToUtc($local8, $limaTz8)
                    } catch {}
                }
                $rawSt8 = if ($ev.status) { [string]$ev.status } else { "" }
                if ($startUtc8 -and $startUtc8 -gt $nowUtc8.AddHours(24)) { continue }
                $evWin8 = Get-AgendaEventWindowEvaluation -Title $cleanTitle8 -StartUtc $startUtc8 -SportHint ([string]$ev.category) -RawStatus $rawSt8
                if ($evWin8.IsConcluded) {
                    $finalizedEvents += [PSCustomObject]@{ Name = $cleanTitle8; Url = $rawLink; Reason = $evWin8.Reason }
                    continue
                }
                $kick8 = $evWin8.KickTag

                $chSlug8 = if ($rawLink -match 'channel=([a-zA-Z0-9_-]+)') { $Matches[1].ToLower() } else { "" }
                $lbl8 = if ($chSlug8 -and $slugLabelMap.ContainsKey($chSlug8)) { $slugLabelMap[$chSlug8] } elseif ($chSlug8) { $chSlug8 } else { "Stream" }
                $apiGlobal3 = if ($chSlug8) { "https://$sxHost888/global3.php?channel=$chSlug8" } else { $rawLink }
                $null = $a8UniqueLinks.Add($apiGlobal3)
                $a8Cand.Add([PSCustomObject]@{
                    Title       = $cleanTitle8
                    DispName    = "$cleanTitle8$kick8 ($lbl8)"
                    ApiUrl      = $apiGlobal3
                    Fallback    = $rawLink
                    Upcoming    = $evWin8.Upcoming
                    SlugCode    = $chSlug8
                    StartsAtUtc = $evWin8.StartsAtUtcStr
                    EndsAtUtc   = $evWin8.EndsAtUtcStr
                })
            }

            $a8Cache = @{}
            $a8NeedResolve = [System.Collections.Generic.List[string]]::new()
            foreach ($u in $a8UniqueLinks) {
                $cachedU = $null
                if ($u -match 'channel=([a-zA-Z0-9_-]+)') {
                    $cKey = $Matches[1].ToLowerInvariant()
                    if ($script:VipSlugCache.ContainsKey($cKey)) { $cachedU = $script:VipSlugCache[$cKey] }
                }
                if ($cachedU) { $a8Cache[$u] = $cachedU } else { $a8NeedResolve.Add($u) }
            }
            $a8Res = Invoke-ParallelItems -Items @($a8NeedResolve) -ScriptBlock {
                param($u)
                try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
                $m3u = $null
                $slug8 = if ($u -match 'channel=([a-zA-Z0-9_-]+)') { $Matches[1] } else { "" }
                if ($u -match 'https?://([^/]+)/global[13]\.php' -and $slug8) {
                    $m3u = Resolve-StreamxNodeUrl -ChannelSlug $slug8 -HostDomain $Matches[1] -Referer "https://cdplay.live/"
                } else {
                    $m3u = Resolve-StreamXhdUrl -LivePageUrl $u -Referer "https://cdplay.live/"
                }
                if (-not $m3u -and $slug8) {
                    $m3u = Resolve-StreamXhdUrl -LivePageUrl ("https://streamxhd.click/live1.php?stream=" + $slug8) -Referer "https://streamxhd.click/"
                }
                if (-not $m3u -and $slug8) {
                    $m3u = Resolve-Tvf90Url -StreamSlug $slug8
                }
                [PSCustomObject]@{ Url = $u; M3u = $m3u; Slug = $slug8 }
            }
            foreach ($ar in $a8Res) {
                $a8Cache[$ar.Url] = $ar.M3u
                if ($ar.M3u -and $ar.Slug -and -not $script:VipSlugCache.ContainsKey($ar.Slug.ToLowerInvariant())) {
                    $script:VipSlugCache[$ar.Slug.ToLowerInvariant()] = $ar.M3u
                }
            }

            $added888 = 0
            foreach ($c8 in $a8Cand) {
                $resolvedM3u = $a8Cache[$c8.ApiUrl]
                $finalM3u = if ($resolvedM3u) { $resolvedM3u } elseif ($c8.Upcoming) { $c8.Fallback } else { $null }
                if ($finalM3u -and -not ($allChannels | Where-Object { $_.MasterUrl -eq $finalM3u -and $_.Name -eq $c8.DispName }) -and -not ($allChannels | Where-Object { $_.Name -eq $c8.DispName })) {
                    $allChannels += [PSCustomObject]@{
                        Id          = "s888_" + ($c8.DispName -replace '[^a-zA-Z0-9]','')
                        Name        = $c8.DispName
                        Group       = Get-ChannelGroup "$($c8.Title) $($c8.SlugCode)" "Football"
                        Slug        = "agenda888"
                        MasterUrl   = $finalM3u
                        FallbackUrl = $c8.Fallback
                        VpnRequired = $true
                        StartsAtUtc = $c8.StartsAtUtc
                        EndsAtUtc   = $c8.EndsAtUtc
                    }
                    $color8 = if ($c8.DispName -match 'Castellano') { "Green" } else { "Cyan" }
                    Write-Host "   [+] [Agenda888] $($c8.DispName) " -NoNewline -ForegroundColor $color8
                    if ($resolvedM3u) { Write-Host "[HLS Verificado | Necesita VPN]" -ForegroundColor DarkGreen } else { Write-Host "[Programado | Necesita VPN]" -ForegroundColor Yellow }
                    $added888++
                }
            }
            Write-Host "       [+] Agenda888 Castellano/Deportes: $added888 señales sincronizadas." -ForegroundColor DarkGreen
        }
    } catch {
        Write-Host "       [-] Agenda888 no disponible: $($_.Exception.Message)" -ForegroundColor DarkGray
    }

    $flHtml = if ($script:Prefetched["FlHtml"]) { $script:Prefetched["FlHtml"] } else { Get-Utf8Content -Uri "https://futbollibregol.org/" -TimeoutSec 4 }
    if ($flHtml) {
        $flMatches = [regex]::Matches($flHtml, '<a[^>]+href="([^"]*en-vivo[^"]*)"[^>]*>([\s\S]*?)<\/a>')
        $flHtmlItems = [System.Collections.Generic.List[PSCustomObject]]::new()
        foreach ($fm in $flMatches) {
            $fUrl = $fm.Groups[1].Value.Trim()
            $rawText = ($fm.Groups[2].Value -replace '<[^>]+>', ' ' -replace '\s+', ' ').Trim()
            if ($rawText -match '(?i)^ver\s*canal$') {
                $slugPart = ($fUrl -replace '^.*/en-vivo/', '' -replace '-online/?$', '' -replace '/$', '')
                $rawText = (Get-Culture).TextInfo.ToTitleCase(($slugPart -replace '-', ' '))
                $rawText = $rawText -replace '\bPlus\b', '+' -replace '(?i)\bDirectv\s*Sports\b', 'DSports' -replace '(?i)\bDirectv\b', 'DSports'
            }
            $fTitle = Translate-ToSpanish $rawText
            if (Test-IsExcludedSport -Name $fTitle) { $script:SkippedSportsCount++; continue }
            if ($fTitle.Length -gt 2 -and -not ($flHtmlItems | Where-Object { $_.Title -eq $fTitle }) -and -not ($allChannels | Where-Object { $_.Name -eq $fTitle })) {
                if ($fUrl -notmatch '^https?://') { $fUrl = "https://futbollibregol.org" + $fUrl }
                $flHtmlItems.Add([PSCustomObject]@{ Title = $fTitle; Url = $fUrl })
                if ($flHtmlItems.Count -ge 15) { break }
            }
        }

        $flHtmlRes = Invoke-ParallelItems -Items @($flHtmlItems) -ScriptBlock {
            param($it)
            try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
            $flMaster = $it.Url
            $keep = $true
            $flPage = Get-Utf8Content -Uri $it.Url -Referer "https://futbollibregol.org/" -TimeoutSec 3
            if (-not $flPage) {
                $keep = $false
            } elseif ($flPage -match '<iframe[^>]+src=["'']([^"'']+)["'']') {
                $rawIfr = $Matches[1].Trim()
                $deepFl = Resolve-EmbedAnyUrl -Url $rawIfr -Referer $it.Url
                if ($deepFl) {
                    $flMaster = $deepFl
                } elseif ($rawIfr -match 'tvf90\.com/(?:[a-z0-9_-]+\.php|online/canal\.php)\?stream=([^&\s]+)') {
                    $xhdBk = Resolve-StreamXhdUrl -LivePageUrl ("https://streamxhd.click/live1.php?stream=" + $Matches[1])
                    if ($xhdBk) { $flMaster = $xhdBk } else { $keep = $false }
                } else {
                    $flMaster = $rawIfr
                }
            }
            if ($keep -and (Test-IsEventFinalized $flMaster $it.Title $null)) { $keep = $false }
            [PSCustomObject]@{ Item = $it; MasterUrl = $flMaster; Keep = $keep }
        }

        foreach ($fhr in $flHtmlRes) {
            if (-not $fhr.Keep) {
                $finalizedEvents += [PSCustomObject]@{ Name = $fhr.Item.Title; Url = $fhr.Item.Url; Reason = "Canal Fútbol Libre sin segmentos activos (404)" }
                continue
            }
            if (-not ($allChannels | Where-Object { $_.Name -eq $fhr.Item.Title })) {
                $allChannels += [PSCustomObject]@{
                    Id          = "fl_" + ($fhr.Item.Title -replace '[^a-zA-Z0-9]','')
                    Name        = $fhr.Item.Title
                    Group       = Get-ChannelGroup $fhr.Item.Title
                    Slug        = "futbollibre"
                    MasterUrl   = $fhr.MasterUrl
                    FallbackUrl = $fhr.Item.Url
                    VpnRequired = $true
                }
                Write-Host "   [+] $($fhr.Item.Title) " -NoNewline -ForegroundColor Green
                if ($fhr.MasterUrl -match '\.m3u8') { Write-Host "[HLS Verificado | Necesita VPN]" -ForegroundColor DarkGreen } else { Write-Host "[Necesita VPN]" -ForegroundColor Red }
            }
        }
    }

    # 3.4 Agenda Internacional & Fútbol en Directo (EmbedMe SG_PUBLIC + DeporteLibre - PARALELO)
    Enter-ScanPhase 'EmbedMe' $esModoVpn
    Write-Host "`n   [*] Analizando agenda deportiva y canales activos en EmbedMe..." -ForegroundColor DarkCyan
    $emHtml = if ($script:Prefetched["EmHtml"]) { $script:Prefetched["EmHtml"] } else { Get-Utf8Content -Uri "https://embedme.st/" -TimeoutSec 4 }
    if ($emHtml -and $emHtml -match 'window\.SG_PUBLIC=(\{.*?\});') {
        try {
            $sgObj = $Matches[1] | ConvertFrom-Json
            $script:EmbedMeStatus = "ONLINE"
            $nowSec = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()

            # A) Partidos de fútbol y deportes activos (filtrando NBA/NFL/NHL)
            $emGameWork = [System.Collections.Generic.List[PSCustomObject]]::new()
            if ($sgObj.games) {
                foreach ($gm in $sgObj.games) {
                    $sportName = [string]$gm.sport
                    $rawStat = ([string]$gm.status).ToLower() -replace '^status_', ''
                    $stDtEm = if ($gm.start_at) { [DateTimeOffset]::Parse([string]$gm.start_at).UtcDateTime } else { $null }
                    $repEndEm = if ($gm.end_at) { [DateTimeOffset]::Parse([string]$gm.end_at).UtcDateTime } else { $null }
                    $evTitle = if ($gm.away.name -and $gm.home.name) { "$($gm.away.name) vs $($gm.home.name)" } else { [string]$gm.custom_title }
                    $evTitle = Translate-ToSpanish $evTitle
                    if (Test-IsExcludedSport -Name $evTitle -SportId $sportName) {
                        $script:SkippedSportsCount++
                        continue
                    }
                    $evWinEm = Get-AgendaEventWindowEvaluation -Title $evTitle -StartUtc $stDtEm -ReportedEndUtc $repEndEm -SportHint $sportName -RawStatus $rawStat
                    if ($evWinEm.IsConcluded) {
                        $finalizedEvents += [PSCustomObject]@{ Name = $evTitle; Url = "https://embedme.st/"; Reason = $evWinEm.Reason }
                        continue
                    }
                    if ($stDtEm -and [DateTime]::UtcNow -ge $stDtEm.AddHours(-24) -and $stDtEm -le [DateTime]::UtcNow.AddHours(24) -and $gm.streams) {
                        $stCands = @($gm.streams | Select-Object -First 2)
                        $gHint = if ($sportName -eq 'soccer') { "Football" } else { "" }
                        $dispEm = $evTitle + $evWinEm.KickTag
                        $stUrls = @()
                        foreach ($stc in $stCands) {
                            $vid = [int]$stc.variant_id
                            $prefix = if ($vid -ge 900001) { "/player/" } else { "/play/" }
                            $vsfx = if ($vid -gt 0) { "-v$vid" } else { "" }
                            $stUrls += "https://embedme.st$($prefix)game-$($stc.game_id)$vsfx.php"
                        }
                        $emGameWork.Add([PSCustomObject]@{
                            Id          = $gm.id
                            Name        = $dispEm
                            Hint        = $gHint
                            Url         = $stUrls[0]
                            AltUrls     = $stUrls
                            Upcoming    = $evWinEm.Upcoming
                            StartsAtUtc = $evWinEm.StartsAtUtcStr
                            EndsAtUtc   = $evWinEm.EndsAtUtcStr
                        })
                    }
                }
            }

            $emGameRes = Invoke-ParallelItems -Items @($emGameWork) -ScriptBlock {
                param($it)
                try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
                $emMaster = $null
                foreach ($candU in $it.AltUrls) {
                    $deepEm = Resolve-EmbedAnyUrl -Url $candU -Referer "https://embedme.st/"
                    if ($deepEm) { $emMaster = $deepEm; break }
                }
                if (-not $emMaster -and $it.Upcoming) {
                    $gBody = Get-Utf8Content -Uri $it.Url -Referer "https://embedme.st/" -TimeoutSec 2
                    if ($gBody) { $emMaster = $it.Url }
                }
                if (-not $emMaster) { return $null }
                [PSCustomObject]@{ Item = $it; MasterUrl = $emMaster }
            }
            foreach ($gr in $emGameRes) {
                if (-not ($allChannels | Where-Object { $_.Name -eq $gr.Item.Name })) {
                    $allChannels += [PSCustomObject]@{
                        Id          = "em_" + ($gr.Item.Id -replace '[^a-zA-Z0-9]','')
                        Name        = $gr.Item.Name
                        Group       = Get-ChannelGroup $gr.Item.Name $gr.Item.Hint
                        Slug        = "embedme_game"
                        MasterUrl   = $gr.MasterUrl
                        FallbackUrl = $gr.Item.Url
                        VpnRequired = $true
                        StartsAtUtc = $gr.Item.StartsAtUtc
                        EndsAtUtc   = $gr.Item.EndsAtUtc
                    }
                    Write-Host "   [+] [Agenda Fútbol/Deportes] $($gr.Item.Name) " -NoNewline -ForegroundColor Cyan
                    if ($gr.MasterUrl -match '\.m3u8') { Write-Host "[HLS Verificado | Necesita VPN]" -ForegroundColor DarkGreen } else { Write-Host "[Necesita VPN]" -ForegroundColor Red }
                }
            }

            # B) Canales 24/7 con estado "running" o "live" en EmbedMe (en paralelo y sin deportes excluidos)
            $emChWork = [System.Collections.Generic.List[PSCustomObject]]::new()
            foreach ($ec in $sgObj.channels) {
                if ($ec.status -notin @('running', 'live')) { continue }
                $ecName = Translate-ToSpanish ([string]$ec.name)
                if ($ecName -match '(?i)DAZN\s*F1') { continue }
                if (Test-IsExcludedSport -Name $ecName) { $script:SkippedSportsCount++; continue }
                if (Test-IsEventFinalized $null $ecName $null) { continue }
                if (-not ($allChannels | Where-Object { $_.Name -eq $ecName })) {
                    $emChWork.Add([PSCustomObject]@{ Id = $ec.id; Name = $ecName; Url = "https://embedme.st/play/channel-$($ec.id).php" })
                }
            }
            $emChRes = Invoke-ParallelItems -Items @($emChWork) -ScriptBlock {
                param($it)
                try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
                $emMaster = $null
                $deepCh = Resolve-EmbedAnyUrl -Url $it.Url -Referer "https://embedme.st/"
                if ($deepCh) {
                    $emMaster = $deepCh
                } else {
                    $emCheck = Get-Utf8Content -Uri $it.Url -Referer "https://embedme.st/" -TimeoutSec 2
                    if ($emCheck -and $emCheck -notmatch '(?i)404\s*Not\s*Found|channel\s*offline') {
                        $emMaster = $it.Url
                    }
                }
                [PSCustomObject]@{ Item = $it; MasterUrl = $emMaster }
            }
            $addedEmCh = 0
            foreach ($cr in $emChRes) {
                if ($cr.MasterUrl -and -not ($allChannels | Where-Object { $_.Name -eq $cr.Item.Name })) {
                    $allChannels += [PSCustomObject]@{
                        Id          = "emch_" + $cr.Item.Id
                        Name        = $cr.Item.Name
                        Group       = Get-ChannelGroup $cr.Item.Name
                        Slug        = "embedme_ch"
                        MasterUrl   = $cr.MasterUrl
                        FallbackUrl = $cr.Item.Url
                        VpnRequired = $true
                    }
                    $addedEmCh++
                }
            }
            if ($addedEmCh -gt 0) {
                Write-Host "       [+] Añadidos $addedEmCh canales adicionales activos desde EmbedMe." -ForegroundColor DarkGreen
            }
        } catch {
            Write-Host "       [-] Error analizando EmbedMe: $($_.Exception.Message)" -ForegroundColor DarkGray
        }
    }

    # 3.4 Agenda DeporteLibre JSON -> Cruce directo con emisiones en Español Castellano (Movistar / DAZN / TDT HLS)
    Enter-ScanPhase 'DepLibre' $esModoVpn
    Write-Host "`n   [*] Buscando emisiones en español castellano en DeporteLibre (agenda.json)..." -ForegroundColor DarkCyan
    try {
        $dlAgendaJson = if ($script:Prefetched["DlAgenda"]) { $script:Prefetched["DlAgenda"] } else { Get-Utf8Content -Uri "https://deportelibre.top/agenda-deportiva/agenda.json" -Referer "https://deportelibre.top/agenda-deportiva/" -TimeoutSec 5 }
        if ($dlAgendaJson) {
            $dlEvents = $dlAgendaJson | ConvertFrom-Json
            $nowUtcDl = [DateTime]::UtcNow
            $dlCastMap = @(
                @{ Re = '(?i)movistar\s*laliga\s*2'; Slug = 'mlaliga2'; Label = 'M+ LaLiga 2 · Castellano' },
                @{ Re = '(?i)movistar\s*la?\s*liga'; Slug = 'mlaliga'; Label = 'M+ LaLiga · Castellano' },
                @{ Re = '(?i)dazn\s*laliga\s*2'; Slug = 'daznlaliga2'; Label = 'DAZN LaLiga 2 · Castellano' },
                @{ Re = '(?i)dazn\s*laliga'; Slug = 'daznlaliga'; Label = 'DAZN LaLiga · Castellano' },
                @{ Re = '(?i)hypermotion|hipermotion'; Slug = 'hypermotion'; Label = 'LaLiga Hypermotion · Castellano' },
                @{ Re = '(?i)movistar\s*liga\s*de\s*campeones\s*2|m\.?\s*campeones\s*2'; Slug = 'mligadecampeones2'; Label = 'M+ Liga de Campeones 2 · Castellano' },
                @{ Re = '(?i)movistar\s*liga\s*de\s*campeones|m\.?\s*campeones'; Slug = 'champions'; Label = 'M+ Liga de Campeones · Castellano' },
                @{ Re = '(?i)#?vamos|movistar\s*vamos'; Slug = 'vamos'; Label = '#Vamos · Castellano' },
                @{ Re = '(?i)movistar\s*plus\+|#movistar'; Slug = 'mplus'; Label = 'Movistar Plus+ · Castellano' },
                @{ Re = '(?i)movistar\s*deportes\s*2|m\.?\s*deportes\s*2'; Slug = 'mdeportes2'; Label = 'M+ Deportes 2 · Castellano' },
                @{ Re = '(?i)movistar\s*deportes|m\.?\s*deportes'; Slug = 'mdeportes'; Label = 'M+ Deportes · Castellano' },
                @{ Re = '(?i)\bdazn\s*1\b'; Slug = 'dazn1'; Label = 'DAZN 1 España · Castellano' },
                @{ Re = '(?i)\bdazn\s*2\b'; Slug = 'dazn2'; Label = 'DAZN 2 España · Castellano' },
                @{ Re = '(?i)\bdazn\s*3\b'; Slug = 'dazn3'; Label = 'DAZN 3 España · Castellano' },
                @{ Re = '(?i)\bdazn\s*4\b'; Slug = 'dazn4'; Label = 'DAZN 4 España · Castellano' },
                @{ Re = '(?i)\bdazn\s*f1\b'; Slug = 'daznf1'; Label = 'DAZN F1 España · Castellano' },
                @{ Re = '(?i)\bgol\s*play\b'; Slug = 'gol'; Label = 'Gol Play · Castellano' },
                @{ Re = '(?i)eurosport\s*1'; Slug = 'eurosport1'; Label = 'Eurosport 1 España · Castellano' },
                @{ Re = '(?i)eurosport\s*2'; Slug = 'eurosport2'; Label = 'Eurosport 2 España · Castellano' }
            )

            $dlCandMatches = [System.Collections.Generic.List[PSCustomObject]]::new()
            $neededDlSlugs = [System.Collections.Generic.HashSet[string]]::new()
            foreach ($ev in $dlEvents) {
                if ($ev.tipo -eq 'separador' -or -not $ev.partido -or -not $ev.canales) { continue }
                $cleanPartido = ([string]$ev.partido -replace '[\uD800-\uDBFF][\uDC00-\uDFFF]', '' -replace '\s{2,}', ' ').Trim()
                $depLabel = "$($ev.deporte) $($ev.competicion)"
                $cleanMatchTitle = Translate-ToSpanish $cleanPartido
                if (Test-IsExcludedSport -Name $cleanMatchTitle -LeagueOrCategory $depLabel -SportId ([string]$ev.deporte)) {
                    $script:SkippedSportsCount++
                    continue
                }
                $startUtcDl = $null
                if ($ev.inicio) {
                    try {
                        $startUtcDl = [DateTime]::Parse([string]$ev.inicio, [System.Globalization.CultureInfo]::InvariantCulture, [System.Globalization.DateTimeStyles]::AssumeUniversal).ToUniversalTime()
                    } catch {}
                }
                if ($startUtcDl -and $startUtcDl -gt $nowUtcDl.AddHours(24)) { continue }
                $rawEstDl = if ($ev.estado) { [string]$ev.estado } else { "" }
                $evWinDl = Get-AgendaEventWindowEvaluation -Title $cleanMatchTitle -StartUtc $startUtcDl -SportHint $depLabel -RawStatus $rawEstDl
                if ($evWinDl.IsConcluded) {
                    $finalizedEvents += [PSCustomObject]@{ Name = $cleanMatchTitle; Url = "https://deportelibre.top/agenda-deportiva/"; Reason = $evWinDl.Reason }
                    continue
                }
                $kickDl = $evWinDl.KickTag

                $dlHint = if ($depLabel -match '(?i)f[uú]tbol|soccer|copa|champions|liga|premier|serie|bundesliga') { "Football" } else { "" }
                $matchedSlugsForEv = @{}
                foreach ($cn in $ev.canales) {
                    $cnName = [string]$cn.nombre
                    if (-not $cnName) { continue }
                    foreach ($cm in $dlCastMap) {
                        if ($cnName -match $cm.Re -and -not $matchedSlugsForEv.ContainsKey($cm.Slug)) {
                            $matchedSlugsForEv[$cm.Slug] = $true
                            $null = $neededDlSlugs.Add($cm.Slug)
                            $dlCandMatches.Add([PSCustomObject]@{
                                Title       = $cleanMatchTitle
                                DispName    = "$cleanMatchTitle$kickDl ($($cm.Label))"
                                Slug        = $cm.Slug
                                Hint        = $dlHint
                                StartsAtUtc = $evWinDl.StartsAtUtcStr
                                EndsAtUtc   = $evWinDl.EndsAtUtcStr
                            })
                            break
                        }
                    }
                }
            }

            if ($neededDlSlugs.Count -gt 0) {
                $sxHostDl = if ($global:ActiveStreamxHost) { $global:ActiveStreamxHost } else { "streamx723.sbs" }
                $dlSlugHls = @{}
                $dlNeedProbe = [System.Collections.Generic.List[string]]::new()
                foreach ($sl in $neededDlSlugs) {
                    $slKey = $sl.ToLowerInvariant()
                    if ($script:VipSlugCache.ContainsKey($slKey)) {
                        $dlSlugHls[$sl] = $script:VipSlugCache[$slKey]
                    } else {
                        $dlNeedProbe.Add($sl)
                    }
                }
                $dlProbeRes = Invoke-ParallelItems -Items @($dlNeedProbe) -ScriptBlock {
                    param($sl)
                    try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
                    $sxBase = if ($ActiveStreamxHost) { $ActiveStreamxHost } else { "streamx723.sbs" }
                    $u = Resolve-StreamxNodeUrl -ChannelSlug $sl -HostDomain $sxBase -Referer "https://cdplay.live/"
                    if (-not $u) { $u = Resolve-StreamXhdUrl -LivePageUrl "https://streamxhd.click/live1.php?stream=$sl" -Referer "https://streamxhd.click/" }
                    if (-not $u) { $u = Resolve-Tvf90Url -StreamSlug $sl }
                    [PSCustomObject]@{ Slug = $sl; M3u = $u }
                }
                foreach ($dr in $dlProbeRes) {
                    if ($dr.M3u) {
                        $dlSlugHls[$dr.Slug] = $dr.M3u
                        $script:VipSlugCache[$dr.Slug.ToLowerInvariant()] = $dr.M3u
                    }
                }
                $addedDlCast = 0
                foreach ($dc in $dlCandMatches) {
                    $hlsU = $dlSlugHls[$dc.Slug]
                    $firstTeam = (($dc.Title -split '\s+vs\s+|\s+-\s+')[0] -replace '[^a-zA-Z0-9áéíóúÁÉÍÓÚñÑ ]','').Trim().Split(' ')[0]
                    $dupMatch = if ($hlsU -and $firstTeam -and $firstTeam.Length -ge 3) {
                        $allChannels | Where-Object { $_.MasterUrl -eq $hlsU -and $_.Name -match [regex]::Escape($firstTeam) }
                    } else { $null }
                    if ($hlsU -and -not $dupMatch -and -not ($allChannels | Where-Object { $_.Name -eq $dc.DispName })) {
                        $allChannels += [PSCustomObject]@{
                            Id          = "dlcast_" + ($dc.DispName -replace '[^a-zA-Z0-9]','')
                            Name        = $dc.DispName
                            Group       = Get-ChannelGroup "$($dc.Title) $($dc.Slug)" $dc.Hint
                            Slug        = "deportelibre_castellano"
                            MasterUrl   = $hlsU
                            FallbackUrl = "https://$sxHostDl/global3.php?channel=$($dc.Slug)"
                            VpnRequired = $true
                            StartsAtUtc = $dc.StartsAtUtc
                            EndsAtUtc   = $dc.EndsAtUtc
                        }
                        Write-Host "   [+] [Castellano Directo] $($dc.DispName) [HLS Verificado | Necesita VPN]" -ForegroundColor Green
                        $addedDlCast++
                    }
                }
                if ($addedDlCast -gt 0) {
                    Write-Host "       [+] DeporteLibre Agenda Castellano: $addedDlCast emisiones en español castellano añadidas." -ForegroundColor DarkGreen
                }
            }
        }
    } catch {
        Write-Host "       [-] Aviso consultando DeporteLibre agenda: $($_.Exception.Message)" -ForegroundColor DarkGray
    }

    # 3.5 Escucha y Sondeo Activo: CandyShop CDN & Red Offshore InStreams (PARALELO Y DEDUPLICADO)
    Enter-ScanPhase 'CandySS' $esModoVpn
    Write-Host "`n   [*] Escucha activa de nodos CandyShop CDN e InStreams (tokens HMAC directos)..." -ForegroundColor DarkCyan
    $candyOnline = $false
    try {
        $swCandy = [System.Diagnostics.Stopwatch]::StartNew()
        $candyRaw = $script:Prefetched["CandyHealth"]
        $candyHealth = if ($candyRaw) { $candyRaw | ConvertFrom-Json } else { Invoke-RestMethod -Uri "https://edge2.candyshop.st/health" -TimeoutSec 2 -ErrorAction Stop }
        $swCandy.Stop()
        if ($candyHealth -and $candyHealth.status -eq "ok") {
            $candyOnline = $true
            Write-Host "       [+] Nodo CandyShop Edge 2: ONLINE ($($swCandy.ElapsedMilliseconds)ms - Uptime: $([Math]::Round($candyHealth.uptime/3600, 1))h | $($script:CandyShopActiveCount) feeds HLS)" -ForegroundColor DarkGreen
        }
    } catch {
        Write-Host "       [-] Nodo CandyShop Edge 2 no disponible: $($_.Exception.Message)" -ForegroundColor DarkGray
    }

    # Ola A única: CA1..CA12 (si CandyShop online) + 4 sondas SSF clave en paralelo simultáneo
    $waveATargets = [System.Collections.Generic.List[PSCustomObject]]::new()
    if ($candyOnline) {
        1..12 | ForEach-Object {
            $cCode = "CA$_"
            $waveATargets.Add([PSCustomObject]@{ Kind = "CA"; Code = $cCode; Url = "https://sofayshop.st/capopro.php?stream=$cCode"; Ref = "https://cdplay.live/" })
        }
    }
    @("SSF49", "SSF31", "SSF32", "SSF44") | ForEach-Object {
        $waveATargets.Add([PSCustomObject]@{ Kind = "SSF"; Code = $_; Url = "https://sofayshop.st/livetvfx.php?stream=$_"; Ref = "https://embedme.st/" })
    }
    $waveARes = Invoke-ParallelItems -Items @($waveATargets) -ScriptBlock {
        param($it)
        try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
        $h = Resolve-CapoCandyShop -IframeUrl $it.Url -Referer $it.Ref
        [PSCustomObject]@{ Kind = $it.Kind; Code = $it.Code; Url = $it.Url; Hls = $h }
    }

    $ssfCache = @{}
    foreach ($wr in $waveARes) {
        if ($wr.Kind -eq "CA" -and $wr.Hls) {
            $extraName = "Capo Deportes Extra ($($wr.Code))"
            if (-not ($allChannels | Where-Object { $_.MasterUrl -eq $wr.Hls -or $_.Name -eq $extraName })) {
                $allChannels += [PSCustomObject]@{
                    Id          = "candy_" + $wr.Code
                    Name        = $extraName
                    Group       = "Deportes España"
                    Slug        = "candyshop"
                    MasterUrl   = $wr.Hls
                    FallbackUrl = $wr.Url
                    VpnRequired = $true
                }
                $script:CandyShopActiveCount++
                Write-Host "   [+] $extraName [HLS Directo CandyShop | Necesita VPN]" -ForegroundColor DarkGreen
            }
        } elseif ($wr.Kind -eq "SSF") {
            $ssfCache[$wr.Code] = $wr.Hls
        }
    }

    $ssf49Hit = $ssfCache["SSF49"]
    if ($ssf49Hit) {
        $daznF1Feeds.Add([PSCustomObject]@{ Url = $ssf49Hit; Fallback = "https://embedme.st/play/channel-62.php"; Source = "instreams"; Verified = $true })
    }
    $anySsfHit = ($ssfCache.Values | Where-Object { $_ } | Select-Object -First 1) -or ($allChannels | Where-Object { $_.MasterUrl -match '/live3/SSF' })
    if ($anySsfHit) {
        $script:InStreamsStatus = "ONLINE"
        Write-Host "       [+] Red InStreams / CandyShop SSF ONLINE: Verificando canales HLS directos..." -ForegroundColor DarkGreen
        $ssfMap = @(
            @{ Code = "SSF44"; Name = "Fox Soccer Plus HD"; Id = "1385756340" },
            @{ Code = "SSF32"; Name = "TNT Sports 1 (UK HD)"; Id = "45" },
            @{ Code = "SSF33"; Name = "TNT Sports 2 (UK HD)"; Id = "46" },
            @{ Code = "SSF34"; Name = "TNT Sports 3 (UK HD)"; Id = "47" },
            @{ Code = "SSF35"; Name = "TNT Sports 4 (UK HD)"; Id = "48" },
            @{ Code = "SSF31"; Name = "Sky Sports F1 (Directo HD)"; Id = "44" },
            @{ Code = "SSF17"; Name = "FOX Deportes HD"; Id = "30" },
            @{ Code = "SSF47"; Name = "ESPN Latino Directo"; Id = "60" },
            @{ Code = "SSF48"; Name = "ESPN 2 Latino Directo"; Id = "61" },
            @{ Code = "SSF51"; Name = "ESPN 4 Latino Directo"; Id = "64" }
        )
        # Evitar doble sondeo de SSF31/SSF32/SSF44 ya cacheados en Ola A
        $ssfNeedProbe = @($ssfMap | Where-Object { -not $ssfCache.ContainsKey($_.Code) })
        $ssfRes = Invoke-ParallelItems -Items $ssfNeedProbe -ScriptBlock {
            param($sm)
            try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
            $h = Resolve-CapoCandyShop -IframeUrl "https://sofayshop.st/livetvfx.php?stream=$($sm.Code)" -Referer "https://embedme.st/"
            [PSCustomObject]@{ Code = $sm.Code; Hls = $h }
        }
        foreach ($sr in $ssfRes) { $ssfCache[$sr.Code] = $sr.Hls }
        foreach ($sm in $ssfMap) {
            $hUrl = $ssfCache[$sm.Code]
            if ($hUrl -and -not ($allChannels | Where-Object { $_.Name -eq $sm.Name })) {
                $allChannels += [PSCustomObject]@{
                    Id          = "in_" + $sm.Code
                    Name        = $sm.Name
                    Group       = Get-ChannelGroup $sm.Name
                    Slug        = "instreams"
                    MasterUrl   = $hUrl
                    FallbackUrl = "https://embedme.st/play/channel-$($sm.Id).php"
                    VpnRequired = $true
                }
                Write-Host "   [+] $($sm.Name) [HLS Directo InStreams | Necesita VPN]" -ForegroundColor DarkGreen
            }
        }
    } else {
        $script:InStreamsStatus = "STANDBY_NO_VPN"
        Write-Host "       [*] Nodo InStreams Offshore en espera de túnel VPN (Finlandia)" -ForegroundColor DarkGray
    }

    # 3.6 Consolidación y Normalización de DAZN F1 España (Opciones limpias sin SD ni HD + Segmentos verificados)
    Write-Host "`n   [*] Consolidando señales de DAZN F1 España..." -ForegroundColor DarkCyan
    if ($daznF1Feeds.Count -eq 0 -and $esModoVpn) {
        $daznF1Feeds.Add([PSCustomObject]@{ Url = "https://cdplay.live/formula1hd.php"; Fallback = "https://cdplay.live/formula1hd.php"; Source = "cdplay"; Verified = $false })
        $daznF1Feeds.Add([PSCustomObject]@{ Url = "https://cdplay.live/formula1.php"; Fallback = "https://cdplay.live/formula1.php"; Source = "cdplay"; Verified = $false })
    }

    $f1OptIdx = 1
    $seenF1 = [System.Collections.Generic.HashSet[string]]::new()
    foreach ($feed in $daznF1Feeds) {
        if (-not $seenF1.Contains($feed.Url)) {
            $seenF1.Add($feed.Url) | Out-Null
            if (-not $feed.Verified -and $feed.Url -match '\.m3u8(?:\?|$)' -and -not (Test-HlsDeepLive -Uri $feed.Url -Referer ($feed.Fallback) -TimeoutSec 3)) {
                $finalizedEvents += [PSCustomObject]@{ Name = "DAZN F1 España ($($feed.Source))"; Url = $feed.Url; Reason = "Señal F1 sin segmentos activos (403/404)" }
                continue
            }
            $optName = "DAZN F1 España (Opción $f1OptIdx)"
            $allChannels += [PSCustomObject]@{
                Id          = "daznf1_opt$f1OptIdx"
                Name        = $optName
                Group       = "F1 España"
                Slug        = "daznf1"
                MasterUrl   = $feed.Url
                FallbackUrl = if ($feed.Fallback) { $feed.Fallback } else { $feed.Url }
                VpnRequired = ($feed.Source -ne "f1net")
            }
            Write-Host "   [+] $optName " -NoNewline -ForegroundColor Green
            if ($feed.Source -ne "f1net") {
                Write-Host "[$($feed.Source) | Necesita VPN]" -ForegroundColor Red
            } else {
                Write-Host "[VPN No Necesaria]" -ForegroundColor DarkGreen
            }
            $f1OptIdx++
        }
    }
} else {
    # MODO ESTRICTO SIN VPN: Filtro definitivo para garantizar CERO canales de VPN
    $allChannels = @($allChannels | Where-Object { -not $_.VpnRequired })
}

if ($script:ParallelPool) {
    try { $script:ParallelPool.Close(); $script:ParallelPool.Dispose() } catch {}
    $script:ParallelPool = $null
}
$script:ScanTimer.Stop()

Enter-ScanPhase 'WebPurge' $esModoVpn
Invoke-WebAiEventPurge

Enter-ScanPhase 'Save' $esModoVpn
Write-Host ""
Write-Host " ========================================================" -ForegroundColor Red
Write-Host "  Modo de operacion: $(if ($esModoVpn) { 'CON VPN (Todos los servidores)' } else { 'SIN VPN (Solo canales abiertos)' })" -ForegroundColor Yellow
Write-Host "  Total canales sincronizados: $($allChannels.Count)" -ForegroundColor Green
if ($finalizedEvents.Count -gt 0) {
    Write-Host "  Eventos finalizados purgados por API/IA: $($finalizedEvents.Count)" -ForegroundColor DarkYellow
}
if ($script:SkippedSportsCount -gt 0) {
    Write-Host "  Deportes excluidos (NBA/NFL/NHL/Copa Col.): $($script:SkippedSportsCount)" -ForegroundColor DarkGray
}
Write-Host ("  Tiempo total de escaneo paralelo: {0:N1}s" -f $script:ScanTimer.Elapsed.TotalSeconds) -ForegroundColor Cyan
Write-Host " ========================================================" -ForegroundColor Red
Write-Host ""

# -------------------------------------------------------------
# 5. ORDENAR (CASTELLANO PRIMERO) Y GUARDAR PLAYLIST M3U UNIFICADA
# -------------------------------------------------------------
$allChannels = @($allChannels | Sort-Object `
    Group, `
    @{ Expression = { if ($_.Name -match '(?i)Castellano|RTVE|M\+\s*LaLiga|DAZN.*Espa|Gol\s*Play|Teledeporte|DMAX|TRECE|El Toro|Telemadrid|Canal Sur|TV3|À Punt|ETB|TVG') { 0 } elseif ($_.Name -match 'Latino') { 2 } else { 1 } } }, `
    @{ Expression = { [regex]::Replace([string]$_.Name, '\d+', { param($m) $m.Value.PadLeft(5, '0') }) } }
)
$sorted = $allChannels
$m3uContent = "#EXTM3U url-tvg=`"`" tvg-shift=0`r`n"

foreach ($c in $sorted) {
    $vpnTag = if ($c.VpnRequired) { "[Necesita VPN]" } else { "[VPN No Necesaria]" }
    $m3uContent += "#EXTINF:-1 tvg-name=`"$($c.Name)`" group-title=`"$($c.Group)`",$($c.Name) $vpnTag`r`n"
    $m3uContent += "$($c.MasterUrl)`r`n"
}

    [System.IO.File]::WriteAllText($OutputFile, $m3uContent, [System.Text.UTF8Encoding]::new($true))

# -------------------------------------------------------------
# 6. GUARDAR ESTADO DE LA API LOCAL (events-status.json)
# -------------------------------------------------------------
$apiObj = [PSCustomObject]@{
    version          = "Build 1.5"
    generated_at     = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    vpn_mode         = [bool]$esModoVpn
    total_channels   = $allChannels.Count
    purged_events    = $finalizedEvents.Count
    server_network   = [PSCustomObject]@{
        embdlol          = "ONLINE"
        ppv_st           = "ONLINE"
        f1net            = "ONLINE"
        rtve_uhd         = "ONLINE"
        candyshop        = if ($script:CandyShopActiveCount -gt 0) { "ONLINE ($($script:CandyShopActiveCount) HLS)" } else { "ONLINE" }
        instreams        = $script:InStreamsStatus
        futbollibre_api  = $script:FutbolLibreApiStatus
        streamxhd_agenda = $script:StreamXhdStatus
        embedme          = $script:EmbedMeStatus
        cdplay           = if ($esModoVpn) { "ONLINE" } else { "VPN_REQUIRED" }
        spanish_vip      = $script:SpanishVipStatus
        web_oracle       = $script:WebOracleStatus
        web_ai_filter    = $script:WebAiStatus
        iptv             = $script:IptvStatus
    }
    channels         = $allChannels
    finalized_events = $finalizedEvents
}

    [System.IO.File]::WriteAllText($ApiStatusFile, ($apiObj | ConvertTo-Json -Depth 6), [System.Text.UTF8Encoding]::new($true))

# -------------------------------------------------------------
# 7. INYECTAR DATOS EN TIEMPO REAL DIRECTAMENTE EN EL REPRODUCTOR HTML
# -------------------------------------------------------------
if (Test-Path $HtmlPlayer) {
    try {
        $htmlContent = [System.IO.File]::ReadAllText($HtmlPlayer, [System.Text.Encoding]::UTF8)
        $jsonChannels = $allChannels | ConvertTo-Json -Compress -Depth 5
        $jsonPurged = $finalizedEvents | ConvertTo-Json -Compress -Depth 5
        $jsonNetwork = $apiObj.server_network | ConvertTo-Json -Compress
        
        $replacementTag = @"
  <script id="atomic-live-data">
    window.ATOMIC_LIVE_DATA = {
      vpnMode: $(if ($esModoVpn) { 'true' } else { 'false' }),
      network: $jsonNetwork,
      channels: $jsonChannels,
      purgedEvents: $jsonPurged
    };
  </script>
"@
        if ($htmlContent -match '<script id="atomic-live-data">') {
            $htmlContent = [regex]::Replace($htmlContent, '(?s)<script id="atomic-live-data">.*?<\/script>', $replacementTag)
        } else {
            $htmlContent = $htmlContent -replace '(?i)<\/head>', "$replacementTag`n</head>"
        }
    [System.IO.File]::WriteAllText($HtmlPlayer, $htmlContent, [System.Text.UTF8Encoding]::new($true))
        Write-Host " Sincronizacion directa con el reproductor HTML: OK" -ForegroundColor Green
    } catch {
        Write-Host " Aviso al sincronizar con el reproductor HTML: $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

Write-Host " Resumen por categorias:" -ForegroundColor Cyan
$groups = $allChannels | Group-Object Group | Sort-Object Count -Descending
foreach ($g in $groups) {
    Write-Host "   * $($g.Name): $($g.Count)" -ForegroundColor DarkCyan
}

Write-Host ""
Write-Host " Playlist guardada con exito en:" -ForegroundColor White
Write-Host " $OutputFile" -ForegroundColor DarkGray
Write-Host " API de estado generada en:" -ForegroundColor White
Write-Host " $ApiStatusFile" -ForegroundColor DarkGray
Write-Host ""

Show-ScanProgressBar 100
Disable-QuietScanMode

# -------------------------------------------------------------
# 8. RESUMEN DE CANALES Y LANZAMIENTO DIRECTO
# -------------------------------------------------------------
$totalFound = $allChannels.Count
$totalHls = @($allChannels | Where-Object { $_.MasterUrl -match '\.m3u8' }).Count
if ($script:QuietScanActive) { Write-Host "" }
Write-Host "  +--------------------------------------------------------------+" -ForegroundColor DarkCyan
Write-Host ("  |  CANALES ENCONTRADOS: {0,-3} ({1} HLS directos en vivo)        |" -f $totalFound, $totalHls) -ForegroundColor Cyan
Write-Host "  +--------------------------------------------------------------+" -ForegroundColor DarkCyan
foreach ($grpRow in ($allChannels | Group-Object Group | Sort-Object Count -Descending)) {
    Write-Host ("    * {0,-30} : {1,3} canales" -f $grpRow.Name, $grpRow.Count) -ForegroundColor Gray
}
if ($script:QuietScanActive) {
    $purgedTxt = if ($finalizedEvents.Count -gt 0) { " | Purgados: $($finalizedEvents.Count)" } else { "" }
    $modeSummaryLabel = if ($usedPhase2Scan) { '2 FASES (Canales sin VPN + Canales que necesitan VPN)' } elseif ($esModoVpn) { 'CON VPN' } else { 'SIN VPN' }
    Write-Host ("`n  [+] Modo: {0} | Tiempo: {1:N1}s{2}" -f $modeSummaryLabel, $script:ScanTimer.Elapsed.TotalSeconds, $purgedTxt) -ForegroundColor DarkCyan
    Write-Host "  [+] Playlist guardada: $OutputFile" -ForegroundColor DarkGray
}
Write-Host ""

if ([string]::IsNullOrWhiteSpace($Accion)) {
    Write-Host "  >> ¿Abrir AtomicBombTV? [Pulsa ENTER para abrir | N = Salir]: " -NoNewline -ForegroundColor Green
    if ([Console]::IsInputRedirected) {
        $respOpen = [Console]::In.ReadLine()
        $opcion = if ($null -ne $respOpen -and ($respOpen -eq '' -or $respOpen -match '^(?i)(s|si|y|yes|1)$')) { "1" } else { "3" }
    } else {
        $respOpen = Read-Host
        $opcion = if ([string]::IsNullOrWhiteSpace($respOpen) -or $respOpen -match '^(?i)(s|si|y|yes|1)$') { "1" } else { "3" }
    }
} else {
    $opcion = $Accion
    if ([string]::IsNullOrWhiteSpace($opcion)) { $opcion = "1" }
}

if ($opcion -eq "1") {
    $rpcScript = Join-Path $ScriptDir "discord-rpc.ps1"
    $serverReady = $false
    try {
        $lanCheck = Invoke-RestMethod -Uri "http://127.0.0.1:45454/lan-info" -TimeoutSec 1 -ErrorAction Stop
        if ($lanCheck -and $lanCheck.version -like "1.*-castv2*") {
            $serverReady = $true
        }
    } catch {}
    if (-not $serverReady) {
        try {
            $oldConns = Get-NetTCPConnection -LocalPort 45454 -ErrorAction SilentlyContinue
            foreach ($oc in $oldConns) {
                if ($oc.OwningProcess -and $oc.OwningProcess -ne $PID) {
                    Stop-Process -Id $oc.OwningProcess -Force -ErrorAction SilentlyContinue
                }
            }
            Start-Sleep -Milliseconds 250
        } catch {}
    }
    if (-not $serverReady -and (Test-Path $rpcScript)) {
        Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$rpcScript`"" -WindowStyle Hidden
        for ($w = 0; $w -lt 30; $w++) {
            try {
                $li2 = Invoke-RestMethod -Uri "http://127.0.0.1:45454/lan-info" -TimeoutSec 1 -ErrorAction Stop
                if ($li2 -and $li2.status -eq "ok") { $serverReady = $true; break }
            } catch {}
            Start-Sleep -Milliseconds 150
        }
    }
    if ($serverReady) {
        Write-Host "`n  Iniciando Javi DJ - Atomic Bomb TV (Chromecast + Web: http://localhost:45454/)..." -ForegroundColor Green
        Start-Process "http://localhost:45454/"
    } elseif (Test-Path $HtmlPlayer) {
        Write-Host "`n  Iniciando Javi DJ - Atomic Bomb TV..." -ForegroundColor Green
        Start-Process $HtmlPlayer
    } else {
        Write-Host "`n  Abriendo lista en el navegador predeterminado..." -ForegroundColor Yellow
        Start-Process $OutputFile
    }
} elseif ($opcion -eq "2") {
    $vlcPaths = @(
        "${env:ProgramFiles}\VideoLAN\VLC\vlc.exe",
        "${env:ProgramFiles(x86)}\VideoLAN\VLC\vlc.exe",
        "$env:LOCALAPPDATA\Programs\VideoLAN\VLC\vlc.exe"
    )
    $vlcExe = $vlcPaths | Where-Object { Test-Path $_ } | Select-Object -First 1

    if ($vlcExe) {
        Write-Host "`n  Iniciando VLC con la lista de reproduccion..." -ForegroundColor Green
        Start-Process $vlcExe -ArgumentList "`"$OutputFile`""
    } else {
        Write-Host "`n  No se encontro VLC instalado en las rutas predeterminadas." -ForegroundColor Yellow
        Start-Process $OutputFile
    }
} else {
    Write-Host "`n  Finalizado. La lista esta lista para usar." -ForegroundColor Green
}
