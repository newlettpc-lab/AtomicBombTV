@echo off
title AtomicBombTV - Version Estable 1.9.2 (Noviembre 2026) - TV en Vivo gratis
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0refresh-playlist.ps1"
if errorlevel 1 pause
exit /b 0
