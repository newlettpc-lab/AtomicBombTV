﻿# AtomicBombTV - Local Stream Proxy, CastV2 & Discord RPC Bridge
# Author: Faraz Arif Malik. Residencia Badalona.
# Encoding: UTF-8 con BOM

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ConfigFile = Join-Path $ScriptDir "discord-config.json"
$DefaultClientId = "1569142203656314992"

# 1. Cargar configuracion
$config = @{
    enabled = $true
    client_id = $DefaultClientId
    application_name = "AtomicBombTV Estable 1.7"
    details = "AtomicBombTV Estable 1.7"
    state = "ABTV Estable 1.7"
    large_image_key = "logo"
    large_text = "AtomicBombTV Estable 1.7"
    http_port = 45454
}

if (Test-Path $ConfigFile) {
    try {
        $json = Get-Content $ConfigFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($json.client_id) { $config.client_id = [string]$json.client_id }
        if ($json.application_name) { $config.application_name = [string]$json.application_name }
        if ($json.details) { $config.details = [string]$json.details }
        if ($json.state) { $config.state = [string]$json.state }
        if ($json.large_image_key) { $config.large_image_key = [string]$json.large_image_key }
        if ($json.large_text) { $config.large_text = [string]$json.large_text }
        if ($json.http_port) { $config.http_port = [int]$json.http_port }
    } catch {}
} else {
    $config | ConvertTo-Json -Depth 3 | Set-Content $ConfigFile -Encoding UTF8
}

# Auto-curacion: detener cualquier proceso anterior que ocupe el puerto
try {
    $conns = Get-NetTCPConnection -LocalPort $config.http_port -ErrorAction SilentlyContinue
    foreach ($c in $conns) {
        if ($c.OwningProcess -and $c.OwningProcess -ne $PID) {
            Stop-Process -Id $c.OwningProcess -Force -ErrorAction SilentlyContinue
        }
    }
    Start-Sleep -Milliseconds 300
} catch {}

$global:currentChannel = "Explorando canales..."
$global:startTimestamp = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
$global:pipeStream = $null
$global:writer = $null
$global:reader = $null

function Connect-DiscordPipe {
    if ($global:pipeStream -and $global:pipeStream.IsConnected) { return $true }

    # Comprobar pipes existentes en <1ms antes de intentar conectar (evita bloqueos cuando Discord no esta abierto)
    $existingPipes = @()
    try {
        $existingPipes = [System.IO.Directory]::GetFiles("\\.\pipe\", "discord-ipc-*") | ForEach-Object { [System.IO.Path]::GetFileName($_) }
    } catch {
        $existingPipes = 0..9 | ForEach-Object { "discord-ipc-$_" }
    }
    if (-not $existingPipes -or $existingPipes.Count -eq 0) { return $false }

    foreach ($pName in $existingPipes) {
        try {
            $p = New-Object System.IO.Pipes.NamedPipeClientStream(".", $pName, [System.IO.Pipes.PipeDirection]::InOut)
            $p.Connect(80)
            $global:pipeStream = $p
            $global:writer = New-Object System.IO.BinaryWriter($p)
            $global:reader = New-Object System.IO.BinaryReader($p)

            # Enviar Handshake (Opcode 0)
            $handshake = @{
                v = 1
                client_id = $config.client_id
            } | ConvertTo-Json -Compress

            $bytes = [System.Text.Encoding]::UTF8.GetBytes($handshake)
            $global:writer.Write([int32]0) # Opcode 0
            $global:writer.Write([int32]$bytes.Length)
            $global:writer.Write($bytes)
            $global:writer.Flush()

            # Leer respuesta de Handshake (encabezado 8 bytes)
            if ($p.CanRead) {
                $op = $global:reader.ReadInt32()
                $len = $global:reader.ReadInt32()
                if ($len -gt 0) {
                    $null = $global:reader.ReadBytes($len)
                }
            }

            return $true
        } catch {
            if ($global:pipeStream) {
                try { $global:pipeStream.Close() } catch {}
                $global:pipeStream = $null
            }
        }
    }
    return $false
}

function Update-DiscordActivity {
    param([string]$channelName)

    if ([string]::IsNullOrWhiteSpace($channelName)) {
        $channelName = "Explorando canales..."
    }
    $global:currentChannel = $channelName

    $connected = Connect-DiscordPipe
    if (-not $connected) { return }

    try {
        $activity = @{
            cmd = "SET_ACTIVITY"
            args = @{
                pid = $PID
                activity = @{
                    type = 3   # 3 = WATCHING ("Viendo")
                    details = $global:currentChannel    # Texto grande: el canal (siempre actualizado)
                    state = $config.state               # Texto pequeño: "ABTV Estable 1.7"
                    timestamps = @{
                        start = $global:startTimestamp
                    }
                    assets = @{
                        large_image = $config.large_image_key
                        large_text = $config.large_text
                    }
                }
            }
            nonce = [Guid]::NewGuid().ToString()
        } | ConvertTo-Json -Depth 8 -Compress

        $bytes = [System.Text.Encoding]::UTF8.GetBytes($activity)
        $global:writer.Write([int32]1) # Opcode 1 (Frame)
        $global:writer.Write([int32]$bytes.Length)
        $global:writer.Write($bytes)
        $global:writer.Flush()

        # Drenar respuesta de SET_ACTIVITY de forma segura
        try {
            if ($global:pipeStream -and $global:pipeStream.IsConnected) {
                $opResp = $global:reader.ReadInt32()
                $lenResp = $global:reader.ReadInt32()
                if ($lenResp -gt 0) {
                    $null = $global:reader.ReadBytes($lenResp)
                }
            }
        } catch {}
    } catch {
        try { $global:pipeStream.Close() } catch {}
        $global:pipeStream = $null
    }
}

# 2. Utilidades LAN, CastV2 Nativo (Android TV / Chromecast) y Servidor HTTP / Proxy HLS C# Concurrente
function Get-LanIPv4 {
    try {
        $ifaces = [System.Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces() |
            Where-Object {
                $_.OperationalStatus -eq [System.Net.NetworkInformation.OperationalStatus]::Up -and
                $_.NetworkInterfaceType -ne [System.Net.NetworkInformation.NetworkInterfaceType]::Loopback -and
                $_.NetworkInterfaceType -ne [System.Net.NetworkInformation.NetworkInterfaceType]::Tunnel -and
                $_.Name -notmatch '(?i)VPN|Urban|Radmin|WireGuard|OpenVPN|TAP|TUN|Teredo|Virtual|Hyper-V|WSL|VMware|VirtualBox|Loopback' -and
                $_.Description -notmatch '(?i)VPN|Urban|Radmin|WireGuard|OpenVPN|TAP|TUN|Teredo|Virtual|Hyper-V|WSL|VMware|VirtualBox'
            }

        $candidates = @()
        foreach ($nic in $ifaces) {
            $props = $nic.GetIPProperties()
            $hasGw = ($props.GatewayAddresses -and $props.GatewayAddresses.Count -gt 0)
            foreach ($ua in $props.UnicastAddresses) {
                if ($ua.Address.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork) {
                    $ipStr = $ua.Address.IPAddressToString
                    if ($ipStr -notmatch '^(?:127\.|169\.254\.)') {
                        $score = if ($ipStr -match '^192\.168\.' -and $hasGw) { 0 }
                                 elseif ($ipStr -match '^(?:10\.|172\.(?:1[6-9]|2\d|3[01])\.)' -and $hasGw) { 1 }
                                 elseif ($hasGw) { 2 }
                                 else { 3 }
                        $candidates += [PSCustomObject]@{ Ip = $ipStr; Score = $score }
                    }
                }
            }
        }
        $best = $candidates | Sort-Object Score | Select-Object -First 1
        if ($best) { return $best.Ip }
    } catch {}
    return "127.0.0.1"
}

$castCsharpSource = @'
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Script.Serialization;

public class CastDeviceInfo {
    public string name;
    public string ip;
    public int port;
    public string model;
    public string source;
}

public class CastCommandResult {
    public bool ok;
    public string tvIp;
    public string playerState;
    public string idleReason;
    public string castUrl;
    public string error;
}

public class CastFrame {
    public string sourceId;
    public string destId;
    public string ns;
    public string payload;
}

public static class AtomicCastV2 {
    private static readonly JavaScriptSerializer Json = new JavaScriptSerializer();

    static AtomicCastV2() {
        try {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            ServicePointManager.DefaultConnectionLimit = 128;
            ServicePointManager.Expect100Continue = false;
            ServicePointManager.UseNagleAlgorithm = false;
        } catch {}
    }

    private static byte[] EncodeVarint(uint val) {
        List<byte> b = new List<byte>();
        while (val >= 0x80) {
            b.Add((byte)((val & 0x7F) | 0x80));
            val >>= 7;
        }
        b.Add((byte)val);
        return b.ToArray();
    }

    private static void WriteStringField(MemoryStream ms, int fieldNum, string val) {
        if (val == null) val = "";
        byte[] utf = Encoding.UTF8.GetBytes(val);
        byte[] tag = EncodeVarint((uint)((fieldNum << 3) | 2));
        byte[] len = EncodeVarint((uint)utf.Length);
        ms.Write(tag, 0, tag.Length);
        ms.Write(len, 0, len.Length);
        ms.Write(utf, 0, utf.Length);
    }

    private static void WriteVarintField(MemoryStream ms, int fieldNum, uint val) {
        byte[] tag = EncodeVarint((uint)((fieldNum << 3) | 0));
        byte[] vb = EncodeVarint(val);
        ms.Write(tag, 0, tag.Length);
        ms.Write(vb, 0, vb.Length);
    }

    public static byte[] BuildCastPacket(string srcId, string dstId, string ns, string payloadJson) {
        MemoryStream ms = new MemoryStream();
        WriteVarintField(ms, 1, 0);
        WriteStringField(ms, 2, srcId);
        WriteStringField(ms, 3, dstId);
        WriteStringField(ms, 4, ns);
        WriteVarintField(ms, 5, 0);
        WriteStringField(ms, 6, payloadJson);
        byte[] body = ms.ToArray();
        byte[] packet = new byte[4 + body.Length];
        packet[0] = (byte)((body.Length >> 24) & 0xFF);
        packet[1] = (byte)((body.Length >> 16) & 0xFF);
        packet[2] = (byte)((body.Length >> 8) & 0xFF);
        packet[3] = (byte)(body.Length & 0xFF);
        Buffer.BlockCopy(body, 0, packet, 4, body.Length);
        return packet;
    }

    private static uint ReadVarint(byte[] buf, ref int pos) {
        uint res = 0;
        int shift = 0;
        while (pos < buf.Length) {
            byte b = buf[pos++];
            res |= (uint)(b & 0x7F) << shift;
            if ((b & 0x80) == 0) break;
            shift += 7;
        }
        return res;
    }

    public static CastFrame DecodeCastBody(byte[] buf) {
        CastFrame cf = new CastFrame();
        int pos = 0;
        while (pos < buf.Length) {
            uint key = ReadVarint(buf, ref pos);
            int fn = (int)(key >> 3);
            int wt = (int)(key & 0x07);
            if (wt == 0) {
                ReadVarint(buf, ref pos);
            } else if (wt == 2) {
                int len = (int)ReadVarint(buf, ref pos);
                if (pos + len > buf.Length) break;
                string s = Encoding.UTF8.GetString(buf, pos, len);
                pos += len;
                if (fn == 2) cf.sourceId = s;
                else if (fn == 3) cf.destId = s;
                else if (fn == 4) cf.ns = s;
                else if (fn == 6) cf.payload = s;
            } else if (wt == 1) {
                pos += 8;
            } else if (wt == 5) {
                pos += 4;
            } else {
                break;
            }
        }
        return cf;
    }

    private static bool ReadExact(Stream st, byte[] buf, int count) {
        int off = 0;
        while (off < count) {
            int n = st.Read(buf, off, count - off);
            if (n <= 0) return false;
            off += n;
        }
        return true;
    }

    private static CastFrame ReadFrame(SslStream ssl) {
        byte[] lenBuf = new byte[4];
        if (!ReadExact(ssl, lenBuf, 4)) return null;
        int len = (lenBuf[0] << 24) | (lenBuf[1] << 16) | (lenBuf[2] << 8) | lenBuf[3];
        if (len <= 0 || len > 1048576) return null;
        byte[] body = new byte[len];
        if (!ReadExact(ssl, body, len)) return null;
        return DecodeCastBody(body);
    }

    private static void SendFrame(SslStream ssl, string src, string dst, string ns, string jsonPayload) {
        byte[] pkt = BuildCastPacket(src, dst, ns, jsonPayload);
        ssl.Write(pkt, 0, pkt.Length);
        ssl.Flush();
    }

    private static bool ValidateCert(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors err) {
        return true;
    }

    private static CastDeviceInfo ProbeEureka(string ip) {
        try {
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create("http://" + ip + ":8008/setup/eureka_info?options=detail");
            req.Timeout = 1000;
            req.ReadWriteTimeout = 1000;
            using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
            using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8)) {
                string txt = sr.ReadToEnd();
                Dictionary<string, object> obj = Json.DeserializeObject(txt) as Dictionary<string, object>;
                if (obj != null) {
                    CastDeviceInfo info = new CastDeviceInfo();
                    info.ip = ip;
                    info.port = 8009;
                    info.name = obj.ContainsKey("name") ? Convert.ToString(obj["name"]) : ("Android TV (" + ip + ")");
                    if (obj.ContainsKey("device_info") && obj["device_info"] is Dictionary<string, object>) {
                        Dictionary<string, object> di = (Dictionary<string, object>)obj["device_info"];
                        info.model = di.ContainsKey("model_name") ? Convert.ToString(di["model_name"]) : "Chromecast / Android TV";
                    } else {
                        info.model = "Chromecast / Android TV";
                    }
                    info.source = "eureka";
                    return info;
                }
            }
        } catch {}
        return null;
    }

    private static bool IsPortOpen(string ip, int port, int timeoutMs) {
        try {
            using (TcpClient c = new TcpClient()) {
                IAsyncResult ar = c.BeginConnect(ip, port, null, null);
                if (ar.AsyncWaitHandle.WaitOne(timeoutMs, false)) {
                    c.EndConnect(ar);
                    return true;
                }
            }
        } catch {}
        return false;
    }

    public static List<CastDeviceInfo> DiscoverDevices(string lanIp, int timeoutMs) {
        Dictionary<string, CastDeviceInfo> found = new Dictionary<string, CastDeviceInfo>();
        object sync = new object();

        try {
            byte[] q = new byte[] {
                0x00,0x00,0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x00,
                11,0x5f,0x67,0x6f,0x6f,0x67,0x6c,0x65,0x63,0x61,0x73,0x74,
                4,0x5f,0x74,0x63,0x70,
                5,0x6c,0x6f,0x63,0x61,0x6c,
                0x00, 0x00,0x0c, 0x00,0x01
            };
            using (UdpClient udp = new UdpClient()) {
                udp.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                udp.Client.Bind(new IPEndPoint(IPAddress.Parse(lanIp), 0));
                udp.Client.ReceiveTimeout = 600;
                IPEndPoint mcast = new IPEndPoint(IPAddress.Parse("224.0.0.251"), 5353);
                udp.Send(q, q.Length, mcast);
                DateTime deadline = DateTime.UtcNow.AddMilliseconds(Math.Min(1200, timeoutMs));
                while (DateTime.UtcNow < deadline) {
                    try {
                        IPEndPoint rem = new IPEndPoint(IPAddress.Any, 0);
                        byte[] resp = udp.Receive(ref rem);
                        string ip = rem.Address.ToString();
                        string ascii = Regex.Replace(Encoding.UTF8.GetString(resp), @"[^\u0020-\u00FF]+", "|");
                        string fn = null;
                        string md = null;
                        Match mFn = Regex.Match(ascii, @"fn=([^|]{1,64})");
                        if (mFn.Success) fn = mFn.Groups[1].Value.Trim();
                        Match mMd = Regex.Match(ascii, @"md=([^|]{1,48})");
                        if (mMd.Success) md = mMd.Groups[1].Value.Trim();
                        lock (sync) {
                            if (!found.ContainsKey(ip)) {
                                CastDeviceInfo d = new CastDeviceInfo();
                                d.ip = ip;
                                d.port = 8009;
                                d.name = string.IsNullOrEmpty(fn) ? ("Chromecast / TV (" + ip + ")") : fn;
                                d.model = string.IsNullOrEmpty(md) ? "Android TV / Cast" : md;
                                d.source = "mdns";
                                found[ip] = d;
                            }
                        }
                    } catch { break; }
                }
            }
        } catch {}

        try {
            int lastDot = lanIp.LastIndexOf('.');
            if (lastDot > 0) {
                string prefix = lanIp.Substring(0, lastDot + 1);
                List<Thread> workers = new List<Thread>();
                int nextHost = 1;
                object qLock = new object();
                for (int t = 0; t < 32; t++) {
                    Thread th = new Thread(delegate() {
                        try {
                            while (true) {
                                int h;
                                lock (qLock) {
                                    if (nextHost > 254) return;
                                    h = nextHost++;
                                }
                                string targetIp = prefix + h.ToString();
                                if (targetIp == lanIp) continue;
                                lock (sync) { if (found.ContainsKey(targetIp)) continue; }
                                if (IsPortOpen(targetIp, 8009, 240)) {
                                    CastDeviceInfo d = ProbeEureka(targetIp);
                                    if (d == null) {
                                        d = new CastDeviceInfo();
                                        d.ip = targetIp;
                                        d.port = 8009;
                                        d.name = "Android TV / Chromecast (" + targetIp + ")";
                                        d.model = "Google Cast";
                                        d.source = "tcp8009";
                                    }
                                    lock (sync) {
                                        if (!found.ContainsKey(targetIp)) found[targetIp] = d;
                                    }
                                }
                            }
                        } catch {}
                    });
                    th.IsBackground = true;
                    th.Start();
                    workers.Add(th);
                }
                foreach (Thread th in workers) th.Join(2000);
            }
        } catch {}

        return new List<CastDeviceInfo>(found.Values);
    }

    public static CastCommandResult CastMedia(string tvIp, int tvPort, string mediaUrl, string title, string subtitle, string imageUrl) {
        CastCommandResult res = new CastCommandResult();
        res.tvIp = tvIp;
        res.castUrl = mediaUrl;
        res.ok = false;

        TcpClient tcp = null;
        SslStream ssl = null;
        try {
            tcp = new TcpClient();
            IAsyncResult ar = tcp.BeginConnect(tvIp, tvPort, null, null);
            if (!ar.AsyncWaitHandle.WaitOne(2500, false)) {
                res.error = "Tiempo agotado conectando a " + tvIp + ":" + tvPort + ". Verifica que tu Android TV esté encendida en el mismo Wi-Fi.";
                return res;
            }
            tcp.EndConnect(ar);
            tcp.ReceiveTimeout = 13000;
            tcp.SendTimeout = 4000;

            ssl = new SslStream(tcp.GetStream(), false, new RemoteCertificateValidationCallback(ValidateCert), null);
            ssl.AuthenticateAsClient(tvIp, null, SslProtocols.Tls12, false);

            string senderId = "sender-" + (Environment.TickCount & 0x7FFF).ToString();
            SendFrame(ssl, senderId, "receiver-0", "urn:x-cast:com.google.cast.tp.connection", "{\"type\":\"CONNECT\",\"origin\":{}}");
            SendFrame(ssl, senderId, "receiver-0", "urn:x-cast:com.google.cast.tp.heartbeat", "{\"type\":\"PING\"}");
            SendFrame(ssl, senderId, "receiver-0", "urn:x-cast:com.google.cast.receiver", "{\"type\":\"LAUNCH\",\"appId\":\"CC1AD845\",\"requestId\":1}");

            string transportId = null;
            DateTime deadlineLaunch = DateTime.UtcNow.AddSeconds(7);
            while (DateTime.UtcNow < deadlineLaunch && transportId == null) {
                CastFrame cf = ReadFrame(ssl);
                if (cf == null) break;
                if (cf.ns == "urn:x-cast:com.google.cast.tp.heartbeat" && cf.payload != null && cf.payload.Contains("PING")) {
                    SendFrame(ssl, senderId, "receiver-0", "urn:x-cast:com.google.cast.tp.heartbeat", "{\"type\":\"PONG\"}");
                } else if (cf.ns == "urn:x-cast:com.google.cast.receiver" && cf.payload != null) {
                    Dictionary<string, object> obj = Json.DeserializeObject(cf.payload) as Dictionary<string, object>;
                    if (obj != null && obj.ContainsKey("status") && obj["status"] is Dictionary<string, object>) {
                        Dictionary<string, object> st = (Dictionary<string, object>)obj["status"];
                        if (st.ContainsKey("applications") && st["applications"] is object[]) {
                            foreach (object ao in (object[])st["applications"]) {
                                Dictionary<string, object> app = ao as Dictionary<string, object>;
                                if (app != null && Convert.ToString(app["appId"]) == "CC1AD845" && app.ContainsKey("transportId")) {
                                    transportId = Convert.ToString(app["transportId"]);
                                    break;
                                }
                            }
                        }
                    }
                }
            }

            if (string.IsNullOrEmpty(transportId)) {
                res.error = "La TV no abrió el receptor Chromecast (CC1AD845).";
                return res;
            }

            SendFrame(ssl, senderId, transportId, "urn:x-cast:com.google.cast.tp.connection", "{\"type\":\"CONNECT\",\"origin\":{}}");

            Dictionary<string, object> meta = new Dictionary<string, object>();
            meta["metadataType"] = 0;
            meta["title"] = string.IsNullOrEmpty(title) ? "AtomicBombTV" : title;
            meta["subtitle"] = string.IsNullOrEmpty(subtitle) ? "AtomicBombTV" : subtitle;
            if (!string.IsNullOrEmpty(imageUrl)) {
                Dictionary<string, object> img = new Dictionary<string, object>();
                img["url"] = imageUrl;
                meta["images"] = new object[] { img };
            }

            // Omitir hlsSegmentFormat / hlsVideoSegmentFormat forzados para permitir autodetección TS/AAC/CMAF en Android TV
            Dictionary<string, object> media = new Dictionary<string, object>();
            media["contentId"] = mediaUrl;
            media["streamType"] = "LIVE";
            media["contentType"] = "application/vnd.apple.mpegurl";
            media["metadata"] = meta;

            Dictionary<string, object> loadReq = new Dictionary<string, object>();
            loadReq["type"] = "LOAD";
            loadReq["requestId"] = 2;
            loadReq["autoplay"] = true;
            loadReq["media"] = media;

            SendFrame(ssl, senderId, transportId, "urn:x-cast:com.google.cast.media", Json.Serialize(loadReq));

            DateTime deadlineMedia = DateTime.UtcNow.AddSeconds(12);
            DateTime bufferingDeadline = DateTime.MaxValue;
            bool sawBuffering = false;
            while (DateTime.UtcNow < deadlineMedia && DateTime.UtcNow < bufferingDeadline) {
                CastFrame cf = ReadFrame(ssl);
                if (cf == null) break;
                if (cf.ns == "urn:x-cast:com.google.cast.tp.heartbeat" && cf.payload != null && cf.payload.Contains("PING")) {
                    SendFrame(ssl, senderId, "receiver-0", "urn:x-cast:com.google.cast.tp.heartbeat", "{\"type\":\"PONG\"}");
                } else if (cf.ns == "urn:x-cast:com.google.cast.media" && cf.payload != null) {
                    Dictionary<string, object> obj = Json.DeserializeObject(cf.payload) as Dictionary<string, object>;
                    if (obj != null) {
                        string msgType = obj.ContainsKey("type") ? Convert.ToString(obj["type"]) : "";
                        if (msgType == "LOAD_FAILED" || msgType == "INVALID_REQUEST") {
                            string det = "";
                            if (obj.ContainsKey("detailedErrorCode")) det += " code=" + Convert.ToString(obj["detailedErrorCode"]);
                            if (obj.ContainsKey("reason")) det += " reason=" + Convert.ToString(obj["reason"]);
                            res.error = "Receptor TV rechazó el stream (" + msgType + det + ")";
                            return res;
                        }
                        if (msgType == "MEDIA_STATUS" && obj.ContainsKey("status") && obj["status"] is object[]) {
                            object[] sts = (object[])obj["status"];
                            if (sts.Length > 0 && sts[0] is Dictionary<string, object>) {
                                Dictionary<string, object> ms = (Dictionary<string, object>)sts[0];
                                res.playerState = ms.ContainsKey("playerState") ? Convert.ToString(ms["playerState"]) : "";
                                res.idleReason = ms.ContainsKey("idleReason") ? Convert.ToString(ms["idleReason"]) : "";
                                if (res.playerState == "PLAYING") {
                                    res.ok = true;
                                    return res;
                                }
                                if (res.playerState == "BUFFERING" && !sawBuffering) {
                                    sawBuffering = true;
                                    bufferingDeadline = DateTime.UtcNow.AddMilliseconds(3500);
                                }
                                if (res.playerState == "IDLE" && res.idleReason == "ERROR") {
                                    res.error = "Android TV no pudo abrir la URL del stream (idleReason=ERROR).";
                                    return res;
                                }
                            }
                        }
                    }
                }
            }
            if (string.IsNullOrEmpty(res.error)) {
                res.ok = true;
                if (string.IsNullOrEmpty(res.playerState)) res.playerState = sawBuffering ? "BUFFERING" : "LOADING";
            }
        } catch (Exception ex) {
            res.error = ex.Message;
        } finally {
            try { if (ssl != null) ssl.Close(); } catch {}
            try { if (tcp != null) tcp.Close(); } catch {}
        }
        return res;
    }

    public static CastCommandResult StopCast(string tvIp, int tvPort) {
        CastCommandResult res = new CastCommandResult();
        res.tvIp = tvIp;
        res.ok = false;
        TcpClient tcp = null;
        SslStream ssl = null;
        try {
            tcp = new TcpClient();
            IAsyncResult ar = tcp.BeginConnect(tvIp, tvPort, null, null);
            if (!ar.AsyncWaitHandle.WaitOne(2000, false)) { res.error = "Timeout"; return res; }
            tcp.EndConnect(ar);
            ssl = new SslStream(tcp.GetStream(), false, new RemoteCertificateValidationCallback(ValidateCert), null);
            ssl.AuthenticateAsClient(tvIp, null, SslProtocols.Tls12, false);
            string senderId = "sender-stop";
            SendFrame(ssl, senderId, "receiver-0", "urn:x-cast:com.google.cast.tp.connection", "{\"type\":\"CONNECT\",\"origin\":{}}");
            SendFrame(ssl, senderId, "receiver-0", "urn:x-cast:com.google.cast.receiver", "{\"type\":\"STOP\",\"requestId\":9}");
            res.ok = true;
            res.playerState = "IDLE";
        } catch (Exception ex) {
            res.error = ex.Message;
        } finally {
            try { if (ssl != null) ssl.Close(); } catch {}
            try { if (tcp != null) tcp.Close(); } catch {}
        }
        return res;
    }
}

public static class AtomicHttpServer {
    private static readonly JavaScriptSerializer Json = new JavaScriptSerializer();
    private static readonly ConcurrentDictionary<string, FreshTokenEntry> TokenCache = new ConcurrentDictionary<string, FreshTokenEntry>();
    private static readonly ConcurrentDictionary<string, long> TsAudioSkewCache = new ConcurrentDictionary<string, long>();
    private static readonly object RefreshLock = new object();

    private class FreshTokenEntry {
        public string StreamUrl;
        public string Referer;
        public DateTime ExpiresUtc;
    }

    private class ResolvedPair {
        public string Url;
        public string Referer;
    }

    public static volatile string ScriptDir = ".";
    public static volatile int HttpPort = 45454;
    public static volatile string LanIp = "127.0.0.1";
    public static volatile string CurrentChannel = "Explorando canales...";
    public static volatile bool ChannelChanged = false;
    public static long StartTimestamp = 0;

    private static TcpListener _listener;
    private static volatile bool _running = false;
    private static string _activeStreamxHost = "streamx723.sbs";

    private static readonly object TxLock = new object();
    private static readonly object RemoteCmdLock = new object();
    private static Dictionary<string, object> _pendingRemoteCmd = null;
    private static readonly object TelemetryLock = new object();
    private static Dictionary<string, object> _latestTelemetry = null;
    public static volatile bool ShutdownRequested = false;
    private static readonly object LifecycleLock = new object();
    private static bool _hasSeenPlayerClient = false;
    private static DateTime _lastPlayerActivityUtc = DateTime.MinValue;
    private static DateTime _playerClosingUtc = DateTime.MinValue;
    private static Process _txProc = null;
    private static string _txSid = "";
    private static string _txDir = "";
    private static string _txSourceKey = "";
    private static string _txMode = "";
    private static string _txVideoCodec = "";
    private static string _txAudioCodec = "";
    private static DateTime _txLastAccessUtc = DateTime.MinValue;
    private static Thread _txReaperThread = null;
    private static long _txSeq = 0;
    private static string _cachedFfmpegPath = null;
    private static string _cachedFfprobePath = null;

    private class AceCand {
        public string Cid;
        public string RawName;
        public int Score;
        public int Up;
        public int Down;
    }

    private static string ClassifyAceGroup(string name) {
        if (string.IsNullOrEmpty(name)) return "Deportes España";
        if (Regex.IsMatch(name, @"(?i)DAZN\s*F1|Formula\s*1.*Espa[ñn]|F1.*Espa[ñn]|F1.*DAZN|Movistar.*F1")) return "F1 España";
        if (Regex.IsMatch(name, @"(?i)DAZN\s*MotoGP|Moto\s*GP.*Espa[ñn]|Moto\s*GP.*DAZN|Moto[23].*DAZN|Movistar.*MotoGP")) return "MotoGP España";
        if (Regex.IsMatch(name, @"(?i)RTVE|\bLa\s*[12]\b|Teledeporte|24 Horas|Clan|Antena\s*3|Cuatro|Telecinco|La\s*Sexta")) return "TDT España";
        if (Regex.IsMatch(name, @"(?i)M\.?\+?\s*(?:La\s*Liga|Liga\s*(?:de\s*)?Campeones)|^Campeones\s*\d|Hypermotion|DAZN\s*La\s*Liga|LaLiga")) return "Fútbol España";
        if (Regex.IsMatch(name, @"(?i)(?:M\.?\+?|Movistar)\s*(?:Estrenos|Acci[oó]n|Comedia|Drama|Originales|Cine|Cl[aá]sico|Hits|Musicales|Pop\s*Up|Series|Terror|Indie|Romance)")) return "Cine y Series España";
        if (Regex.IsMatch(name, @"(?i)(?:M\.?\+?|Movistar)\s*(?:Documentales|Cero)")) return "Documentales y Cultura España";
        if (Regex.IsMatch(name, @"(?i)Formula\s*1|\bF1\b|\bF1TV\b|Sky\s*Sports?\s*F1")) return "Formula 1 Internacional";
        if (Regex.IsMatch(name, @"(?i)MotoGP|Moto\s*GP|Moto2|Moto3")) return "MotoGP y Motor Internacional";
        if (Regex.IsMatch(name, @"(?i)M\.?\+?\s*(?:Deportes?\b|Vamos|Golf|Multideporte)|DAZN|Eurosport|Tennis\s*Channel|Tenis|Movistar")) return "Deportes España";
        return "Otros";
    }

    private static Dictionary<string, object> SearchFreshAceStreams(string tagsCsv, int maxChannels) {
        string defaultCsv = "m+,movistar,motogp,f1,formula,dazn,tenis,tennis,laliga,champions,deportes,eurosport,golf,vamos,elcano,shickat";
        string effectiveCsv = string.IsNullOrEmpty(tagsCsv) ? defaultCsv : tagsCsv;
        string[] rawParts = effectiveCsv.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
        List<string> tagList = new List<string>();
        HashSet<string> seenTags = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (string rp in rawParts) {
            string t = rp.Trim();
            if (!string.IsNullOrEmpty(t) && seenTags.Add(t)) tagList.Add(t);
            if (tagList.Count >= 20) break;
        }
        if (tagList.Count == 0) {
            tagList.Add("m+"); tagList.Add("motogp"); tagList.Add("tenis"); tagList.Add("f1"); tagList.Add("dazn");
        }

        string[] responses = new string[tagList.Count];
        Thread[] workers = new Thread[tagList.Count];
        for (int i = 0; i < tagList.Count; i++) {
            int idx = i;
            string tag = tagList[idx];
            workers[idx] = new Thread(delegate() {
                try {
                    string apiUri = "https://search-ace.stream/search?query=" + Uri.EscapeDataString(tag);
                    HttpWebRequest req = (HttpWebRequest)WebRequest.Create(apiUri);
                    req.Method = "GET";
                    req.Timeout = 5000;
                    req.ReadWriteTimeout = 5000;
                    req.Referer = "https://search-ace.stream/";
                    req.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36";
                    req.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
                    using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
                    using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8)) {
                        responses[idx] = sr.ReadToEnd();
                    }
                } catch { }
            });
            workers[idx].IsBackground = true;
            workers[idx].Start();
        }
        for (int i = 0; i < workers.Length; i++) {
            try { workers[i].Join(6000); } catch { }
        }

        Dictionary<string, AceCand> cidMap = new Dictionary<string, AceCand>(StringComparer.OrdinalIgnoreCase);
        for (int i = 0; i < responses.Length; i++) {
            string body = responses[i];
            if (string.IsNullOrEmpty(body)) continue;
            try {
                object[] arr = Json.Deserialize<object[]>(body);
                if (arr == null) continue;
                foreach (object itemObj in arr) {
                    Dictionary<string, object> it = itemObj as Dictionary<string, object>;
                    if (it == null) continue;
                    string cid = it.ContainsKey("content_id") && it["content_id"] != null ? it["content_id"].ToString().Trim().ToLowerInvariant() : "";
                    if (!Regex.IsMatch(cid, @"^[a-f0-9]{40}$")) continue;
                    string rn = it.ContainsKey("name") && it["name"] != null ? it["name"].ToString().Trim() : "";
                    if (string.IsNullOrEmpty(rn)) continue;
                    int up = 0; int dn = 0;
                    try { if (it.ContainsKey("thumbs_up") && it["thumbs_up"] != null) up = Convert.ToInt32(it["thumbs_up"]); } catch { }
                    try { if (it.ContainsKey("thumbs_down") && it["thumbs_down"] != null) dn = Convert.ToInt32(it["thumbs_down"]); } catch { }
                    if (up == 0 && dn >= 2) continue;
                    if (dn > up + 3) continue;
                    int score = (up * 3) - (dn * 2);
                    AceCand existing;
                    if (!cidMap.TryGetValue(cid, out existing) || score > existing.Score) {
                        AceCand c = new AceCand();
                        c.Cid = cid; c.RawName = rn; c.Score = score; c.Up = up; c.Down = dn;
                        cidMap[cid] = c;
                    }
                }
            } catch { }
        }

        List<AceCand> cands = new List<AceCand>(cidMap.Values);
        cands.Sort(delegate(AceCand a, AceCand b) {
            int cmp = b.Score.CompareTo(a.Score);
            return (cmp != 0) ? cmp : b.Up.CompareTo(a.Up);
        });

        List<Dictionary<string, object>> channelsOut = new List<Dictionary<string, object>>();
        HashSet<string> seenNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (AceCand cand in cands) {
            if (channelsOut.Count >= maxChannels) break;
            string rn = cand.RawName;
            if (Regex.IsMatch(rn, @"(?i)\b(?:test|promo|adult|xxx|vod)\b")) continue;
            bool isMotor = Regex.IsMatch(rn, @"(?i)F1|Formula\s*1|Fórmula\s*1|Moto\s*GP|MotoGP|F1TV");
            bool isTennis = Regex.IsMatch(rn, @"(?i)\b(?:Tennis\s*Channel|Tenis|ATP|WTA)\b") && cand.Score >= 3;
            bool isEs = Regex.IsMatch(rn, @"(?i)DAZN|M\+|M\.|Movistar|LaLiga|Hypermotion|Campeones|Deportes|Vamos|Golf|Estrenos|Cl[aá]sicos|Comedia|Drama|Terror|Indie|Romance|Hits|Originales|Documentales|Cine\s*Espa|Teledeporte|\bLa\s*[12]\b|Antena\s*3|Cuatro|Telecinco|La\s*Sexta") && !Regex.IsMatch(rn, @"(?i)\[(?:DE|PL|RU|IT|FR|NL|TR|UK|PT|RO|BR|CZ|HU)\]");
            bool isEu = Regex.IsMatch(rn, @"(?i)^Eurosport\s*[12]\b") && !Regex.IsMatch(rn, @"(?i)\[(?:RU|PL|NL|IT|DE|FR|TR|AR|UK|PT|RO|BR|CZ|HU)\]|\b(?:RUS|POL|GER|FRA|ITA|POR|RUM|TUR)\b");
            if (!isMotor && !isTennis && !isEs && !isEu) continue;
            if (isMotor && !isEs && cand.Score < 6) continue;

            string clean = Regex.Replace(rn, @"\|.*$", "");
            clean = Regex.Replace(clean, @"-->?\s*NEW\s*ERA", "");
            clean = Regex.Replace(clean, @"(?i)\b(?:IPNS|ZeroNet)\b", "");
            clean = Regex.Replace(clean, @"\[[^\]]*https?[^\]]*\]", "");
            clean = Regex.Replace(clean, @"https?://\S+", "");
            clean = Regex.Replace(clean, @"(?i)\belcano\.top\b", "(Elcano)");
            clean = Regex.Replace(clean, @"(?i)\bshickat\b", "(Shickat)");
            clean = Regex.Replace(clean, @"\s*\((?:Elcano|Shickat)\)\s*\((?:Elcano|Shickat)\)", "");
            clean = Regex.Replace(clean, @"(?i)\s+\bSpain\b\s*$", "");
            clean = Regex.Replace(clean, @"\s{2,}", " ").Trim(' ', '-', '|', '/');
            if (string.IsNullOrEmpty(clean)) continue;
            clean = Regex.Replace(clean, @"^M\.?\s+(Deportes.*)$", "M+ $1");
            clean = Regex.Replace(clean, @"^M\.\s*(.+)$", "M+ $1");
            if (Regex.IsMatch(clean, @"(?i)^Moto\s*GP\b") && clean.IndexOf("DAZN", StringComparison.OrdinalIgnoreCase) < 0) clean = "DAZN " + clean;
            clean = Regex.Replace(clean, @"(?i)Moto\s*GP", "MotoGP");

            string dispName = clean + " [AceStream P2P]";
            string grp = ClassifyAceGroup(dispName);
            if (!seenNames.Add(dispName)) continue;

            Dictionary<string, object> row = new Dictionary<string, object>();
            row["Id"] = "ace_" + cand.Cid.Substring(0, 12);
            row["Name"] = dispName;
            row["Group"] = grp;
            row["Slug"] = "acestream";
            row["MasterUrl"] = "acestream://" + cand.Cid;
            row["FallbackUrl"] = "http://127.0.0.1:6878/ace/manifest.m3u8?id=" + cand.Cid;
            row["VpnRequired"] = false;
            row["Up"] = cand.Up;
            row["Down"] = cand.Down;
            channelsOut.Add(row);
        }

        Dictionary<string, object> res = new Dictionary<string, object>();
        res["ok"] = true;
        res["source"] = "https://search-ace.stream/";
        res["tags"] = tagList.ToArray();
        res["count"] = channelsOut.Count;
        res["channels"] = channelsOut.ToArray();
        return res;
    }

    private class TranscodeResult {
        public bool Ok;
        public string Sid;
        public string PlaylistPath;
        public string VideoCodec;
        public string AudioCodec;
        public string TranscodeMode;
        public string Error;
    }

    private const string UaBrowser = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
    private const string UaIptv = "TiviMate/4.7.0";

    private static bool IsIptvDirectUrl(string url) {
        if (string.IsNullOrEmpty(url)) return false;
        return Regex.IsMatch(url, @"(?:\/play\/hls|lvtoken=)", RegexOptions.IgnoreCase);
    }

    private static string FindTool(string exeName) {
        try {
            List<string> candidates = new List<string>();
            if (!string.IsNullOrEmpty(ScriptDir)) {
                candidates.Add(Path.Combine(ScriptDir, exeName));
                candidates.Add(Path.Combine(ScriptDir, "ffmpeg\\bin\\" + exeName));
                candidates.Add(Path.Combine(ScriptDir, "bin\\" + exeName));
            }
            candidates.Add(Path.Combine("C:\\ffmpeg\\bin", exeName));
            try {
                string pf = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
                if (!string.IsNullOrEmpty(pf)) candidates.Add(Path.Combine(pf, "ffmpeg\\bin\\" + exeName));
            } catch {}
            string pathEnv = Environment.GetEnvironmentVariable("PATH") ?? "";
            foreach (string p in pathEnv.Split(';')) {
                string tp = (p ?? "").Trim().Trim('"');
                if (!string.IsNullOrEmpty(tp)) candidates.Add(Path.Combine(tp, exeName));
            }
            foreach (string c in candidates) {
                try {
                    if (!string.IsNullOrEmpty(c) && File.Exists(c)) return c;
                } catch {}
            }
        } catch {}
        return "";
    }

    public static bool HasFfmpeg() {
        if (_cachedFfmpegPath == null) _cachedFfmpegPath = FindTool("ffmpeg.exe");
        return !string.IsNullOrEmpty(_cachedFfmpegPath);
    }

    private static string GetFfprobePath() {
        if (_cachedFfprobePath == null) _cachedFfprobePath = FindTool("ffprobe.exe");
        return _cachedFfprobePath;
    }

    private static void StopTranscoderLocked() {
        if (_txProc != null) {
            try { if (!_txProc.HasExited) _txProc.Kill(); } catch {}
            try { _txProc.Dispose(); } catch {}
            _txProc = null;
        }
        if (!string.IsNullOrEmpty(_txDir)) {
            string oldDir = _txDir;
            _txDir = "";
            _txSid = "";
            _txSourceKey = "";
            _txMode = "";
            _txVideoCodec = "";
            _txAudioCodec = "";
            ThreadPool.QueueUserWorkItem(delegate(object dObj) {
                Thread.Sleep(220);
                try { if (Directory.Exists((string)dObj)) Directory.Delete((string)dObj, true); } catch {}
            }, oldDir);
        } else {
            _txSid = "";
            _txSourceKey = "";
            _txMode = "";
            _txVideoCodec = "";
            _txAudioCodec = "";
        }
    }

    private static void TxReaperLoop() {
        while (_running) {
            try {
                Thread.Sleep(4000);
                lock (TxLock) {
                    if (_txProc != null && !_txProc.HasExited && (DateTime.UtcNow - _txLastAccessUtc).TotalSeconds > 120) {
                        StopTranscoderLocked();
                    }
                }
            } catch {}
        }
    }

    private static void ProbeStreamCodecs(string localProxyUrl, out string vCodec, out string aCodec, out bool videoIncompatible) {
        vCodec = "";
        aCodec = "";
        videoIncompatible = false;
        string ffprobe = GetFfprobePath();
        if (string.IsNullOrEmpty(ffprobe)) return;
        Process p = null;
        try {
            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = ffprobe;
            psi.Arguments = "-v error -extension_picky 0 -allowed_segment_extensions ALL -analyzeduration 1800000 -probesize 1500000 -show_entries stream=codec_type,codec_name,profile,pix_fmt,width -of compact \"" + localProxyUrl.Replace("\"", "") + "\"";
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            p = Process.Start(psi);
            string stdout = "";
            Thread outReader = new Thread(delegate() {
                try { stdout = p.StandardOutput.ReadToEnd(); } catch {}
            });
            outReader.IsBackground = true;
            outReader.Start();
            if (!p.WaitForExit(6500)) {
                try { if (!p.HasExited) p.Kill(); } catch {}
            } else {
                outReader.Join(400);
            }
            if (!string.IsNullOrEmpty(stdout)) {
                foreach (string rawLine in stdout.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)) {
                    string sType = "";
                    string sCodec = "";
                    string sProf = "";
                    string sPix = "";
                    int sWidth = 0;
                    foreach (string part in rawLine.Split('|')) {
                        int eq = part.IndexOf('=');
                        if (eq <= 0) continue;
                        string k = part.Substring(0, eq).Trim().ToLowerInvariant();
                        string v = part.Substring(eq + 1).Trim().ToLowerInvariant();
                        if (k == "codec_type") sType = v;
                        else if (k == "codec_name") sCodec = v;
                        else if (k == "profile") sProf = v;
                        else if (k == "pix_fmt") sPix = v;
                        else if (k == "width") { int.TryParse(v, out sWidth); }
                    }
                    if (sType == "video" && string.IsNullOrEmpty(vCodec)) {
                        vCodec = sCodec;
                        if ((!string.IsNullOrEmpty(sCodec) && sCodec != "h264") ||
                            sProf.Contains("10") || sProf.Contains("4:2:2") || sProf.Contains("4:4:4") ||
                            sPix.Contains("10") || sPix.Contains("12") || sPix.Contains("422") || sPix.Contains("444") ||
                            sWidth > 1920) {
                            videoIncompatible = true;
                        }
                    } else if (sType == "audio" && string.IsNullOrEmpty(aCodec)) {
                        aCodec = sCodec;
                    }
                }
            }
        } catch {}
        finally {
            if (p != null) { try { p.Dispose(); } catch {} }
        }
    }

    private static bool IsIncompatibleCastAudio(string audioCodec) {
        if (string.IsNullOrEmpty(audioCodec)) return false;
        return audioCodec == "mp2" || audioCodec == "ac3" || audioCodec == "eac3" ||
               audioCodec == "dts" || audioCodec == "truehd" || audioCodec == "mp3" ||
               audioCodec == "opus" || audioCodec == "vorbis" || audioCodec == "wmav2";
    }

    private static string BuildLocalCastProxyInputUrl(string uRaw, string refRaw, string fbRaw) {
        StringBuilder ub = new StringBuilder();
        ub.Append("http://127.0.0.1:").Append(HttpPort).Append("/cast-proxy?u=").Append(EncodeB64Url(uRaw));
        if (!string.IsNullOrEmpty(refRaw)) ub.Append("&ref=").Append(EncodeB64Url(refRaw));
        if (!string.IsNullOrEmpty(fbRaw)) ub.Append("&fb=").Append(EncodeB64Url(fbRaw));
        return ub.ToString();
    }

    private static TranscodeResult StartTranscode(string uRaw, string refRaw, string fbRaw, string reqMode, string titleHint) {
        TranscodeResult res = new TranscodeResult();
        if (!HasFfmpeg()) {
            res.Error = "ffmpeg.exe no encontrado";
            return res;
        }
        string effReqMode = string.IsNullOrEmpty(reqMode) ? "auto" : reqMode.Trim().ToLowerInvariant();
        if (effReqMode != "h264" && effReqMode != "audio" && effReqMode != "auto") effReqMode = "auto";

        string localInput = BuildLocalCastProxyInputUrl(uRaw, refRaw, fbRaw);

        // Decidir si necesitamos transcodificar vídeo H.264 o basta -c:v copy + AAC
        string probedV = "";
        string probedA = "";
        bool probedVIncompat = false;
        bool encodeH264 = (effReqMode == "h264");
        if (effReqMode == "auto") {
            bool titleHintsHevc = !string.IsNullOrEmpty(titleHint) && Regex.IsMatch(titleHint, @"\b(?:HEVC|H\.?265|HDR|UHD|4K)\b", RegexOptions.IgnoreCase);
            ProbeStreamCodecs(localInput, out probedV, out probedA, out probedVIncompat);
            if (!string.IsNullOrEmpty(probedV)) {
                encodeH264 = probedVIncompat;
            } else {
                encodeH264 = titleHintsHevc;
            }
        }
        string actualMode = encodeH264 ? "h264" : "audio";

        lock (TxLock) {
            if (_txProc != null && !_txProc.HasExited && _txSourceKey == uRaw && _txMode == actualMode && !string.IsNullOrEmpty(_txDir)) {
                string existM3u8 = Path.Combine(_txDir, "index.m3u8");
                if (File.Exists(existM3u8)) {
                    _txLastAccessUtc = DateTime.UtcNow;
                    res.Ok = true;
                    res.Sid = _txSid;
                    res.PlaylistPath = "/tx/" + _txSid + "/index.m3u8";
                    res.VideoCodec = !string.IsNullOrEmpty(_txVideoCodec) ? _txVideoCodec : (encodeH264 ? "hevc->h264" : "h264");
                    res.AudioCodec = _txAudioCodec;
                    res.TranscodeMode = actualMode;
                    return res;
                }
            }
            StopTranscoderLocked();

            long seq = Interlocked.Increment(ref _txSeq);
            string sid = "s" + seq.ToString() + "_" + (Environment.TickCount & 0xFFFF).ToString("x");
            string baseTmp = Path.Combine(Path.GetTempPath(), "abtv_tx_" + HttpPort.ToString());
            string txDir = Path.Combine(baseTmp, sid);
            Directory.CreateDirectory(txDir);

            string m3u8Path = Path.Combine(txDir, "index.m3u8");
            string segPattern = Path.Combine(txDir, "seg_%05d.ts");

            StringBuilder args = new StringBuilder();
            args.Append("-hide_banner -loglevel warning ");
            args.Append("-extension_picky 0 -allowed_segment_extensions ALL ");
            args.Append("-fflags +genpts+discardcorrupt -avoid_negative_ts make_zero ");
            args.Append("-i \"").Append(localInput.Replace("\"", "")).Append("\" ");
            args.Append("-map 0:v:0? -map 0:a:0? -sn ");
            if (encodeH264) {
                args.Append("-vf \"yadif=0:-1:1,scale='min(1920,iw)':-2,format=yuv420p\" ");
                args.Append("-c:v libx264 -preset ultrafast -tune zerolatency -profile:v high -level 4.1 -sc_threshold 0 -force_key_frames \"expr:gte(t,n_forced*2)\" -crf 23 -maxrate 5000k -bufsize 8000k ");
            } else {
                args.Append("-c:v copy ");
            }
            args.Append("-c:a aac -ac 2 -ar 48000 -b:a 160k -max_muxing_queue_size 1024 ");
            args.Append("-f hls -hls_time 2 -hls_list_size 40 -hls_delete_threshold 15 -hls_flags delete_segments+independent_segments+omit_endlist ");
            args.Append("-hls_segment_filename \"").Append(segPattern).Append("\" \"").Append(m3u8Path).Append("\"");

            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = _cachedFfmpegPath;
            psi.Arguments = args.ToString();
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardError = true;

            Process proc = Process.Start(psi);
            Thread errReader = new Thread(delegate() {
                try { proc.StandardError.ReadToEnd(); } catch {}
            });
            errReader.IsBackground = true;
            errReader.Start();

            _txProc = proc;
            _txSid = sid;
            _txDir = txDir;
            _txSourceKey = uRaw;
            _txMode = actualMode;
            _txVideoCodec = !string.IsNullOrEmpty(probedV) ? probedV : (encodeH264 ? "hevc" : "h264");
            _txAudioCodec = probedA;
            _txLastAccessUtc = DateTime.UtcNow;
        }

        // Esperar fuera del lock hasta 12s a que exista index.m3u8 + >= 2 segmentos .ts listos (o 1 tras 6s)
        string targetM3u8 = "";
        lock (TxLock) {
            targetM3u8 = string.IsNullOrEmpty(_txDir) ? "" : Path.Combine(_txDir, "index.m3u8");
        }
        DateTime startWait = DateTime.UtcNow;
        DateTime deadline = startWait.AddSeconds(12);
        bool ready = false;
        while (DateTime.UtcNow < deadline) {
            Process curProc = null;
            string curDir = "";
            lock (TxLock) {
                curProc = _txProc;
                curDir = _txDir;
            }
            if (curProc == null || curProc.HasExited || string.IsNullOrEmpty(curDir)) break;
            try {
                if (File.Exists(targetM3u8)) {
                    string txt = File.ReadAllText(targetM3u8);
                    MatchCollection segMatches = Regex.Matches(txt, @"(seg_\d+\.ts)");
                    if (txt.IndexOf("#EXTINF:", StringComparison.Ordinal) >= 0 && segMatches.Count > 0) {
                        int validCount = 0;
                        foreach (Match sm in segMatches) {
                            string segPath = Path.Combine(curDir, sm.Groups[1].Value);
                            if (File.Exists(segPath) && new FileInfo(segPath).Length >= 4096) {
                                validCount++;
                            }
                        }
                        if (validCount >= 2 || (validCount >= 1 && (DateTime.UtcNow - startWait).TotalSeconds >= 6.0)) {
                            ready = true;
                            break;
                        }
                    }
                }
            } catch {}
            Thread.Sleep(150);
        }

        lock (TxLock) {
            if (ready && _txProc != null && !_txProc.HasExited) {
                _txLastAccessUtc = DateTime.UtcNow;
                res.Ok = true;
                res.Sid = _txSid;
                res.PlaylistPath = "/tx/" + _txSid + "/index.m3u8";
                res.VideoCodec = _txVideoCodec;
                res.AudioCodec = _txAudioCodec;
                res.TranscodeMode = _txMode;
            } else {
                StopTranscoderLocked();
                res.Ok = false;
                res.Error = "ffmpeg no pudo generar segmentos HLS a tiempo";
            }
        }
        return res;
    }

    private static string ExtractTsStreamKey(string url) {
        if (string.IsNullOrEmpty(url)) return "";
        Match m = Regex.Match(url, @"^(https?://[^/]+/[^?]*)/[^/?]+_\d+\.ts", RegexOptions.IgnoreCase);
        if (m.Success) return m.Groups[1].Value;
        int qi = url.IndexOf('?');
        string clean = (qi >= 0) ? url.Substring(0, qi) : url;
        return Regex.Replace(clean, @"_\d+\.ts$", "", RegexOptions.IgnoreCase);
    }

    private static long ReadPesPts(byte[] b, int o) {
        long p30 = (long)(uint)((b[o] & 0x0E) >> 1);
        long p22 = (long)(uint)b[o + 1];
        long p15 = (long)(uint)((b[o + 2] & 0xFE) >> 1);
        long p7  = (long)(uint)b[o + 3];
        long p0  = (long)(uint)((b[o + 4] & 0xFE) >> 1);
        return (p30 << 30) | (p22 << 22) | (p15 << 15) | (p7 << 7) | p0;
    }

    private static void WritePesPts(byte[] b, int o, int topMarkerNibble, long pts) {
        long p = pts & 0x1FFFFFFFFL;
        b[o]     = (byte)((topMarkerNibble & 0xF0) | (int)((p >> 29) & 0x0E) | 0x01);
        b[o + 1] = (byte)((p >> 22) & 0xFF);
        b[o + 2] = (byte)((int)((p >> 14) & 0xFE) | 0x01);
        b[o + 3] = (byte)((p >> 7) & 0xFF);
        b[o + 4] = (byte)((int)((p << 1) & 0xFE) | 0x01);
    }

    private static long Signed33Delta(long a, long b) {
        long d = (a - b) & 0x1FFFFFFFFL;
        if (d >= 0x100000000L) d -= 0x200000000L;
        return d;
    }

    private static void AlignMpegTsPtsIfSkewed(string url, byte[] buf, int len) {
        if (buf == null || len < 188 || buf[0] != 0x47) return;
        long firstVideoPts = -1;
        long firstAudioPts = -1;
        for (int off = 0; off + 188 <= len; off += 188) {
            if (buf[off] != 0x47) continue;
            bool pusi = (buf[off + 1] & 0x40) != 0;
            int afc = (buf[off + 3] >> 4) & 0x03;
            if (!pusi || (afc != 1 && afc != 3)) continue;
            int pOff = off + 4;
            if (afc == 3) {
                if (pOff >= off + 188) continue;
                pOff += 1 + buf[pOff];
            }
            if (pOff + 14 > off + 188) continue;
            if (buf[pOff] != 0x00 || buf[pOff + 1] != 0x00 || buf[pOff + 2] != 0x01) continue;
            byte sid = buf[pOff + 3];
            int ptsFlags = (buf[pOff + 7] >> 6) & 0x03;
            if (ptsFlags < 2) continue;
            long pts = ReadPesPts(buf, pOff + 9);
            if (sid >= 0xE0 && sid <= 0xEF && firstVideoPts < 0) firstVideoPts = pts;
            else if (sid >= 0xC0 && sid <= 0xDF && firstAudioPts < 0) firstAudioPts = pts;
            if (firstVideoPts >= 0 && firstAudioPts >= 0) break;
        }
        if (firstVideoPts < 0 || firstAudioPts < 0) return;

        string key = ExtractTsStreamKey(url);
        long skewTicks = 0;
        bool hasCached = !string.IsNullOrEmpty(key) && TsAudioSkewCache.TryGetValue(key, out skewTicks);
        if (!hasCached) {
            long d = Signed33Delta(firstVideoPts, firstAudioPts);
            skewTicks = (Math.Abs(d) > 180000L) ? d : 0L;
            if (!string.IsNullOrEmpty(key)) TsAudioSkewCache[key] = skewTicks;
        } else if (skewTicks != 0) {
            long resyncedDiff = Signed33Delta(firstVideoPts, (firstAudioPts + skewTicks) & 0x1FFFFFFFFL);
            if (Math.Abs(resyncedDiff) > 450000L) {
                long d = Signed33Delta(firstVideoPts, firstAudioPts);
                skewTicks = (Math.Abs(d) > 180000L) ? d : 0L;
                TsAudioSkewCache[key] = skewTicks;
            }
        }
        if (skewTicks == 0) return;

        for (int off = 0; off + 188 <= len; off += 188) {
            if (buf[off] != 0x47) continue;
            bool pusi = (buf[off + 1] & 0x40) != 0;
            int afc = (buf[off + 3] >> 4) & 0x03;
            if (!pusi || (afc != 1 && afc != 3)) continue;
            int pOff = off + 4;
            if (afc == 3) {
                if (pOff >= off + 188) continue;
                pOff += 1 + buf[pOff];
            }
            if (pOff + 14 > off + 188) continue;
            if (buf[pOff] != 0x00 || buf[pOff + 1] != 0x00 || buf[pOff + 2] != 0x01) continue;
            byte sid = buf[pOff + 3];
            if (sid < 0xC0 || sid > 0xDF) continue;
            int ptsFlags = (buf[pOff + 7] >> 6) & 0x03;
            if (ptsFlags < 2) continue;
            long pts = ReadPesPts(buf, pOff + 9);
            WritePesPts(buf, pOff + 9, buf[pOff + 9] & 0xF0, pts + skewTicks);
            if (ptsFlags == 3 && pOff + 19 <= off + 188) {
                long dts = ReadPesPts(buf, pOff + 14);
                WritePesPts(buf, pOff + 14, buf[pOff + 14] & 0xF0, dts + skewTicks);
            }
        }
    }

    public static bool Start(int port, string scriptDir, string lanIp, long startTs) {
        HttpPort = port;
        ScriptDir = scriptDir;
        LanIp = lanIp;
        StartTimestamp = startTs;
        try {
            ServicePointManager.DefaultConnectionLimit = 128;
            ServicePointManager.Expect100Continue = false;
            ServicePointManager.UseNagleAlgorithm = false;
            ThreadPool.SetMinThreads(64, 64);
        } catch {}

        _listener = TcpListener.Create(port);
        try {
            _listener.ExclusiveAddressUse = false;
            _listener.Server.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
        } catch {}

        bool started = false;
        for (int attempt = 0; attempt < 6; attempt++) {
            try {
                _listener.Start(128);
                started = true;
                break;
            } catch {
                Thread.Sleep(400);
            }
        }
        if (!started) return false;

        try {
            string oldTmp = Path.Combine(Path.GetTempPath(), "abtv_tx_" + port.ToString());
            if (Directory.Exists(oldTmp)) Directory.Delete(oldTmp, true);
        } catch {}

        _running = true;
        Thread acceptThread = new Thread(AcceptLoop);
        acceptThread.IsBackground = true;
        acceptThread.Start();
        _txReaperThread = new Thread(TxReaperLoop);
        _txReaperThread.IsBackground = true;
        _txReaperThread.Start();
        return true;
    }

    public static void Stop() {
        _running = false;
        lock (TxLock) { StopTranscoderLocked(); }
        try { if (_listener != null) _listener.Stop(); } catch {}
    }

    private static void TouchPlayerActivity() {
        lock (LifecycleLock) {
            _hasSeenPlayerClient = true;
            _lastPlayerActivityUtc = DateTime.UtcNow;
            _playerClosingUtc = DateTime.MinValue;
        }
    }

    private static void MarkPlayerClosing() {
        lock (LifecycleLock) {
            if (_hasSeenPlayerClient) {
                _playerClosingUtc = DateTime.UtcNow;
            }
        }
    }

    public static bool ShouldAutoShutdown() {
        if (ShutdownRequested) return true;
        DateTime now = DateTime.UtcNow;
        lock (LifecycleLock) {
            if (_playerClosingUtc != DateTime.MinValue &&
                (now - _playerClosingUtc).TotalSeconds >= 5.0 &&
                (now - _lastPlayerActivityUtc).TotalSeconds >= 5.0) {
                return true;
            }
            if (_hasSeenPlayerClient && (now - _lastPlayerActivityUtc).TotalSeconds >= 95.0) {
                bool txBusy = false;
                lock (TxLock) {
                    txBusy = (_txProc != null && !_txProc.HasExited);
                }
                if (!txBusy) return true;
            }
        }
        return false;
    }

    private static void AcceptLoop() {
        while (_running) {
            try {
                TcpClient client = _listener.AcceptTcpClient();
                ThreadPool.QueueUserWorkItem(HandleClient, client);
            } catch {
                if (!_running) break;
                Thread.Sleep(30);
            }
        }
    }

    private static string DecodeB64Url(string s) {
        if (string.IsNullOrEmpty(s)) return "";
        try {
            string b = s.Replace('-', '+').Replace('_', '/');
            int mod = b.Length % 4;
            if (mod == 2) b += "==";
            else if (mod == 3) b += "=";
            return Encoding.UTF8.GetString(Convert.FromBase64String(b));
        } catch { return ""; }
    }

    private static string EncodeB64Url(string s) {
        if (string.IsNullOrEmpty(s)) return "";
        return Convert.ToBase64String(Encoding.UTF8.GetBytes(s)).TrimEnd('=').Replace('+', '-').Replace('/', '_');
    }

    private static Dictionary<string, string> ParseQuery(string qs) {
        Dictionary<string, string> d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (string.IsNullOrEmpty(qs)) return d;
        foreach (string kv in qs.Split('&')) {
            if (string.IsNullOrEmpty(kv)) continue;
            int eq = kv.IndexOf('=');
            if (eq > 0) {
                string k = Uri.UnescapeDataString(kv.Substring(0, eq));
                string v = Uri.UnescapeDataString(kv.Substring(eq + 1));
                d[k] = v;
            } else {
                d[Uri.UnescapeDataString(kv)] = "";
            }
        }
        return d;
    }

    private static void SendHeaders(NetworkStream ns, int code, string statusText, string ctype, long contentLength, string contentRange) {
        StringBuilder sb = new StringBuilder();
        sb.Append("HTTP/1.1 ").Append(code).Append(' ').Append(statusText).Append("\r\n");
        sb.Append("Access-Control-Allow-Origin: *\r\n");
        sb.Append("Access-Control-Allow-Private-Network: true\r\n");
        sb.Append("Access-Control-Allow-Methods: GET, POST, OPTIONS, HEAD\r\n");
        sb.Append("Access-Control-Allow-Headers: *\r\n");
        sb.Append("Access-Control-Expose-Headers: Content-Length, Content-Range, Accept-Ranges, Content-Type\r\n");
        sb.Append("Accept-Ranges: bytes\r\n");
        sb.Append("Cache-Control: no-store, no-cache, must-revalidate\r\n");
        sb.Append("Content-Type: ").Append(ctype).Append("\r\n");
        if (!string.IsNullOrEmpty(contentRange)) {
            sb.Append("Content-Range: ").Append(contentRange).Append("\r\n");
        }
        if (contentLength >= 0) {
            sb.Append("Content-Length: ").Append(contentLength).Append("\r\n");
        }
        sb.Append("Connection: close\r\n\r\n");
        byte[] hb = Encoding.ASCII.GetBytes(sb.ToString());
        ns.Write(hb, 0, hb.Length);
    }

    private static void SendBytesResponse(NetworkStream ns, int code, string statusText, string ctype, byte[] bytes, bool isHead) {
        SendHeaders(ns, code, statusText, ctype, bytes.Length, null);
        if (!isHead && bytes.Length > 0) {
            ns.Write(bytes, 0, bytes.Length);
        }
        ns.Flush();
    }

    private static string FetchText(string url, string referer, int timeoutMs) {
        try {
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
            req.Timeout = timeoutMs;
            req.ReadWriteTimeout = timeoutMs;
            req.UserAgent = UaBrowser;
            if (!string.IsNullOrEmpty(referer)) {
                req.Referer = referer;
                if (referer.IndexOf("mediasetinfinity.es", StringComparison.OrdinalIgnoreCase) >= 0) {
                    req.Headers.Add("Origin", "https://www.mediasetinfinity.es");
                }
            }
            using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
            using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8)) {
                return sr.ReadToEnd();
            }
        } catch { return null; }
    }

    private static ResolvedPair ResolveFreshM3u8(string fbUrl, string refHint, int depth) {
        if (string.IsNullOrEmpty(fbUrl) || depth > 3) return null;
        if (fbUrl.IndexOf("challenges.cloudflare.com", StringComparison.OrdinalIgnoreCase) >= 0) return null;
        if (Regex.IsMatch(fbUrl, @"\.m3u8(?:\?|$)", RegexOptions.IgnoreCase)) {
            ResolvedPair rp = new ResolvedPair();
            rp.Url = fbUrl;
            rp.Referer = IsIptvDirectUrl(fbUrl) ? "" : (string.IsNullOrEmpty(refHint) ? fbUrl : refHint);
            return rp;
        }

        // 0. Mediaset Infinity via Google DAI Linear HLS POST
        Match mDai = Regex.Match(fbUrl, @"dai\.google\.com/linear/v1/hls/event/([a-zA-Z0-9_-]+)/stream", RegexOptions.IgnoreCase);
        if (mDai.Success) {
            try {
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create("https://dai.google.com/linear/v1/hls/event/" + mDai.Groups[1].Value + "/stream");
                req.Method = "POST";
                req.Timeout = 5000;
                req.ContentLength = 0;
                req.UserAgent = UaBrowser;
                req.Referer = "https://www.mediasetinfinity.es/";
                req.Headers.Add("Origin", "https://www.mediasetinfinity.es");
                using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
                using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8)) {
                    Dictionary<string, object> obj = Json.DeserializeObject(sr.ReadToEnd()) as Dictionary<string, object>;
                    if (obj != null && obj.ContainsKey("stream_manifest")) {
                        string manifest = Convert.ToString(obj["stream_manifest"]);
                        if (!string.IsNullOrEmpty(manifest)) {
                            string masterTxt = FetchText(manifest, "https://www.mediasetinfinity.es/", 4500);
                            string picked = manifest;
                            if (!string.IsNullOrEmpty(masterTxt) && masterTxt.IndexOf("#EXTM3U", StringComparison.OrdinalIgnoreCase) >= 0) {
                                int bestBw = -1;
                                string[] lines = masterTxt.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                                int curBw = 0;
                                bool skipAudioOnly = false;
                                foreach (string rawL in lines) {
                                    string l = rawL.Trim();
                                    if (l.StartsWith("#EXT-X-STREAM-INF", StringComparison.OrdinalIgnoreCase)) {
                                        Match mbw = Regex.Match(l, @"BANDWIDTH=(\d+)");
                                        curBw = mbw.Success ? int.Parse(mbw.Groups[1].Value) : 0;
                                        skipAudioOnly = (l.IndexOf("RESOLUTION=", StringComparison.OrdinalIgnoreCase) < 0 && l.IndexOf("avc1", StringComparison.OrdinalIgnoreCase) < 0);
                                    } else if (!l.StartsWith("#")) {
                                        if (!skipAudioOnly && curBw > bestBw) {
                                            try {
                                                picked = new Uri(new Uri(manifest), l).AbsoluteUri;
                                                bestBw = curBw;
                                            } catch {}
                                        }
                                        curBw = 0;
                                        skipAudioOnly = false;
                                    }
                                }
                            }
                            ResolvedPair rp = new ResolvedPair();
                            rp.Url = picked;
                            rp.Referer = "https://www.mediasetinfinity.es/";
                            return rp;
                        }
                    }
                }
            } catch {}
            return null;
        }

        // 1. Embdlol /watch API
        Match mEmb = Regex.Match(fbUrl, @"embdlol\.st/embed/([a-zA-Z0-9-]+)", RegexOptions.IgnoreCase);
        if (mEmb.Success) {
            try {
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create("https://api.embdlol.st/watch");
                req.Method = "POST";
                req.Timeout = 4000;
                req.ContentType = "application/json";
                req.UserAgent = UaBrowser;
                req.Referer = "https://embdlol.st/";
                req.Headers.Add("Origin", "https://embdlol.st");
                byte[] postB = Encoding.UTF8.GetBytes("{\"watchId\":\"" + mEmb.Groups[1].Value + "\"}");
                req.ContentLength = postB.Length;
                using (Stream rs = req.GetRequestStream()) rs.Write(postB, 0, postB.Length);
                using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
                using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8)) {
                    Dictionary<string, object> obj = Json.DeserializeObject(sr.ReadToEnd()) as Dictionary<string, object>;
                    if (obj != null && obj.ContainsKey("url")) {
                        ResolvedPair rp = new ResolvedPair();
                        rp.Url = Convert.ToString(obj["url"]);
                        rp.Referer = "https://embdlol.st/";
                        return rp;
                    }
                }
            } catch {}
            return null;
        }

        // 2. streamx*.sbs/global1.php o global3.php?channel=<slug>
        Match mSx = Regex.Match(fbUrl, @"https?://(streamx[a-z0-9]+\.sbs)/global[13]\.php\?channel=([^&]+)", RegexOptions.IgnoreCase);
        if (mSx.Success) {
            string h1 = mSx.Groups[1].Value;
            string slug = mSx.Groups[2].Value;
            string[] hostsToTry = (h1 == _activeStreamxHost)
                ? new string[] { h1, "streamx723.sbs", "streamx061.sbs" }
                : new string[] { h1, _activeStreamxHost, "streamx723.sbs" };
            foreach (string h in hostsToTry) {
                if (string.IsNullOrEmpty(h)) continue;
                string tryUrl = "https://" + h + "/global3.php?channel=" + slug;
                string body = FetchText(tryUrl, string.IsNullOrEmpty(refHint) ? "https://cdplay.live/" : refHint, 4000);
                if (!string.IsNullOrEmpty(body)) {
                    Match ms = Regex.Match(body, "\"src\"\\s*:\\s*\"([^\"]+\\.m3u8[^\"]*)\"");
                    if (ms.Success) {
                        _activeStreamxHost = h;
                        ResolvedPair rp = new ResolvedPair();
                        rp.Url = ms.Groups[1].Value.Replace("\\/", "/").Replace("\\u0026", "&");
                        rp.Referer = tryUrl;
                        return rp;
                    }
                }
            }
            return ResolveFreshM3u8("https://streamxhd.click/live1.php?stream=" + slug, fbUrl, depth + 1);
        }

        // 3. streamxhd.click/channel/?id=<slug> -> /live1.php?stream=<slug> y streamxhd.click/live*.php (var playbackURL)
        Match mXhdId = Regex.Match(fbUrl, @"https?://streamxhd\.click/channel/\?id=([^&]+)", RegexOptions.IgnoreCase);
        if (mXhdId.Success) {
            return ResolveFreshM3u8("https://streamxhd.click/live1.php?stream=" + mXhdId.Groups[1].Value, fbUrl, depth + 1);
        }
        if (Regex.IsMatch(fbUrl, @"streamxhd\.click/live\d*\.php", RegexOptions.IgnoreCase)) {
            string html = FetchText(fbUrl, "https://streamxhd.click/", 4500);
            if (!string.IsNullOrEmpty(html)) {
                int i = html.IndexOf("var playbackURL", StringComparison.Ordinal);
                if (i >= 0) {
                    int j = html.IndexOf("var adsPayload", i, StringComparison.Ordinal);
                    if (j < 0) j = html.IndexOf("var reloadDelay", i, StringComparison.Ordinal);
                    if (j > i) {
                        string blk = html.Substring(i, j - i);
                        int sa = blk.IndexOf("[[", StringComparison.Ordinal);
                        int ea = (sa >= 0) ? blk.IndexOf("]];", sa, StringComparison.Ordinal) : -1;
                        if (sa >= 0 && ea > sa) {
                            Match mK = Regex.Match(blk.Substring(ea), @"function\s+[a-zA-Z0-9_]+\(\)\{return\s+(\d+);\}\s*function\s+[a-zA-Z0-9_]+\(\)\{return\s+(\d+);\}");
                            if (mK.Success) {
                                int k = int.Parse(mK.Groups[1].Value) + int.Parse(mK.Groups[2].Value);
                                string arrStr = blk.Substring(sa + 1, ea - sa);
                                List<KeyValuePair<int, char>> chars = new List<KeyValuePair<int, char>>();
                                foreach (Match em in Regex.Matches(arrStr, @"\[(\d+),""([^""]+)""\]")) {
                                    try {
                                        int idx = int.Parse(em.Groups[1].Value);
                                        string dec = Encoding.ASCII.GetString(Convert.FromBase64String(em.Groups[2].Value));
                                        string digits = Regex.Replace(dec, @"\D", "");
                                        if (!string.IsNullOrEmpty(digits)) {
                                            chars.Add(new KeyValuePair<int, char>(idx, (char)(int.Parse(digits) - k)));
                                        }
                                    } catch {}
                                }
                                chars.Sort(delegate(KeyValuePair<int, char> a, KeyValuePair<int, char> b) { return a.Key.CompareTo(b.Key); });
                                StringBuilder uSb = new StringBuilder();
                                foreach (KeyValuePair<int, char> kv in chars) uSb.Append(kv.Value);
                                string decoded = uSb.ToString();
                                if (Regex.IsMatch(decoded, @"^https?://.*\.m3u8", RegexOptions.IgnoreCase)) {
                                    ResolvedPair rp = new ResolvedPair();
                                    rp.Url = decoded;
                                    rp.Referer = fbUrl;
                                    return rp;
                                }
                            }
                        }
                    }
                }
            }
            return null;
        }

        // 4. CandyShop / sofayshop / xstream / 104game
        Match mCapo2 = Regex.Match(fbUrl, @"104game\.click/player/capo2/(\d+)", RegexOptions.IgnoreCase);
        if (mCapo2.Success) {
            return ResolveFreshM3u8("https://sofayshop.st/hlsspanich.php?stream=H" + mCapo2.Groups[1].Value, fbUrl, depth + 1);
        }
        if (Regex.IsMatch(fbUrl, @"capopro\.php\?stream=|hlsspanich\.php\?stream=|livetvfx\.php\?stream=|sofayshop\.st|xstream\.st", RegexOptions.IgnoreCase)) {
            string html = FetchText(fbUrl, string.IsNullOrEmpty(refHint) ? "https://cdplay.live/" : refHint, 4000);
            if (string.IsNullOrEmpty(html)) {
                Match mp = Regex.Match(fbUrl, @"/(capopro\.php\?stream=CA\d+|livetvfx\.php\?stream=SSF\d+|hlsspanich\.php\?stream=H\d+)", RegexOptions.IgnoreCase);
                if (mp.Success) {
                    html = FetchText("https://sofayshop.st/" + mp.Groups[1].Value, refHint, 4000);
                }
            }
            if (!string.IsNullOrEmpty(html)) {
                string best = null;
                foreach (Match mm in Regex.Matches(html, @"https://[^""'\\]+index\.m3u8\?st=[^""']+")) {
                    string cand = mm.Value.Replace("\\u0026", "&");
                    if (cand.IndexOf("edge2.candyshop.st", StringComparison.OrdinalIgnoreCase) >= 0) { best = cand; break; }
                    if (best == null && cand.IndexOf("candyshop.st", StringComparison.OrdinalIgnoreCase) >= 0) best = cand;
                    else if (best == null) best = cand;
                }
                if (best == null) {
                    Match mg = Regex.Match(html, @"https?://[^\s""'\\<>]+\.m3u8[^\s""'\\<>]*", RegexOptions.IgnoreCase);
                    if (mg.Success) best = mg.Value.Replace("\\/", "/").Replace("\\u0026", "&");
                }
                if (best != null) {
                    ResolvedPair rp = new ResolvedPair();
                    rp.Url = best;
                    rp.Referer = "https://sofayshop.st/";
                    return rp;
                }
            }
            return null;
        }

        // 5. Página wrapper genérica (tvf90, cdplay, embedme, futbollibregol): busca .m3u8 o sigue <iframe>
        Uri baseU = null;
        try { baseU = new Uri(fbUrl); } catch {}
        string pageRef = !string.IsNullOrEmpty(refHint) ? refHint : (baseU != null ? (baseU.Scheme + "://" + baseU.Authority + "/") : fbUrl);
        string pageHtml = FetchText(fbUrl, pageRef, 4500);
        if (string.IsNullOrEmpty(pageHtml)) return null;

        Match directM = Regex.Match(pageHtml, @"https?://[^\s""'<>]+\.m3u8[^\s""'<>]*", RegexOptions.IgnoreCase);
        if (directM.Success) {
            ResolvedPair rp = new ResolvedPair();
            rp.Url = directM.Value.Replace("\\/", "/").Replace("\\u0026", "&");
            rp.Referer = fbUrl;
            return rp;
        }

        foreach (Match ifr in Regex.Matches(pageHtml, @"<iframe[^>]+src=[""']([^""']+)[""']", RegexOptions.IgnoreCase)) {
            string sub = ifr.Groups[1].Value.Trim();
            if (string.IsNullOrEmpty(sub) || sub.StartsWith("about:", StringComparison.OrdinalIgnoreCase)) continue;
            if (sub.IndexOf("challenges.cloudflare.com", StringComparison.OrdinalIgnoreCase) >= 0) continue;
            try {
                string absSub = (baseU != null) ? (new Uri(baseU, sub)).AbsoluteUri : sub;
                ResolvedPair rp = ResolveFreshM3u8(absSub, fbUrl, depth + 1);
                if (rp != null) return rp;
            } catch {}
        }
        return null;
    }

    private static string AutoReferer(string targetUrl, string refUrl) {
        if (targetUrl.IndexOf("candyshop.st", StringComparison.OrdinalIgnoreCase) >= 0) {
            if (string.IsNullOrEmpty(refUrl) || (refUrl.IndexOf("sofayshop.st", StringComparison.OrdinalIgnoreCase) < 0 && refUrl.IndexOf("embedme.st", StringComparison.OrdinalIgnoreCase) < 0))
                return "https://sofayshop.st/";
            return refUrl;
        }
        if (targetUrl.IndexOf("ftlly.com", StringComparison.OrdinalIgnoreCase) >= 0) {
            if (string.IsNullOrEmpty(refUrl) || refUrl.IndexOf("tvf90.com", StringComparison.OrdinalIgnoreCase) < 0)
                return "https://tvf90.com/";
            return refUrl;
        }
        if (targetUrl.IndexOf("futlivehd.com", StringComparison.OrdinalIgnoreCase) >= 0) {
            if (string.IsNullOrEmpty(refUrl) || refUrl.IndexOf("streamx", StringComparison.OrdinalIgnoreCase) < 0)
                return "https://streamxhd.click/";
            return refUrl;
        }
        if (targetUrl.IndexOf("embdlol.st", StringComparison.OrdinalIgnoreCase) >= 0) {
            return "https://embdlol.st/";
        }
        if (targetUrl.IndexOf("envivosenhd.", StringComparison.OrdinalIgnoreCase) >= 0) {
            return "https://streamxhd.click/";
        }
        if (targetUrl.IndexOf("instreams.", StringComparison.OrdinalIgnoreCase) >= 0) {
            return "https://sofayshop.st/";
        }
        if (targetUrl.IndexOf("mediasetinfinity.es", StringComparison.OrdinalIgnoreCase) >= 0 ||
            targetUrl.IndexOf("dai.google.com", StringComparison.OrdinalIgnoreCase) >= 0) {
            return "https://www.mediasetinfinity.es/";
        }
        return refUrl;
    }

    private static HttpWebRequest BuildUpstreamRequest(string targetUrl, string refUrl, string rangeHdr, string method) {
        HttpWebRequest req = (HttpWebRequest)WebRequest.Create(targetUrl);
        req.Method = string.IsNullOrEmpty(method) ? "GET" : method;
        bool isAceLocal = targetUrl.IndexOf("127.0.0.1:6878/ace/", StringComparison.OrdinalIgnoreCase) >= 0;
        bool isIptvManifest = IsIptvDirectUrl(targetUrl) && Regex.IsMatch(targetUrl, @"\.m3u8(?:\?|$)", RegexOptions.IgnoreCase);
        req.Timeout = isAceLocal ? 15000 : (isIptvManifest ? 7000 : 10000);
        req.ReadWriteTimeout = isAceLocal ? 20000 : (isIptvManifest ? 8000 : 15000);
        req.KeepAlive = true;
        req.AllowAutoRedirect = true;
        req.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
        req.UserAgent = IsIptvDirectUrl(targetUrl) ? UaIptv : UaBrowser;
        if (targetUrl.IndexOf("embdlol.st", StringComparison.OrdinalIgnoreCase) >= 0) {
            req.Headers.Add("Origin", "https://embdlol.st");
        } else if (targetUrl.IndexOf("mediasetinfinity.es", StringComparison.OrdinalIgnoreCase) >= 0 ||
                   targetUrl.IndexOf("dai.google.com", StringComparison.OrdinalIgnoreCase) >= 0) {
            req.Headers.Add("Origin", "https://www.mediasetinfinity.es");
        }
        string effRef = IsIptvDirectUrl(targetUrl) ? "" : AutoReferer(targetUrl, refUrl);
        if (!string.IsNullOrEmpty(effRef)) {
            req.Referer = effRef;
        }
        if (!string.IsNullOrEmpty(rangeHdr) && !Regex.IsMatch(targetUrl, @"\.m3u8(?:\?|$)", RegexOptions.IgnoreCase)) {
            Match mr = Regex.Match(rangeHdr, @"bytes=(\d+)-(\d*)");
            if (mr.Success) {
                try {
                    long from = long.Parse(mr.Groups[1].Value);
                    if (!string.IsNullOrEmpty(mr.Groups[2].Value)) req.AddRange(from, long.Parse(mr.Groups[2].Value));
                    else req.AddRange(from);
                } catch {}
            }
        }
        return req;
    }

    private static void HandleProxy(NetworkStream ns, string hostHdr, string rangeHdr, Dictionary<string, string> q, bool isHead) {
        string rawTarget = q.ContainsKey("u") ? DecodeB64Url(q["u"]) : "";
        string refUrl = q.ContainsKey("ref") ? DecodeB64Url(q["ref"]) : "";
        string fbUrl = q.ContainsKey("fb") ? DecodeB64Url(q["fb"]) : "";

        if (string.IsNullOrEmpty(rawTarget) || !Regex.IsMatch(rawTarget, @"^https?://", RegexOptions.IgnoreCase)) {
            SendBytesResponse(ns, 400, "Bad Request", "text/plain", Encoding.UTF8.GetBytes("Missing u"), isHead);
            return;
        }

        string effTarget = rawTarget;
        string effRef = refUrl;
        FreshTokenEntry cached;
        if (TokenCache.TryGetValue(rawTarget, out cached) && cached.ExpiresUtc > DateTime.UtcNow) {
            effTarget = cached.StreamUrl;
            if (!string.IsNullOrEmpty(cached.Referer)) effRef = cached.Referer;
        }

        bool isManifestUrl = Regex.IsMatch(effTarget, @"(?:\.m3u8(?:\?|$)|dai\.google\.com/linear/v1/hls/event/)", RegexOptions.IgnoreCase);
        bool upstreamWasHead = (isHead && !isManifestUrl);
        HttpWebRequest req = null;
        HttpWebResponse upResp = null;

        try {
            try {
                req = BuildUpstreamRequest(effTarget, effRef, rangeHdr, upstreamWasHead ? "HEAD" : "GET");
                upResp = (HttpWebResponse)req.GetResponse();
            } catch (WebException wex) {
                int sc = (wex.Response is HttpWebResponse) ? (int)((HttpWebResponse)wex.Response).StatusCode : 0;
                if (upResp != null) { try { upResp.Close(); } catch {} upResp = null; }
                try { if (wex.Response != null) wex.Response.Close(); } catch {}

                // Si la URL fijada de borde (TokenCache) caduco, limpiar y reintentar via URL raiz original
                if (!string.Equals(effTarget, rawTarget, StringComparison.OrdinalIgnoreCase) && string.IsNullOrEmpty(fbUrl)) {
                    FreshTokenEntry oldEntry;
                    TokenCache.TryRemove(rawTarget, out oldEntry);
                    effTarget = rawTarget;
                    effRef = refUrl;
                    req = BuildUpstreamRequest(effTarget, effRef, rangeHdr, upstreamWasHead ? "HEAD" : "GET");
                    upResp = (HttpWebResponse)req.GetResponse();
                } else if (IsIptvDirectUrl(rawTarget) && !upstreamWasHead && (sc == 0 || sc == 403 || sc == 404 || sc == 502 || sc == 503 || sc == 504)) {
                    // Reintento limpio para nodos HLS externos lentos o rotos en round-robin 302
                    FreshTokenEntry oldEntry;
                    TokenCache.TryRemove(rawTarget, out oldEntry);
                    effTarget = rawTarget;
                    effRef = refUrl;
                    Thread.Sleep(150);
                    req = BuildUpstreamRequest(effTarget, effRef, rangeHdr, "GET");
                    upResp = (HttpWebResponse)req.GetResponse();
                } else if (upstreamWasHead && (sc == 405 || sc == 403 || sc == 400 || sc == 501 || sc == 0)) {
                    // Si el servidor IPTV no acepta HEAD (405/403/400/501), reintentar headers con GET sin consumir cuerpo
                    upstreamWasHead = false;
                    req = BuildUpstreamRequest(effTarget, effRef, rangeHdr, "GET");
                    upResp = (HttpWebResponse)req.GetResponse();
                } else if ((sc == 403 || sc == 401 || sc == 404 || sc == 405 || sc == 410 || sc == 503) && !string.IsNullOrEmpty(fbUrl) && isManifestUrl) {
                    // Auto-refrescar token en vivo si caducó y disponemos de FallbackUrl
                    FreshTokenEntry fRemoved;
                    TokenCache.TryRemove(rawTarget, out fRemoved);
                    ResolvedPair fresh = null;
                    lock (RefreshLock) {
                        FreshTokenEntry check2;
                        if (TokenCache.TryGetValue(rawTarget, out check2) && check2.ExpiresUtc > DateTime.UtcNow && check2.StreamUrl != effTarget) {
                            fresh = new ResolvedPair { Url = check2.StreamUrl, Referer = check2.Referer };
                        } else {
                            fresh = ResolveFreshM3u8(fbUrl, refUrl, 0);
                            if (fresh != null && !string.IsNullOrEmpty(fresh.Url)) {
                                FreshTokenEntry entry = new FreshTokenEntry();
                                entry.StreamUrl = fresh.Url;
                                entry.Referer = fresh.Referer;
                                entry.ExpiresUtc = DateTime.UtcNow.AddSeconds(90);
                                TokenCache[rawTarget] = entry;
                            }
                        }
                    }
                    if (fresh != null && !string.IsNullOrEmpty(fresh.Url)) {
                        effTarget = fresh.Url;
                        if (!string.IsNullOrEmpty(fresh.Referer)) effRef = fresh.Referer;
                        req = BuildUpstreamRequest(effTarget, effRef, rangeHdr, "GET");
                        upResp = (HttpWebResponse)req.GetResponse();
                    } else if (sc == 503) {
                        Thread.Sleep(250);
                        req = BuildUpstreamRequest(effTarget, effRef, rangeHdr, "GET");
                        upResp = (HttpWebResponse)req.GetResponse();
                    } else {
                        throw;
                    }
                } else if (sc == 503) {
                    Thread.Sleep(250);
                    req = BuildUpstreamRequest(effTarget, effRef, rangeHdr, "GET");
                    upResp = (HttpWebResponse)req.GetResponse();
                } else {
                    throw;
                }
            }

            string upCtype = string.IsNullOrEmpty(upResp.ContentType) ? "application/octet-stream" : upResp.ContentType;
            int respCode = (int)upResp.StatusCode;
            string respRange = upResp.Headers["Content-Range"];
            long respLen = upResp.ContentLength;

            if (isHead && !isManifestUrl) {
                if (Regex.IsMatch(effTarget, @"\.ts(?:\?|$)", RegexOptions.IgnoreCase) &&
                    upCtype.IndexOf("video", StringComparison.OrdinalIgnoreCase) < 0) {
                    upCtype = "video/mp2t";
                }
                SendHeaders(ns, respCode, "OK", upCtype, respLen, respRange);
                ns.Flush();
                if (!upstreamWasHead) { try { req.Abort(); } catch {} }
                return;
            }

            bool isM3u = isManifestUrl || (upCtype.IndexOf("mpegurl", StringComparison.OrdinalIgnoreCase) >= 0);
            if (!isM3u && respLen > 0 && respLen <= 65536 && Regex.IsMatch(effTarget, @"\.m3u|\bplaylist\b", RegexOptions.IgnoreCase)) {
                isM3u = true;
            }

            if (isM3u) {
                byte[] rawBytes;
                using (Stream upSt = upResp.GetResponseStream())
                using (MemoryStream ms = new MemoryStream()) {
                    upSt.CopyTo(ms);
                    rawBytes = ms.ToArray();
                }

                string m3uText = Encoding.UTF8.GetString(rawBytes);
                if (m3uText.IndexOf("#EXTM3U", StringComparison.OrdinalIgnoreCase) < 0 && !isManifestUrl) {
                    SendBytesResponse(ns, respCode, "OK", upCtype, rawBytes, isHead);
                    return;
                }

                Uri finalUri = upResp.ResponseUri;
                // Pin sticky edge URI for IPTV 302 redirects so Hls.js polls the same edge sequence consistently
                if (finalUri != null && !string.Equals(finalUri.AbsoluteUri, rawTarget, StringComparison.OrdinalIgnoreCase) &&
                    (IsIptvDirectUrl(rawTarget) || finalUri.AbsoluteUri.IndexOf("lvtoken=", StringComparison.OrdinalIgnoreCase) >= 0)) {
                    FreshTokenEntry pin = new FreshTokenEntry();
                    pin.StreamUrl = finalUri.AbsoluteUri;
                    pin.Referer = effRef;
                    pin.ExpiresUtc = DateTime.UtcNow.AddSeconds(120);
                    TokenCache[rawTarget] = pin;
                }

                string proxyHost = !string.IsNullOrEmpty(hostHdr) ? hostHdr : (LanIp + ":" + HttpPort.ToString());
                string activeRef = IsIptvDirectUrl(effTarget) ? "" : AutoReferer(effTarget, effRef);
                string refParam = !string.IsNullOrEmpty(activeRef) ? ("&ref=" + EncodeB64Url(activeRef)) : "";
                string fbParam = !string.IsNullOrEmpty(fbUrl) ? ("&fb=" + EncodeB64Url(fbUrl)) : "";

                string[] lines = Regex.Split(m3uText, @"\r?\n");
                StringBuilder outSb = new StringBuilder(m3uText.Length * 2);
                for (int li = 0; li < lines.Length; li++) {
                    string ln = lines[li];
                    string t = ln.Trim();
                    if (!string.IsNullOrEmpty(t) && !t.StartsWith("#")) {
                        try {
                            string abs = (new Uri(finalUri, t)).AbsoluteUri;
                            string childFb = Regex.IsMatch(abs, @"\.m3u8(?:\?|$)", RegexOptions.IgnoreCase) ? fbParam : "";
                            outSb.Append("http://").Append(proxyHost).Append("/cast-proxy?u=").Append(EncodeB64Url(abs)).Append(refParam).Append(childFb);
                        } catch {
                            outSb.Append(ln);
                        }
                    } else if (ln.IndexOf("URI=\"", StringComparison.Ordinal) >= 0) {
                        outSb.Append(Regex.Replace(ln, "URI=\"([^\"]+)\"", delegate(Match m) {
                            string origUri = m.Groups[1].Value;
                            try {
                                string abs = (new Uri(finalUri, origUri)).AbsoluteUri;
                                return "URI=\"http://" + proxyHost + "/cast-proxy?u=" + EncodeB64Url(abs) + refParam + "\"";
                            } catch {
                                return m.Value;
                            }
                        }));
                    } else {
                        outSb.Append(ln);
                    }
                    if (li < lines.Length - 1) outSb.Append("\r\n");
                }

                byte[] outBytes = Encoding.UTF8.GetBytes(outSb.ToString());
                SendBytesResponse(ns, 200, "OK", "application/vnd.apple.mpegurl; charset=utf-8", outBytes, isHead);
            } else {
                bool isTsSeg = Regex.IsMatch(effTarget, @"\.ts(?:\?|$)", RegexOptions.IgnoreCase);
                // Normalizar Content-Type para segmentos MPEG-TS y CMAF (evita text/vnd.trolltech.linguist en servidores IPTV)
                if (isTsSeg && upCtype.IndexOf("video", StringComparison.OrdinalIgnoreCase) < 0) {
                    upCtype = "video/mp2t";
                } else if (Regex.IsMatch(effTarget, @"\.m4s(?:\?|$)", RegexOptions.IgnoreCase) &&
                           upCtype.IndexOf("video", StringComparison.OrdinalIgnoreCase) < 0 &&
                           upCtype.IndexOf("iso", StringComparison.OrdinalIgnoreCase) < 0) {
                    upCtype = "video/iso.segment";
                } else if (Regex.IsMatch(effTarget, @"\.aac(?:\?|$)", RegexOptions.IgnoreCase) &&
                           upCtype.IndexOf("audio", StringComparison.OrdinalIgnoreCase) < 0) {
                    upCtype = "audio/aac";
                }

                string tsKey = ExtractTsStreamKey(effTarget);
                long cachedSkew = 0;
                bool hasCachedSkew = !string.IsNullOrEmpty(tsKey) && TsAudioSkewCache.TryGetValue(tsKey, out cachedSkew);

                if (!isHead && isTsSeg && IsIptvDirectUrl(effTarget) && (!hasCachedSkew || cachedSkew != 0) && (respLen < 0 || respLen <= 25165824)) {
                    byte[] tsBytes;
                    using (Stream upSt = upResp.GetResponseStream())
                    using (MemoryStream ms = new MemoryStream()) {
                        upSt.CopyTo(ms);
                        tsBytes = ms.ToArray();
                    }
                    AlignMpegTsPtsIfSkewed(effTarget, tsBytes, tsBytes.Length);
                    SendHeaders(ns, respCode, (respCode == 206 ? "Partial Content" : "OK"), upCtype, tsBytes.Length, respRange);
                    if (tsBytes.Length > 0) ns.Write(tsBytes, 0, tsBytes.Length);
                    ns.Flush();
                } else {
                    SendHeaders(ns, respCode, (respCode == 206 ? "Partial Content" : "OK"), upCtype, respLen, respRange);
                    if (!isHead) {
                        byte[] buf = new byte[65536];
                        using (Stream upSt = upResp.GetResponseStream()) {
                            int n;
                            while ((n = upSt.Read(buf, 0, buf.Length)) > 0) {
                                ns.Write(buf, 0, n);
                            }
                        }
                    }
                    ns.Flush();
                }
            }
        } catch (WebException wex) {
            int code = 502;
            if (wex.Response is HttpWebResponse) {
                code = (int)((HttpWebResponse)wex.Response).StatusCode;
                try { wex.Response.Close(); } catch {}
            }
            try { SendBytesResponse(ns, code, "Upstream Error", "text/plain", Encoding.UTF8.GetBytes(wex.Message), isHead); } catch {}
        } catch (Exception ex) {
            try { SendBytesResponse(ns, 502, "Proxy Error", "text/plain", Encoding.UTF8.GetBytes(ex.Message), isHead); } catch {}
        } finally {
            if (upResp != null) { try { upResp.Close(); } catch {} }
        }
    }

    private static string GetMimeType(string fileName) {
        string low = fileName.ToLowerInvariant();
        if (low.EndsWith(".html")) return "text/html; charset=utf-8";
        if (low.EndsWith(".json")) return "application/json; charset=utf-8";
        if (low.EndsWith(".m3u")) return "audio/x-mpegurl; charset=utf-8";
        if (low.EndsWith(".jpg") || low.EndsWith(".jpeg")) return "image/jpeg";
        if (low.EndsWith(".png")) return "image/png";
        return "application/octet-stream";
    }

    private static void HandleClient(object state) {
        TcpClient client = (TcpClient)state;
        try {
            client.ReceiveTimeout = 6000;
            client.SendTimeout = 20000;
            NetworkStream ns = client.GetStream();
            StreamReader sr = new StreamReader(ns, Encoding.ASCII);

            string requestLine = sr.ReadLine();
            if (string.IsNullOrEmpty(requestLine)) return;

            string hostHdr = "";
            string rangeHdr = "";
            string line;
            while ((line = sr.ReadLine()) != null && line.Trim().Length > 0) {
                if (line.StartsWith("Host:", StringComparison.OrdinalIgnoreCase)) {
                    hostHdr = line.Substring(5).Trim();
                } else if (line.StartsWith("Range:", StringComparison.OrdinalIgnoreCase)) {
                    rangeHdr = line.Substring(6).Trim();
                }
            }

            string[] parts = requestLine.Split(' ');
            string method = (parts.Length >= 1) ? parts[0].ToUpperInvariant() : "GET";
            bool isHead = (method == "HEAD");
            string rawTarget = (parts.Length >= 2) ? parts[1] : "/";

            if (method == "OPTIONS") {
                SendBytesResponse(ns, 200, "OK", "text/plain", new byte[0], false);
                return;
            }

            int qIdx = rawTarget.IndexOf('?');
            string pathOnly = (qIdx >= 0) ? rawTarget.Substring(0, qIdx) : rawTarget;
            string queryStr = (qIdx >= 0) ? rawTarget.Substring(qIdx + 1) : "";
            Dictionary<string, string> q = ParseQuery(queryStr);

            if (pathOnly == "/cast-discover") {
                List<CastDeviceInfo> devs = AtomicCastV2.DiscoverDevices(LanIp, 1200);
                List<Dictionary<string, object>> arr = new List<Dictionary<string, object>>();
                foreach (CastDeviceInfo d in devs) {
                    Dictionary<string, object> item = new Dictionary<string, object>();
                    item["name"] = d.name;
                    item["ip"] = d.ip;
                    item["port"] = d.port;
                    item["model"] = d.model;
                    item["source"] = d.source;
                    arr.Add(item);
                }
                Dictionary<string, object> resp = new Dictionary<string, object>();
                resp["ok"] = true;
                resp["lanIp"] = LanIp;
                resp["port"] = HttpPort;
                resp["devices"] = arr.ToArray();
                SendBytesResponse(ns, 200, "OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(Json.Serialize(resp)), isHead);
                return;
            }

            if (pathOnly == "/cast-send") {
                string tvIp = q.ContainsKey("ip") ? q["ip"].Trim() : "";
                string uRaw = q.ContainsKey("u") ? DecodeB64Url(q["u"]) : "";
                string refRaw = q.ContainsKey("ref") ? DecodeB64Url(q["ref"]) : "";
                string fbRaw = q.ContainsKey("fb") ? DecodeB64Url(q["fb"]) : "";
                string titleRaw = q.ContainsKey("title") ? q["title"].Trim() : "";
                bool useProxyFlag = !q.ContainsKey("proxy") || q["proxy"] != "0";
                bool forceTx = q.ContainsKey("transcode") && q["transcode"] == "1";
                string reqTxMode = q.ContainsKey("mode") ? q["mode"].Trim() : "";

                if (!Regex.IsMatch(tvIp, @"^\d{1,3}(?:\.\d{1,3}){3}$") || !Regex.IsMatch(uRaw, @"^https?://", RegexOptions.IgnoreCase)) {
                    Dictionary<string, object> errResp = new Dictionary<string, object>();
                    errResp["ok"] = false;
                    errResp["error"] = "IP de TV o URL de canal inválida.";
                    SendBytesResponse(ns, 400, "Bad Request", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(Json.Serialize(errResp)), isHead);
                    return;
                }

                string finalCastUrl = uRaw;
                if (useProxyFlag) {
                    StringBuilder ub = new StringBuilder();
                    ub.Append("http://").Append(LanIp).Append(':').Append(HttpPort).Append("/cast-proxy?u=").Append(EncodeB64Url(uRaw));
                    if (!string.IsNullOrEmpty(refRaw)) ub.Append("&ref=").Append(EncodeB64Url(refRaw));
                    if (!string.IsNullOrEmpty(fbRaw)) ub.Append("&fb=").Append(EncodeB64Url(fbRaw));
                    finalCastUrl = ub.ToString();
                }

                bool didTranscode = false;
                string txModeUsed = "";
                string txVideoUsed = "";
                string txAudioUsed = "";
                bool preTxNeeded = false;
                string preTxMode = "auto";

                if (HasFfmpeg()) {
                    if (forceTx || !string.IsNullOrEmpty(reqTxMode)) {
                        preTxNeeded = true;
                        preTxMode = string.IsNullOrEmpty(reqTxMode) ? "auto" : reqTxMode;
                    } else if (Regex.IsMatch(titleRaw, @"\b(?:HEVC|H\.?265|HDR|UHD|4K)\b", RegexOptions.IgnoreCase)) {
                        preTxNeeded = true;
                        preTxMode = "h264";
                    } else if (IsIptvDirectUrl(uRaw) || uRaw.IndexOf("127.0.0.1:6878/ace/", StringComparison.OrdinalIgnoreCase) >= 0) {
                        string pv, pa;
                        bool pvIncompat = false;
                        ProbeStreamCodecs(BuildLocalCastProxyInputUrl(uRaw, refRaw, fbRaw), out pv, out pa, out pvIncompat);
                        if (pvIncompat || IsIncompatibleCastAudio(pa)) {
                            preTxNeeded = true;
                            preTxMode = pvIncompat ? "h264" : "audio";
                        }
                    }
                }

                if (preTxNeeded) {
                    TranscodeResult txRes = StartTranscode(uRaw, refRaw, fbRaw, preTxMode, titleRaw);
                    if (txRes.Ok) {
                        finalCastUrl = "http://" + LanIp + ":" + HttpPort.ToString() + txRes.PlaylistPath;
                        didTranscode = true;
                        txModeUsed = txRes.TranscodeMode ?? preTxMode;
                        txVideoUsed = txRes.VideoCodec ?? "";
                        txAudioUsed = txRes.AudioCodec ?? "";
                    }
                }

                string subLabel = "AtomicBombTV Estable 1.7" + (didTranscode ? " (H.264 + AAC)" : (useProxyFlag ? " (Túnel PC)" : " (Directo)"));
                string imgUrl = "http://" + LanIp + ":" + HttpPort.ToString() + "/logo.jpg";
                CastCommandResult cRes = AtomicCastV2.CastMedia(tvIp, 8009, finalCastUrl, titleRaw, subLabel, imgUrl);

                // Si Chromecast rechazó el stream directo/túnel, auto-transcodificar a H.264+AAC si ffmpeg está disponible
                if (!cRes.ok && !didTranscode && HasFfmpeg()) {
                    TranscodeResult retryTx = StartTranscode(uRaw, refRaw, fbRaw, "h264", titleRaw);
                    if (retryTx.Ok) {
                        finalCastUrl = "http://" + LanIp + ":" + HttpPort.ToString() + retryTx.PlaylistPath;
                        didTranscode = true;
                        txModeUsed = retryTx.TranscodeMode ?? "h264";
                        txVideoUsed = retryTx.VideoCodec ?? "";
                        txAudioUsed = retryTx.AudioCodec ?? "";
                        subLabel = "AtomicBombTV Estable 1.7 (H.264 + AAC)";
                        cRes = AtomicCastV2.CastMedia(tvIp, 8009, finalCastUrl, titleRaw, subLabel, imgUrl);
                    }
                }

                Dictionary<string, object> outObj = new Dictionary<string, object>();
                outObj["ok"] = cRes.ok;
                outObj["tvIp"] = tvIp;
                outObj["playerState"] = cRes.playerState ?? "";
                outObj["idleReason"] = cRes.idleReason ?? "";
                outObj["castUrl"] = finalCastUrl;
                outObj["useProxy"] = useProxyFlag;
                outObj["transcoded"] = didTranscode;
                outObj["txMode"] = txModeUsed;
                outObj["txVideoCodec"] = txVideoUsed;
                outObj["txAudioCodec"] = txAudioUsed;
                outObj["error"] = cRes.error ?? "";
                SendBytesResponse(ns, 200, "OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(Json.Serialize(outObj)), isHead);
                return;
            }

            if (pathOnly == "/cast-stop") {
                lock (TxLock) { StopTranscoderLocked(); }
                string tvIp = q.ContainsKey("ip") ? q["ip"].Trim() : "";
                CastCommandResult sRes;
                if (Regex.IsMatch(tvIp, @"^\d{1,3}(?:\.\d{1,3}){3}$")) {
                    sRes = AtomicCastV2.StopCast(tvIp, 8009);
                } else {
                    sRes = new CastCommandResult();
                    sRes.ok = false;
                    sRes.error = "IP inválida";
                }
                Dictionary<string, object> outObj = new Dictionary<string, object>();
                outObj["ok"] = sRes.ok;
                outObj["error"] = sRes.error ?? "";
                SendBytesResponse(ns, 200, "OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(Json.Serialize(outObj)), isHead);
                return;
            }

            if (pathOnly == "/transcode-start") {
                string rawU = q.ContainsKey("u") ? q["u"] : "";
                string uRaw = rawU.StartsWith("http", StringComparison.OrdinalIgnoreCase) ? rawU : DecodeB64Url(rawU);
                string refRaw = q.ContainsKey("ref") ? DecodeB64Url(q["ref"]) : "";
                string fbRaw = q.ContainsKey("fb") ? DecodeB64Url(q["fb"]) : "";
                string reqMode = q.ContainsKey("mode") ? q["mode"].Trim() : "auto";
                string titleRaw = q.ContainsKey("title") ? q["title"].Trim() : "";

                Dictionary<string, object> txObj = new Dictionary<string, object>();
                if (!Regex.IsMatch(uRaw, @"^https?://", RegexOptions.IgnoreCase)) {
                    txObj["ok"] = false;
                    txObj["error"] = "URL de origen inválida";
                    SendBytesResponse(ns, 400, "Bad Request", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(Json.Serialize(txObj)), isHead);
                    return;
                }
                TranscodeResult tr = StartTranscode(uRaw, refRaw, fbRaw, reqMode, titleRaw);
                txObj["ok"] = tr.Ok;
                txObj["sid"] = tr.Sid ?? "";
                txObj["playlistPath"] = tr.PlaylistPath ?? "";
                txObj["playlistUrl"] = tr.Ok ? ("http://127.0.0.1:" + HttpPort.ToString() + tr.PlaylistPath) : "";
                txObj["lanUrl"] = tr.Ok ? ("http://" + LanIp + ":" + HttpPort.ToString() + tr.PlaylistPath) : "";
                txObj["mode"] = tr.TranscodeMode ?? "";
                txObj["videoCodec"] = tr.VideoCodec ?? "";
                txObj["audioCodec"] = tr.AudioCodec ?? "";
                txObj["error"] = tr.Error ?? "";
                SendBytesResponse(ns, tr.Ok ? 200 : 500, tr.Ok ? "OK" : "Error", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(Json.Serialize(txObj)), isHead);
                return;
            }

            if (pathOnly == "/transcode-stop") {
                lock (TxLock) { StopTranscoderLocked(); }
                Dictionary<string, object> stopObj = new Dictionary<string, object>();
                stopObj["ok"] = true;
                SendBytesResponse(ns, 200, "OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(Json.Serialize(stopObj)), isHead);
                return;
            }

            Match txMatch = Regex.Match(pathOnly, @"^/tx/([a-zA-Z0-9_-]+)/([a-zA-Z0-9_.-]+)$");
            if (txMatch.Success) {
                string reqSid = txMatch.Groups[1].Value;
                string reqFile = txMatch.Groups[2].Value;
                string txFilePath = "";
                lock (TxLock) {
                    if (_txSid == reqSid && !string.IsNullOrEmpty(_txDir) && reqFile.IndexOf("..", StringComparison.Ordinal) < 0) {
                        _txLastAccessUtc = DateTime.UtcNow;
                        txFilePath = Path.Combine(_txDir, reqFile);
                    }
                }
                if (string.IsNullOrEmpty(txFilePath)) {
                    SendBytesResponse(ns, 404, "Not Found", "text/plain", Encoding.UTF8.GetBytes("Transcode session expired"), isHead);
                    return;
                }
                byte[] fileData = null;
                for (int rTry = 0; rTry < 5; rTry++) {
                    try {
                        if (File.Exists(txFilePath)) {
                            using (FileStream fs = new FileStream(txFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                            using (MemoryStream ms = new MemoryStream()) {
                                fs.CopyTo(ms);
                                fileData = ms.ToArray();
                            }
                            break;
                        }
                    } catch {}
                    Thread.Sleep(50);
                }
                if (fileData == null) {
                    SendBytesResponse(ns, 404, "Not Found", "text/plain", Encoding.UTF8.GetBytes("Segment not ready"), isHead);
                    return;
                }
                string ctype = reqFile.EndsWith(".m3u8", StringComparison.OrdinalIgnoreCase)
                    ? "application/vnd.apple.mpegurl; charset=utf-8"
                    : "video/mp2t";
                if (!string.IsNullOrEmpty(rangeHdr) && fileData.Length > 0) {
                    Match rm = Regex.Match(rangeHdr, @"bytes=(\d*)-(\d*)", RegexOptions.IgnoreCase);
                    if (rm.Success) {
                        long totalLen = fileData.LongLength;
                        long rStart = 0;
                        long rEnd = totalLen - 1;
                        if (!string.IsNullOrEmpty(rm.Groups[1].Value)) {
                            rStart = long.Parse(rm.Groups[1].Value);
                            if (!string.IsNullOrEmpty(rm.Groups[2].Value)) rEnd = Math.Min(long.Parse(rm.Groups[2].Value), totalLen - 1);
                        } else if (!string.IsNullOrEmpty(rm.Groups[2].Value)) {
                            long suffixLen = long.Parse(rm.Groups[2].Value);
                            rStart = Math.Max(0, totalLen - suffixLen);
                        }
                        if (rStart < 0 || rStart >= totalLen || rEnd < rStart) {
                            SendHeaders(ns, 416, "Range Not Satisfiable", "text/plain", 0, "bytes */" + totalLen.ToString());
                            ns.Flush();
                            return;
                        }
                        int sliceLen = (int)(rEnd - rStart + 1);
                        string contentRange = "bytes " + rStart.ToString() + "-" + rEnd.ToString() + "/" + totalLen.ToString();
                        SendHeaders(ns, 206, "Partial Content", ctype, sliceLen, contentRange);
                        if (!isHead && sliceLen > 0) {
                            ns.Write(fileData, (int)rStart, sliceLen);
                        }
                        ns.Flush();
                        return;
                    }
                }
                SendBytesResponse(ns, 200, "OK", ctype, fileData, isHead);
                return;
            }

            if (pathOnly == "/resolve-stream") {
                string rawU = q.ContainsKey("u") ? q["u"] : "";
                string targetU = rawU.StartsWith("http", StringComparison.OrdinalIgnoreCase) ? rawU : DecodeB64Url(rawU);
                string refU = q.ContainsKey("ref") ? DecodeB64Url(q["ref"]) : "";
                Dictionary<string, object> resObj = new Dictionary<string, object>();
                ResolvedPair resolved = !string.IsNullOrEmpty(targetU) ? ResolveFreshM3u8(targetU, refU, 0) : null;
                if (resolved != null && !string.IsNullOrEmpty(resolved.Url)) {
                    resObj["status"] = "ok";
                    resObj["url"] = resolved.Url;
                    resObj["ref"] = resolved.Referer ?? "";
                } else {
                    resObj["status"] = "fail";
                    resObj["url"] = "";
                    resObj["ref"] = "";
                }
                SendBytesResponse(ns, 200, "OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(Json.Serialize(resObj)), isHead);
                return;
            }

            if (pathOnly == "/cast-proxy") {
                HandleProxy(ns, hostHdr, rangeHdr, q, isHead);
                return;
            }

            if (pathOnly == "/lan-info") {
                Dictionary<string, object> lanObj = new Dictionary<string, object>();
                lanObj["status"] = "ok";
                lanObj["version"] = "1.7.0-castv2-tx";
                lanObj["lanIp"] = LanIp;
                lanObj["port"] = HttpPort;
                lanObj["hasFfmpeg"] = HasFfmpeg();
                lanObj["app"] = "AtomicBombTV Estable 1.7";
                SendBytesResponse(ns, 200, "OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(Json.Serialize(lanObj)), isHead);
                return;
            }

            if (pathOnly == "/ace-status" || pathOnly == "/ace-start") {
                bool isRunning = false;
                string versionStr = "";
                try {
                    HttpWebRequest reqAce = (HttpWebRequest)WebRequest.Create("http://127.0.0.1:6878/webui/api/service?method=get_version");
                    reqAce.Timeout = 800;
                    reqAce.ReadWriteTimeout = 800;
                    using (HttpWebResponse respAce = (HttpWebResponse)reqAce.GetResponse())
                    using (StreamReader srAce = new StreamReader(respAce.GetResponseStream(), Encoding.UTF8)) {
                        string bodyAce = srAce.ReadToEnd();
                        if (!string.IsNullOrEmpty(bodyAce) && bodyAce.IndexOf("version", StringComparison.OrdinalIgnoreCase) >= 0) {
                            isRunning = true;
                            versionStr = bodyAce;
                        }
                    }
                } catch { }

                string exeFound = "";
                string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                string[] acePaths = new string[] {
                    Path.Combine(appData, "ACEStream\\engine\\ace_engine.exe"),
                    Path.Combine(localAppData, "ACEStream\\engine\\ace_engine.exe"),
                    "C:\\Program Files\\ACEStream\\engine\\ace_engine.exe",
                    "C:\\Program Files (x86)\\ACEStream\\engine\\ace_engine.exe"
                };
                foreach (string ap in acePaths) {
                    if (File.Exists(ap)) { exeFound = ap; break; }
                }

                if (pathOnly == "/ace-start" && !isRunning && !string.IsNullOrEmpty(exeFound)) {
                    try {
                        ProcessStartInfo psiAce = new ProcessStartInfo(exeFound);
                        psiAce.WindowStyle = ProcessWindowStyle.Hidden;
                        psiAce.CreateNoWindow = true;
                        psiAce.UseShellExecute = false;
                        Process.Start(psiAce);
                        for (int w = 0; w < 8 && !isRunning; w++) {
                            Thread.Sleep(500);
                            try {
                                using (TcpClient tc = new TcpClient()) {
                                    IAsyncResult ar = tc.BeginConnect("127.0.0.1", 6878, null, null);
                                    if (ar.AsyncWaitHandle.WaitOne(250, false)) {
                                        tc.EndConnect(ar);
                                        isRunning = true;
                                    }
                                }
                            } catch { }
                        }
                    } catch { }
                }

                Dictionary<string, object> aceObj = new Dictionary<string, object>();
                aceObj["running"] = isRunning;
                aceObj["installed"] = isRunning || !string.IsNullOrEmpty(exeFound);
                aceObj["exePath"] = exeFound;
                aceObj["enginePort"] = 6878;
                aceObj["rawVersion"] = versionStr;
                SendBytesResponse(ns, 200, "OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(Json.Serialize(aceObj)), isHead);
                return;
            }

            if (pathOnly == "/ace-search") {
                string tagsCsv = q.ContainsKey("tags") ? q["tags"] : (q.ContainsKey("q") ? q["q"] : (q.ContainsKey("query") ? q["query"] : ""));
                int maxCh = 85;
                if (q.ContainsKey("limit")) { int.TryParse(q["limit"], out maxCh); if (maxCh < 1 || maxCh > 150) maxCh = 85; }
                Dictionary<string, object> searchRes = SearchFreshAceStreams(tagsCsv, maxCh);
                SendBytesResponse(ns, 200, "OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(Json.Serialize(searchRes)), isHead);
                return;
            }

            if (pathOnly == "/remote-command") {
                TouchPlayerActivity();
                Dictionary<string, object> cmdObj = new Dictionary<string, object>();
                lock (RemoteCmdLock) {
                    if (_pendingRemoteCmd != null) {
                        cmdObj = _pendingRemoteCmd;
                        _pendingRemoteCmd = null;
                    } else {
                        cmdObj["action"] = "none";
                    }
                }
                SendBytesResponse(ns, 200, "OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(Json.Serialize(cmdObj)), isHead);
                return;
            }

            if (pathOnly == "/remote-tune") {
                string chId = q.ContainsKey("id") ? q["id"].Trim() : "";
                string chName = q.ContainsKey("name") ? q["name"].Trim() : "";
                lock (RemoteCmdLock) {
                    _pendingRemoteCmd = new Dictionary<string, object>();
                    _pendingRemoteCmd["action"] = "tune";
                    _pendingRemoteCmd["channelId"] = chId;
                    _pendingRemoteCmd["name"] = chName;
                }
                Dictionary<string, object> res = new Dictionary<string, object>();
                res["ok"] = true;
                res["queued"] = "tune";
                res["channelId"] = chId;
                SendBytesResponse(ns, 200, "OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(Json.Serialize(res)), isHead);
                return;
            }

            if (pathOnly == "/remote-reload") {
                lock (RemoteCmdLock) {
                    _pendingRemoteCmd = new Dictionary<string, object>();
                    _pendingRemoteCmd["action"] = "reload";
                }
                Dictionary<string, object> res = new Dictionary<string, object>();
                res["ok"] = true;
                res["queued"] = "reload";
                SendBytesResponse(ns, 200, "OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(Json.Serialize(res)), isHead);
                return;
            }

            if (pathOnly == "/player-telemetry") {
                TouchPlayerActivity();
                lock (TelemetryLock) {
                    _latestTelemetry = new Dictionary<string, object>();
                    _latestTelemetry["channelId"] = q.ContainsKey("id") ? q["id"] : "";
                    _latestTelemetry["channelName"] = q.ContainsKey("name") ? q["name"] : "";
                    _latestTelemetry["currentTime"] = q.ContainsKey("t") ? q["t"] : "0";
                    _latestTelemetry["buffered"] = q.ContainsKey("buf") ? q["buf"] : "0";
                    _latestTelemetry["stalls"] = q.ContainsKey("stalls") ? q["stalls"] : "0";
                    _latestTelemetry["errors"] = q.ContainsKey("errs") ? q["errs"] : "0";
                    _latestTelemetry["state"] = q.ContainsKey("state") ? q["state"] : "unknown";
                    _latestTelemetry["updatedUtc"] = DateTime.UtcNow.ToString("o");
                }
                Dictionary<string, object> res = new Dictionary<string, object>();
                res["ok"] = true;
                SendBytesResponse(ns, 200, "OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(Json.Serialize(res)), isHead);
                return;
            }

            if (pathOnly == "/player-status") {
                Dictionary<string, object> res = new Dictionary<string, object>();
                lock (TelemetryLock) {
                    if (_latestTelemetry != null) {
                        res = new Dictionary<string, object>(_latestTelemetry);
                    } else {
                        res["state"] = "no_telemetry_yet";
                    }
                }
                SendBytesResponse(ns, 200, "OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(Json.Serialize(res)), isHead);
                return;
            }

            if (pathOnly == "/player-closing") {
                MarkPlayerClosing();
                Dictionary<string, object> res = new Dictionary<string, object>();
                res["ok"] = true;
                res["closing"] = true;
                SendBytesResponse(ns, 200, "OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(Json.Serialize(res)), isHead);
                return;
            }

            if (pathOnly == "/shutdown") {
                ShutdownRequested = true;
                Dictionary<string, object> res = new Dictionary<string, object>();
                res["ok"] = true;
                res["shutdown"] = true;
                SendBytesResponse(ns, 200, "OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(Json.Serialize(res)), isHead);
                return;
            }

            if (q.ContainsKey("channel")) {
                TouchPlayerActivity();
                string chName = q["channel"].Trim();
                if (string.IsNullOrEmpty(chName)) chName = "Explorando canales...";
                if (chName != CurrentChannel) {
                    CurrentChannel = chName;
                    StartTimestamp = (DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).Ticks / 10000000L;
                    ChannelChanged = true;
                }
                Dictionary<string, object> chObj = new Dictionary<string, object>();
                chObj["status"] = "ok";
                chObj["app"] = "AtomicBombTV";
                chObj["type"] = "watching";
                chObj["channel"] = CurrentChannel;
                SendBytesResponse(ns, 200, "OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(Json.Serialize(chObj)), isHead);
                return;
            }

            string targetFile = null;
            if (pathOnly == "/" || pathOnly == "/index.html" || pathOnly == "/AtomicBombTV-Player.html") {
                TouchPlayerActivity();
                targetFile = "AtomicBombTV-Player.html";
            }
            else if (pathOnly == "/events-status.json") targetFile = "events-status.json";
            else if (pathOnly == "/playlist.m3u") targetFile = "playlist.m3u";
            else if (pathOnly == "/logo.jpg") targetFile = "logo.jpg";
            else if (pathOnly == "/atomicbomb_logo.png") targetFile = "atomicbomb_logo.png";

            if (targetFile != null) {
                string fullPath = Path.Combine(ScriptDir, targetFile);
                if (File.Exists(fullPath)) {
                    byte[] fBytes = File.ReadAllBytes(fullPath);
                    SendBytesResponse(ns, 200, "OK", GetMimeType(targetFile), fBytes, isHead);
                } else {
                    SendBytesResponse(ns, 404, "Not Found", "text/plain", Encoding.UTF8.GetBytes("File not found"), isHead);
                }
                return;
            }

            Dictionary<string, object> defObj = new Dictionary<string, object>();
            defObj["status"] = "ok";
            defObj["app"] = "AtomicBombTV";
            defObj["type"] = "watching";
            defObj["channel"] = CurrentChannel;
            SendBytesResponse(ns, 200, "OK", "application/json; charset=utf-8", Encoding.UTF8.GetBytes(Json.Serialize(defObj)), isHead);
        } catch {
        } finally {
            try { client.Close(); } catch {}
        }
    }
}
'@

try {
    if ($null -eq ('AtomicCastV2' -as [type]) -or $null -eq ('AtomicHttpServer' -as [type])) {
        Add-Type -TypeDefinition $castCsharpSource -ReferencedAssemblies @('System.Web.Extensions') -Language CSharp
    }
} catch {}

# 3. Iniciar servidor HTTP C# Dual-Stack (IPv6 + IPv4: localhost, 127.0.0.1 y 192.168.x.x)
$cachedLanIp = Get-LanIPv4
$serverOk = $false
try {
    if ($null -ne ('AtomicHttpServer' -as [type])) {
        $serverOk = [AtomicHttpServer]::Start([int]$config.http_port, [string]$ScriptDir, [string]$cachedLanIp, [long]$global:startTimestamp)
    }
} catch {}

if (-not $serverOk) {
    exit 0
}

Update-DiscordActivity $global:currentChannel
$lastCheck = [DateTime]::UtcNow

# Bucle ligero para mantener Discord Rich Presence e IP LAN sincronizados (con auto-cierre al cerrar el navegador)
while ($true) {
    try {
        if ([AtomicHttpServer]::ShouldAutoShutdown()) {
            break
        }
        if ([AtomicHttpServer]::ChannelChanged) {
            [AtomicHttpServer]::ChannelChanged = $false
            $global:startTimestamp = [AtomicHttpServer]::StartTimestamp
            Update-DiscordActivity ([AtomicHttpServer]::CurrentChannel)
        }
        $now = [DateTime]::UtcNow
        if (($now - $lastCheck).TotalSeconds -ge 4) {
            $lastCheck = $now
            [AtomicHttpServer]::LanIp = Get-LanIPv4
            if (-not ($global:pipeStream -and $global:pipeStream.IsConnected)) {
                Update-DiscordActivity ([AtomicHttpServer]::CurrentChannel)
            }
        }
        Start-Sleep -Milliseconds 180
    } catch {
        Start-Sleep -Milliseconds 300
    }
}

try { [AtomicHttpServer]::Stop() } catch {}
try {
    if ($global:pipeStream) {
        try { $global:pipeStream.Close() } catch {}
        $global:pipeStream = $null
    }
} catch {}
exit 0
