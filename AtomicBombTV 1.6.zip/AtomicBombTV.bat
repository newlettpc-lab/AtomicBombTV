@echo off
title AtomicBombTV - Version Build 1.6 (Noviembre 2026) - TV en Vivo gratis VIP
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0refresh-playlist.ps1"
if errorlevel 1 pause
exit /b 0
