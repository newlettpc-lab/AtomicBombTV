﻿# AtomicBombTV (Version Estable 1.9 - Noviembre 2026)
# Author: Faraz Arif Malik. Residencia Badalona.
# Encoding: UTF-8 con BOM

param(
    [string]$ModoVpn = $null,
    [string]$BuscarAce = $null,
    [string]$Accion = $null,
    [switch]$ShowDetails
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12 }
[System.Net.ServicePointManager]::DefaultConnectionLimit = 256
[System.Net.ServicePointManager]::Expect100Continue = $false
[System.Net.ServicePointManager]::UseNagleAlgorithm = $false
$ProgressPreference = 'SilentlyContinue'
$Host.UI.RawUI.WindowTitle = "AtomicBombTV - Version Estable 1.9 (Noviembre 2026)"

if (-not ('AtomicFastHttp' -as [type])) {
Add-Type -ReferencedAssemblies @('System.Net.Http', 'System.Core') -TypeDefinition @'
using System;
using System.Collections.Concurrent;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

public static class AtomicFastHttp
{
    private static readonly HttpClient _client;
    public static readonly ConcurrentDictionary<string, bool> BlockedHosts = new ConcurrentDictionary<string, bool>(StringComparer.OrdinalIgnoreCase);

    static AtomicFastHttp()
    {
        try { ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls13; }
        catch { ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12; }
        ServicePointManager.DefaultConnectionLimit = 256;
        ServicePointManager.Expect100Continue = false;
        ServicePointManager.UseNagleAlgorithm = false;

        var handler = new HttpClientHandler
        {
            AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate,
            AllowAutoRedirect = true,
            UseCookies = false
        };
        _client = new HttpClient(handler);
        _client.Timeout = TimeSpan.FromSeconds(15);
    }

    public static string GetHost(string url)
    {
        try { return new Uri(url).Host.ToLowerInvariant(); } catch { return ""; }
    }

    private static bool IsDeadNetworkException(Exception ex)
    {
        for (var cur = ex; cur != null; cur = cur.InnerException)
        {
            var we = cur as WebException;
            if (we != null && we.Response == null && we.Status != WebExceptionStatus.Timeout && we.Status != WebExceptionStatus.RequestCanceled)
                return true;
        }
        return false;
    }

    public static async Task<string> GetUtf8Async(string url, string referer, string origin, string ua, int timeoutMs, bool trackBlock = true)
    {
        if (string.IsNullOrEmpty(url)) return null;
        string host = GetHost(url);
        if (trackBlock && !string.IsNullOrEmpty(host) && BlockedHosts.ContainsKey(host)) return null;

        using (var cts = new CancellationTokenSource(timeoutMs > 0 ? timeoutMs : 2500))
        {
            try
            {
                using (var req = new HttpRequestMessage(HttpMethod.Get, url))
                {
                    if (!string.IsNullOrEmpty(ua)) req.Headers.TryAddWithoutValidation("User-Agent", ua);
                    if (!string.IsNullOrEmpty(referer)) req.Headers.TryAddWithoutValidation("Referer", referer);
                    if (!string.IsNullOrEmpty(origin)) req.Headers.TryAddWithoutValidation("Origin", origin);
                    using (var resp = await _client.SendAsync(req, HttpCompletionOption.ResponseContentRead, cts.Token).ConfigureAwait(false))
                    {
                        if (!resp.IsSuccessStatusCode) return null;
                        byte[] bytes = await resp.Content.ReadAsByteArrayAsync().ConfigureAwait(false);
                        return Encoding.UTF8.GetString(bytes);
                    }
                }
            }
            catch (TaskCanceledException) { return null; }
            catch (OperationCanceledException) { return null; }
            catch (Exception ex)
            {
                if (trackBlock && !string.IsNullOrEmpty(host) && IsDeadNetworkException(ex))
                    BlockedHosts[host] = true;
                return null;
            }
        }
    }

    public static string GetUtf8(string url, string referer, string origin, string ua, int timeoutMs, bool trackBlock = true)
    {
        return GetUtf8Async(url, referer, origin, ua, timeoutMs, trackBlock).GetAwaiter().GetResult();
    }

    private static async Task<bool> ProbeSegmentBytesAsync(string segUrl, string referer, string origin, string ua, int timeoutMs)
    {
        using (var cts = new CancellationTokenSource(timeoutMs > 0 ? timeoutMs : 2500))
        {
            try
            {
                using (var req = new HttpRequestMessage(HttpMethod.Get, segUrl))
                {
                    if (!string.IsNullOrEmpty(ua)) req.Headers.TryAddWithoutValidation("User-Agent", ua);
                    if (!string.IsNullOrEmpty(referer)) req.Headers.TryAddWithoutValidation("Referer", referer);
                    if (!string.IsNullOrEmpty(origin)) req.Headers.TryAddWithoutValidation("Origin", origin);
                    using (var resp = await _client.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, cts.Token).ConfigureAwait(false))
                    {
                        if ((int)resp.StatusCode < 200 || (int)resp.StatusCode >= 300) return false;
                        using (var stream = await resp.Content.ReadAsStreamAsync().ConfigureAwait(false))
                        {
                            byte[] buf = new byte[16];
                            int n = await stream.ReadAsync(buf, 0, 16, cts.Token).ConfigureAwait(false);
                            return n > 0;
                        }
                    }
                }
            }
            catch { return false; }
        }
    }

    public static async Task<bool> TestStreamDeepLiveAsync(string uri, string referer, string origin, string ua, int timeoutMs, bool skipBlockCache)
    {
        if (string.IsNullOrWhiteSpace(uri) || !(uri.StartsWith("http://", StringComparison.OrdinalIgnoreCase) || uri.StartsWith("https://", StringComparison.OrdinalIgnoreCase)))
            return false;
        string host = GetHost(uri);
        if (!skipBlockCache && !string.IsNullOrEmpty(host) && BlockedHosts.ContainsKey(host))
            return false;

        string txt = await GetUtf8Async(uri, referer, origin, ua, timeoutMs, !skipBlockCache).ConfigureAwait(false);
        if (string.IsNullOrEmpty(txt)) return false;

        if (txt.IndexOf("<MPD", StringComparison.OrdinalIgnoreCase) >= 0)
        {
            if (txt.IndexOf("ContentProtection", StringComparison.OrdinalIgnoreCase) >= 0) return false;
            try
            {
                var mb = Regex.Match(txt, @"<BaseURL[^>]*>([^<]+)</BaseURL>");
                string baseUrl = mb.Success ? new Uri(new Uri(uri), mb.Groups[1].Value.Trim()).AbsoluteUri : uri;
                int vIdx = txt.IndexOf("contentType=\"video\"", StringComparison.OrdinalIgnoreCase);
                string vBlk = vIdx > 0 ? txt.Substring(vIdx) : txt;
                var mr = Regex.Match(vBlk, @"<Representation\s+id=""([^""]+)""");
                if (!mr.Success) return false;
                string repId = mr.Groups[1].Value;
                string probePath = null;
                var mm = Regex.Match(vBlk, @"media=""([^""]+)""");
                var md = Regex.Match(vBlk, @"duration=""(\d+)""");
                var mts = Regex.Match(vBlk, @"timescale=""(\d+)""");
                var mi = Regex.Match(vBlk, @"initialization=""([^""]+)""");
                if (mm.Success && md.Success && mts.Success && txt.Contains("2015-01-01T00:00:03"))
                {
                    double segSec = double.Parse(md.Groups[1].Value) / Math.Max(1.0, double.Parse(mts.Groups[1].Value));
                    long num = (long)Math.Floor((DateTimeOffset.UtcNow.ToUnixTimeSeconds() - 1420070403.0) / segSec) - 3L;
                    probePath = mm.Groups[1].Value.Replace("$RepresentationID$", repId).Replace("$Number$", num.ToString());
                }
                else if (mi.Success)
                {
                    probePath = mi.Groups[1].Value.Replace("$RepresentationID$", repId);
                }
                if (string.IsNullOrEmpty(probePath)) return false;
                string segUrl = new Uri(new Uri(baseUrl), probePath).AbsoluteUri;
                return await ProbeSegmentBytesAsync(segUrl, referer, origin, ua, timeoutMs).ConfigureAwait(false);
            }
            catch { return false; }
        }

        if (!txt.Contains("#EXTM3U")) return false;
        if (Regex.IsMatch(txt, @"(?i)METHOD=SAMPLE-AES|skd://|com\.apple\.streamingkeydelivery|edef8ba9-79d6-4ace-a3c8-27dcd51d21ed|com\.microsoft\.playready"))
            return false;

        string childUrl = uri;
        string txt2 = txt;
        if (txt.Contains("#EXT-X-STREAM-INF"))
        {
            string[] lines = txt.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            string firstChild = null;
            string anyChild = null;
            foreach (string raw in lines)
            {
                string l = raw.Trim();
                if (string.IsNullOrEmpty(l) || l.StartsWith("#")) continue;
                if (anyChild == null) anyChild = l;
                if (!Regex.IsMatch(l, @"(?i)_audio.*\.m3u8")) { firstChild = l; break; }
            }
            if (firstChild == null) firstChild = anyChild;
            if (firstChild == null) return false;
            try { childUrl = new Uri(new Uri(uri), firstChild).AbsoluteUri; } catch { return false; }
            txt2 = await GetUtf8Async(childUrl, referer, origin, ua, timeoutMs, !skipBlockCache).ConfigureAwait(false);
            if (string.IsNullOrEmpty(txt2) || !txt2.Contains("#EXTM3U")) return false;
            if (Regex.IsMatch(txt2, @"(?i)METHOD=SAMPLE-AES|skd://|com\.apple\.streamingkeydelivery|edef8ba9-79d6-4ace-a3c8-27dcd51d21ed|com\.microsoft\.playready"))
                return false;
        }

        string seg = null;
        string[] lines2 = txt2.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
        for (int i = lines2.Length - 1; i >= 0; i--)
        {
            string l = lines2[i].Trim();
            if (!string.IsNullOrEmpty(l) && !l.StartsWith("#")) { seg = l; break; }
        }
        if (seg == null)
        {
            var mm = Regex.Match(txt2, @"#EXT-X-MAP:URI=""([^""]+)""");
            if (mm.Success) seg = mm.Groups[1].Value;
        }
        if (seg == null) return false;
        string segAbs;
        try { segAbs = new Uri(new Uri(childUrl), seg).AbsoluteUri; } catch { return false; }
        return await ProbeSegmentBytesAsync(segAbs, referer, origin, ua, timeoutMs).ConfigureAwait(false);
    }

    public static bool TestStreamDeepLive(string uri, string referer, string origin, string ua, int timeoutMs, bool skipBlockCache)
    {
        return TestStreamDeepLiveAsync(uri, referer, origin, ua, timeoutMs, skipBlockCache).GetAwaiter().GetResult();
    }

    public static string[] BatchGetUrls(string[] urls, string[] refs, string[] origs, string ua, int timeoutMs)
    {
        int n = urls.Length;
        string[] res = new string[n];
        var tasks = new Task[n];
        for (int i = 0; i < n; i++)
        {
            int idx = i;
            tasks[idx] = Task.Run(async () =>
            {
                string r = (refs != null && idx < refs.Length) ? refs[idx] : null;
                string o = (origs != null && idx < origs.Length) ? origs[idx] : null;
                res[idx] = await GetUtf8Async(urls[idx], r, o, ua, timeoutMs, false).ConfigureAwait(false);
            });
        }
        Task.WaitAll(tasks);
        return res;
    }

    public static string[] BatchPickFirstLive(string[] candsJoined, string[] refs, string[] origs, int[] timeoutsMs, bool[] skipCache, string ua, int maxConcurrency)
    {
        int n = candsJoined.Length;
        string[] res = new string[n];
        using (var sem = new SemaphoreSlim(maxConcurrency > 0 ? maxConcurrency : 96))
        {
            var tasks = new Task[n];
            for (int i = 0; i < n; i++)
            {
                int idx = i;
                tasks[idx] = Task.Run(async () =>
                {
                    await sem.WaitAsync().ConfigureAwait(false);
                    try
                    {
                        string[] cands = (candsJoined[idx] ?? "").Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
                        string r = (refs != null && idx < refs.Length) ? refs[idx] : null;
                        string o = (origs != null && idx < origs.Length) ? origs[idx] : "null";
                        int tm = (timeoutsMs != null && idx < timeoutsMs.Length) ? timeoutsMs[idx] : 2000;
                        bool sk = (skipCache != null && idx < skipCache.Length) && skipCache[idx];
                        foreach (string c in cands)
                        {
                            if (await TestStreamDeepLiveAsync(c, r, o, ua, tm, sk).ConfigureAwait(false))
                            {
                                res[idx] = c;
                                break;
                            }
                        }
                    }
                    finally { sem.Release(); }
                });
            }
            Task.WaitAll(tasks);
        }
        return res;
    }
}
'@
}

$script:ScanTimer = [System.Diagnostics.Stopwatch]::StartNew()
$global:BlockedHosts = [AtomicFastHttp]::BlockedHosts
$global:ActiveStreamxHost = "streamx723.sbs"
$script:ParallelPool = $null
$script:CandyShopActiveCount = 0
$script:SkippedSportsCount = 0
$script:InStreamsStatus = "STANDBY"
$script:FutbolLibreApiStatus = "OFFLINE"
$script:EmbedMeStatus = "OFFLINE"
$script:SpanishVipStatus = "STANDBY"
$script:StreamXhdStatus = "OFFLINE"
$script:WebOracleStatus = "OFFLINE"
$script:WebAiStatus = "STANDBY"
$script:FormaturaStatus = "OFFLINE"
$script:AzplayStatus = "OFFLINE"
$script:WebOracleEvents = [System.Collections.Generic.List[object]]::new()
$script:AiApiKey = if ($env:GEMINI_API_KEY) { $env:GEMINI_API_KEY } else { "" }
$script:AiModel = "gemini-2.5-flash"
try {
    $cfgP = Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) "discord-config.json"
    if (Test-Path $cfgP) {
        $cfgObj = [System.IO.File]::ReadAllText($cfgP, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
        if ($cfgObj.ai_api_key -and -not $script:AiApiKey) { $script:AiApiKey = [string]$cfgObj.ai_api_key }
        if ($cfgObj.ai_model) { $script:AiModel = [string]$cfgObj.ai_model }
    }
} catch {}

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$OutputFile = Join-Path $ScriptDir "playlist.m3u"
$ApiStatusFile = Join-Path $ScriptDir "events-status.json"
$HtmlPlayer = Join-Path $ScriptDir "AtomicBombTV-Player.html"
$script:FinishCacheFile = Join-Path $ScriptDir "event-finish-cache.json"
$script:FinishCache = [hashtable]::Synchronized(@{})
$script:FinishCacheDirty = $false
$script:PurgeGraceMinutes = 15
$UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

Write-Host ""
Write-Host "  ================================================================" -ForegroundColor Red
Write-Host "   ATOMIC BOMB TV" -NoNewline -ForegroundColor Yellow
Write-Host "  |  " -NoNewline -ForegroundColor DarkGray
Write-Host "Version Estable 1.9" -NoNewline -ForegroundColor Green
Write-Host " (Noviembre 2026)" -ForegroundColor Gray
Write-Host "   TV en Vivo gratis" -ForegroundColor Green
Write-Host "  ================================================================" -ForegroundColor Red
Write-Host "  ¡Bienvenido a AtomicBombTV! Iniciando asistente de canales..." -ForegroundColor Cyan
Write-Host "  Aviso Legal: Esta aplicacion solo recopila directos que estan publicamente visibles en Internet," -ForegroundColor DarkGray
Write-Host "  los creadores de AtomicBombTV no se hacen responsables del uso indebido de estos y se reservan" -ForegroundColor DarkGray
Write-Host "  el derecho de bloquear la aplicacion remotamente para todos los dispositivos si hay riesgo legal." -ForegroundColor DarkGray
Write-Host ""

$script:LocalVersion = "1.9.1"
$script:LastListenCheckUtc = [DateTime]::MinValue

function Invoke-PeriodicListenCheckSilent {
    try {
        $now = [DateTime]::UtcNow
        if ($script:LastListenCheckUtc -ne [DateTime]::MinValue -and ($now - $script:LastListenCheckUtc).TotalSeconds -lt 60) {
            return
        }
        $script:LastListenCheckUtc = $now
        $cb = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
        foreach ($u in @(
            "https://github.com/newlettpc-lab/AtomicBombTV/blob/main/listen?_t=$cb",
            "https://raw.githubusercontent.com/newlettpc-lab/AtomicBombTV/main/listen?_t=$cb",
            "https://raw.githubusercontent.com/newlettpc-lab/AtomicBombTV/main/listen.txt?_t=$cb"
        )) {
            try {
                $req = [System.Net.WebRequest]::CreateHttp($u)
                $req.Proxy = $null
                $req.Timeout = 1500
                $req.ReadWriteTimeout = 1500
                $req.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AtomicBombTV-Monitor"
                $resp = $req.GetResponse()
                $sr = New-Object System.IO.StreamReader($resp.GetResponseStream(), [System.Text.Encoding]::UTF8)
                $body = $sr.ReadToEnd()
                $sr.Close()
                $resp.Close()
                if ($body) {
                    $parsedText = $body
                    if ($u -like "*/blob/*") {
                        $m = [regex]::Match($body, '"rawLines"\s*:\s*(\[(?:[^\[\]]|\\.)*\])')
                        if ($m.Success) {
                            $arr = $m.Groups[1].Value | ConvertFrom-Json
                            $parsedText = ($arr -join "`n")
                        } else {
                            continue
                        }
                    }
                    $blk = Test-ListenBlockPayload $parsedText
                    if ($blk.Blocked) {
                        Invoke-RemoteBlockTermination $blk.Reason
                    }
                    return
                }
            } catch {}
        }
    } catch {}
}

function Test-ListenBlockPayload([string]$RawText) {
    if ([string]::IsNullOrWhiteSpace($RawText)) {
        return [PSCustomObject]@{ Blocked = $false; Reason = "" }
    }
    $cleaned = $RawText.Replace(([string][char]0xFEFF), '')
    $blocked = $false
    $reason = ""
    $lines = $cleaned -replace "`r`n", "`n" -replace "`r", "`n" -split "`n"
    foreach ($ln in $lines) {
        $t = $ln.Trim()
        if ([string]::IsNullOrWhiteSpace($t) -or $t.StartsWith("#") -or $t.StartsWith("//")) { continue }
        if ($t -match '^(?i)(?:block|blocked)\s*[:=]\s*(1|true|yes|si)\b') { $blocked = $true }
        elseif ($t -match '^(?i)(?:block|blocked)\s*[:=]\s*(0|false|no)\b') { $blocked = $false }
        elseif ($t -match '^(?i)(?:reason|message|motivo|mensaje)\s*[:=]\s*(.+)$') { $reason = $Matches[1].Trim() }
    }
    if (-not $blocked -and $RawText -match '(?i)"block(?:ed)?"\s*:\s*(1|true)\b') {
        $blocked = $true
    }
    return [PSCustomObject]@{ Blocked = $blocked; Reason = $reason }
}

function Invoke-RemoteBlockTermination([string]$ReasonText) {
    try { if (Get-Command Disable-QuietScanMode -ErrorAction SilentlyContinue) { Disable-QuietScanMode } } catch {}
    $motivo = if ([string]::IsNullOrWhiteSpace($ReasonText)) {
        "No disponible temporalmente."
    } else { $ReasonText.Trim() }
    Write-Host ""
    Write-Host "  +==============================================================+" -ForegroundColor Red
    Write-Host "  |   [!] ATOMICBOMBTV - APLICACION BLOQUEADA REMOTAMENTE        |" -ForegroundColor Red
    Write-Host "  +==============================================================+" -ForegroundColor Red
    Write-Host "  Se ha bloqueado la aplicacion remotamente." -ForegroundColor Yellow
    Write-Host "  AtomicBombTV no esta disponible en este momento." -ForegroundColor Yellow
    Write-Host ""
    Write-Host ("  Motivo: {0}" -f $motivo) -ForegroundColor White
    Write-Host ""
    Write-Host "  >> [ Cerrar aplicacion: pulsa ENTER ] " -NoNewline -ForegroundColor Gray
    if ([Console]::IsInputRedirected) {
        [void][Console]::In.ReadLine()
        Write-Host ""
    } else {
        while ([Console]::KeyAvailable) { [void][Console]::ReadKey($true) }
        while ($true) {
            $k = [Console]::ReadKey($true)
            if ($k.Key -eq 'Enter' -or $k.Key -eq 'Escape' -or [int]$k.KeyChar -eq 13 -or [int]$k.KeyChar -eq 10) {
                Write-Host ""
                break
            }
        }
    }
    exit 0
}

function ConvertTo-ComparableVersion([string]$VerText) {
    if ($VerText -match '(\d+(?:\.\d+)+)') {
        try {
            $raw = [version]$Matches[1]
            return [version]::new($raw.Major, $raw.Minor, [Math]::Max(0, $raw.Build), [Math]::Max(0, $raw.Revision))
        } catch {}
    }
    return $null
}

function ConvertTo-SummarizedReleaseNotes([string]$RawBody) {
    $fallback = @(
        "Nuevos canales disponibles y búsqueda más rápida.",
        "Optimización en la reproducción y mayor estabilidad.",
        "Mejoras visuales, envío al televisor y correcciones generales."
    )
    if ([string]::IsNullOrWhiteSpace($RawBody)) { return $fallback }

    $cleanedRaw = $RawBody.Replace(([string][char]0xFEFF), '')
    $lines = $cleanedRaw -replace "`r`n", "`n" -replace "`r", "`n" -split "`n"
    $out = [System.Collections.Generic.List[string]]::new()
    foreach ($line in $lines) {
        $t = $line.Trim()
        if ([string]::IsNullOrWhiteSpace($t)) { continue }
        if ($t.StartsWith("---") -or $t.StartsWith("===")) { continue }
        if ($t -match '(?i)^(?:#+\s*)?(?:novedades|cambios|changelog|whats?\s*new|release\s*notes|downloads?|sha256)\s*:?$') { continue }
        if ($t -match '(?i)^https?://\S+$') { continue }
        if ($t -match '(?i)^[a-f0-9]{32,}.*$') { continue }

        $t = $t -replace '^#+\s*', ''
        $t = $t -replace '^[\-\*\+•]\s+', ''
        $t = $t -replace '^\d+[.)]\s+', ''
        $t = [regex]::Replace($t, '\[([^\]]+)\]\([^)]+\)', '$1')
        $t = $t.Replace('**', '').Replace('__', '').Replace('`', '')
        $t = ($t -replace '\s{2,}', ' ').Trim()
        if ($t.Length -lt 4) { continue }
        if ($t.Length -gt 130) { $t = $t.Substring(0, 127).Trim() + "..." }

        $out.Add($t)
        if ($out.Count -ge 5) { break }
    }
    if ($out.Count -eq 0) { return $fallback }
    return @($out)
}

function Get-RemoteNovedadesTxt([string]$RepoSlug) {
    try {
        $cb = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
        $urls = @(
            "https://github.com/$RepoSlug/blob/main/novedades.txt?_t=$cb",
            "https://github.com/$RepoSlug/blob/main/NOVEDADES.txt?_t=$cb",
            "https://raw.githubusercontent.com/$RepoSlug/main/novedades.txt?_t=$cb",
            "https://raw.githubusercontent.com/$RepoSlug/main/NOVEDADES.txt?_t=$cb",
            "https://api.github.com/repos/$RepoSlug/contents/novedades.txt"
        )
        $bodies = [AtomicFastHttp]::BatchGetUrls(
            $urls,
            @($null, $null, $null, $null, $null),
            @($null, $null, $null, $null, $null),
            "AtomicBombTV-Updater",
            2800
        )
        foreach ($idx in @(0, 1)) {
            $b = $bodies[$idx]
            if ($b) {
                $m = [regex]::Match($b, '"rawLines"\s*:\s*(\[(?:[^\[\]]|\\.)*\])')
                if ($m.Success) {
                    try {
                        $arr = $m.Groups[1].Value | ConvertFrom-Json
                        $joined = ($arr -join "`n").Trim()
                        if (-not [string]::IsNullOrWhiteSpace($joined)) { return $joined }
                    } catch {}
                }
            }
        }
        foreach ($idx in @(2, 3)) {
            if ($bodies[$idx] -and -not [string]::IsNullOrWhiteSpace($bodies[$idx]) -and $bodies[$idx] -notmatch '^\s*404:\s*Not Found') {
                return [string]$bodies[$idx]
            }
        }
        if ($bodies[4] -and $bodies[4].Trim().StartsWith("{")) {
            try {
                $jo = $bodies[4] | ConvertFrom-Json
                if ($jo.content) {
                    $b64 = ([string]$jo.content) -replace '\s+', ''
                    if ($b64) {
                        $dec = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($b64))
                        if (-not [string]::IsNullOrWhiteSpace($dec)) { return $dec }
                    }
                }
            } catch {}
        }
    } catch {}
    return $null
}

function Invoke-MandatoryUpdateCheck {
    Write-Host ("  [+] Comprobando version del programa en GitHub (Actual: Estable {0})..." -f $script:LocalVersion) -ForegroundColor Cyan
    $repoSlug = "newlettpc-lab/AtomicBombTV"
    $localVerObj = ConvertTo-ComparableVersion $script:LocalVersion
    if (-not $localVerObj) { return }

    $candidates = [System.Collections.Generic.List[object]]::new()
    # Comprobar API Contents (incluye archivo listen en tiempo real sin cache CDN) + Releases + Raw en paralelo
    $cb = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    $uContents = "https://api.github.com/repos/$repoSlug/contents"
    $uRel = "https://api.github.com/repos/$repoSlug/releases/latest"
    $uRaw = "https://raw.githubusercontent.com/$repoSlug/main/refresh-playlist.ps1"
    $uListenApi = "https://api.github.com/repos/$repoSlug/contents/listen"
    $uListen = "https://raw.githubusercontent.com/$repoSlug/main/listen?_t=$cb"
    $uListenTxt = "https://raw.githubusercontent.com/$repoSlug/main/listen.txt?_t=$cb"
    $updBodies = [AtomicFastHttp]::BatchGetUrls(
        @($uContents, $uRel, $uRaw, $uListenApi, $uListen, $uListenTxt),
        @($null, $null, $null, $null, $null, $null),
        @($null, $null, $null, $null, $null, $null),
        "AtomicBombTV-Updater",
        2200
    )

    $listenDecoded = $null
    if ($updBodies[3] -and $updBodies[3].Trim().StartsWith("{")) {
        try {
            $lj = $updBodies[3] | ConvertFrom-Json
            if ($lj.content) {
                $b64 = ([string]$lj.content) -replace '\s+', ''
                if ($b64) {
                    $listenDecoded = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($b64))
                }
            }
        } catch {}
    }
    foreach ($lBody in @($listenDecoded, $updBodies[4], $updBodies[5])) {
        if ($lBody) {
            $script:LastListenCheckUtc = [DateTime]::UtcNow
            $blkRes = Test-ListenBlockPayload $lBody
            if ($blkRes.Blocked) {
                Invoke-RemoteBlockTermination $blkRes.Reason
            }
            break
        }
    }

    if ($updBodies[0]) {
        try {
            $contents = $updBodies[0] | ConvertFrom-Json
            foreach ($item in @($contents)) {
                if ($item.type -ne 'file' -or -not $item.name) { continue }
                if ($item.name -match '(?i)^AtomicBombTV[\s._-]*v?(\d+(?:\.\d+)+)\.zip$') {
                    $vObj = ConvertTo-ComparableVersion $Matches[1]
                    if ($vObj) {
                        $candidates.Add([PSCustomObject]@{
                            VerStr      = $Matches[1]
                            VerObj      = $vObj
                            ZipName     = [string]$item.name
                            DownloadUrl = if ($item.download_url) { [string]$item.download_url } else { "https://raw.githubusercontent.com/$repoSlug/main/$([Uri]::EscapeDataString($item.name))" }
                            PageUrl     = "https://github.com/$repoSlug"
                            Notes       = ""
                        })
                    }
                } elseif ($item.name -ieq 'version.json') {
                    try {
                        $vjUrl = if ($item.download_url) { [string]$item.download_url } else { "https://raw.githubusercontent.com/$repoSlug/main/version.json" }
                        $vjTxt = [AtomicFastHttp]::GetUtf8($vjUrl, $null, $null, "AtomicBombTV-Updater", 1800, $false)
                        if ($vjTxt) {
                            $jo = $vjTxt | ConvertFrom-Json
                            $vRaw = if ($jo.pc_version) { [string]$jo.pc_version } else { [string]$jo.version }
                            $vObj = ConvertTo-ComparableVersion $vRaw
                            if ($vObj) {
                                $vStr = if ($vRaw -match '(\d+(?:\.\d+)+)') { $Matches[1] } else { "$($vObj.Major).$($vObj.Minor)" }
                                $dlUrl = if ($jo.zip_url) { [string]$jo.zip_url } elseif ($jo.url) { [string]$jo.url } else { "https://github.com/$repoSlug/releases/latest" }
                                $vjNotes = if ($jo.notes) { [string]$jo.notes } elseif ($jo.changelog) { [string]$jo.changelog } else { "" }
                                $candidates.Add([PSCustomObject]@{
                                    VerStr      = $vStr
                                    VerObj      = $vObj
                                    ZipName     = "AtomicBombTV $vStr.zip"
                                    DownloadUrl = $dlUrl
                                    PageUrl     = "https://github.com/$repoSlug"
                                    Notes       = $vjNotes
                                })
                            }
                        }
                    } catch {}
                } elseif ($item.name -ieq 'refresh-playlist.ps1' -and $updBodies[2]) {
                    $headTxt = if ($updBodies[2].Length -gt 600) { $updBodies[2].Substring(0, 600) } else { [string]$updBodies[2] }
                    if ($headTxt -match '(?i)Version\s+(?:Estable|Build)\s+v?(\d+(?:\.\d+)+)') {
                        $vObj = ConvertTo-ComparableVersion $Matches[1]
                        if ($vObj) {
                            $candidates.Add([PSCustomObject]@{
                                VerStr      = $Matches[1]
                                VerObj      = $vObj
                                ZipName     = "AtomicBombTV $($Matches[1]).zip"
                                DownloadUrl = "https://github.com/$repoSlug/archive/refs/heads/main.zip"
                                PageUrl     = "https://github.com/$repoSlug"
                                Notes       = ""
                            })
                        }
                    }
                }
            }
        } catch {}
    }

    if ($updBodies[1]) {
        try {
            $rel = $updBodies[1] | ConvertFrom-Json
            if ($rel) {
                $relVerText = if ($rel.tag_name) { [string]$rel.tag_name } else { [string]$rel.name }
                $vObj = ConvertTo-ComparableVersion $relVerText
                if ($vObj) {
                    $zipAsset = @($rel.assets | Where-Object { $_.name -match '(?i)\.zip$' }) | Select-Object -First 1
                    $verClean = if ($relVerText -match '(\d+(?:\.\d+)+)') { $Matches[1] } else { "$($vObj.Major).$($vObj.Minor)" }
                    $candidates.Add([PSCustomObject]@{
                        VerStr      = $verClean
                        VerObj      = $vObj
                        ZipName     = if ($zipAsset) { [string]$zipAsset.name } else { "AtomicBombTV $verClean.zip" }
                        DownloadUrl = if ($zipAsset -and $zipAsset.browser_download_url) { [string]$zipAsset.browser_download_url } elseif ($rel.zipball_url) { [string]$rel.zipball_url } else { "https://github.com/$repoSlug/releases/latest" }
                        PageUrl     = if ($rel.html_url) { [string]$rel.html_url } else { "https://github.com/$repoSlug/releases" }
                        Notes       = if ($rel.body) { [string]$rel.body } else { "" }
                    })
                }
            }
        } catch {}
    }

    if ($candidates.Count -eq 0 -and $updBodies[2]) {
        $rawHead = if ($updBodies[2].Length -gt 600) { $updBodies[2].Substring(0, 600) } else { [string]$updBodies[2] }
        if ($rawHead -match '(?i)Version\s+(?:Estable|Build)\s+v?(\d+(?:\.\d+)+)') {
            $vObj = ConvertTo-ComparableVersion $Matches[1]
            if ($vObj) {
                $verStr = $Matches[1]
                $candidates.Add([PSCustomObject]@{
                    VerStr      = $verStr
                    VerObj      = $vObj
                    ZipName     = "AtomicBombTV $verStr.zip"
                    DownloadUrl = "https://github.com/$repoSlug/archive/refs/heads/main.zip"
                    PageUrl     = "https://github.com/$repoSlug"
                    Notes       = ""
                })
            }
        }
    }

    if ($candidates.Count -eq 0) {
        Write-Host ("  [i] No se pudo verificar actualizaciones remotas. Continuando con Estable {0}." -f $script:LocalVersion) -ForegroundColor DarkGray
        Write-Host ""
        return
    }
    $best = $candidates | Sort-Object VerObj -Descending | Select-Object -First 1
    if (-not $best -or $best.VerObj -le $localVerObj) {
        Write-Host ("  [OK] Tienes la ultima version disponible: AtomicBombTV Estable {0}" -f $script:LocalVersion) -ForegroundColor Green
        Write-Host ""
        return
    }

    $novedadesTxt = Get-RemoteNovedadesTxt $repoSlug
    $notesRaw = if (-not [string]::IsNullOrWhiteSpace($novedadesTxt)) { $novedadesTxt } else { [string]$best.Notes }
    if ([string]::IsNullOrWhiteSpace($notesRaw)) {
        $noteCand = $candidates | Where-Object { $_.VerObj -eq $best.VerObj -and -not [string]::IsNullOrWhiteSpace($_.Notes) } | Select-Object -First 1
        if ($noteCand) { $notesRaw = [string]$noteCand.Notes }
    }
    $summaryNotes = ConvertTo-SummarizedReleaseNotes $notesRaw

    Write-Host "  +--------------------------------------------------------------+" -ForegroundColor Red
    Write-Host ("  |  NUEVA VERSION DISPONIBLE: AtomicBombTV {0,-21}|" -f $best.VerStr) -ForegroundColor Yellow
    Write-Host "  +--------------------------------------------------------------+" -ForegroundColor Red
    Write-Host ("  [!] Tu version actual (Estable {0}) ha quedado obsoleta." -f $script:LocalVersion) -ForegroundColor White
    Write-Host "  [!] Es obligatorio descargar la nueva version para continuar." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  Novedades mas relevantes:" -ForegroundColor Cyan
    foreach ($nl in $summaryNotes) {
        Write-Host ("    * {0}" -f $nl) -ForegroundColor Gray
    }
    Write-Host ""
    Write-Host "  >> Nueva version disponible. Presiona ENTER para descargarla..." -NoNewline -ForegroundColor Green

    if ([Console]::IsInputRedirected) {
        [void][Console]::In.ReadLine()
        Write-Host ""
    } else {
        while ($true) {
            $k = [Console]::ReadKey($true)
            if ($k.Key -eq 'Enter') {
                Write-Host ""
                break
            }
        }
    }

    $dlDir = Join-Path $env:USERPROFILE "Downloads"
    if (-not (Test-Path $dlDir)) { $dlDir = [Environment]::GetFolderPath('Desktop') }
    $safeZipName = ($best.ZipName -replace '[\\/:*?"<>|]', '_')
    if (-not $safeZipName.ToLowerInvariant().EndsWith('.zip')) { $safeZipName += ".zip" }
    $destZip = Join-Path $dlDir $safeZipName

    Write-Host ("  [+] Descargando {0}..." -f $safeZipName) -ForegroundColor Cyan
    $downloadedOk = $false
    try {
        Invoke-WebRequest -Uri $best.DownloadUrl -OutFile $destZip -UserAgent "AtomicBombTV-Updater" -UseBasicParsing -TimeoutSec 45 -ErrorAction Stop
        if (Test-Path $destZip) {
            $fi = Get-Item $destZip
            if ($fi.Length -ge 10240) {
                $fs = [System.IO.File]::OpenRead($destZip)
                $b0 = $fs.ReadByte(); $b1 = $fs.ReadByte(); $fs.Close()
                if ($b0 -eq 0x50 -and $b1 -eq 0x4B) { $downloadedOk = $true }
            }
        }
    } catch {}

    if ($downloadedOk) {
        Write-Host ("  [OK] Descarga guardada en: {0}" -f $destZip) -ForegroundColor Green
        Write-Host "  [i] Descomprime el nuevo archivo para usar la ultima version." -ForegroundColor Gray
        try { Start-Process explorer.exe -ArgumentList "/select,`"$destZip`"" } catch {}
    } else {
        if (Test-Path $destZip) { Remove-Item $destZip -Force -ErrorAction SilentlyContinue }
        Write-Host "  [!] Abriendo enlace de descarga directa en el navegador..." -ForegroundColor Yellow
        try { Start-Process $best.DownloadUrl } catch { try { Start-Process $best.PageUrl } catch {} }
    }
    Start-Sleep -Milliseconds 1800
    exit 0
}

Invoke-MandatoryUpdateCheck

function Get-ActiveVpnConnection {
    <# Detecta cualquier VPN de internet activa en Windows evitando falsos positivos de redes LAN virtuales. #>
    $ignoreDesc = '(?i)Radmin|Hamachi|ZeroTier|Tailscale|Hyper-V|VirtualBox|VMware|KM-TEST|Loopback|Bluetooth|Wi-Fi Direct'
    $vpnPattern = '(?i)Proton|WireGuard|Wintun|OpenVPN|TAP-Windows|NordLynx|NordVPN|Surfshark|Mullvad|ExpressVPN|CyberGhost|UrbanVPN|Windscribe|Private\s*Internet|\bPIA\b|HideMyAss|TunnelBear|Hotspot\s*Shield|Cisco\s*AnyConnect|Fortinet|Pulse\s*Secure|GlobalProtect|Cloudflare\s*WARP|WAN\s*Miniport.*(?:IKEv2|L2TP|PPTP|SSTP)|\bVPN\b|\bTun\b|\bTunnel\b'
    try {
        $adapter = Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object {
            $_.Status -eq 'Up' -and
            $_.Name -notmatch $ignoreDesc -and
            $_.InterfaceDescription -notmatch $ignoreDesc -and
            ($_.Name -match $vpnPattern -or $_.InterfaceDescription -match $vpnPattern)
        } | Select-Object -First 1
        if ($adapter) {
            return [PSCustomObject]@{ Connected = $true; AdapterName = [string]$adapter.Name; Description = [string]$adapter.InterfaceDescription }
        }
    } catch {}
    try {
        $ras = Get-VpnConnection -ErrorAction SilentlyContinue | Where-Object { $_.ConnectionStatus -eq 'Connected' } | Select-Object -First 1
        if ($ras) {
            return [PSCustomObject]@{ Connected = $true; AdapterName = [string]$ras.Name; Description = 'Windows VPN (RAS)' }
        }
    } catch {}
    return [PSCustomObject]@{ Connected = $false; AdapterName = ''; Description = '' }
}

function Read-InteractiveKeyNonBlocking {
    if ([Console]::IsInputRedirected) { return $null }
    try {
        if ([Console]::KeyAvailable) { return [Console]::ReadKey($true) }
    } catch {}
    return $null
}

function Wait-VpnConnectAtStart {
    $vpnNow = Get-ActiveVpnConnection
    if ($vpnNow.Connected) {
        Write-Host ("  [+] VPN detectada ({0}) -> Analizando todos los canales (con y sin VPN)..." -f $vpnNow.AdapterName) -ForegroundColor Green
        Write-Host ""
        return $true
    }
    Write-Host "  +--------------------------------------------------------------+" -ForegroundColor DarkCyan
    Write-Host "  |  [CONEXION VPN RECOMENDADA] ANALISIS COMPLETO DE CANALES     |" -ForegroundColor Cyan
    Write-Host "  +--------------------------------------------------------------+" -ForegroundColor DarkCyan
    Write-Host "  [!] No se detecta ninguna VPN conectada. (Recomendado: Paises Bajos)" -ForegroundColor Yellow
    Write-Host "  [>] Conectate a una VPN en tu ordenador para analizar TODOS los" -ForegroundColor White
    Write-Host "      canales disponibles." -ForegroundColor White
    Write-Host "  [!] AVISO: Si analizas sin VPN, NO se mostraran todos los" -ForegroundColor DarkYellow
    Write-Host "      canales ni servidores exclusivos de VPN (M+ LaLiga, DAZN, F1, Agendas)." -ForegroundColor DarkYellow
    Write-Host ""
    Write-Host "  >> Esperando conexion VPN automaticamente en tu app VPN..." -ForegroundColor Cyan
    Write-Host "     [" -NoNewline -ForegroundColor Gray
    Write-Host "S / ENTER" -NoNewline -ForegroundColor Green
    Write-Host " = Seguir esperando VPN | " -NoNewline -ForegroundColor Gray
    Write-Host "N" -NoNewline -ForegroundColor Magenta
    Write-Host " = Analizar solo canales sin VPN]: " -NoNewline -ForegroundColor Gray
    if ([Console]::IsInputRedirected) {
        $ans = [Console]::In.ReadLine()
        if ($ans -match '^(?i)n(?:o)?$') {
            Write-Host "`n  [!] Analizando solo canales sin VPN..." -ForegroundColor Yellow
            Write-Host ""
            return $false
        }
        return (Get-ActiveVpnConnection).Connected
    }
    $waitingPrinted = $false
    while ($true) {
        Start-Sleep -Milliseconds 350
        $chk = Get-ActiveVpnConnection
        if ($chk.Connected) {
            Write-Host ("`n  [+] VPN detectada ({0}). Estabilizando red e iniciando analisis completo..." -f $chk.AdapterName) -ForegroundColor Green
            Start-Sleep -Milliseconds 1200
            Write-Host ""
            return $true
        }
        $k = Read-InteractiveKeyNonBlocking
        if ($k) {
            if ($k.KeyChar -match '^(?i)n$') {
                Write-Host "N"
                Write-Host "`n  [!] Omitiendo VPN: analizando solamente canales sin VPN..." -ForegroundColor Yellow
                Write-Host ""
                return $false
            }
            if ($k.Key -eq 'Enter' -or $k.KeyChar -match '^(?i)s$') {
                if (-not $waitingPrinted) {
                    Write-Host "S"
                    Write-Host "  [i] Esperando conexion VPN (Paises Bajos recomendado)... [Pulsa 'N' para continuar sin VPN]" -ForegroundColor Cyan
                    $waitingPrinted = $true
                }
            }
        }
    }
}

# Flujo unificado en una sola pasada: pide VPN al principio si no esta conectada y analiza todo junto
if ([string]::IsNullOrWhiteSpace($ModoVpn)) {
    $esModoVpn = Wait-VpnConnectAtStart
} else {
    $esModoVpn = ($ModoVpn -match '^(?i)s(?:i|í)?$')
    if ($esModoVpn) {
        Write-Host "`n  [+] Modo Completo CON VPN activado: Analizando todos los canales disponibles..." -ForegroundColor Green
    } else {
        Write-Host "`n  [+] Modo Estricto SIN VPN activado: Sincronizando SOLAMENTE canales abiertos..." -ForegroundColor Cyan
    }
    Write-Host ""
}

function Confirm-AceStreamScanAtStart {
    Write-Host "  +--------------------------------------------------------------+" -ForegroundColor DarkMagenta
    Write-Host "  |  [ACE STREAM P2P] BUSQUEDA DE CANALES P2P (SOLO PC)          |" -ForegroundColor Magenta
    Write-Host "  +--------------------------------------------------------------+" -ForegroundColor DarkMagenta
    Write-Host "  [i] Consulta y busca la mayor cantidad de canales P2P en calidad superior mediante la API de AtomicBombTV" -ForegroundColor Gray
    Write-Host "  >> ¿Quieres buscar y añadir canales P2P? (Necesario instalar y tener ejecutado AceStream)" -ForegroundColor Cyan
    Write-Host "     [" -NoNewline -ForegroundColor Gray
    Write-Host "S" -NoNewline -ForegroundColor Green
    Write-Host " = Si (buscar más canales | " -NoNewline -ForegroundColor Gray
    Write-Host "N" -NoNewline -ForegroundColor Yellow
    Write-Host " = No (solo canales servidores HLS)]: " -NoNewline -ForegroundColor Gray

    if ([Console]::IsInputRedirected) {
        $ans = [Console]::In.ReadLine()
        if ($ans -match '^(?i)s(?:i|í)?$') {
            Write-Host "`n  [+] Busqueda AceStream activada" -ForegroundColor Magenta
            Write-Host ""
            return $true
        }
        Write-Host "`n  [i] AceStream omitido (N): consultando solo los canales que ya tenemos." -ForegroundColor Yellow
        Write-Host ""
        return $false
    }

    while ($true) {
        $k = [Console]::ReadKey($true)
        if ($k.KeyChar -match '^(?i)s$') {
            Write-Host "S" -ForegroundColor Green
            Write-Host "  [+] Busqueda AceStream activada" -ForegroundColor Magenta
            Write-Host ""
            return $true
        }
        if ($k.KeyChar -match '^(?i)n$') {
            Write-Host "N" -ForegroundColor Yellow
            Write-Host "  [i] AceStream omitido (N): escaneando sin consultar AceStream (solo canales actuales)." -ForegroundColor Yellow
            Write-Host ""
            return $false
        }
    }
}

if ([string]::IsNullOrWhiteSpace($BuscarAce)) {
    $esBuscarAceStream = Confirm-AceStreamScanAtStart
} else {
    $esBuscarAceStream = ($BuscarAce -match '^(?i)s(?:i|í)?$')
    if ($esBuscarAceStream) {
        Write-Host "  [+] Busqueda AceStream activada (S): M+, MotoGP, Tenis, F1, DAZN..." -ForegroundColor Magenta
    } else {
        Write-Host "  [i] AceStream omitido (N): consultando solo los canales que ya tenemos." -ForegroundColor Yellow
    }
    Write-Host ""
}

function Get-HostKey([string]$url) {
    if ($url -match '^https?://([^/:]+)') { return $Matches[1].ToLower() }
    return ""
}

function Get-Utf8Content {
    param(
        [string]$Uri,
        [string]$Referer = $null,
        [int]$TimeoutSec = 3
    )
    if ([string]::IsNullOrWhiteSpace($Uri)) { return $null }
    return [AtomicFastHttp]::GetUtf8($Uri, $Referer, $null, $UserAgent, ([Math]::Max(800, $TimeoutSec * 1000)), $true)
}

function Test-HlsLive {
    param(
        [string]$Uri,
        [string]$Referer = $null,
        [int]$TimeoutSec = 3
    )
    $txt = [AtomicFastHttp]::GetUtf8($Uri, $Referer, $null, $UserAgent, ([Math]::Max(800, $TimeoutSec * 1000)), $true)
    return ($null -ne $txt -and ($txt -match '#EXTM3U' -or $txt -match '<MPD'))
}

function Test-HlsDeepLive {
    param(
        [string]$Uri,
        [string]$Referer = $null,
        [string]$Origin = "null",
        [int]$TimeoutSec = 3,
        [switch]$SkipBlockCache
    )
    return [AtomicFastHttp]::TestStreamDeepLive($Uri, $Referer, $Origin, $UserAgent, ([Math]::Max(800, $TimeoutSec * 1000)), [bool]$SkipBlockCache)
}

function Resolve-CapoCandyShop {
    param(
        [string]$IframeUrl,
        [string]$Referer = "https://cdplay.live/"
    )
    $targetUrl = $IframeUrl
    $innerReferer = $Referer

    # Soportar doble salto 104game.click/player/capo2/<N> -> sofayshop.st/hlsspanich.php?stream=H<N>
    if ($IframeUrl -match '104game\.click/player/capo2/(\d+)') {
        $capoNum = $Matches[1]
        $hopHtml = Get-Utf8Content -Uri $IframeUrl -Referer $Referer -TimeoutSec 4
        $innerReferer = $IframeUrl
        if ($hopHtml -and $hopHtml -match '(?:https?:)?//(sofayshop\.st/hlsspanich\.php\?stream=H\d+)') {
            $targetUrl = "https://" + $Matches[1]
        } else {
            $targetUrl = "https://sofayshop.st/hlsspanich.php?stream=H$capoNum"
        }
    }

    if ($targetUrl -match '^https?://[^/]+/(capopro\.php\?stream=CA\d+|livetvfx\.php\?stream=SSF\d+|hlsspanich\.php\?stream=H\d+)') {
        $targetUrl = "https://xstream.st/" + $Matches[1]
    }

    $extractCandyCandidates = {
        param([string]$BodyHtml)
        if ([string]::IsNullOrWhiteSpace($BodyHtml)) { return @() }
        $c = @([regex]::Matches($BodyHtml, 'https://[^"''\\]+(?:index|master)\.(?:m3u8|mpd)[^\s"''<>\\]*') |
            ForEach-Object { $_.Value -replace '\\u0026', '&' -replace '\\/', '/' } |
            Select-Object -Unique)
        if (-not $c -or $c.Count -eq 0) {
            $c = @([regex]::Matches($BodyHtml, 'https?://[^\s"''<>\\]+\.(?:m3u8|mpd)[^\s"''<>\\]*') |
                ForEach-Object { $_.Value -replace '\\u0026', '&' -replace '\\/', '/' } |
                Select-Object -Unique)
        }
        return $c
    }

    $html = Get-Utf8Content -Uri $targetUrl -Referer $innerReferer -TimeoutSec 4
    $candidates = @(& $extractCandyCandidates $html)
    # Si el nodo origen (xstream.st o sofayshop.st) está bloqueado o devuelve stub sin manifiesto, espejar en el host alternativo
    if ((-not $candidates -or $candidates.Count -eq 0) -and $targetUrl -match '^https?://([^/]+)/(capopro\.php\?stream=CA\d+|livetvfx\.php\?stream=SSF\d+|hlsspanich\.php\?stream=H\d+)') {
        $altHost = if ($Matches[1] -ieq "xstream.st") { "sofayshop.st" } else { "xstream.st" }
        $mirrorUrl = "https://$altHost/" + $Matches[2]
        $htmlMirror = Get-Utf8Content -Uri $mirrorUrl -Referer $innerReferer -TimeoutSec 4
        $candidates = @(& $extractCandyCandidates $htmlMirror)
        if ($candidates -and $candidates.Count -gt 0) { $targetUrl = $mirrorUrl }
    }
    if (-not $candidates -or $candidates.Count -eq 0) { return $null }

    # Colapsar espejos del mismo cluster: mantener 1 /live/ + 1 /live3/ en CandyShop (preferir edge2) + respaldo alternativo
    $orderedAll = @($candidates | Sort-Object {
        if ($_ -match 'edge2\.candyshop\.st') { 0 }
        elseif ($_ -match 'candyshop\.st') { 1 }
        elseif ($_ -match 'instreams\.') { 2 }
        elseif ($_ -match 'gate4\.st') { 3 }
        else { 4 }
    })
    $candyLive1 = $orderedAll | Where-Object { $_ -match 'candyshop\.st.*/live/' } | Select-Object -First 1
    $candyLive3 = $orderedAll | Where-Object { $_ -match 'candyshop\.st.*/live3/' } | Select-Object -First 1
    $candyAny = if (-not $candyLive1 -and -not $candyLive3) { $orderedAll | Where-Object { $_ -match 'candyshop\.st' } | Select-Object -First 1 } else { $null }
    $altCdns = @($orderedAll | Where-Object { $_ -notmatch 'candyshop\.st' } | Select-Object -First 2)
    $fastCands = @(@($candyLive1, $candyLive3, $candyAny) + $altCdns | Where-Object { $_ } | Select-Object -Unique | Select-Object -First 5)

    foreach ($cand in $fastCands) {
        if (Test-HlsDeepLive -Uri $cand -Referer $targetUrl -TimeoutSec 3 -SkipBlockCache) {
            return $cand
        }
    }
    return $null
}

function Resolve-RedxEsUrl {
    param(
        [string]$StreamSlug
    )
    if ([string]::IsNullOrWhiteSpace($StreamSlug)) { return $null }
    $map = @{
        "dazn1"      = "http://45.134.141.161:2200/ARG/DAZN_1_HD/index.m3u8"
        "eurosport1" = "http://45.134.141.161:2200/ARG/Eurosport_1_HD/index.m3u8"
        "eurosport2" = "http://45.134.141.161:2200/ARG/Eurosport_2_HD/index.m3u8"
        "mlaliga"    = "http://45.134.141.161:2200/ARG/Movistar_La_Liga_HD/index.m3u8"
        "mdeportes"  = "http://45.134.141.161:2200/ARG/Movistar_Deportes/index.m3u8"
        "mgolf"      = "http://45.134.141.161:2200/ARG/Movistar_Golf_HD/index.m3u8"
        "daznf1"     = "http://45.134.141.161:2200/ARG/Formula_1_HD/index.m3u8"
        "natgeowild" = "http://45.134.141.161:2200/ARG/Nat_Geo_Wild_HD/index.m3u8"
    }
    $k = $StreamSlug.ToLowerInvariant().Trim()
    if (-not $map.ContainsKey($k)) { return $null }
    $u = $map[$k]
    if (Test-HlsDeepLive -Uri $u -TimeoutSec 3) {
        return $u
    }
    return $null
}

function Resolve-Tvf90Url {
    param(
        [string]$StreamSlug,
        [string]$Referer = "https://tvf90.com/"
    )
    if ([string]::IsNullOrWhiteSpace($StreamSlug)) { return $null }
    $html = Get-Utf8Content -Uri ("https://tvf90.com/5.php?stream=" + $StreamSlug) -Referer $Referer -TimeoutSec 4
    if ($html) {
        $m3u = Get-ExtractedManifestFromHtml -Html $html
        if ($m3u -and (Test-HlsDeepLive -Uri $m3u -Referer "https://tvf90.com/" -TimeoutSec 4 -SkipBlockCache)) {
            return $m3u
        }
    }
    return $null
}

function Resolve-StreamxNodeUrl {
    param(
        [string]$ChannelSlug,
        [string]$HostDomain = $null,
        [string]$Referer = "https://cdplay.live/"
    )
    if ([string]::IsNullOrWhiteSpace($ChannelSlug)) { return $null }
    if (-not $HostDomain) { $HostDomain = $global:ActiveStreamxHost }
    $hostsToTry = @($HostDomain, "streamx723.sbs", "streamx061.sbs") | Where-Object { $_ } | Select-Object -Unique
    foreach ($h in $hostsToTry) {
        if ($global:BlockedHosts -and $global:BlockedHosts.ContainsKey($h)) { continue }
        $wrapUrl = "https://$h/global3.php?channel=$ChannelSlug"
        $wrapBody = Get-Utf8Content -Uri $wrapUrl -Referer $Referer -TimeoutSec 4
        if ($wrapBody -and $wrapBody -match '"src"\s*:\s*"([^"]+)"') {
            $m3uProbe = $Matches[1] -replace '\\/', '/' -replace '\\u0026', '&'
            if (Test-HlsDeepLive -Uri $m3uProbe -Referer $wrapUrl -TimeoutSec 4 -SkipBlockCache) {
                $global:ActiveStreamxHost = $h
                return $m3uProbe
            }
        }
    }
    return $null
}

function Resolve-StreamXhdUrl {
    param(
        [string]$LivePageUrl,
        [string]$Referer = "https://streamxhd.click/"
    )
    $html = Get-Utf8Content -Uri $LivePageUrl -Referer $Referer -TimeoutSec 4
    if (-not $html) { return $null }

    $i = $html.IndexOf("var playbackURL")
    if ($i -lt 0) { return $null }
    $j = $html.IndexOf("var adsPayload", $i)
    if ($j -lt 0) { $j = $html.IndexOf("var reloadDelay", $i) }
    if ($j -lt 0) { return $null }

    $blk = $html.Substring($i, $j - $i)
    $sa = $blk.IndexOf("[[")
    $ea = $blk.IndexOf("]];", $sa)
    if ($sa -lt 0 -or $ea -le $sa) { return $null }

    # Conservar corchetes externos de elementos 0 y N-1 para decodificacion integra de los 142+ caracteres
    $arrStr = $blk.Substring($sa + 1, $ea - $sa)
    $mK = [regex]::Match($blk.Substring($ea), 'function\s+[a-zA-Z0-9_]+\(\)\{return\s+(\d+);\}\s*function\s+[a-zA-Z0-9_]+\(\)\{return\s+(\d+);\}')
    if (-not $mK.Success) { return $null }

    $k = [int]$mK.Groups[1].Value + [int]$mK.Groups[2].Value
    $elems = $arrStr -split '(?<=\]),(?=\[)'
    $chars = foreach ($el in $elems) {
        if ($el -match '^\[(\d+),"([^"]+)"\]$') {
            try {
                $rawDec = [System.Text.Encoding]::ASCII.GetString([Convert]::FromBase64String($Matches[2]))
                $numOnly = $rawDec -replace '\D', ''
                if ($numOnly) {
                    [PSCustomObject]@{ idx = [int]$Matches[1]; ch = [char]([int]$numOnly - $k) }
                }
            } catch {}
        }
    }
    $decoded = (($chars | Sort-Object idx).ch -join '')
    if ($decoded -match '^https?://.*\.m3u8') {
        if (Test-HlsDeepLive -Uri $decoded -Referer $LivePageUrl -TimeoutSec 4 -SkipBlockCache) {
            return $decoded
        }
    }
    return $null
}

function Resolve-EmbdlolWatchUrl {
    param([string]$WatchId)
    if ([string]::IsNullOrWhiteSpace($WatchId)) { return $null }
    try {
        $watchBody = '{"watchId":"' + $WatchId + '"}'
        $wResp = Invoke-RestMethod -Uri "https://api.embdlol.st/watch" -Method POST -Body $watchBody -ContentType "application/json" -TimeoutSec 4 -ErrorAction Stop
        if ($wResp -and $wResp.url) {
            if (Test-HlsDeepLive -Uri $wResp.url -Referer "https://embdlol.st/" -Origin "https://embdlol.st" -TimeoutSec 4 -SkipBlockCache) {
                return $wResp.url
            }
        }
    } catch {}
    return $null
}

function Decode-EhgembxeM3u8 {
    param([string]$Html)
    if ([string]::IsNullOrWhiteSpace($Html)) { return $null }
    try {
        $matchesAll = [regex]::Matches($Html, '\[\s*(\d+(?:\s*,\s*\d+){15,})\s*\][\s\S]{0,220}?(?:var|let|const)?\s*[a-zA-Z_$][\w$]*\s*=\s*(\d+)\s*[,;]\s*(?:var|let|const)?\s*[a-zA-Z_$][\w$]*\s*=\s*(\d+)')
        foreach ($m in $matchesAll) {
            $parts = $m.Groups[1].Value -split ','
            $x = [int]$m.Groups[2].Value
            $y = [int]$m.Groups[3].Value
            $sb = [System.Text.StringBuilder]::new($parts.Length)
            $ok = $true
            foreach ($p in $parts) {
                $val = [int]($p.Trim())
                $ch = (($val -bxor $x) - $y + 256) % 256
                if ($ch -lt 32 -or $ch -gt 126) { $ok = $false; break }
                [void]$sb.Append([char]$ch)
            }
            if ($ok) {
                $cand = $sb.ToString().Trim()
                if ($cand -match '^https?://' -and ($cand -match '\.m3u8' -or $cand -match '\.mpd')) {
                    return $cand
                }
            }
        }
    } catch {}
    return $null
}

function Decode-CharCodeUrls {
    param([string]$Html)
    if ([string]::IsNullOrWhiteSpace($Html)) { return $null }
    try {
        $matchesAll = [regex]::Matches($Html, 'String\.fromCharCode\(\s*(\d+(?:\s*,\s*\d+){12,})\s*\)')
        foreach ($m in $matchesAll) {
            $parts = $m.Groups[1].Value -split ','
            $sb = [System.Text.StringBuilder]::new($parts.Length)
            foreach ($p in $parts) {
                $c = [int]($p.Trim())
                if ($c -ge 32 -and $c -le 126) { [void]$sb.Append([char]$c) }
            }
            $cand = $sb.ToString().Trim()
            if ($cand -match '^https?://' -and ($cand -match '\.m3u8' -or $cand -match '\.mpd' -or $cand -match '/hls/')) {
                return $cand
            }
        }
    } catch {}
    return $null
}

function Get-ExtractedManifestFromHtml {
    param([string]$Html)
    if ([string]::IsNullOrWhiteSpace($Html)) { return $null }
    $d1 = Decode-EhgembxeM3u8 -Html $Html
    if ($d1) { return $d1 }
    $d2 = Decode-CharCodeUrls -Html $Html
    if ($d2) { return $d2 }

    $cands = [System.Collections.Generic.List[string]]::new()
    foreach ($mp in [regex]::Matches($Html, '(https?://[^\s"''<>\\]+\.(?:m3u8|mpd)[^\s"''<>\\]*)')) {
        $u = $mp.Groups[1].Value -replace '\\u0026', '&' -replace '\\/', '/'
        if (-not $cands.Contains($u)) { $cands.Add($u) }
    }
    foreach ($me in [regex]::Matches($Html, '(https?:\\/\\/[^\s"''<>]+\.(?:m3u8|mpd)[^\s"''<>]*)')) {
        $u = $me.Groups[1].Value -replace '\\/', '/' -replace '\\u0026', '&'
        if (-not $cands.Contains($u)) { $cands.Add($u) }
    }
    foreach ($mab in [regex]::Matches($Html, 'atob\(\s*["'']([A-Za-z0-9+/=]{20,})["'']\s*\)')) {
        try {
            $raw = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($mab.Groups[1].Value)).Trim()
            if ($raw -match '^https?://' -and ($raw -match '\.m3u8' -or $raw -match '\.mpd') -and -not $cands.Contains($raw)) {
                $cands.Add($raw)
            }
        } catch {}
    }
    foreach ($c in $cands) {
        if ($c -match '(?i)azplay|formaturamaxi|candyshop') { return $c }
    }
    if ($cands.Count -gt 0) { return $cands[0] }
    return $null
}

function Resolve-EmbedAnyUrl {
    param(
        [string]$Url,
        [string]$Referer = "https://cdplay.live/",
        [int]$Depth = 0
    )
    if ([string]::IsNullOrWhiteSpace($Url) -or $Depth -gt 3) { return $null }
    if ($Url -match 'challenges\.cloudflare\.com') { return $null }
    if ($Url -match '\.(?:m3u8|mpd)(?:\?|$)') {
        if (Test-HlsDeepLive -Uri $Url -Referer $Referer -TimeoutSec 4 -SkipBlockCache) { return $Url }
        return $null
    }
    if ($Url -match 'embdlol\.st/embed/([a-zA-Z0-9-]+)') {
        return (Resolve-EmbdlolWatchUrl -WatchId $Matches[1])
    }
    if ($Url -match '104game\.click/player/capo2/\d+|capopro\.php\?stream=|livetvfx\.php\?stream=|hlsspanich\.php\?stream=|xstream\.st/|sofayshop\.st/') {
        return (Resolve-CapoCandyShop -IframeUrl $Url -Referer $Referer)
    }
    if ($Url -match 'streamxhd\.click/live\d*\.php\?stream=') {
        return (Resolve-StreamXhdUrl -LivePageUrl $Url -Referer $Referer)
    }
    if ($Url -match 'streamxhd\.click/channel/\?id=([^&\s]+)') {
        return (Resolve-StreamXhdUrl -LivePageUrl ("https://streamxhd.click/live1.php?stream=" + $Matches[1]) -Referer $Referer)
    }
    if ($Url -match 'streamx[a-z0-9]+\.sbs/global[13]\.php\?channel=([^&\s]+)') {
        $chSlug = $Matches[1]
        $res = Resolve-StreamxNodeUrl -ChannelSlug $chSlug -Referer $Referer
        if (-not $res) {
            $res = Resolve-StreamXhdUrl -LivePageUrl "https://streamxhd.click/live1.php?stream=$chSlug" -Referer $Referer
        }
        if (-not $res) {
            $res = Resolve-Tvf90Url -StreamSlug $chSlug -Referer $Referer
        }
        return $res
    }
    if ($Url -match 'tvf90\.com/(?:[a-z0-9_-]+\.php|online/canal\.php)\?stream=([^&\s]+)') {
        $tvfSlug = $Matches[1]
        $resT = Resolve-Tvf90Url -StreamSlug $tvfSlug -Referer $Referer
        if (-not $resT) {
            $resT = Resolve-StreamXhdUrl -LivePageUrl "https://streamxhd.click/live1.php?stream=$tvfSlug" -Referer $Referer
        }
        return $resT
    }

    $baseRef = if ($Referer) { $Referer } elseif ($Url -match '^(https?://[^/]+/)') { $Matches[1] } else { "https://cdplay.live/" }
    $emHtml = Get-Utf8Content -Uri $Url -Referer $baseRef -TimeoutSec 5
    if (-not [string]::IsNullOrWhiteSpace($emHtml)) {
        $dirM3u = Get-ExtractedManifestFromHtml -Html $emHtml
        if ($dirM3u) {
            if (Test-HlsDeepLive -Uri $dirM3u -Referer $Url -TimeoutSec 4 -SkipBlockCache) { return $dirM3u }
        }
        $ifrMatches = [regex]::Matches($emHtml, '<iframe[^>]+src=["'']([^"'']+)["'']', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
        $tried = 0
        foreach ($im in $ifrMatches) {
            $subSrc = $im.Groups[1].Value.Trim()
            if ([string]::IsNullOrWhiteSpace($subSrc) -or $subSrc -match '^(?i)(?:about:|javascript:|data:)' -or $subSrc -match '(?i)challenges\.cloudflare\.com|googlesyndication|doubleclick') { continue }
            $absSub = $subSrc
            if ($subSrc -notmatch '^https?://') {
                try { $absSub = ([Uri]::new([Uri]::new($Url), $subSrc)).AbsoluteUri } catch {}
            }
            $tried++
            $subRes = Resolve-EmbedAnyUrl -Url $absSub -Referer $Url -Depth ($Depth + 1)
            if ($subRes) { return $subRes }
            if ($tried -ge 4) { break }
        }
    }
    return $null
}

function Translate-ToSpanish($name) {
    if ([string]::IsNullOrWhiteSpace($name)) { return "" }
    $t = ($name -replace '\s+', ' ').Trim()

    # Detección y normalización precisa de canales españoles de deportes, TDT y motor
    if ($t -match '(?i)^formula\s*1(?:\s*hd)?$') { return "DAZN F1 España" }
    if ($t -match '(?i)^motogp(?:\s*hd)?$') { return "DAZN MotoGP España HD" }
    if ($t -match '(?i)^dazn\s*f1(?:\s*hd)?$') { return "DAZN F1 España" }
    if ($t -match '(?i)^dazn\s*motogp(?:\s*hd)?$') { return "DAZN MotoGP España HD" }
    if ($t -match '(?i)^dazn\s*([1-4])(?:\s*es|\s*espa[ñn]a)?(?:\s*hd)?$') { return "DAZN $($Matches[1]) España HD" }
    if ($t -match '(?i)^(?:movistar\+?|m\+)\s*deportes(?:\s*(\d+))?(?:\s*hd)?$') {
        $num = if ($Matches[1]) { " $($Matches[1])" } else { "" }
        return "Movistar+ Deportes$num España HD"
    }
    if ($t -match '(?i)^(?:movistar\+?|m\+|#)\s*vamos(?:\s*hd)?$') { return "Movistar+ Vamos España HD" }
    if ($t -match '(?i)^(?:movistar\+?|m\+)\s*golf(?:\s*hd)?$') { return "Movistar+ Golf España HD" }
    if ($t -match '(?i)^(?:movistar\+?|m\+)\s*laliga(?:\s*(\d+))?(?:\s*hd)?$') {
        $num = if ($Matches[1]) { " $($Matches[1])" } else { "" }
        return "M+ LaLiga$num España HD"
    }
    if ($t -match '(?i)^dazn\s*laliga(?:\s*(\d+))?(?:\s*hd)?$') {
        $num = if ($Matches[1]) { " $($Matches[1])" } else { "" }
        return "DAZN LaLiga$num España HD"
    }
    if ($t -match '(?i)^(?:movistar\+?|m\+)\s*(?:liga\s*de\s*campeones|champions)(?:\s*(\d+))?(?:\s*hd)?$') {
        $num = if ($Matches[1]) { " $($Matches[1])" } else { "" }
        return "M+ Liga de Campeones$num España HD"
    }
    if ($t -match '(?i)^eurosport\s*([12])\s*(?:es|esp|espa[ñn]a|spanish)(?:\s*hd)?$') { return "Eurosport $($Matches[1]) España HD" }
    if ($t -match '(?i)^gol\s*(?:play|tv)(?:\s*es|\s*espa[ñn]a)?$') { return "Gol Play España (TDT)" }
    if ($t -match '(?i)^teledeporte(?:\s*hd|\s*uhd)?$') { return "Teledeporte RTVE UHD / HD" }
    if ($t -match '(?i)^la\s*1(?:\s*uhd|\s*hd)?$') { return "RTVE La 1 UHD / HD" }
    if ($t -match '(?i)^la\s*2(?:\s*hd|\s*uhd)?$') { return "RTVE La 2 UHD / HD" }
    if ($t -match '(?i)^(?:canal\s*)?24\s*h(?:oras)?(?:\s*hd)?$') { return "RTVE Canal 24 Horas HD" }
    if ($t -match '(?i)^capo\s*deportes$') { return "Capo Deportes HD (España / Deportes)" }
    if ($t -match '(?i)^capo\s*deportes\s*2') { return "Capo Deportes 2 HD (Eventos En Vivo)" }
    if ($t -match '(?i)^spanish$') { return "DAZN F1 España" }

    $t = $t -replace '(?i)\bF1\s*-\s*Interlagos.*DAZN\b', 'DAZN F1 España'
    $t = $t -replace '(?i)\bMoto\d*/\d*/GP\s*-\s*Lusail.*DAZN\b', 'DAZN MotoGP España HD'
    $t = $t -replace '(?i)\b(\d+)\s*Hours of\b', '$1 Horas de'
    $t = $t -replace '(?i)\bHours of\b', 'Horas de'
    $t = $t -replace '(?i)\bSprint Shootout\b', 'Clasificación Sprint'
    $t = $t -replace '(?i)\bSprint Race\b', 'Carrera Sprint'
    $t = $t -replace '(?i)\bRace\b', 'Carrera'
    $t = $t -replace '(?i)\bQualifying\b', 'Clasificación'
    $t = $t -replace '(?i)\bPractice\b', 'Entrenamientos Libres'
    $t = $t -replace '(?i)\bSunday\b', 'Domingo'
    $t = $t -replace '(?i)\bSaturday\b', 'Sábado'
    $t = $t -replace '(?i)\bFriday\b', 'Viernes'
    $t = $t -replace '(?i)\bWorld\b', 'Internacional'
    $t = $t -replace '(?i)\bDrivers track\b', 'Cámara de Pilotos (Onboard)'
    $t = $t -replace '(?i)\bData Channel\b', 'Canal de Datos y Telemetría'
    $t = $t -replace '(?i)\bPit Lane\b', 'Calle de Boxes (Pitlane)'
    $t = $t -replace '(?i)\bWarmup\b', 'Calentamiento'
    $t = $t -replace '(?i)\bPre-Race\b', 'Previo de Carrera'
    $t = $t -replace '(?i)\bPost-Race\b', 'Post Carrera'
    $t = $t -replace '(?i)\bMulti Lang\b', 'Multi Idioma'
    $t = $t -replace '(?i)\bFC Cologne\b', 'FC Colonia'
    $t = $t -replace '(?i)\bSpanish\b', 'Español'
    $t = $t -replace '(?i)\bItalian\b', 'Italiano'
    $t = $t -replace '(?i)\bGerman\b', 'Alemán'
    $t = $t -replace '(?i)\bFrench\b', 'Francés'
    $t = $t -replace '(?i)\bEnglish\b', 'Inglés'
    $t = $t -replace '(?i)\bHighlights\b', 'Resumen'
    $t = $t -replace '(?i)\bQuarterfinals?\b', 'Cuartos de Final'
    $t = $t -replace '(?i)\bSemifinals?\b', 'Semifinales'
    $t = $t -replace '(?i)\bRound of 16\b', 'Octavos de Final'
    $t = $t -replace "(?i)\bMen'?s Singles\b", 'Individual Masculino'
    $t = $t -replace "(?i)\bWomen'?s Singles\b", 'Individual Femenino'
    $t = $t -replace '(?i)\bMixed Doubles\b', 'Dobles Mixtos'
    $t = $t -replace '(?i)\bDoubles\b', 'Dobles'
    $t = $t -replace '(?i)\s+at\s+', ' vs '
    $t = $t -replace '(?i)\s+v\s+', ' vs '
    $t = $t -replace '<[^>]+>', ''
    return $t.Trim()
}

function Get-ChannelGroup($name, $sourceHint = "") {
    # 1. F1 España (DAZN F1 España y señales de Fórmula 1 en español)
    if ($sourceHint -eq 'IPTV_F1_ES' -or $name -match '(?i)DAZN\s*F1|Formula\s*1.*Espa[ñn]|F1.*Espa[ñn]|F1.*DAZN|Movistar.*F1|Carrera.*DAZN|Race.*DAZN|GP\s*(?:de\s*)?Espa[ñn]a.*F1|F1.*GP\s*(?:de\s*)?Espa[ñn]a') {
        return 'F1 España'
    }
    # 2. MotoGP España (DAZN MotoGP España y señales de MotoGP en español)
    if ($name -match '(?i)DAZN\s*MotoGP|Moto\s*GP.*Espa[ñn]|Moto\s*GP.*DAZN|Moto[23].*DAZN|Moto[23].*Espa[ñn]|Movistar.*MotoGP|GP\s*(?:de\s*)?Espa[ñn]a.*Moto|GP\s*(?:de\s*)?(?:Jerez|Catalu[ñn]a|Arag[oó]n|Valencia).*Moto') {
        return 'MotoGP España'
    }
    # 3. Canales deportivos españoles TV específicos (antes de clubes para evitar colisiones como Real Madrid TV)
    if ($name -match '(?i)Real\s*Madrid\s*TV|Bar[çc]a\s*TV') {
        return 'Deportes España'
    }
    # 3b. Pistas explicitas de IPTV Lineal (Cine/Cultura/Infantil-Musica) antes de TDT/Clubes
    if ($sourceHint -eq 'IPTV_CINE') { return 'Cine y Series España' }
    if ($sourceHint -eq 'IPTV_CULTURA') { return 'Documentales y Cultura España' }
    if ($sourceHint -eq 'IPTV_INFANTIL_MUSICA') { return 'Infantil y Música España' }
    # 4. TDT España (solo emisoras lineales, evitando robar partidos "vs" que mencionen un canal como La 1 o Teledeporte)
    if ($name -notmatch '(?i)\bvs\.?\b' -and ($sourceHint -eq 'IPTV_TDT' -or $name -match '(?i)RTVE|\bLa 1\b|\bLa 2\b|Teledeporte|24 Horas|Clan|\bTVE\b|Gol\s*Play|Antena\s*3|Cuatro|Telecinco|La\s*Sexta|LaSexta|Mega|Neox|Nova|\bBoing\b|Energy|Be\s*Mad|Atresplayer|Atreseries|A3Series|\bFDF\b|Factor[ií]a\s*de\s*Ficci[oó]n|\bDivinity\b|\bDKISS\b|^TEN(?:\s|$)|Squirrel(?:\s*2)?|La\s*S[eé]ptima|3\/?24(?:\s*CAT)?|Super\s*3|Bon\s*Dia|Onda\s*C[aá]diz|Teleonuba|Canal\s*Parlamento|7TV\s*[A-Z]|Hit\s*TV|Mitele|Telemadrid|LaOtra|La\s*Otra|DMAX|\bTRECE\b|El Toro TV|Negocios TV|Canal Sur|\bTV3\b|El 33|TV3CAT|[ÀA]\s*Punt|\bETB\s*[12]|\bTVG\b|Galicia TV|Arag[oó]n|IB3|\bTPA\b|CyLTV|7RM|Navarra TV|TeleValencia|\bCMM\b|Canal Extremadura|TV\s*Canaria|\bTDT\b|Sol\s*M[uú]sica|France\s*24\s*Espa')) {
        return 'TDT España'
    }
    # 5. Emisoras IPTV de Deportes España con nombre de evento variable (p. ej. DAZN Eventos con partidos NBA/internacionales)
    if ($name -match '(?i)^(?:DAZN\s*Eventos|LaLiga\+\s*Eventos?|FootballClub|2RFEF)\b') {
        if ($name -match '(?i)LaLiga\+|FootballClub|2RFEF') { return 'Fútbol España' }
        return 'Deportes España'
    }
    # 5b. Respetar pista explicita de Tenis, Baloncesto o NFL antes de comprobar clubes/países
    if ($sourceHint -match '(?i)^(?:Tennis|Tenis)$') { return 'Tenis' }
    if ($sourceHint -eq "Basketball") { return 'Baloncesto' }
    if ($sourceHint -eq "NFL") { return 'NFL' }
    # 5c. Tenis (ATP, WTA, Grand Slam, Tennis Channel, Masters 1000, Copa Davis y tenistas ATP/WTA)
    $isTennisName = ($name -notmatch '(?i)\b(?:F[oó]rmula\s*1|F1|MotoGP|LaLiga|Hypermotion|NBA|NFL|Baloncesto|Football|Darts|Snooker)\b') -and (
        $name -match '(?i)(?:Tennis\s*Channel|\bTenis\b|\bTennis\b|\bATP\b|\bWTA\b|Grand\s*Slam(?!\s*(?:of\s*)?Darts)|Roland\s*Garros|Wimbledon|Australian\s*Open|US\s*Open.*(?:Tennis|Tenis|ATP|WTA)|(?:Tennis|Tenis|ATP|WTA).*US\s*Open|Davis\s*Cup|Copa\s*Davis|Billie\s*Jean\s*King|Laver\s*Cup|United\s*Cup|Mutua\s*Madrid|Madrid\s*Open|Conde\s*de\s*God[oó]|Barcelona\s*Open|Indian\s*Wells|Miami\s*Open|Monte[- ]?Carlo|Rome\s*Open|Internazionali.*Roma|Cincinnati\s*Open|Shanghai\s*Masters|Paris\s*Masters|Masters\s*(?:de\s*)?Madrid|Masters\s*1000|Next\s*Gen\s*ATP)' -or
        $name -match '(?i)\b(?:Alcaraz|Sinner|Djokovic|Nadal|Zverev|Medvedev|Tsitsipas|Rublev|Fritz|Holger\s*Rune|Casper\s*Ruud|Hurkacz|Dimitrov|Draper|Musetti|De\s*Minaur|Shelton|Tiafoe|Fonseca|Arthur\s*Fils|Davidovich|Bautista\s*Agut|Munar|Sabalenka|Swiatek|Gauff|Paolini|Rybakina|Pegula|Badosa|Qinwen\s*Zheng|Zheng\s*Qinwen|Mirra\s*Andreeva|Raducanu|Osaka|Azarenka|Bucsa|Sorribes|Granollers|Zeballos)\b'
    )
    if ($isTennisName) {
        return 'Tenis'
    }
    if ($name -match '(?i)M\.?\+?\s*(?:La\s*Liga|Liga\s*(?:de\s*)?Campeones)|^Campeones\s*\d|Hypermotion|DAZN\s*La\s*Liga') {
        return 'Fútbol España'
    }
    if ($name -match '(?i)M\.?\+?\s*(?:Deportes?\b|Vamos|Golf|Ellas|Multideporte)|^#?Vamos\b|DAZN\s*[1-4]\b|DAZN\s*Baloncesto|M\.\s*Deportes|Movistar\s*Plus\+?') {
        return 'Deportes España'
    }
    if ($name -match '(?i)(?:M\.?\+?|Movistar)\s*(?:Estrenos|Acci[oó]n|Comedia|Drama|Originales|Cine\s*Espa[ñn]?ol?|Cl[aá]sicos?|Hits|Musicales|Pop\s*Up|Series|Terror|Indie|Romance)') {
        return 'Cine y Series España'
    }
    if ($name -match '(?i)(?:M\.?\+?|Movistar)\s*(?:Documentales|Cero)') {
        return 'Documentales y Cultura España'
    }
    # 6. Fútbol España (M+ LaLiga, DAZN LaLiga, Hypermotion, M+ Liga de Campeones, Selección y clubes españoles)
    if ($name -notmatch '(?i)Talleres\s+de\s+C[oó]rdoba|Am[eé]rica\s+de\s+Cali' -and $name -match '(?i)LaLiga|Movistar\s*LaLiga|M\+\s*LaLiga|MLaLiga|DAZN\s*LaLiga|DLaLiga|Hypermotion|M\+\s*Liga\s*(?:de\s*)?Campeones|MCampeones|Movistar.*Campeones|Primera\s*Federaci[oó]n|1ª\s*Federaci[oó]n|Segunda\s*Federaci[oó]n|2ª?\s*RFEF|FootballClub|FanPlay\s*TV|LaLiga\+|Top\s*Bar[çc]a\s*TV|Betis\s*TV|DAZN\s*Liga\s*F|Copa\s*del\s*Rey|Supercopa\s*de\s*Espa|Liga\s*F\b|\bRFEF\b|Selecci[oó]n\s*Espa[ñn]ola|\bEspa[ñn]a\b|\bSpain\b|Celta|Levante|Barcelona|Bar[çc]a|Real\s*Madrid|Atl[eé]tico(?:\s+de)?\s+Madrid|Atl[eé]tico\s+Baleares|Sevilla|Betis|Valencia|Girona|(?<!Wigan\s|Charlton\s|Oldham\s|Forfar\s|Dunfermline\s)Athletic|Villarreal|Real\s*Sociedad|Mallorca|Osasuna|Getafe|Espanyol|Alav[eé]s|Legan[eé]s|Valladolid|Las\s*Palmas|Rayo\s*Vallecano|Oviedo|Real\s*Sporting|Sporting\s*Gij|Zaragoza|Racing\s*Santander|Racing\s*Ferrol|Deportivo\s+(?:de\s+La\s+)?Coru[ñn]a|\bRC\s*Deportivo\b|M[aá]laga|C[aá]diz|Almer[ií]a|Granada|Elche|Tenerife|Sabadell|Eldense|Mirand[eé]s|Castell[oó]n|C[oó]rdoba|Burgos|Huesca|Eibar|Cartagena|Badalona|Albacete|Cultural\s*Leonesa|Real\s*Murcia|Algeciras') {
        return 'Fútbol España'
    }
    # 7. Emisoras fijas y eventos de Deportes España (ACB, ciclismo español, canales M+/DAZN sin partido internacional)
    if ($name -match '(?i)\bACB\b|DAZN\s*Baloncesto|Liga\s*Endesa|Unicaja|Baskonia|UCAM\s*Murcia|Manresa|Obradoiro|Joventut|Alonso\s*(?:vs|F1)?|Carlos\s*Sainz|Marc\s*M[aá]rquez|La\s*Vuelta|Vuelta\s*a\s*Espa|Capo\s*Deportes|Esport\s*3|Esport3|UFC.*\(ES\)|UFC\s*(?:Fight\s*Pass|Network|Evento)') {
        return 'Deportes España'
    }
    if ($name -notmatch '(?i)\bvs\.?\b' -and $name -match '(?i)Movistar\+\s*Deportes|M\+\s*Deportes?|Movistar\s*Deportes?|MDeportes|Movistar\+\s*Vamos|Movistar\s*Vamos|Movistar\s*Plus\+|M\+\s*Vamos|MVamos|MPlus|#?Vamos|Movistar\+\s*Golf|M\+\s*Golf|Movistar\+\s*Ellas|M\+\s*Ellas|DAZN\s*[1-4]|DAZN\s*Futsal|DAZN\s*Eventos|One\s*Toro|OneToro|Torol[eé]|M\+\s*Multideporte|Multideporte|Ubeat|MyPadel|DBike|Surf\s*Channel|Rally\s*TV|Moto\s*Adv|Garage\s*TV|Eurosport.*Espa[ñn]|Deportes.*Espa[ñn]|Espa[ñn]a.*Deportes') {
        return 'Deportes España'
    }
    if ($name -notmatch '(?i)\b(?:UK|FR|DE|IT|PL|NL|US|International)\b' -and $name -match '(?i)^Eurosport\s*[12]\b') {
        return 'Deportes España'
    }
    # 8. Formula 1 Internacional
    if ($name -match '(?i)Formula\s*1|\bF1\b|\bF1TV\b|^(?:TRACKER|DATA)$|Interlagos|Sky\s*Sports\s*F1|Sky\s*F1|Sky\s*Sport\s*F1|Fox\s*Sports\s*F1|F1\s*TV|Carrera.*Sky|Carrera.*Apple|Carrera.*UHD|Race.*Sky|Race.*UHD|Nexa|Pilotos|Onboard|Telemetr|Pit\s*Lane|Pitlane') {
        return 'Formula 1 Internacional'
    }
    # 9. MotoGP y Motor Internacional
    if ($name -match '(?i)MotoGP|Moto\s*GP|Lusail|Moto2|Moto3|WEC|Endurance|Horas\s*de|Autodromo|Rally|NASCAR|IndyCar|Superbike|WSBK|Motorsport|Garage\s*TV') {
        return 'MotoGP y Motor Internacional'
    }
    # 10. Fútbol Internacional (partidos/ligas extranjeros incluso si se emiten en DAZN/Castellano)
    if ($name -match '(?i)Premier\s*League|EFL\s*Championship|FA\s*Cup|Serie\s*A|Serie\s*B|Bundesliga|Ligue\s*1|Ligue\s*2|Primeira\s*Liga|Eredivisie|Champions\s*League|UEFA\s*Women(?:\x27s)?\s*Champions|Europa\s*League|Conference\s*League|Libertadores|Sudamericana|Brasileir|Liga\s*MX|LigaPro|\bMLS\b|Nations\s*League|World\s*Cup|Mundial|Eliminatorias|Brighton|Brentford|Crystal\s*Palace|Liverpool|Ipswich|Bournemouth|Sunderland|Chelsea|Arsenal|Manchester|Tottenham|Newcastle|Aston\s*Villa|West\s*Ham|Everton|Fulham|Wolves|Nottingham|Leicester|Southampton|Plymouth|Berkhamsted|Stafford|Grimsby|Stockport|Napoli|Lazio|\bGenoa\b|\bMilan\b|\bMonza\b|Atalanta|Fiorentina|Juventus|\bInter\b|\bRoma\b|Bologna|Torino|Cologne|Colonia|Leverkusen|Bayern|Dortmund|Leipzig|Stuttgart|Frankfurt|\bPSG\b|Marseille|\bLyon\b|Monaco|\bLille\b|Benfica|\bPorto\b|Sporting|\bAjax\b|\bPSV\b|Feyenoord|\bBoca\b|\bRiver\b|Flamengo|Palmeiras|Corinthians|Monterrey|Quer[eé]taro|Chivas|Cruz\s*Azul|Tigres|Galatasaray|Fenerbah[cç]e|\bCeltic\b|(?<!New\s+York\s+)\bRangers\b|\bSoccer\b|F[uú]tbol') {
        return 'Fútbol Internacional'
    }
    if ($sourceHint -eq "Football") {
        return 'Fútbol Internacional'
    }
    if ($sourceHint -eq 'IPTV_FUTBOL_ES') {
        return 'Fútbol España'
    }
    # 11. Eventos no futbolísticos emitidos en español castellano / cadenas España
    if ($name -match '(?i)Movistar|M\+\s*Deportes|MDeportes|#?Vamos|MPlus|DAZN\s*[1-4]|Eurosport.*Espa[ñn]|Castellano|Teledeporte|\bEspa[ñn]ol\b') {
        return 'Deportes España'
    }
    # 12. Baloncesto (NBA, NCAA, Euroliga)
    if ($name -match '(?i)\b(?:NBA|Baloncesto|Basketball|League\s*Pass|Euroliga|Euroleague|Bulls|76ers|Celtics|Lakers|Warriors|Nets|Knicks|Heat|Mavericks|Nuggets|Suns|Bucks|Pelicans|Clippers|Timberwolves|Jazz|Hawks|Cavaliers|Hornets|Wizards|Pistons|Grizzlies|Raptors|Pacers|Rockets|Spurs|Thunder|Blazers|Kings|Magic|Huskies|Longhorns|Volunteers|Hurricanes|Crimson\s*Tide|UConn)\b') {
        return 'Baloncesto'
    }
    # 13. NFL (Fútbol Americano)
    if ($name -match '(?i)\bNFL\b|Bills|Vikings|Bengals|Falcons|Texans|Chargers|Cardinals|Seahawks|Patriots|Chiefs|Cowboys|Packers|Eagles|Steelers|49ers|Ravens|Lions|Dolphins|Jets|Giants|Commanders|Bears|Saints|Buccaneers|Panthers|Rams|Broncos|Raiders|Colts|Jaguars|Titans|Browns') {
        return 'NFL'
    }
    # 13b. Cine y Series España
    if ($name -match '(?i)M\.?\+?\s*(?:Estrenos|Acci[oó]n|Comedia|Drama|Originales|Cine\s*Espa|Cl[aá]sico|Hits|Musicales|Pop\s*Up|Series|Terror|Indie|Romance)|Estrenos\s*M\+|FlixOl[eé]|(?:Canal\s+)?Hollywood|\bTCM\b|Sundance|Somos|Warner\s*TV|\bAXN\b|Calle\s*13|SYFY|COSMO|\bAMC\b(?!\s*(?:Break|Crime|Living|Western))|XTRM|\bDark\b|Star\s*Channel|Comedy\s*Central|Run\s*Time|FREE\s*TV\s*SAS|Taquilla|OnePlay|1Play|Netflix|Apple\s*TV\+\s*Series|PrimeVideo|Paramount\s*(?:Channel|Network)|Bom\s*Cine|Cines\s*Verdi|Cine\s*Feel\s*Good|Cine\s*Cl[aá]sico|Acontra\+|BBC\s*(?:Drama|Series)|Canal\s*Las\s*Estrellas|Kanal\s*D\s*Drama|Coraz[oó]n|Rakuten\s*Tv\s*Top') {
        return 'Cine y Series España'
    }
    # 13c. Documentales y Cultura España
    if ($name -match '(?i)M\+\s*Documentales|Discovery\s*Channel|Odisea|Nat(?:ional)?\s*Geo(?:graphic|grafic)|BBC\s*(?:Earth|History|TopGear|Food|LifeStyle)|\bHistoria\b|Caza\s*y\s*Pesca|Cazavisi[oó]n|Iberalia|Canal\s*Cocina|Decasa|AMC\s*(?:Break|Crime|Living|Western)|Crimen\s*(?:\+|Mas).*Investigaci|Cr[ií]menes\s*Reales|Escapa\s*TV|Love\s*The\s*Planet|Tastemade|M\+\s*Cero|Gran\s*Hermano|My\s*Zen') {
        return 'Documentales y Cultura España'
    }
    # 13d. Infantil y Música España
    if ($name -match '(?i)DreamWorks|Disney\s*Jr|Boing|Canal\s*Panda|Baby\s*TV|Nickelodeon|Nick\s*Jr|EnFamilia|Duck\s*TV|Rakuten\s*Tv\s*Family|\bMTV\b|Sol\s*M[uú]sica|Sol\s*Music|Mezzo|VH1|Classica|All\s*Flamenco|Molahits|Cadena\s*Elite|Vega\s*Fibra') {
        return 'Infantil y Música España'
    }
    if ($sourceHint -eq 'IPTV_DEPORTES_ES') {
        return 'Deportes España'
    }
    # 14. Canales TV y 24/7 Internacionales (incluye CNN, Fox News, Fox Cricket/Footy, Willow, ESPN, Sky, Disney+, Golf, ViX, SporTV, etc.)
    if ($name -match '(?i)24\/?7|ESPN|DSPORTS|DirecTV|TUDN|Win\s*Sports|TNT\s*Sports|Telemundo|Universo|Liga\s*1|Sky\s*Sport|\bNBC\b|Fox\s*Sports|Fox\s*Soccer|FOX\s*Deportes|Fox\s*News|Fox\s*Cricket|Fox\s*Footy|Fox\s*League|Fox\s*One|Willow|\bCNN\b|\bTBS\b|truTV|\bABC\b|\bCBS\b|\bFOX\b|Paramount\+|Peacock|Prime\s*Video|Apple\s*TV|Disney\+|\bGolf\b|PGA\s*Tour|DP\s*(?:World|Internacional)|Ryder\s*Cup|Golf\s*Channel|Canal\+|Sport\s*TV|SporTV|\bViX\b|beIN\s*Sports?|\bBBC\b|Azplay|Red\s*Bull\s*TV|Ziggo|Viaplay|Optus|Stan\s*Sport|Setanta|Eleven\s*Sports|SuperSport|Match\s*TV|Arena\s*Sport|SportKlub|DAZN\b|Polsat|\bFS[12]\b|\bTSN\d*\b|\bTNT\b|USA\s*Net|ACC\s*Network|Big\s*Ten\s*Network|CBS\s*Sports|ThreeNow|Premier\s*Sports|BeIN|TyC\s*Sports|Eurosport|Racing\s*TV|At\s*The\s*Races|FIFA\+|Historia|BBC\s*Drama|Cine\s*Friki|Cine\s*Western|Todo\s*Novelas|Rakuten\s*TV|MyTime|Pet\s*Collective|Plus|\bAEW\b|\bWWE\b|\bUFC\b|\bTNA\b') {
        return 'Canales TV Internacionales'
    }
    if ($name -match '(?i)\bvs\.?\b' -and $script:WebOracleEvents -and $script:WebOracleEvents.Count -gt 0) {
        $ovTenis = Find-WebOracleMatchStatus -EventTitle $name
        if ($ovTenis -and $ovTenis.Source -eq 'ESPN-Tennis') { return 'Tenis' }
    }
    return 'Otros'
}

# -------------------------------------------------------------
# FILTRO RAPIDO DE DEPORTES EXCLUIDOS Y MOTOR PARALELO (RUNSPACES)
# -------------------------------------------------------------
function Test-IsExcludedSport {
    param(
        [string]$Name,
        [string]$LeagueOrCategory = "",
        [string]$SportId = ""
    )
    if ($SportId -match '(?i)^(?:basketball|nba|nhl|cfb|ncaa|cbb|nfl|hockey|ice.?hockey|american.?football)$') { return $true }
    if ($LeagueOrCategory -match '(?i)(?:copa\s*colombia|liga\s*(?:de\s*)?colombia|liga\s*betplay|categor[ií]a\s*primera\s*a|f[uú]tbol\s*colombiano|dimayor|primera\s*b|torneo\s*proyecci[oó]n|\bNBA\b|\bNCAA\b|\bCBB\b|\bWNBA\b|\bNFL\b|\bNHL\b|basketball|baloncesto|american\s*football|ice\s*hockey|\bhockey\b)') { return $true }
    $grp = Get-ChannelGroup $Name ""
    if ($grp -in @('Baloncesto', 'NFL')) { return $true }
    if ($Name -match '(?i)(?:NBA\s*League\s*Pass|NFL\s*RedZone|NFL\s*Network|\bRed\s*Zone\b|\bNHL\b|\bIowa\s*@\s*UConn\b|Maple\s*Leafs|Canadiens|Red\s*Wings|Bruins|Blackhawks|Oilers|Penguins|Flyers|Canucks|Islanders|Avalanche|Panthers\s*vs|Blue\s*Jackets|Senators|Capitals|Devils|Golden\s*Knights|Kraken|Predators|Ducks|Mammoth|Envigado|Deportivo\s*Pasto|Boyac[aá]\s*Chic[oó]|Llaneros|Jag[uü]ares\s*de\s*C[oó]rdoba|Patriotas\s*vs|Rionegro|[AÁ]guilas\s*Doradas|Fortaleza\s*CEIF|La\s*Equidad|Once\s*Caldas|Atl[eé]tico\s*Bucaramanga|Deportivo\s*Pereira|Independiente\s*Medell[ií]n|Independiente\s*Santa\s*Fe|Millonarios|Deportes\s*Tolima|Atl[eé]tico\s*Nacional|Am[eé]rica\s*de\s*Cali|Deportivo\s*Cali|\bJunior\s*vs|vs\s*Junior\b)') {
        return $true
    }
    return $false
}

# -------------------------------------------------------------
# MOTOR DE PURGA INTELIGENTE ENTRENADO CON AGENDAS WEB Y FILTRO IA
# -------------------------------------------------------------
function Normalize-EventText([string]$Text) {
    if ([string]::IsNullOrWhiteSpace($Text)) { return "" }
    $formD = $Text.Normalize([System.Text.NormalizationForm]::FormD)
    $sb = [System.Text.StringBuilder]::new($formD.Length)
    foreach ($ch in $formD.ToCharArray()) {
        if ([System.Globalization.CharUnicodeInfo]::GetUnicodeCategory($ch) -ne [System.Globalization.UnicodeCategory]::NonSpacingMark) {
            [void]$sb.Append($ch)
        }
    }
    $clean = $sb.ToString().ToLowerInvariant()
    $clean = $clean -replace 'feberbache', 'fenerbahce' -replace '\bol\s+lyonnes\b', 'ol lyonnes' -replace '\bm[uü]nchen\b', 'munich' -replace '\bman\s+utd\b', 'manchester united' -replace '\bman\s+city\b', 'manchester city'
    $clean = ($clean -replace '[&/\-\|:\.\(\)\[\],]+', ' ' -replace '[^a-z0-9\s]', ' ' -replace '\s{2,}', ' ').Trim()
    return $clean
}

function Get-EventBaseTitle([string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Name)) { return "" }
    $t = $Name.Trim()
    $t = $t -replace '\s*\[[^\]]+\]', ''
    $t = $t -replace '\s*\([^)]*(?:Castellano|Latino|Opci[oó]n|HD\s*\||SD\s*\||NOWTV|TBS|CW\s+on|Sky\s+Sports|ESPN[^)]*|M\+[^)]*|Movistar[^)]*|DAZN[^)]*|Disney\+[^)]*|TUDN[^)]*|Win\s*Sports[^)]*|Gol\s*Play[^)]*|Vamos[^)]*)[^)]*\)', ''
    $t = $t -replace '\s*-\s*(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+\d{1,2}(?:,?\s*\d{4})?$', ''
    $t = $t -replace '\s{2,}', ' '
    return $t.Trim()
}

function Get-CoreTeamTokens([string]$TeamRaw) {
    $norm = Normalize-EventText $TeamRaw
    if (-not $norm) { return @() }
    $stop = @('fc','cf','sc','ac','cd','ud','rc','ca','sd','if','sk','fk','bk','sv','vfl','vfb','tsg','fsv','rb','real','club','city','united','utd','town','athletic','atletico','sporting','deportivo','women','wom','femenino','femenil','ladies','san','santa','saint','st','de','la','el','los','las','del','al','fc','sc','ii')
    $all = @($norm -split '\s+' | Where-Object { $_ -and $_.Length -ge 2 })
    $core = @($all | Where-Object { $_ -notin $stop -and $_.Length -ge 3 })
    if ($core.Count -gt 0) { return $core }
    return @($all | Where-Object { $_.Length -ge 3 })
}

function Get-EventTeamPair([string]$Title) {
    $base = Get-EventBaseTitle $Title
    if ($base -match ':\s*(.+)$') {
        $afterColon = $Matches[1].Trim()
        if ($afterColon -match '(?i)\b(?:vs\.?|versus)\b|\s+at\s+|\s+-\s+') {
            $base = $afterColon
        }
    }
    if ($base -match '^(?i)(.+?)\s+(?:vs\.?|versus|v)\s+(.+)$') {
        return @($Matches[1].Trim(), $Matches[2].Trim())
    }
    if ($base -cmatch '^(.+?)\s+at\s+([A-Z].+)$') {
        return @($Matches[1].Trim(), $Matches[2].Trim())
    }
    if ($base -notmatch '(?i)Nov\s+\d|Round|Stage|Day\s*#' -and $base -match '^(.+?)\s+-\s+(.+)$') {
        return @($Matches[1].Trim(), $Matches[2].Trim())
    }
    return @()
}

function Test-SideTokenOverlap([string[]]$TokensA, [string[]]$TokensB) {
    if (-not $TokensA -or -not $TokensB -or $TokensA.Count -eq 0 -or $TokensB.Count -eq 0) { return $false }
    foreach ($a in $TokensA) {
        foreach ($b in $TokensB) {
            if ($a -eq $b) { return $true }
            if ($a.Length -ge 5 -and $b.Length -ge 5 -and ($a.StartsWith($b) -or $b.StartsWith($a))) { return $true }
        }
    }
    return $false
}

function Test-IsLinearChannel([string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Name)) { return $false }
    if ($Name -match '(?i)\b24/7\b') { return $true }
    # Si contiene marcas inequívocas de partido o fecha de evento puntual, NO es canal lineal 24/7
    if ($Name -match '(?i)\b(?:vs\.?|versus)\b|\[(?:\d{1,2}/)?\d{1,2}:\d{2}\]|\((?:[^)]*(?:Castellano|Latino|Opci[oó]n))' -or
        $Name -cmatch '\s+at\s+[A-Z]' -or
        $Name -match '(?i)\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+\d{1,2}(?:,?\s*20\d{2})\b' -or
        $Name -match '(?i)^(?:Torneo|Copa\s+de|Liga\s+MX|Liga\s+de|Premier\s+P[aá]del|UEFA|Champions\s+League|ATP\s*-|WTA\s*-|AEW|WWE|UFC)\b') {
        # Excepción: canales lineales puros con "Opción X" como "DAZN F1 (Opción 2)" sin "vs" ni fecha
        if ($Name -match '(?i)\(Opci[oó]n\s*\d+\)$' -and $Name -notmatch '(?i)\bvs\.?\b|\[') {
            return $true
        }
        return $false
    }
    if ($Name -match '(?i)(?:\[AceStream|RTVE|\bLa 1\b|\bLa 2\b|Teledeporte|24 Horas|24h|Clan|\bTVE\b|\bTDT\b|Tennis\s*Channel|M\.?\+?\s*LaLiga|DAZN\s*LaLiga|Hypermotion|TV Bar|Liga\s*(?:de\s*)?Campeones|DAZN\s*[1-4]|DAZN\s*F1|DAZN\s*MotoGP|DAZN\s*Eventos|DAZN\s*Baloncesto|DAZN\s*Liga\s*F|Movistar.*Deportes|M\.?\+?\s*Deportes?|M\.?\+?\s*Multideporte|\bVamos\b|M\.?\+?\s*Golf|M\.?\+?\s*Ellas|Eurosport|Gol\s*Play|Capo Deportes|Real Madrid TV|Bar[cç]a TV|\bESPN\b|\bESPN\d|\bESPNU\b|DSPORTS|DirecTV|TUDN|TNT Sports|TNT\b|Win Sports|Liga 1 Max|Telemundo|Universo|Sky Sports?|\bNBC\b|ThreeNow|Premier Sports|Formula 1|F1 TV|\bF1TV\b|\bMotoGP\b|^(?:TRACKER|DATA)$|Fox Sports|\bFS[12]\b|\bViX\b|beIN\s*Sports?|SporTV|WWE\s*Network|\bBBC\b|Azplay|Fox Soccer|FOX Deportes|ACC Network|Big Ten Network|CBS Sports|USA Net|TSN\d*|Señal|Nexa|Pilotos|Onboard|Telemetr|Antena 3|Cuatro|Telecinco|La\s*Sexta|DMAX|TRECE|Telemadrid|Canal Sur|TV3|ETB|TVG|À Punt|M\.?\+?\s*(?:Estrenos|Acci[oó]n|Comedia|Drama|Originales|Cine|Cl[aá]sico|Hits|Musicales|Pop\s*Up|Series|Terror|Indie|Romance|Documentales|Cero)|Estrenos\s*M\+|FlixOl[eé]|Hollywood|\bTCM\b|Sundance|Warner\s*TV|\bAXN\b|Calle\s*13|SYFY|COSMO|\bAMC\b|XTRM|\bDark\b|Star\s*Channel|Comedy\s*Central|Run\s*Time|FREE\s*TV|Taquilla|OnePlay|Netflix|PrimeVideo|Apple\s*TV\+|Discovery|Odisea|Nat(?:ional)?\s*Geo|Historia|Classica|Iberalia|Canal\s*Cocina|Decasa|DreamWorks|Disney\s*Jr|Boing|Nickelodeon|Nick\s*Jr|EnFamilia|Canal\s*Panda|Baby\s*TV|Duck\s*TV|\bMTV\b|Mezzo|VH1|LaLiga\+|FanPlay|\bRFEF\b|FootballClub|Primera\s*Federaci[oó]n|Segunda\s*Federaci[oó]n|2ª\s*RFEF|DKISS|Paramount\s*(?:Channel|Network)|Somos|Squirrel|\bFDF\b|Atreseries|Divinity|^TEN\b|La\s*S[eé]ptima|3\/?24|BBC\s*(?:Drama|Series)|Cines\s*Verdi|Bom\s*Cine|Cine\s*Feel\s*Good|Cine\s*Cl[aá]sico|Acontra\+|One\s*Toro|Torol[eé]|Super\s*3|Bon\s*Dia|Onda\s*C[aá]diz|Teleonuba|Canal\s*Parlamento|7TV|Hit\s*TV)') {
        return $true
    }
    return $false
}

function Test-IsSafeHttpUrl([string]$Url) {
    if ([string]::IsNullOrWhiteSpace($Url)) { return $false }
    if ($Url -match '[\x00-\x1F\x7F"''<>]') { return $false }
    return ($Url -match '^https?://[^\s"''<>]+$')
}

function Test-EventTitlePastDate([string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Name)) { return $false }
    if (Test-IsLinearChannel $Name) { return $false }
    $nowUtc = [DateTime]::UtcNow
    $monthMap = @{
        'jan'=1;'ene'=1;'feb'=2;'mar'=3;'apr'=4;'abr'=4;'may'=5;'jun'=6;
        'jul'=7;'aug'=8;'ago'=8;'sep'=9;'oct'=10;'nov'=11;'dec'=12;'dic'=12
    }
    # 1. Etiqueta de hora explícita [dd/MM HH:mm]
    if ($Name -match '\[(\d{1,2})/(\d{1,2})\s+(\d{1,2}):(\d{2})\]') {
        try {
            $dd = [int]$Matches[1]; $mm = [int]$Matches[2]; $hh = [int]$Matches[3]; $mi = [int]$Matches[4]
            $yr = (Get-Date).Year
            $dtLocal = [DateTime]::new($yr, $mm, $dd, $hh, $mi, 0, [DateTimeKind]::Local)
            if (($dtLocal - (Get-Date)).TotalDays -gt 180) { $dtLocal = $dtLocal.AddYears(-1) }
            elseif (((Get-Date) - $dtLocal).TotalDays -gt 180) { $dtLocal = $dtLocal.AddYears(1) }
            if ([DateTime]::Now -gt $dtLocal.AddHours(3.5)) { return $true }
        } catch {}
    }
    # 2. Fecha calendario inglesa explícita (ej. "Nov 10, 2026" o "November 10")
    if ($Name -match '(?i)\b(Jan|Feb|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|January|February|March|April|June|July|August|September|October|November|December)\.?\s+(\d{1,2})(?:,?\s*(20\d{2}))?\b') {
        try {
            $mon = $monthMap[$Matches[1].Substring(0,3).ToLower()]
            $day = [int]$Matches[2]
            $yr = if ($Matches[3]) { [int]$Matches[3] } else { $nowUtc.Year }
            $dUtc = [DateTime]::new($yr, $mon, $day, 0, 0, 0, [DateTimeKind]::Utc)
            if ($nowUtc -gt $dUtc.AddDays(1).AddHours(10)) { return $true }
        } catch {}
    }
    # 3. Fecha calendario española/mixta estricta (ej. "10 de noviembre", "10 noviembre 2026" - nunca "1 Mar Menor")
    if ($Name -match '(?i)\b(\d{1,2})\s+(?:de\s+(enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|octubre|noviembre|diciembre|ene|feb|mar|abr|may|jun|jul|ago|sep|oct|nov|dic)|(enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|octubre|noviembre|diciembre|january|february|march|april|june|july|august|september|october|november|december))\b(?:\s+(?:de\s+)?(20\d{2}))?') {
        try {
            $day = [int]$Matches[1]
            $monRaw = if ($Matches[2]) { $Matches[2] } else { $Matches[3] }
            $mon = $monthMap[$monRaw.Substring(0,3).ToLower()]
            $yr = if ($Matches[4]) { [int]$Matches[4] } else { $nowUtc.Year }
            $dUtc = [DateTime]::new($yr, $mon, $day, 0, 0, 0, [DateTimeKind]::Utc)
            if ($nowUtc -gt $dUtc.AddDays(1).AddHours(10)) { return $true }
        } catch {}
    }
    if ($Name -match '\b(20\d{2})-(\d{2})-(\d{2})\b') {
        try {
            $dUtc = [DateTime]::new([int]$Matches[1], [int]$Matches[2], [int]$Matches[3], 0, 0, 0, [DateTimeKind]::Utc)
            if ($nowUtc -gt $dUtc.AddDays(1).AddHours(10)) { return $true }
        } catch {}
    }
    return $false
}

function Get-EstimatedEventDurationMinutes([string]$Title, [string]$SportHint = "") {
    $ctx = "$SportHint $Title"
    if ($ctx -match '(?i)\b(?:ufc|mma|boxing|boxeo|wwe|aew|tna|wrestl|fight|combate|dynamite|smackdown|collision|raw|nxt)\b') { return 210 }
    if ($ctx -match '(?i)\b(?:tennis|tenis|padel|p[aá]del|atp|wta|roland|wimbledon|open|davis|alcaraz|sinner|djokovic|nadal|sabalenka|swiatek|badosa|zverev|medvedev)\b') { return 165 }
    if ($ctx -match '(?i)\b(?:f1|formula\s*1|motogp|moto\s*gp|rally|nascar|indycar|wec|grand\s*prix)\b') { return 150 }
    if ($ctx -match '(?i)\b(?:football|soccer|f[uú]tbol|liga|cup|copa|champions|europa|trophy|libertadores|sudamericana|reserva)\b' -or $Title -match '(?i)\bvs\.?\b') { return 135 }
    return 150
}

function Import-EventFinishCache {
    if (-not $script:FinishCache) { $script:FinishCache = [hashtable]::Synchronized(@{}) }
    $script:FinishCache.Clear()
    $script:FinishCacheDirty = $false
    if (-not $script:FinishCacheFile -or -not (Test-Path $script:FinishCacheFile)) { return }
    try {
        $raw = [System.IO.File]::ReadAllText($script:FinishCacheFile, [System.Text.Encoding]::UTF8)
        if ([string]::IsNullOrWhiteSpace($raw)) { return }
        $obj = $raw | ConvertFrom-Json
        $cutoff = [DateTime]::UtcNow.AddHours(-36)
        foreach ($prop in $obj.PSObject.Properties) {
            try {
                $dt = [DateTime]::Parse([string]$prop.Value, [System.Globalization.CultureInfo]::InvariantCulture).ToUniversalTime()
                if ($dt -gt $cutoff) {
                    $script:FinishCache[[string]$prop.Name] = $dt.ToString("yyyy-MM-ddTHH:mm:ssZ")
                } else {
                    $script:FinishCacheDirty = $true
                }
            } catch {}
        }
    } catch {}
}

function Save-EventFinishCache {
    if (-not $script:FinishCacheFile -or -not $script:FinishCacheDirty -or -not $script:FinishCache) { return }
    try {
        $cutoff = [DateTime]::UtcNow.AddHours(-36)
        $clean = [ordered]@{}
        foreach ($k in @($script:FinishCache.Keys)) {
            try {
                $dt = [DateTime]::Parse([string]$script:FinishCache[$k], [System.Globalization.CultureInfo]::InvariantCulture).ToUniversalTime()
                if ($dt -gt $cutoff) {
                    $clean[$k] = $dt.ToString("yyyy-MM-ddTHH:mm:ssZ")
                }
            } catch {}
        }
        $json = $clean | ConvertTo-Json -Depth 3
        [System.IO.File]::WriteAllText($script:FinishCacheFile, $json, [System.Text.UTF8Encoding]::new($false))
        $script:FinishCacheDirty = $false
    } catch {}
}

function Get-EventFinishEvaluation {
    param(
        [string]$EventTitle,
        [Nullable[DateTime]]$StartUtc = $null,
        [string]$SportHint = "",
        [bool]$IsAborted = $false,
        [Nullable[DateTime]]$EndedHintUtc = $null,
        [string]$Reason = "Evento finalizado"
    )
    $nowUtc = [DateTime]::UtcNow
    $graceMin = if ($script:PurgeGraceMinutes -and $script:PurgeGraceMinutes -gt 0) { [int]$script:PurgeGraceMinutes } else { 15 }
    if ($IsAborted) {
        return [PSCustomObject]@{ ShouldPurge = $true; Reason = $Reason; GraceUntilUtc = $null }
    }
    $normKey = Normalize-EventText (Get-EventBaseTitle $EventTitle)
    if ([string]::IsNullOrWhiteSpace($normKey)) {
        return [PSCustomObject]@{ ShouldPurge = $true; Reason = $Reason; GraceUntilUtc = $null }
    }
    if ($EndedHintUtc -and $nowUtc -ge $EndedHintUtc.AddMinutes($graceMin)) {
        return [PSCustomObject]@{ ShouldPurge = $true; Reason = "$Reason (+${graceMin}m expirados)"; GraceUntilUtc = $EndedHintUtc.AddMinutes($graceMin) }
    }
    $durMin = Get-EstimatedEventDurationMinutes -Title $EventTitle -SportHint $SportHint
    $staleThreshold = [Math]::Max($durMin, 155) + $graceMin
    if ($StartUtc -and $nowUtc -gt $StartUtc.AddMinutes($staleThreshold)) {
        return [PSCustomObject]@{ ShouldPurge = $true; Reason = "$Reason (horario y margen de ${graceMin}m expirados)"; GraceUntilUtc = $StartUtc.AddMinutes($staleThreshold) }
    }
    if ($null -eq $script:FinishCache) { $script:FinishCache = [hashtable]::Synchronized(@{}) }
    $firstFinUtc = $nowUtc
    if ($script:FinishCache.ContainsKey($normKey)) {
        try {
            $firstFinUtc = [DateTime]::Parse([string]$script:FinishCache[$normKey], [System.Globalization.CultureInfo]::InvariantCulture).ToUniversalTime()
        } catch {
            $script:FinishCache[$normKey] = $nowUtc.ToString("yyyy-MM-ddTHH:mm:ssZ")
            $script:FinishCacheDirty = $true
        }
    } else {
        if ($EndedHintUtc -and $EndedHintUtc -lt $nowUtc) { $firstFinUtc = $EndedHintUtc }
        $script:FinishCache[$normKey] = $firstFinUtc.ToString("yyyy-MM-ddTHH:mm:ssZ")
        $script:FinishCacheDirty = $true
    }
    $graceUntilUtc = $firstFinUtc.AddMinutes($graceMin)
    if ($nowUtc -ge $graceUntilUtc) {
        return [PSCustomObject]@{ ShouldPurge = $true; Reason = "$Reason (+${graceMin}m completados)"; GraceUntilUtc = $graceUntilUtc }
    }
    return [PSCustomObject]@{ ShouldPurge = $false; Reason = "Margen post-partido activo hasta $($graceUntilUtc.ToLocalTime().ToString('HH:mm'))"; GraceUntilUtc = $graceUntilUtc }
}

function Test-EventHlsEndedOrDead {
    param(
        [string]$Uri,
        [string]$Referer = $null
    )
    if ([string]::IsNullOrWhiteSpace($Uri) -or $Uri -notmatch '\.m3u8(?:\?|$)') { return $false }
    try {
        $txt = [AtomicFastHttp]::GetUtf8($Uri, $Referer, "null", $UserAgent, 2500, $false)
        if ([string]::IsNullOrWhiteSpace($txt)) { return $true }
        if ($txt -notmatch '#EXTM3U') { return $true }
        if ($txt -match '#EXT-X-ENDLIST') { return $true }
        $targetTxt = $txt
        if ($txt -match '#EXT-X-STREAM-INF') {
            $subRel = ($txt -split "`r?`n" | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith('#') -and $_ -notmatch '(?i)_audio' } | Select-Object -First 1)
            if ($subRel) {
                $subUri = ([Uri]::new([Uri]::new($Uri), $subRel)).AbsoluteUri
                $subTxt = [AtomicFastHttp]::GetUtf8($subUri, $Referer, "null", $UserAgent, 2500, $false)
                if ([string]::IsNullOrWhiteSpace($subTxt) -or $subTxt -notmatch '#EXTM3U') { return $true }
                if ($subTxt -match '#EXT-X-ENDLIST') { return $true }
                $targetTxt = $subTxt
            }
        }
        $pdtMatches = [regex]::Matches($targetTxt, '#EXT-X-PROGRAM-DATE-TIME:([^\r\n]+)')
        if ($pdtMatches.Count -gt 0) {
            $lastPdtRaw = $pdtMatches[$pdtMatches.Count - 1].Groups[1].Value.Trim()
            $lastPdtUtc = [DateTime]::Parse($lastPdtRaw, [System.Globalization.CultureInfo]::InvariantCulture).ToUniversalTime()
            if (([DateTime]::UtcNow - $lastPdtUtc).TotalMinutes -gt 15) { return $true }
        }
        $hasSeg = $false
        foreach ($ln in ($targetTxt -split "`r?`n")) {
            $tr = $ln.Trim()
            if ($tr -and -not $tr.StartsWith('#')) { $hasSeg = $true; break }
        }
        if (-not $hasSeg -and $targetTxt -notmatch '#EXT-X-MAP:') { return $true }
        if (-not (Test-HlsDeepLive -Uri $Uri -Referer $Referer -TimeoutSec 3 -SkipBlockCache)) { return $true }
    } catch {}
    return $false
}

function Find-WebOracleMatchStatus([string]$EventTitle, [Nullable[DateTime]]$ApproxStartUtc = $null) {
    if (-not $script:WebOracleEvents -or $script:WebOracleEvents.Count -eq 0) { return $null }
    $pair = Get-EventTeamPair $EventTitle
    $nowUtc = [DateTime]::UtcNow

    if ($pair.Count -eq 2) {
        $tA = Get-CoreTeamTokens $pair[0]
        $tB = Get-CoreTeamTokens $pair[1]
        if ($tA.Count -gt 0 -and $tB.Count -gt 0) {
            foreach ($ov in $script:WebOracleEvents) {
                if ($ApproxStartUtc -and $ov.StartUtc) {
                    if ([Math]::Abs(($ov.StartUtc - $ApproxStartUtc).TotalHours) -gt 40) { continue }
                }
                if (-not $ov.TokensA -or -not $ov.TokensB) { continue }
                $direct = (Test-SideTokenOverlap $tA $ov.TokensA) -and (Test-SideTokenOverlap $tB $ov.TokensB)
                $flipped = (Test-SideTokenOverlap $tA $ov.TokensB) -and (Test-SideTokenOverlap $tB $ov.TokensA)
                if ($direct -or $flipped) {
                    $verdict = if ($ov.Completed -or $ov.State -eq 'post' -or $ov.Detail -match '(?i)Postponed|Canceled|Cancelled|Abandoned|Suspended|FT|Final|Retired|Walkover') { 'POST' }
                               elseif ($ov.State -eq 'in') { 'IN' }
                               else { 'PRE' }
                    return [PSCustomObject]@{ Verdict = $verdict; Source = $ov.Source; Detail = $ov.Detail; StartUtc = $ov.StartUtc; MatchName = $ov.Title }
                }
            }
        }
    }

    # Coincidencia por nombre único en torneos de motor / UFC / tenis acabado
    $normTitle = Normalize-EventText (Get-EventBaseTitle $EventTitle)
    foreach ($ov in $script:WebOracleEvents) {
        if ($ov.Kind -eq 'event' -and $ov.NormTitle) {
            if ($ov.EndUtc -and $nowUtc -gt $ov.EndUtc -and ($normTitle -like "*$($ov.NormTitle)*" -or $ov.NormTitle -like "*$normTitle*")) {
                return [PSCustomObject]@{ Verdict = 'POST'; Source = $ov.Source; Detail = $ov.Detail; StartUtc = $ov.StartUtc; MatchName = $ov.Title }
            }
        }
    }
    return $null
}

function Get-AgendaEventWindowEvaluation {
    param(
        [string]$Title,
        [Nullable[DateTime]]$StartUtc = $null,
        [Nullable[DateTime]]$ReportedEndUtc = $null,
        [int]$ReportedDurationMinutes = 0,
        [string]$SportHint = "",
        [string]$RawStatus = ""
    )
    $nowUtc = [DateTime]::UtcNow
    if ($RawStatus -and ($RawStatus -match '(?i)^(?:postponed|cancel.*|suspend.*|abandoned|aplazado|suspendido|cancelado)$')) {
        return [PSCustomObject]@{ IsConcluded = $true; Reason = "Evento cancelado/aplazado ($RawStatus)"; KickTag = ""; Upcoming = $false; StartsAtUtcStr = ""; EndsAtUtcStr = "" }
    }
    if (Test-EventTitlePastDate $Title) {
        return [PSCustomObject]@{ IsConcluded = $true; Reason = "Fecha de evento vencida"; KickTag = ""; Upcoming = $false; StartsAtUtcStr = ""; EndsAtUtcStr = "" }
    }
    $durMin = Get-EstimatedEventDurationMinutes -Title $Title -SportHint $SportHint
    if ($ReportedDurationMinutes -gt 0) {
        $durMin = [Math]::Min($ReportedDurationMinutes, $durMin)
    }
    $estEndUtc = if ($ReportedEndUtc -and $StartUtc) {
        $cap = $StartUtc.AddMinutes($durMin)
        if ($ReportedEndUtc -lt $cap) { $ReportedEndUtc } else { $cap }
    } elseif ($ReportedEndUtc) {
        $ReportedEndUtc
    } elseif ($StartUtc) {
        $StartUtc.AddMinutes($durMin)
    } else { $null }

    $oracle = Find-WebOracleMatchStatus -EventTitle $Title -ApproxStartUtc $StartUtc
    if ($oracle -and $oracle.Verdict -eq 'POST') {
        $isAborted = ($oracle.Detail -match '(?i)Postponed|Cancel|Suspend|Abandoned')
        $finEval = Get-EventFinishEvaluation -EventTitle $Title -StartUtc $StartUtc -SportHint $SportHint -IsAborted $isAborted -Reason "Oráculo Web ($($oracle.Source)): $($oracle.Detail)"
        if ($finEval.ShouldPurge) {
            return [PSCustomObject]@{ IsConcluded = $true; Reason = $finEval.Reason; KickTag = ""; Upcoming = $false; StartsAtUtcStr = ""; EndsAtUtcStr = "" }
        }
        $estEndUtc = $finEval.GraceUntilUtc
    }
    $oracleLive = ($oracle -and $oracle.Verdict -eq 'IN')
    if ($oracleLive) {
        $nkLive = Normalize-EventText (Get-EventBaseTitle $Title)
        if ($nkLive -and $script:FinishCache -and $script:FinishCache.ContainsKey($nkLive)) {
            $script:FinishCache.Remove($nkLive)
            $script:FinishCacheDirty = $true
        }
        if ($estEndUtc -and $estEndUtc -lt $nowUtc.AddMinutes(30)) {
            $estEndUtc = $nowUtc.AddMinutes(30)
        }
    }
    if (-not $oracleLive -and $RawStatus -and ($RawStatus -match '(?i)^(?:finished|final.*|post|complete.*|closed|awarded|ft|aet|pen|finalizado|terminado|ended)$')) {
        $finEval = Get-EventFinishEvaluation -EventTitle $Title -StartUtc $StartUtc -SportHint $SportHint -IsAborted $false -EndedHintUtc $estEndUtc -Reason "Estado oficial finalizado ($RawStatus)"
        if ($finEval.ShouldPurge) {
            return [PSCustomObject]@{ IsConcluded = $true; Reason = $finEval.Reason; KickTag = ""; Upcoming = $false; StartsAtUtcStr = ""; EndsAtUtcStr = "" }
        }
        $estEndUtc = $finEval.GraceUntilUtc
    } elseif (-not $oracleLive -and $estEndUtc -and $nowUtc -gt $estEndUtc) {
        $finEval = Get-EventFinishEvaluation -EventTitle $Title -StartUtc $StartUtc -SportHint $SportHint -IsAborted $false -EndedHintUtc $estEndUtc -Reason "Horario concluido ($($estEndUtc.ToLocalTime().ToString('HH:mm')))"
        if ($finEval.ShouldPurge) {
            return [PSCustomObject]@{ IsConcluded = $true; Reason = $finEval.Reason; KickTag = ""; Upcoming = $false; StartsAtUtcStr = ""; EndsAtUtcStr = "" }
        }
        $estEndUtc = $finEval.GraceUntilUtc
    }

    $upcoming = ($null -ne $StartUtc -and $StartUtc -gt $nowUtc)
    $kickTag = ""
    if ($upcoming) {
        $localKick = $StartUtc.ToLocalTime()
        $kickTag = if ($localKick.Date -eq (Get-Date).Date) { " [$($localKick.ToString('HH:mm'))]" } else { " [$($localKick.ToString('dd/MM HH:mm'))]" }
    }
    $stIso = if ($StartUtc) { $StartUtc.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ") } else { "" }
    $enIso = if ($estEndUtc) { $estEndUtc.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ") } else { "" }
    return [PSCustomObject]@{ IsConcluded = $false; Reason = ""; KickTag = $kickTag; Upcoming = $upcoming; StartsAtUtcStr = $stIso; EndsAtUtcStr = $enIso }
}

$script:QuietScanActive = (-not $ShowDetails)
$script:QuietWriteHostHooked = $false
$script:ScanStageStart = 0
$script:ScanStageEnd = 100
$script:LastShownPct = -1
$script:LastMilestonePct = -1
$script:ScanBarLabel = if ($esModoVpn) { "Analizando todos los canales (con y sin VPN)" } else { "Buscando canales abiertos (sin VPN)" }

function Reset-ScanProgressState([string]$Label) {
    if (-not [string]::IsNullOrWhiteSpace($Label)) { $script:ScanBarLabel = $Label }
    $script:ScanStageStart = 0
    $script:ScanStageEnd = 100
    $script:LastShownPct = -1
    $script:LastMilestonePct = -1
}

function Show-ScanProgressBar([int]$Percent) {
    <# Dibuja una unica barra de progreso limpia mientras el escaneo corre en background. #>
    if (-not $script:QuietScanActive) { return }
    $clamped = [Math]::Max(0, [Math]::Min(100, $Percent))
    if ($clamped -lt $script:LastShownPct) { $clamped = $script:LastShownPct }
    if ($clamped -eq $script:LastShownPct) { return }
    $script:LastShownPct = $clamped
    $barWidth = 28
    $filled = [int][Math]::Round(($clamped / 100.0) * $barWidth)
    $empty = $barWidth - $filled
    $bar = ([string]::new([char]0x2588, $filled)) + ([string]::new([char]0x2591, $empty))
    $line = "  [+] {0}... [{1}] {2,3}%" -f $script:ScanBarLabel, $bar, $clamped
    if ([Console]::IsOutputRedirected) {
        $milestone = if ($clamped -eq 0) { 0 } elseif ($clamped -ge 100) { 100 } else { [int]([Math]::Floor($clamped / 25) * 25) }
        if ($milestone -gt $script:LastMilestonePct) {
            $script:LastMilestonePct = $milestone
            [Console]::WriteLine($line)
        }
        return
    }
    $prevColor = $null
    try {
        $prevColor = [Console]::ForegroundColor
        [Console]::ForegroundColor = if ($clamped -ge 100) { [ConsoleColor]::Green } else { [ConsoleColor]::Cyan }
    } catch {}
    try {
        [Console]::Write("`r$line   ")
        if ($clamped -ge 100) { [Console]::WriteLine("") }
    } finally {
        if ($null -ne $prevColor) { try { [Console]::ForegroundColor = $prevColor } catch {} }
    }
}

function Set-ScanStage([int]$StartPct, [int]$EndPct) {
    $script:ScanStageStart = [Math]::Max(0, [Math]::Min(100, $StartPct))
    $script:ScanStageEnd = [Math]::Max($script:ScanStageStart, [Math]::Min(100, $EndPct))
    Show-ScanProgressBar $script:ScanStageStart
}

function Enter-ScanPhase([string]$PhaseName, [bool]$IsVpnMode) {
    Invoke-PeriodicListenCheckSilent
    $mapVpnFull = @{
        'Oracle'   = @(0, 7);   'Prefetch' = @(7, 15);  'Embdlol'   = @(15, 23); 'F1Net'    = @(23, 30)
        'Ppv'      = @(30, 38); 'Formatura'= @(38, 43); 'RtveTdt'   = @(43, 57); 'CdPlay'   = @(57, 62)
        'EsStageA' = @(62, 66); 'EsStageB' = @(66, 69); 'EsStageC'  = @(69, 72); 'FutbolLb' = @(72, 77)
        'StreamXhd'= @(77, 81); 'CastVip'  = @(81, 85); 'EmbedMe'   = @(85, 89); 'DepLibre' = @(89, 92)
        'CandySS'  = @(92, 95); 'AceStream'= @(95, 97); 'WebPurge'  = @(97, 99); 'Save'     = @(99, 100)
    }
    $mapOpen = @{
        'Oracle'   = @(0, 10);  'Prefetch' = @(10, 22); 'Embdlol'   = @(22, 34); 'F1Net'    = @(34, 45)
        'Ppv'      = @(45, 56); 'Formatura'= @(56, 64); 'RtveTdt'   = @(64, 88); 'AceStream' = @(88, 94); 'WebPurge' = @(94, 99); 'Save' = @(99, 100)
    }
    $tbl = if ($IsVpnMode) { $mapVpnFull } else { $mapOpen }
    if ($tbl.ContainsKey($PhaseName)) {
        $pair = $tbl[$PhaseName]
        Set-ScanStage $pair[0] $pair[1]
    }
}

function Enable-QuietScanMode {
    if (-not $script:QuietScanActive -or $script:QuietWriteHostHooked) { return }
    try {
        Set-Item -Path 'Function:\script:Write-Host' -Value {
            param(
                [Parameter(Position = 0, ValueFromPipeline = $true, ValueFromRemainingArguments = $true)][object]$Object,
                [switch]$NoNewline,
                [object]$ForegroundColor,
                [object]$BackgroundColor,
                [object]$Separator
            )
            process {}
        } -ErrorAction Stop
        $script:QuietWriteHostHooked = $true
    } catch {}
}

function Disable-QuietScanMode {
    if ($script:QuietWriteHostHooked) {
        Remove-Item -Path 'Function:\Write-Host' -ErrorAction SilentlyContinue
        $script:QuietWriteHostHooked = $false
    }
}

$script:HelperFunctionNames = @(
    'Get-HostKey', 'Get-Utf8Content', 'Test-HlsLive', 'Test-HlsDeepLive',
    'Decode-EhgembxeM3u8', 'Decode-CharCodeUrls', 'Get-ExtractedManifestFromHtml',
    'Resolve-CapoCandyShop', 'Resolve-RedxEsUrl', 'Resolve-Tvf90Url', 'Resolve-StreamxNodeUrl',
    'Resolve-StreamXhdUrl', 'Resolve-EmbdlolWatchUrl', 'Resolve-EmbedAnyUrl',
    'Translate-ToSpanish', 'Get-ChannelGroup', 'Test-IsEventFinalized', 'Test-IsExcludedSport',
    'Normalize-EventText', 'Get-EventBaseTitle', 'Get-CoreTeamTokens', 'Get-EventTeamPair',
    'Test-SideTokenOverlap', 'Test-IsLinearChannel', 'Test-IsSafeHttpUrl',
    'Test-EventTitlePastDate', 'Get-EstimatedEventDurationMinutes', 'Get-EventFinishEvaluation',
    'Test-EventHlsEndedOrDead', 'Find-WebOracleMatchStatus',
    'Get-AgendaEventWindowEvaluation', 'Invoke-WebSearchAiClassifier'
)

function Initialize-ParallelPool([int]$MaxThreads = 96) {
    if ($script:ParallelPool) { return }
    $iss = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
    foreach ($fnName in $script:HelperFunctionNames) {
        $cmd = Get-Command $fnName -CommandType Function -ErrorAction SilentlyContinue
        if ($cmd) {
            $iss.Commands.Add([System.Management.Automation.Runspaces.SessionStateFunctionEntry]::new($fnName, $cmd.Definition))
        }
    }
    $iss.Variables.Add([System.Management.Automation.Runspaces.SessionStateVariableEntry]::new('UserAgent', $UserAgent, $null))
    $iss.Variables.Add([System.Management.Automation.Runspaces.SessionStateVariableEntry]::new('ProgressPreference', 'SilentlyContinue', $null))
    $iss.Variables.Add([System.Management.Automation.Runspaces.SessionStateVariableEntry]::new('BlockedHosts', $global:BlockedHosts, $null))
    $iss.Variables.Add([System.Management.Automation.Runspaces.SessionStateVariableEntry]::new('ActiveStreamxHost', $global:ActiveStreamxHost, $null))
    $iss.Variables.Add([System.Management.Automation.Runspaces.SessionStateVariableEntry]::new('WebOracleEvents', $script:WebOracleEvents, $null))
    $iss.Variables.Add([System.Management.Automation.Runspaces.SessionStateVariableEntry]::new('FinishCache', $script:FinishCache, $null))
    $iss.Variables.Add([System.Management.Automation.Runspaces.SessionStateVariableEntry]::new('PurgeGraceMinutes', $script:PurgeGraceMinutes, $null))
    $iss.Variables.Add([System.Management.Automation.Runspaces.SessionStateVariableEntry]::new('AiApiKey', $script:AiApiKey, $null))
    $iss.Variables.Add([System.Management.Automation.Runspaces.SessionStateVariableEntry]::new('AiModel', $script:AiModel, $null))
    if ($script:QuietScanActive) {
        $iss.Commands.Add([System.Management.Automation.Runspaces.SessionStateFunctionEntry]::new(
            'Write-Host',
            'param([Parameter(Position=0,ValueFromPipeline=$true,ValueFromRemainingArguments=$true)]$Object,[switch]$NoNewline,$ForegroundColor,$BackgroundColor,$Separator) process {}'
        ))
    }
    $script:ParallelPool = [runspacefactory]::CreateRunspacePool(1, $MaxThreads, $iss, $Host)
    $script:ParallelPool.ApartmentState = [System.Threading.ApartmentState]::MTA
    $script:ParallelPool.Open()
}

function Invoke-ParallelItems {
    param(
        [array]$Items,
        [scriptblock]$ScriptBlock
    )
    if (-not $Items -or $Items.Count -eq 0) { return @() }
    Initialize-ParallelPool 96
    $scriptStr = $ScriptBlock.ToString()
    $jobs = [System.Collections.Generic.List[PSCustomObject]]::new()
    foreach ($it in $Items) {
        $ps = [powershell]::Create()
        $ps.RunspacePool = $script:ParallelPool
        [void]$ps.AddScript($scriptStr)
        [void]$ps.AddArgument($it)
        $handle = $ps.BeginInvoke()
        $jobs.Add([PSCustomObject]@{ Ps = $ps; Handle = $handle })
    }
    if ($script:QuietScanActive -and $jobs.Count -gt 0) {
        $totalJobs = $jobs.Count
        $stageSpan = [Math]::Max(0, $script:ScanStageEnd - $script:ScanStageStart)
        while ($true) {
            $completed = 0
            foreach ($j in $jobs) {
                if ($j.Handle.IsCompleted) { $completed++ }
            }
            if ($stageSpan -gt 0) {
                $pct = $script:ScanStageStart + [int][Math]::Floor(($completed / [double]$totalJobs) * $stageSpan)
                Show-ScanProgressBar $pct
            }
            if ($completed -ge $totalJobs) { break }
            Start-Sleep -Milliseconds 15
        }
    } elseif ($script:QuietScanActive) {
        Show-ScanProgressBar $script:ScanStageEnd
    }
    $results = [System.Collections.Generic.List[object]]::new()
    foreach ($job in $jobs) {
        try {
            $out = $job.Ps.EndInvoke($job.Handle)
            foreach ($o in $out) {
                if ($null -ne $o) { $results.Add($o) }
            }
        } catch {} finally {
            $job.Ps.Dispose()
        }
    }
    return @($results)
}

function Initialize-WebAgendaOracle {
    Import-EventFinishCache
    Write-Host " [+] Sincronizando Oráculo Web de Agendas Deportivas (ESPN + Marcadores Reales)..." -ForegroundColor Cyan
    $nowUtc = [DateTime]::UtcNow
    $dYest = $nowUtc.AddDays(-1).ToString('yyyyMMdd')
    $dToday = $nowUtc.ToString('yyyyMMdd')
    $dTom = $nowUtc.AddDays(1).ToString('yyyyMMdd')
    $tsToday = $nowUtc.ToString('yyyy-MM-dd')
    $tsYest = $nowUtc.AddDays(-1).ToString('yyyy-MM-dd')

    $endpoints = @(
        [PSCustomObject]@{ Key = 'Oracle_0'; Kind = 'espn_soccer'; Url = "https://site.api.espn.com/apis/site/v2/sports/soccer/all/scoreboard?dates=$dYest" },
        [PSCustomObject]@{ Key = 'Oracle_1'; Kind = 'espn_soccer'; Url = "https://site.api.espn.com/apis/site/v2/sports/soccer/all/scoreboard?dates=$dToday" },
        [PSCustomObject]@{ Key = 'Oracle_2'; Kind = 'espn_soccer'; Url = "https://site.api.espn.com/apis/site/v2/sports/soccer/all/scoreboard?dates=$dTom" },
        [PSCustomObject]@{ Key = 'Oracle_3'; Kind = 'espn_tennis'; Url = "https://site.api.espn.com/apis/site/v2/sports/tennis/atp/scoreboard" },
        [PSCustomObject]@{ Key = 'Oracle_4'; Kind = 'espn_tennis'; Url = "https://site.api.espn.com/apis/site/v2/sports/tennis/wta/scoreboard" },
        [PSCustomObject]@{ Key = 'Oracle_5'; Kind = 'espn_other';  Url = "https://site.api.espn.com/apis/site/v2/sports/racing/f1/scoreboard" },
        [PSCustomObject]@{ Key = 'Oracle_6'; Kind = 'espn_other';  Url = "https://site.api.espn.com/apis/site/v2/sports/mma/ufc/scoreboard" },
        [PSCustomObject]@{ Key = 'Oracle_7'; Kind = 'tsdb';        Url = "https://www.thesportsdb.com/api/v1/json/123/eventsday.php?d=$tsToday" },
        [PSCustomObject]@{ Key = 'Oracle_8'; Kind = 'tsdb';        Url = "https://www.thesportsdb.com/api/v1/json/123/eventsday.php?d=$tsYest" }
    )

    $fetched = [System.Collections.Generic.List[PSCustomObject]]::new()
    $missingEps = [System.Collections.Generic.List[PSCustomObject]]::new()
    foreach ($ep in $endpoints) {
        if ($script:Prefetched -and $script:Prefetched.ContainsKey($ep.Key) -and $script:Prefetched[$ep.Key]) {
            $fetched.Add([PSCustomObject]@{ Kind = $ep.Kind; Json = [string]$script:Prefetched[$ep.Key] })
        } else {
            $missingEps.Add($ep)
        }
    }
    if ($missingEps.Count -gt 0) {
        $missUrls = [string[]]::new($missingEps.Count)
        $missRefs = [string[]]::new($missingEps.Count)
        $missOrigs = [string[]]::new($missingEps.Count)
        for ($mi = 0; $mi -lt $missingEps.Count; $mi++) {
            $missUrls[$mi] = $missingEps[$mi].Url
            $missRefs[$mi] = "https://www.espn.com/"
            $missOrigs[$mi] = ""
        }
        $missBodies = [AtomicFastHttp]::BatchGetUrls($missUrls, $missRefs, $missOrigs, $UserAgent, 3000)
        for ($mi = 0; $mi -lt $missingEps.Count; $mi++) {
            if ($missBodies[$mi]) {
                $fetched.Add([PSCustomObject]@{ Kind = $missingEps[$mi].Kind; Json = $missBodies[$mi] })
            }
        }
    }

    $seenKeys = [System.Collections.Generic.HashSet[string]]::new()
    if ($script:WebOracleEvents -is [System.Collections.Generic.List[object]]) {
        $script:WebOracleEvents.Clear()
    } else {
        $script:WebOracleEvents = [System.Collections.Generic.List[object]]::new()
    }

    foreach ($res in $fetched) {
        try {
            $obj = $res.Json | ConvertFrom-Json
            if ($res.Kind -eq 'espn_soccer' -and $obj.events) {
                foreach ($ev in $obj.events) {
                    $idKey = "espn_" + [string]$ev.id
                    if (-not $seenKeys.Add($idKey)) { continue }
                    $st = if ($ev.status -and $ev.status.type) { $ev.status.type } else { $null }
                    $pair = Get-EventTeamPair ([string]$ev.name)
                    $stDt = $null
                    try { $stDt = [DateTime]::Parse([string]$ev.date, [System.Globalization.CultureInfo]::InvariantCulture).ToUniversalTime() } catch {}
                    if ($pair.Count -eq 2) {
                        $script:WebOracleEvents.Add([PSCustomObject]@{
                            Kind      = 'match'
                            Source    = 'ESPN-Soccer'
                            Title     = [string]$ev.name
                            NormTitle = Normalize-EventText ([string]$ev.name)
                            TokensA   = @(Get-CoreTeamTokens $pair[0])
                            TokensB   = @(Get-CoreTeamTokens $pair[1])
                            StartUtc  = $stDt
                            EndUtc    = $null
                            State     = if ($st) { [string]$st.state } else { '' }
                            Completed = if ($st) { [bool]$st.completed } else { $false }
                            Detail    = if ($st) { [string]$st.shortDetail } else { '' }
                        })
                    }
                }
            } elseif ($res.Kind -eq 'espn_tennis' -and $obj.events) {
                foreach ($ev in $obj.events) {
                    $endDt = $null
                    try { if ($ev.endDate) { $endDt = [DateTime]::Parse([string]$ev.endDate, [System.Globalization.CultureInfo]::InvariantCulture).ToUniversalTime() } } catch {}
                    if ($endDt -and $nowUtc -gt $endDt) {
                        $script:WebOracleEvents.Add([PSCustomObject]@{
                            Kind      = 'event'
                            Source    = 'ESPN-Tennis'
                            Title     = [string]$ev.name
                            NormTitle = Normalize-EventText ([string]$ev.name)
                            TokensA   = @(); TokensB = @()
                            StartUtc  = $null; EndUtc = $endDt
                            State     = 'post'; Completed = $true; Detail = 'Torneo concluido'
                        })
                    }
                    if ($ev.groupings) {
                        foreach ($gp in $ev.groupings) {
                            foreach ($cp in $gp.competitions) {
                                $st = if ($cp.status -and $cp.status.type) { $cp.status.type } else { $null }
                                if ($cp.competitors -and $cp.competitors.Count -ge 2) {
                                    $c0 = $cp.competitors[0]
                                    $c1 = $cp.competitors[1]
                                    $p1 = if ($c0.athlete -and $c0.athlete.displayName) { [string]$c0.athlete.displayName } elseif ($c0.team -and $c0.team.displayName) { [string]$c0.team.displayName } elseif ($c0.roster -and $c0.roster.shortDisplayName) { [string]$c0.roster.shortDisplayName } else { "" }
                                    $p2 = if ($c1.athlete -and $c1.athlete.displayName) { [string]$c1.athlete.displayName } elseif ($c1.team -and $c1.team.displayName) { [string]$c1.team.displayName } elseif ($c1.roster -and $c1.roster.shortDisplayName) { [string]$c1.roster.shortDisplayName } else { "" }
                                    if ($p1 -and $p2) {
                                        $cpDt = $null
                                        try { if ($cp.date) { $cpDt = [DateTime]::Parse([string]$cp.date, [System.Globalization.CultureInfo]::InvariantCulture).ToUniversalTime() } } catch {}
                                        $script:WebOracleEvents.Add([PSCustomObject]@{
                                            Kind      = 'match'
                                            Source    = 'ESPN-Tennis'
                                            Title     = "$p1 vs $p2"
                                            NormTitle = Normalize-EventText "$p1 vs $p2"
                                            TokensA   = @(Get-CoreTeamTokens $p1)
                                            TokensB   = @(Get-CoreTeamTokens $p2)
                                            StartUtc  = $cpDt; EndUtc = $null
                                            State     = if ($st) { [string]$st.state } else { '' }
                                            Completed = if ($st) { [bool]$st.completed } else { $false }
                                            Detail    = if ($st) { [string]$st.shortDetail } else { '' }
                                        })
                                    }
                                }
                            }
                        }
                    }
                }
            } elseif ($res.Kind -eq 'espn_other' -and $obj.events) {
                foreach ($ev in $obj.events) {
                    $st = if ($ev.status -and $ev.status.type) { $ev.status.type } else { $null }
                    $endDt = $null
                    try { if ($ev.endDate) { $endDt = [DateTime]::Parse([string]$ev.endDate, [System.Globalization.CultureInfo]::InvariantCulture).ToUniversalTime() } elseif ($ev.date) { $endDt = [DateTime]::Parse([string]$ev.date, [System.Globalization.CultureInfo]::InvariantCulture).ToUniversalTime().AddHours(4) } } catch {}
                    $isOver = ($st -and ($st.completed -or $st.state -eq 'post'))
                    if ($isOver) {
                        $script:WebOracleEvents.Add([PSCustomObject]@{
                            Kind      = 'event'
                            Source    = 'ESPN-Sport'
                            Title     = [string]$ev.name
                            NormTitle = Normalize-EventText ([string]$ev.name)
                            TokensA   = @(); TokensB = @()
                            StartUtc  = $null; EndUtc = if ($endDt) { $endDt } else { $nowUtc.AddMinutes(-1) }
                            State     = 'post'; Completed = $true; Detail = [string]$st.shortDetail
                        })
                    }
                }
            } elseif ($res.Kind -eq 'tsdb' -and $obj.events) {
                foreach ($ev in $obj.events) {
                    $stTxt = [string]$ev.strStatus
                    $isDone = ($stTxt -match '(?i)^(?:FT|AET|AP|Finished|Postponed|Cancelled|Abandoned)$')
                    $isIn = ($stTxt -match '(?i)^(?:1H|2H|HT|ET|Live|Playing)$')
                    if (-not $isDone -and -not $isIn) { continue }
                    $pair = Get-EventTeamPair ([string]$ev.strEvent)
                    if ($pair.Count -eq 2) {
                        $script:WebOracleEvents.Add([PSCustomObject]@{
                            Kind      = 'match'
                            Source    = 'TheSportsDB'
                            Title     = [string]$ev.strEvent
                            NormTitle = Normalize-EventText ([string]$ev.strEvent)
                            TokensA   = @(Get-CoreTeamTokens $pair[0])
                            TokensB   = @(Get-CoreTeamTokens $pair[1])
                            StartUtc  = $null; EndUtc = $null
                            State     = if ($isDone) { 'post' } else { 'in' }
                            Completed = $isDone
                            Detail    = $stTxt
                        })
                    }
                }
            }
        } catch {}
    }

    if ($script:WebOracleEvents.Count -gt 0) {
        $script:WebOracleStatus = "ONLINE ($($script:WebOracleEvents.Count) eventos)"
        Write-Host "   [+] Oráculo Web sincronizado: $($script:WebOracleEvents.Count) partidos/eventos oficiales cargados." -ForegroundColor DarkGreen
    }
}

# -------------------------------------------------------------
# DETECCION AUTOMATIZADA Y EN TIEMPO REAL DE EVENTOS CONCLUIDOS
# -------------------------------------------------------------
function Test-IsEventFinalized($url, $name, $watchId) {
    if ([string]::IsNullOrWhiteSpace($name)) { return $true }

    # Canales 24/7 lineales genuinos (sin cruce vs/fecha de partido) NUNCA se descartan
    if (Test-IsLinearChannel $name) {
        return $false
    }

    # 0. Fechas explícitas pasadas en el título del evento (ej. "WWE NXT - Nov 10, 2026")
    if (Test-EventTitlePastDate $name) {
        return $true
    }

    # 0b. Oráculo Web oficial en tiempo real (ESPN / TheSportsDB) con margen post-partido de 15 min
    $oracleMatch = Find-WebOracleMatchStatus -EventTitle $name
    if ($oracleMatch) {
        if ($oracleMatch.Verdict -eq 'POST') {
            $isAb = ($oracleMatch.Detail -match '(?i)Postponed|Cancel|Suspend|Abandoned')
            $finEv = Get-EventFinishEvaluation -EventTitle $name -StartUtc $oracleMatch.StartUtc -IsAborted $isAb -Reason "Oráculo Web ($($oracleMatch.Source)): $($oracleMatch.Detail)"
            if ($finEv.ShouldPurge) { return $true }
            if ($url -and $url -match '\.m3u8(?:\?|$)' -and (Test-EventHlsEndedOrDead -Uri $url)) { return $true }
            return $false
        }
        if ($oracleMatch.Verdict -eq 'IN' -or $oracleMatch.Verdict -eq 'PRE') {
            $nk = Normalize-EventText (Get-EventBaseTitle $name)
            if ($nk -and $script:FinishCache -and $script:FinishCache.ContainsKey($nk)) {
                $script:FinishCache.Remove($nk)
                $script:FinishCacheDirty = $true
            }
            return $false
        }
    }

    $checkTarget = "$name $url"

    # 1. Eventos concluidos identificados por nombre/URL históricos
    if ($checkTarget -match '(?i)(?:Interlagos|S[aã]o Paulo|so-paulo|Lusail|Qatar|Monza|6 Horas|6 Hours|Horas de Monza|brazil/race|01a1ba3d|01a1b7cb|Antonelli|Max ver|Lerclec)') {
        return $true
    }

    # 2. Partidos concluidos históricos
    if ($checkTarget -match '(?i)(?:Napoli vs Lazio|Brighton.*Brentford|Crystal Palace.*Liverpool|Ipswich.*Bournemouth|Sunderland.*Chelsea|Stafford.*Grimsby|LaligaPremier|Genoa.*Milan|Monza.*Atalanta|Cray Wanderers.*Stockport|Celta.*Levante|Cologne.*Leverkusen|Colonia.*Leverkusen|Fiorentina.*Juventus|intercomo|Bengals.*Falcons)') {
        return $true
    }

    # 3. Días pasados en eventos no fijos
    if ($name -match '(?i)(?:Sunday|Saturday|Friday|Domingo|Sábado|Viernes)' -and $name -notmatch '(?i)(?:Formula|F1|DAZN|TV|Directa)') {
        return $true
    }

    # 4. Chequeo automatizado de emisión HLS en vivo (VOD / #EXT-X-ENDLIST o PDT antiguo)
    if ($watchId) {
        try {
            $bodyJson = '{"watchId":"' + $watchId + '"}'
            $wReq = Invoke-RestMethod -Uri "https://api.embdlol.st/watch" -Method POST -Body $bodyJson -ContentType "application/json" -TimeoutSec 3 -ErrorAction SilentlyContinue
            if ($wReq -and $wReq.url) {
                $m3uResp = Invoke-WebRequest -Uri $wReq.url -Headers @{"Referer"="https://embdlol.st/"; "Origin"="https://embdlol.st"} -TimeoutSec 3 -UseBasicParsing -ErrorAction SilentlyContinue
                if ($m3uResp -and $m3uResp.Content) {
                    $m3uText = [System.Text.Encoding]::UTF8.GetString($m3uResp.Content)
                    if ($m3uText -match '#EXT-X-ENDLIST') { return $true }
                    $subMatch = [regex]::Match($m3uText, '(?m)^(/.*m3u8.*)$')
                    if ($subMatch.Success) {
                        $base = [regex]::Match($wReq.url, '^(https?://[^/]+)').Groups[1].Value
                        $mediaUrl = $base + $subMatch.Groups[1].Value
                        $mediaResp = Invoke-WebRequest -Uri $mediaUrl -Headers @{"Referer"="https://embdlol.st/"; "Origin"="https://embdlol.st"} -TimeoutSec 3 -UseBasicParsing -ErrorAction SilentlyContinue
                        if ($mediaResp -and $mediaResp.Content) {
                            $mediaText = [System.Text.Encoding]::UTF8.GetString($mediaResp.Content)
                            if ($mediaText -match '#EXT-X-ENDLIST') { return $true }
                            $pdtMatch = [regex]::Match($mediaText, '#EXT-X-PROGRAM-DATE-TIME:([^\r\n]+)')
                            if ($pdtMatch.Success) {
                                $streamUtc = [DateTime]::Parse($pdtMatch.Groups[1].Value).ToUniversalTime()
                                $diffHours = ([DateTime]::UtcNow - $streamUtc).TotalHours
                                if ($diffHours -gt 1.5) {
                                    return $true
                                }
                            }
                        }
                    }
                }
            }
        } catch {}
    }

    # 5. Comprobación HTTP si la URL devuelve estado offline o fin
    if ($url -and $url -notmatch '\.m3u8(?:\?|$)') {
        try {
            $checkReq = [System.Net.HttpWebRequest]::Create($url)
            $checkReq.Method = "GET"
            $checkReq.Timeout = 1200
            $checkReq.UserAgent = $UserAgent
            $response = $checkReq.GetResponse()
            $stream = $response.GetResponseStream()
            $reader = New-Object System.IO.StreamReader($stream)
            $buffer = New-Object char[] 2048
            $readCount = $reader.Read($buffer, 0, 2048)
            $snippet = New-Object string($buffer, 0, $readCount)
            $reader.Close()
            $response.Close()

            if ($snippet -match '(?i)(?:MET_FTB_FINISH|MET_FTB_EVENT_END|SS_OVER|STREAM IS OFFLINE|Evento Finalizado|Transmisión finalizada|Partido terminado|404 Not Found)') {
                return $true
            }
        } catch [System.Net.WebException] {
            $errResp = $_.Exception.Response
            if ($errResp) {
                $code = [int]$errResp.StatusCode
                if ($code -ge 400 -and $code -le 410) { return $true }
            }
        } catch {}
    }

    return $false
}

function Invoke-WebSearchAiClassifier {
    param(
        [string]$EventTitle,
        [Nullable[DateTime]]$StartsAtUtc = $null,
        [string]$SportHint = ""
    )
    $nowUtc = [DateTime]::UtcNow
    $base = Get-EventBaseTitle $EventTitle
    $pair = Get-EventTeamPair $base
    $queryCore = if ($pair.Count -eq 2) { "`"$($pair[0])`" `"$($pair[1])`"" } else { "`"$base`"" }
    $dateHint = $nowUtc.ToString('MMMM yyyy', [System.Globalization.CultureInfo]::InvariantCulture)
    $q = "$queryCore $dateHint result OR postponed"

    $headlines = [System.Collections.Generic.List[PSCustomObject]]::new()
    $feeds = @(
        "https://news.google.com/rss/search?q=$([Uri]::EscapeDataString($q))&hl=en-US&gl=US&ceid=US:en",
        "https://news.google.com/rss/search?q=$([Uri]::EscapeDataString("$queryCore resultado OR aplazado"))&hl=es-419&gl=ES&ceid=ES:es"
    )
    foreach ($fUrl in $feeds) {
        $xmlTxt = Get-Utf8Content -Uri $fUrl -Referer "https://news.google.com/" -TimeoutSec 4
        if (-not $xmlTxt) { continue }
        try {
            [xml]$x = $xmlTxt
            foreach ($it in ($x.rss.channel.item | Select-Object -First 8)) {
                $hTitle = [string]$it.title
                if ([string]::IsNullOrWhiteSpace($hTitle)) { continue }
                $pubUtc = $null
                try { $pubUtc = [DateTimeOffset]::Parse([string]$it.pubDate).UtcDateTime } catch {}
                if ($pubUtc -and ($nowUtc - $pubUtc).TotalHours -gt 48) { continue }

                # Filtrar para asegurar relevancia estricta con los dos equipos o evento
                $hNorm = Normalize-EventText $hTitle
                $hTokens = @($hNorm -split '\s+' | Where-Object { $_.Length -ge 3 })
                $relevant = $false
                if ($pair.Count -eq 2) {
                    $tA = Get-CoreTeamTokens $pair[0]
                    $tB = Get-CoreTeamTokens $pair[1]
                    if ((Test-SideTokenOverlap $tA $hTokens) -and (Test-SideTokenOverlap $tB $hTokens)) { $relevant = $true }
                } else {
                    $tEvt = Get-CoreTeamTokens $base
                    if ($tEvt.Count -ge 2) {
                        $hits = @($tEvt | Where-Object { Test-SideTokenOverlap @($_) $hTokens }).Count
                        if ($hits -ge [Math]::Min(2, $tEvt.Count)) { $relevant = $true }
                    } elseif ($tEvt.Count -eq 1) {
                        $relevant = Test-SideTokenOverlap $tEvt $hTokens
                    }
                }
                if ($relevant) {
                    $headlines.Add([PSCustomObject]@{ Title = $hTitle; PubUtc = $pubUtc })
                }
            }
        } catch {}
        if ($headlines.Count -ge 4) { break }
    }

    if ($headlines.Count -eq 0) {
        return [PSCustomObject]@{ Verdict = 'KEEP'; Reason = 'Sin noticias concluyentes' }
    }

    # Modo opcional LLM real (Gemini API si el usuario configuró gemini/ai_api_key)
    if ($script:AiApiKey -and $script:AiModel) {
        try {
            $snipLines = ($headlines | Select-Object -First 5 | ForEach-Object { "- [$($_.PubUtc)] $($_.Title)" }) -join "`n"
            $promptTxt = "Current UTC: $($nowUtc.ToString('u')). Sport: `"$SportHint`". Event: `"$base`" (StartUTC: $(if($StartsAtUtc){$StartsAtUtc.ToString('u')}else{'Unknown'})). News:`n$snipLines`nClassify strictly: LIVE if halftime, extra time, penalties, rain/medical delay, or ongoing tennis sets; POSTPONED if delayed/canceled; FINISHED only if official final result/post-match recap/winner/score. Apply 15-minute post-match grace window using News PubUtc vs Current UTC. Reply ONLY JSON: {`"decision`":`"PURGE`"|`"KEEP`",`"aborted`":true|false,`"reason`":`"...`"}. PURGE if postponed/canceled (0m grace) OR finished >=15m ago; KEEP if still live OR within 15m of finish."
            $reqBody = @{ contents = @(@{ parts = @(@{ text = $promptTxt }) }); generationConfig = @{ temperature = 0; responseMimeType = "application/json" } } | ConvertTo-Json -Depth 6
            $gemUri = "https://generativelanguage.googleapis.com/v1beta/models/$($script:AiModel):generateContent?key=$($script:AiApiKey)"
            $gemResp = Invoke-RestMethod -Uri $gemUri -Method POST -Body $reqBody -ContentType "application/json" -TimeoutSec 5 -ErrorAction Stop
            $rawAi = $gemResp.candidates[0].content.parts[0].text
            $aiJson = $rawAi | ConvertFrom-Json
            if ($aiJson.decision -eq 'PURGE') {
                $finAi = Get-EventFinishEvaluation -EventTitle $EventTitle -StartUtc $StartsAtUtc -SportHint $SportHint -IsAborted ([bool]$aiJson.aborted) -Reason "IA Gemini Web: $($aiJson.reason)"
                return [PSCustomObject]@{ Verdict = $(if ($finAi.ShouldPurge) { 'PURGE' } else { 'KEEP_GRACE' }); GraceUntilUtc = $finAi.GraceUntilUtc; Reason = $finAi.Reason }
            }
            if ($aiJson.decision -eq 'KEEP') {
                return [PSCustomObject]@{ Verdict = 'KEEP'; GraceUntilUtc = $null; Reason = "IA Gemini Web: $($aiJson.reason)" }
            }
        } catch {}
    }

    # Clasificador IA/NLP autónomo basado en pruebas web en vivo (cero claves requeridas + margen 15 min)
    $isTenCtx = ($SportHint -match '(?i)tenis|tennis' -or $EventTitle -match '(?i)\b(?:tenis|tennis|atp|wta|roland\s*garros|wimbledon|alcaraz|sinner|djokovic|badosa|sabalenka|swiatek)\b')
    $minPlayMin = if ($isTenCtx) { 55 } else { 85 }
    $allowConcluded = ($null -eq $StartsAtUtc) -or ($nowUtc -ge $StartsAtUtc.AddMinutes($minPlayMin))
    foreach ($hl in $headlines) {
        $ht = $hl.Title
        # 1. Aplazado o suspendido (aplica incluso antes del pitido inicial, 0m de margen)
        if ($ht -match '(?i)\b(?:postponed|aplazado|suspendido|reprogramado|rescheduled|cancelled|canceled|called off)\b' -and
            $ht -notmatch '(?i)\b(?:if|could|might|may be|risk of|rain\s*delay|temporarily\s*suspended|por\s*lluvia)\b') {
            return [PSCustomObject]@{ Verdict = 'PURGE'; GraceUntilUtc = $null; Reason = "Web Search (Aplazado/Suspendido): $ht" }
        }
        # 2. Marcador final o crónica post-partido verificada (detectando si sigue vivo en prórroga/descanso/sets)
        if ($allowConcluded) {
            if ($ht -match '(?i)(?:live updates|w/\s*live|live score|live stream|how to watch|donde ver|d[oó]nde ver|a qu[eé] hora|horario|match time|preview|previa|prediction|pron[oó]stico|en vivo|en directo|alineaciones|lineups|minuto a minuto|follow live|halftime|half[- ]time|descanso|extra\s*time|pr[oó]rroga|penalt(?:y|ies|is)\s*shootout|rain\s*delay|tiebreak|\bset\s*[1-5]\b|serving|en\s*juego)') {
                continue
            }
            if ($StartsAtUtc -and $hl.PubUtc -and $hl.PubUtc -lt $StartsAtUtc.AddMinutes([Math]::Max(45, $minPlayMin - 5))) {
                continue
            }
            $isFinHeadline = ($ht -match '(?i)(?:\b\d+\s*[-–:]\s*\d+\b|\b\d[-–]\d\s*,\s*\d[-–]\d\b|\b(?:crushes?|routs?|thrashes?|defeats?|beats?|edges?|tops?|win[s]?\b|wins title|in\s+straight\s+sets|in\s+three\s+sets|advances\s+to|retires|walkover|golea|vence|derrota|remonta|empata|cae ante|se\s+clasifica|avanza\s+a|full[- ]?time|\bFT\b|final score|resumen|highlights|cr[oó]nica|recap|post[- ]?match|results.*winners|winners.*results))')
            if ($isFinHeadline) {
                $pubHint = if ($hl.PubUtc) { $hl.PubUtc } else { $null }
                $finNlp = Get-EventFinishEvaluation -EventTitle $EventTitle -StartUtc $StartsAtUtc -SportHint $SportHint -IsAborted $false -EndedHintUtc $pubHint -Reason "Filtro IA Web (Finalizado): $ht"
                return [PSCustomObject]@{ Verdict = $(if ($finNlp.ShouldPurge) { 'PURGE' } else { 'KEEP_GRACE' }); GraceUntilUtc = $finNlp.GraceUntilUtc; Reason = $finNlp.Reason }
            }
        }
    }
    return [PSCustomObject]@{ Verdict = 'KEEP'; GraceUntilUtc = $null; Reason = 'Web sin confirmación de cierre' }
}

function Test-IsProtectedLinearChannel($ch) {
    if (-not $ch) { return $false }
    if ($ch.PSObject.Properties['IsIptv'] -and $ch.IsIptv) { return $true }
    if ($ch.PSObject.Properties['Slug'] -and $ch.Slug -match '^(?:iptv|tdt|rtve)') { return $true }
    if ($ch.PSObject.Properties['Id'] -and $ch.Id -match '^(?:iptv|tdt|rtve)_') { return $true }
    if ($ch.PSObject.Properties['IsLinear'] -and $ch.IsLinear) { return $true }
    if ($ch.Group -in @('TDT España', 'Cine y Series España', 'Documentales y Cultura España', 'Infantil y Música España')) { return $true }
    return (Test-IsLinearChannel $ch.Name)
}

function Invoke-WebAiEventPurge {
    Write-Host "`n [+] Filtro IA Web: Auditando eventos residuales, margen de 15m y streams HLS activos..." -ForegroundColor Cyan
    $nowUtc = [DateTime]::UtcNow
    $surviving = [System.Collections.Generic.List[PSCustomObject]]::new()
    $purgedByBase = @{}
    $graceByBase = @{}
    $aiCandidates = @{}

    # Pasada A: Horarios + Fechas + Oráculo ESPN/TSDB con margen post-finalización de 15 minutos
    foreach ($ch in $script:allChannels) {
        if (Test-IsProtectedLinearChannel $ch) {
            $surviving.Add($ch)
            continue
        }
        $baseKey = (Get-EventBaseTitle $ch.Name).ToLowerInvariant()
        $stUtc = if ($ch.PSObject.Properties['StartsAtUtc'] -and $ch.StartsAtUtc) {
            try { [DateTime]::Parse([string]$ch.StartsAtUtc, [System.Globalization.CultureInfo]::InvariantCulture).ToUniversalTime() } catch { $null }
        } else { $null }
        $endUtc = if ($ch.PSObject.Properties['EndsAtUtc'] -and $ch.EndsAtUtc) {
            try { [DateTime]::Parse([string]$ch.EndsAtUtc, [System.Globalization.CultureInfo]::InvariantCulture).ToUniversalTime() } catch { $null }
        } else { $null }

        $oracle = Find-WebOracleMatchStatus -EventTitle $ch.Name -ApproxStartUtc $stUtc
        if ($oracle -and $oracle.Verdict -eq 'POST') {
            $isAb = ($oracle.Detail -match '(?i)Postponed|Cancel|Suspend|Abandoned')
            $finEv = Get-EventFinishEvaluation -EventTitle $ch.Name -StartUtc $stUtc -SportHint $ch.Group -IsAborted $isAb -Reason "Oráculo Web ($($oracle.Source)): $($oracle.Detail)"
            if ($finEv.ShouldPurge) {
                $script:finalizedEvents += [PSCustomObject]@{ Name = $ch.Name; Url = $ch.MasterUrl; Reason = $finEv.Reason }
                Write-Host "   [PURGADO WEB] $($ch.Name) ($($finEv.Reason))" -ForegroundColor DarkYellow
                continue
            }
            if ($finEv.GraceUntilUtc -and $ch.PSObject.Properties['EndsAtUtc']) {
                $ch.EndsAtUtc = $finEv.GraceUntilUtc.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
            }
        }
        $oracleLive = ($oracle -and $oracle.Verdict -eq 'IN')
        if ($oracleLive) {
            $nkLive = Normalize-EventText (Get-EventBaseTitle $ch.Name)
            if ($nkLive -and $script:FinishCache -and $script:FinishCache.ContainsKey($nkLive)) {
                $script:FinishCache.Remove($nkLive)
                $script:FinishCacheDirty = $true
            }
            if ($ch.PSObject.Properties['EndsAtUtc']) {
                $ext = $nowUtc.AddMinutes(30)
                if (-not $endUtc -or $endUtc -lt $ext) {
                    $ch.EndsAtUtc = $ext.ToString("yyyy-MM-ddTHH:mm:ssZ")
                }
            }
        } elseif (-not ($oracle -and $oracle.Verdict -eq 'POST') -and $endUtc -and $nowUtc -gt $endUtc) {
            $finEv = Get-EventFinishEvaluation -EventTitle $ch.Name -StartUtc $stUtc -SportHint $ch.Group -IsAborted $false -EndedHintUtc $endUtc -Reason "Horario estimado concluido"
            if ($finEv.ShouldPurge) {
                $script:finalizedEvents += [PSCustomObject]@{ Name = $ch.Name; Url = $ch.MasterUrl; Reason = $finEv.Reason }
                Write-Host "   [PURGADO HORA] $($ch.Name) ($($finEv.Reason))" -ForegroundColor DarkYellow
                continue
            }
            if ($finEv.GraceUntilUtc -and $ch.PSObject.Properties['EndsAtUtc']) {
                $ch.EndsAtUtc = $finEv.GraceUntilUtc.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
            }
        }
        if (Test-EventTitlePastDate $ch.Name) {
            $script:finalizedEvents += [PSCustomObject]@{ Name = $ch.Name; Url = $ch.MasterUrl; Reason = "Fecha de evento vencida" }
            Write-Host "   [PURGADO FECHA] $($ch.Name)" -ForegroundColor DarkYellow
            continue
        }

        $surviving.Add($ch)
        if (-not $oracle -and $baseKey -and -not $aiCandidates.ContainsKey($baseKey)) {
            if ($null -eq $stUtc -or $nowUtc -ge $stUtc.AddMinutes(-120)) {
                $aiCandidates[$baseKey] = [PSCustomObject]@{ Key = $baseKey; Title = (Get-EventBaseTitle $ch.Name); StartsAtUtc = $stUtc; Group = $ch.Group }
            }
        }
    }

    # Pasada B: Búsqueda web + Clasificador IA/NLP sobre eventos ambiguos
    $candList = @($aiCandidates.Values | Select-Object -First 45)
    if ($candList.Count -gt 0) {
        $script:WebAiStatus = "ONLINE ($($candList.Count) consultados)"
        $aiRes = Invoke-ParallelItems -Items $candList -ScriptBlock {
            param($c)
            try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
            $dec = Invoke-WebSearchAiClassifier -EventTitle $c.Title -StartsAtUtc $c.StartsAtUtc -SportHint $c.Group
            [PSCustomObject]@{ Key = $c.Key; Title = $c.Title; Decision = $dec }
        }
        foreach ($ar in $aiRes) {
            if ($ar.Decision -and $ar.Decision.Verdict -eq 'PURGE') {
                $purgedByBase[$ar.Key] = $ar.Decision.Reason
            } elseif ($ar.Decision -and $ar.Decision.Verdict -eq 'KEEP_GRACE' -and $ar.Decision.GraceUntilUtc) {
                $graceByBase[$ar.Key] = $ar.Decision.GraceUntilUtc
            }
        }
    } else {
        $script:WebAiStatus = "ONLINE (0 ambiguos)"
    }

    $afterAi = [System.Collections.Generic.List[PSCustomObject]]::new()
    foreach ($ch in $surviving) {
        if (-not (Test-IsProtectedLinearChannel $ch)) {
            $bk = (Get-EventBaseTitle $ch.Name).ToLowerInvariant()
            if ($purgedByBase.ContainsKey($bk)) {
                $rsn = $purgedByBase[$bk]
                $script:finalizedEvents += [PSCustomObject]@{ Name = $ch.Name; Url = $ch.MasterUrl; Reason = $rsn }
                Write-Host "   [PURGADO IA-WEB] $($ch.Name) ($rsn)" -ForegroundColor Yellow
                continue
            }
            if ($graceByBase.ContainsKey($bk) -and $ch.PSObject.Properties['EndsAtUtc']) {
                $ch.EndsAtUtc = $graceByBase[$bk].ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
            }
        }
        $afterAi.Add($ch)
    }

    # Pasada C: Verificación paralela de HLS de eventos (#EXT-X-ENDLIST / stream caído 404 / PDT congelado)
    $hlsProbeList = [System.Collections.Generic.List[PSCustomObject]]::new()
    for ($hi = 0; $hi -lt $afterAi.Count; $hi++) {
        $hc = $afterAi[$hi]
        if (Test-IsProtectedLinearChannel $hc) { continue }
        if ($hc.MasterUrl -notmatch '\.m3u8(?:\?|$)') { continue }
        $stH = if ($hc.PSObject.Properties['StartsAtUtc'] -and $hc.StartsAtUtc) {
            try { [DateTime]::Parse([string]$hc.StartsAtUtc, [System.Globalization.CultureInfo]::InvariantCulture).ToUniversalTime() } catch { $null }
        } else { $null }
        if ($null -eq $stH -or $nowUtc -gt $stH.AddMinutes(45)) {
            $refH = if ($hc.PSObject.Properties['FallbackUrl'] -and $hc.FallbackUrl -match '^https?://') { $hc.FallbackUrl } else { $null }
            $hlsProbeList.Add([PSCustomObject]@{ Index = $hi; Url = $hc.MasterUrl; Ref = $refH; Name = $hc.Name })
        }
    }
    $deadIndices = [System.Collections.Generic.HashSet[int]]::new()
    if ($hlsProbeList.Count -gt 0) {
        $probeOut = Invoke-ParallelItems -Items @($hlsProbeList) -ScriptBlock {
            param($p)
            try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
            $isDead = Test-EventHlsEndedOrDead -Uri $p.Url -Referer $p.Ref
            [PSCustomObject]@{ Index = $p.Index; Dead = $isDead }
        }
        foreach ($po in $probeOut) {
            if ($po.Dead) { [void]$deadIndices.Add($po.Index) }
        }
    }
    if ($script:ParallelPool) {
        try { $script:ParallelPool.Close(); $script:ParallelPool.Dispose() } catch {}
        $script:ParallelPool = $null
    }

    if ($deadIndices.Count -gt 0) {
        $finalSurviving = [System.Collections.Generic.List[PSCustomObject]]::new()
        for ($hi = 0; $hi -lt $afterAi.Count; $hi++) {
            $hc = $afterAi[$hi]
            if ($deadIndices.Contains($hi)) {
                $script:finalizedEvents += [PSCustomObject]@{ Name = $hc.Name; Url = $hc.MasterUrl; Reason = "HLS evento finalizado (#EXT-X-ENDLIST o señal inactiva)" }
                Write-Host "   [PURGADO HLS] $($hc.Name) (stream terminado)" -ForegroundColor Yellow
                continue
            }
            $finalSurviving.Add($hc)
        }
        $script:allChannels = @($finalSurviving)
    } else {
        $script:allChannels = @($afterAi)
    }
    Save-EventFinishCache
}

$allChannels = @()
$daznF1Feeds = [System.Collections.Generic.List[PSCustomObject]]::new()
$finalizedEvents = @()
$script:Prefetched = @{}
$script:VipSlugCache = @{}
$script:ScanTimer.Restart()
Enable-QuietScanMode
trap { if (Get-Command Disable-QuietScanMode -ErrorAction SilentlyContinue) { Disable-QuietScanMode }; break }

function Get-VpnPrefetchTargets {
    return @(
        [PSCustomObject]@{ Key = "ProbeSx723";  Url = "https://streamx723.sbs/global3.php?channel=mlaliga"; Ref = "https://cdplay.live/"; Orig = ""; Timeout = 2; MarkDead = $true; Ua = "" },
        [PSCustomObject]@{ Key = "ProbeSx061";  Url = "https://streamx061.sbs/global3.php?channel=mlaliga"; Ref = "https://cdplay.live/"; Orig = ""; Timeout = 2; MarkDead = $true; Ua = "" },
        [PSCustomObject]@{ Key = "ProbeLa16";   Url = "https://la16hd.com/dsportsar.php"; Ref = "https://cdplay.live/"; Orig = ""; Timeout = 2; MarkDead = $true; Ua = "" },
        [PSCustomObject]@{ Key = "CdHtml";      Url = "https://cdplay.live/"; Ref = ""; Orig = ""; Timeout = 3; MarkDead = $false; Ua = "" },
        [PSCustomObject]@{ Key = "Diaries";     Url = "https://api.wqxag.com/diaries.json"; Ref = "https://futbollibregol.org/"; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" },
        [PSCustomObject]@{ Key = "XhdEv";       Url = "https://streamxhd.click/eventos.json"; Ref = "https://streamxhd.click/"; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" },
        [PSCustomObject]@{ Key = "Ag888";       Url = "https://streamx723.sbs/json/agenda888.json"; Ref = "https://streamx723.sbs/"; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" },
        [PSCustomObject]@{ Key = "FlHtml";      Url = "https://futbollibregol.org/"; Ref = ""; Orig = ""; Timeout = 3; MarkDead = $false; Ua = "" },
        [PSCustomObject]@{ Key = "EmHtml";      Url = "https://embedme.st/"; Ref = ""; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" },
        [PSCustomObject]@{ Key = "DlAgenda";    Url = "https://deportelibre.top/agenda-deportiva/agenda.json"; Ref = "https://deportelibre.top/agenda-deportiva/"; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" },
        [PSCustomObject]@{ Key = "CandyHealth"; Url = "https://edge2.candyshop.st/health"; Ref = ""; Orig = ""; Timeout = 2; MarkDead = $false; Ua = "" }
    )
}

function Invoke-PrefetchBatch([array]$Targets) {
    if (-not $Targets -or $Targets.Count -eq 0) { return }
    $urls = [string[]]::new($Targets.Count)
    $refs = [string[]]::new($Targets.Count)
    $origs = [string[]]::new($Targets.Count)
    for ($i = 0; $i -lt $Targets.Count; $i++) {
        $urls[$i] = [string]$Targets[$i].Url
        $refs[$i] = [string]$Targets[$i].Ref
        $origs[$i] = [string]$Targets[$i].Orig
    }
    $bodies = [AtomicFastHttp]::BatchGetUrls($urls, $refs, $origs, $UserAgent, 4500)
    for ($i = 0; $i -lt $Targets.Count; $i++) {
        $txt = $bodies[$i]
        if ($txt) {
            $script:Prefetched[$Targets[$i].Key] = $txt
        } elseif ($Targets[$i].MarkDead) {
            $dk = Get-HostKey $Targets[$i].Url
            if ($dk -and $global:BlockedHosts) { $global:BlockedHosts[$dk] = $true }
        }
    }
}

# Pre-descarga paralela simultánea de Oráculo ESPN + TODOS los índices y comprobación anticipada de nodos muertos
try {
    $rpcWarmScript = Join-Path $ScriptDir "discord-rpc.ps1"
    if (Test-Path $rpcWarmScript) {
        Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$rpcWarmScript`" -WarmCacheOnly" -WindowStyle Hidden -ErrorAction SilentlyContinue | Out-Null
    }
} catch {}
Enter-ScanPhase 'Prefetch' $esModoVpn
Write-Host " [+] Pre-descargando oráculo deportivo, índices globales y agendas multi-servidor en paralelo..." -ForegroundColor Cyan
$nowOrUtc = [DateTime]::UtcNow
$dYestOr = $nowOrUtc.AddDays(-1).ToString('yyyyMMdd')
$dTodayOr = $nowOrUtc.ToString('yyyyMMdd')
$dTomOr = $nowOrUtc.AddDays(1).ToString('yyyyMMdd')
$tsTodayOr = $nowOrUtc.ToString('yyyy-MM-dd')
$tsYestOr = $nowOrUtc.AddDays(-1).ToString('yyyy-MM-dd')
$preFetchTargets = [System.Collections.Generic.List[PSCustomObject]]::new()
$preFetchTargets.Add([PSCustomObject]@{ Key = "Oracle_0";  Url = "https://site.api.espn.com/apis/site/v2/sports/soccer/all/scoreboard?dates=$dYestOr"; Ref = "https://www.espn.com/"; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" })
$preFetchTargets.Add([PSCustomObject]@{ Key = "Oracle_1";  Url = "https://site.api.espn.com/apis/site/v2/sports/soccer/all/scoreboard?dates=$dTodayOr"; Ref = "https://www.espn.com/"; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" })
$preFetchTargets.Add([PSCustomObject]@{ Key = "Oracle_2";  Url = "https://site.api.espn.com/apis/site/v2/sports/soccer/all/scoreboard?dates=$dTomOr"; Ref = "https://www.espn.com/"; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" })
$preFetchTargets.Add([PSCustomObject]@{ Key = "Oracle_3";  Url = "https://site.api.espn.com/apis/site/v2/sports/tennis/atp/scoreboard"; Ref = "https://www.espn.com/"; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" })
$preFetchTargets.Add([PSCustomObject]@{ Key = "Oracle_4";  Url = "https://site.api.espn.com/apis/site/v2/sports/tennis/wta/scoreboard"; Ref = "https://www.espn.com/"; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" })
$preFetchTargets.Add([PSCustomObject]@{ Key = "Oracle_5";  Url = "https://site.api.espn.com/apis/site/v2/sports/racing/f1/scoreboard"; Ref = "https://www.espn.com/"; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" })
$preFetchTargets.Add([PSCustomObject]@{ Key = "Oracle_6";  Url = "https://site.api.espn.com/apis/site/v2/sports/mma/ufc/scoreboard"; Ref = "https://www.espn.com/"; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" })
$preFetchTargets.Add([PSCustomObject]@{ Key = "Oracle_7";  Url = "https://www.thesportsdb.com/api/v1/json/123/eventsday.php?d=$tsTodayOr"; Ref = "https://www.espn.com/"; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" })
$preFetchTargets.Add([PSCustomObject]@{ Key = "Oracle_8";  Url = "https://www.thesportsdb.com/api/v1/json/123/eventsday.php?d=$tsYestOr"; Ref = "https://www.espn.com/"; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" })
$preFetchTargets.Add([PSCustomObject]@{ Key = "Embdlol";   Url = "https://api.embdlol.st/struct"; Ref = "https://embdlol.st/"; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" })
$preFetchTargets.Add([PSCustomObject]@{ Key = "F1Net";     Url = "https://f1net1.dpdns.org/source.txt"; Ref = ""; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" })
$preFetchTargets.Add([PSCustomObject]@{ Key = "Ppv";       Url = "https://api.ppv.st/api/streams"; Ref = "https://ppv.st/"; Orig = "https://ppv.st"; Timeout = 4; MarkDead = $false; Ua = "" })
$preFetchTargets.Add([PSCustomObject]@{ Key = "TdtJson";   Url = "https://www.tdtchannels.com/lists/tv.json"; Ref = ""; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" })
$preFetchTargets.Add([PSCustomObject]@{ Key = "IptvEs";    Url = "https://iptv-org.github.io/iptv/countries/es.m3u"; Ref = ""; Orig = ""; Timeout = 4; MarkDead = $false; Ua = "" })
foreach ($vt in (Get-VpnPrefetchTargets)) { $preFetchTargets.Add($vt) }
Invoke-PrefetchBatch @($preFetchTargets)
Enter-ScanPhase 'Oracle' $esModoVpn
Initialize-WebAgendaOracle

# -------------------------------------------------------------
# 1. EMISIONES EN DIRECTO - SERVIDOR DE EVENTOS 1 (EMBDLOL - PARALELO)
# -------------------------------------------------------------
Enter-ScanPhase 'Embdlol' $esModoVpn
Write-Host " [+] Analizando servidor de emisiones deportivas en directo..." -ForegroundColor Cyan

try {
    $embRaw = $script:Prefetched["Embdlol"]
    if (-not $embRaw) {
        $response = Invoke-WebRequest -Uri "https://api.embdlol.st/struct" -UserAgent $UserAgent -UseBasicParsing -TimeoutSec 5
        $embRaw = $response.Content
    }
    $data = $embRaw | ConvertFrom-Json
    $embdWorkItems = [System.Collections.Generic.List[PSCustomObject]]::new()

    foreach ($ch in $data.channels) {
        $spanishName = Translate-ToSpanish $ch.channelname
        if (Test-IsExcludedSport -Name $spanishName) {
            $script:SkippedSportsCount++
            continue
        }
        $embedCheckUrl = "https://embdlol.st/embed/$($ch.id)"
        if (Test-IsEventFinalized $embedCheckUrl $spanishName $null) {
            $finalizedEvents += [PSCustomObject]@{ Name = $spanishName; Url = $embedCheckUrl; Reason = "Evento concluido" }
            continue
        }
        $embdWorkItems.Add([PSCustomObject]@{ Id = $ch.id; Name = $spanishName; EmbedUrl = $embedCheckUrl })
    }

    $embdRes = Invoke-ParallelItems -Items @($embdWorkItems) -ScriptBlock {
        param($item)
        try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
        $watchUrl = "https://api.embdlol.st/watch"
        $streamMaster = $null
        $isExpired = $false
        $watchBody = '{"watchId":"' + $item.Id + '"}'
        try {
            $wResp = Invoke-RestMethod -Uri $watchUrl -Method POST -Body $watchBody -ContentType "application/json" -TimeoutSec 3 -ErrorAction Stop
            if ($wResp -and $wResp.url) {
                if (Test-HlsDeepLive -Uri $wResp.url -Referer "https://embdlol.st/" -Origin "https://embdlol.st" -TimeoutSec 3) {
                    $streamMaster = $wResp.url
                }
            }
        } catch {}

        if (-not $streamMaster) {
            if ((Test-IsEventFinalized $item.EmbedUrl $item.Name $item.Id) -or -not (Test-IsLinearChannel $item.Name)) {
                $isExpired = $true
            } else {
                $pageCheck = Get-Utf8Content -Uri $item.EmbedUrl -Referer "https://embdlol.st/" -TimeoutSec 2
                if ($pageCheck) { $streamMaster = $item.EmbedUrl } else { $isExpired = $true }
            }
        } elseif (-not (Test-IsLinearChannel $item.Name) -and (Test-IsEventFinalized $streamMaster $item.Name $item.Id)) {
            $isExpired = $true
        }
        [PSCustomObject]@{ Item = $item; MasterUrl = $streamMaster; Expired = $isExpired }
    }

    foreach ($er in $embdRes) {
        if ($er.Expired -or -not $er.MasterUrl) {
            $finalizedEvents += [PSCustomObject]@{ Name = $er.Item.Name; Url = $er.Item.EmbedUrl; Reason = "Emisión Embdlol sin segmentos activos" }
            continue
        }
        if (-not ($allChannels | Where-Object { $_.Name -eq $er.Item.Name })) {
            $allChannels += [PSCustomObject]@{
                Id          = "embd_" + $er.Item.Id
                Name        = $er.Item.Name
                Group       = Get-ChannelGroup $er.Item.Name
                Slug        = $er.Item.Id
                MasterUrl   = $er.MasterUrl
                FallbackUrl = $er.Item.EmbedUrl
                VpnRequired = $false
            }
            Write-Host "   [+] $($er.Item.Name) " -NoNewline -ForegroundColor Green
            if ($er.MasterUrl -match '\.m3u8') {
                Write-Host "[HLS Verificado | VPN No Necesaria]" -ForegroundColor DarkGreen
            } else {
                Write-Host "[Embed Activo | VPN No Necesaria]" -ForegroundColor DarkGreen
            }
        }
    }
} catch {
    Write-Host "   [-] Servidor de emisiones temporalmente no disponible: $($_.Exception.Message)" -ForegroundColor Yellow
}

# -------------------------------------------------------------
# 2. EMISIONES DE MOTOR Y DEPORTES - SERVIDOR 2 (F1NET - PARALELO)
# -------------------------------------------------------------
Enter-ScanPhase 'F1Net' $esModoVpn
Write-Host "`n [+] Analizando red de emisiones de motor y deportes..." -ForegroundColor Cyan

try {
    $f1Raw = $script:Prefetched["F1Net"]
    if (-not $f1Raw) {
        $f1Resp = Invoke-WebRequest -Uri "https://f1net1.dpdns.org/source.txt" -UserAgent $UserAgent -UseBasicParsing -TimeoutSec 5
        if ($f1Resp.StatusCode -eq 200) { $f1Raw = $f1Resp.Content }
    }
    if ($f1Raw -and $f1Raw.Length -gt 100) {
        $f1WorkItems = [System.Collections.Generic.List[PSCustomObject]]::new()
        foreach ($line in ($f1Raw -split "`n")) {
            $parts = $line -split '\|'
            if ($parts.Count -ge 3) {
                $rawName = $parts[0].Trim()
                $slug = $parts[1].Trim()
                $streamUrl = $parts[2].Trim()
                $normName = switch -Regex ($rawName) {
                    '(?i)Spanish'         { "DAZN F1 España" }
                    '(?i)Stream 1'        { "F1 - Señal 1 HD" }
                    '(?i)Stream 2'        { "F1 - Señal 2 HD" }
                    '(?i)Stream 3'        { "Sky Sports F1 HD" }
                    '(?i)Full\s*HD\s*1'   { "F1 - Señal Full HD 1 (Internacional)" }
                    '(?i)Full\s*Hd\s*3'   { "F1 - Señal Full HD 3 (Internacional)" }
                    '(?i)4k\s*UHD'        { "F1 - Señal 4K UHD (Internacional)" }
                    '(?i)Italian'         { "Sky Sport F1 Italia HD (Italiano)" }
                    '(?i)German'          { "Sky Sport F1 Alemania HD (Alemán)" }
                    '(?i)F1 TV'           { "F1 TV Internacional HD" }
                    '(?i)Fox Sports HD'   { "Fox Sports F1 HD" }
                    '(?i)Full Hd 4'       { "F1 - Señal Nexa HD" }
                    '(?i)HD Stream'       { "Sky F1 1080p HD" }
                    '(?i)Apple Tv 2'      { "F1 - Señal Apple TV" }
                    '(?i)Multi Lang 4k'   { "F1 - Señal 4K Multi-Idioma" }
                    '(?i)Sky Sports HD'   { "Sky Sports HD" }
                    '(?i)Drivers track'   { "F1 - Cámara de Pilotos (Onboard)" }
                    '(?i)Data Channel'    { "F1 - Canal de Datos y Telemetría" }
                    default               { Translate-ToSpanish $rawName }
                }
                if (Test-IsEventFinalized $streamUrl $normName $null) {
                    $finalizedEvents += [PSCustomObject]@{ Name = $normName; Url = $streamUrl; Reason = "Evento concluido" }
                    continue
                }
                $f1WorkItems.Add([PSCustomObject]@{ Name = $normName; Slug = $slug; Url = $streamUrl })
            }
        }

        $f1Results = Invoke-ParallelItems -Items @($f1WorkItems) -ScriptBlock {
            param($it)
            try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
            $resolved = Resolve-EmbedAnyUrl -Url $it.Url -Referer "https://f1net1.dpdns.org/"
            [PSCustomObject]@{ Item = $it; Ok = [bool]$resolved; ResolvedUrl = $resolved }
        }
        $f1LiveCount = 0
        foreach ($fr in $f1Results) {
            if (-not $fr.Ok) {
                continue
            }
            $f1LiveCount++
            $liveUrl = if ($fr.ResolvedUrl) { $fr.ResolvedUrl } else { $fr.Item.Url }
            if ($fr.Item.Name -match '(?i)DAZN\s*F1') {
                $daznF1Feeds.Add([PSCustomObject]@{ Url = $liveUrl; Fallback = $fr.Item.Url; Source = "f1net"; Verified = $true })
            } elseif (-not ($allChannels | Where-Object { $_.Name -eq $fr.Item.Name })) {
                $allChannels += [PSCustomObject]@{
                    Id          = "f1net_" + ($fr.Item.Name -replace '[^a-zA-Z0-9]','')
                    Name        = $fr.Item.Name
                    Group       = Get-ChannelGroup $fr.Item.Name
                    Slug        = $fr.Item.Slug
                    MasterUrl   = $liveUrl
                    FallbackUrl = $fr.Item.Url
                    VpnRequired = $false
                }
                Write-Host "   [+] $($fr.Item.Name) [HLS Verificado | VPN No Necesaria]" -ForegroundColor DarkGreen
            }
        }
        if ($f1LiveCount -eq 0 -and $f1WorkItems.Count -gt 0) {
            Write-Host "   [-] F1Net: $($f1WorkItems.Count) señales sin emisión activa ahora (omitidas)." -ForegroundColor DarkGray
        }
    }
} catch {
    Write-Host "   [-] Red de emisiones de motor no accesible directamente." -ForegroundColor DarkGray
}

# -------------------------------------------------------------
# 3. AGENDA Y EMISIONES EN VIVO DINAMICAS - SERVIDOR 3 (PPV.ST - PARALELO)
# -------------------------------------------------------------
Enter-ScanPhase 'Ppv' $esModoVpn
Write-Host "`n [+] Analizando red de eventos y canales 24/7 (PPV.ST)..." -ForegroundColor Cyan

try {
    $ppvResp = if ($script:Prefetched["Ppv"]) { $script:Prefetched["Ppv"] | ConvertFrom-Json } else {
        Invoke-RestMethod -Uri "https://api.ppv.st/api/streams" -UserAgent $UserAgent -Headers @{
            "Origin" = "https://ppv.st";
            "Referer" = "https://ppv.st/"
        } -TimeoutSec 5
    }

    if ($ppvResp -and $ppvResp.streams) {
        $nowEpoch = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        $ppvWorkItems = [System.Collections.Generic.List[PSCustomObject]]::new()
        foreach ($cat in $ppvResp.streams) {
            $ppvCatHint = if ($cat.category -match '(?i)^(?:Football|Soccer|F[uú]tbol)$') { "Football" }
                          elseif ($cat.category -match '(?i)Tennis|Tenis|ATP|WTA') { "Tennis" }
                          elseif ($cat.category -match '(?i)American\s*Football|NFL') { "NFL" }
                          elseif ($cat.category -match '(?i)Basketball') { "Basketball" }
                          else { "" }
            foreach ($st in $cat.streams) {
                $is247 = ($st.always_live -eq 1)
                if (-not $st.iframe) { continue }
                $chName = Translate-ToSpanish $st.name
                if (Test-IsExcludedSport -Name $chName -LeagueOrCategory ([string]$cat.category)) {
                    $script:SkippedSportsCount++
                    continue
                }
                $evWin = $null
                $isUpcoming = $false
                if (-not $is247) {
                    $stUtc = if ($st.starts_at -gt 0) { [DateTimeOffset]::FromUnixTimeSeconds([long]$st.starts_at).UtcDateTime } else { $null }
                    $repEndUtc = if ($st.ends_at -gt 0) { [DateTimeOffset]::FromUnixTimeSeconds([long]$st.ends_at).UtcDateTime } else { $null }
                    if ($stUtc -and $stUtc -gt [DateTime]::UtcNow.AddHours(24)) { continue }
                    $evWin = Get-AgendaEventWindowEvaluation -Title $chName -StartUtc $stUtc -ReportedEndUtc $repEndUtc -SportHint ([string]$cat.category)
                    if ($evWin.IsConcluded) {
                        $finalizedEvents += [PSCustomObject]@{ Name = $st.name; Url = $st.iframe; Reason = $evWin.Reason }
                        continue
                    }
                    $isUpcoming = $evWin.Upcoming
                }
                if ($st.source_tag -and $st.source_tag -notmatch '24/7') {
                    $chName += " ($($st.source_tag))"
                }
                if ($isUpcoming -and $evWin.KickTag) {
                    $chName += $evWin.KickTag
                }
                $ppvWorkItems.Add([PSCustomObject]@{
                    Name        = $chName
                    Slug        = $st.uri_name
                    Iframe      = $st.iframe
                    Upcoming    = $isUpcoming
                    Hint        = $ppvCatHint
                    StartsAtUtc = if ($evWin) { $evWin.StartsAtUtcStr } else { "" }
                    EndsAtUtc   = if ($evWin) { $evWin.EndsAtUtcStr } else { "" }
                })
            }
        }

        $ppvRes = Invoke-ParallelItems -Items @($ppvWorkItems) -ScriptBlock {
            param($it)
            try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
            $masterStream = $it.Iframe
            $keep = $true
            if ($it.Iframe -match 'embdlol\.st/embed/([a-zA-Z0-9-]+)') {
                $verifiedPpvHls = Resolve-EmbdlolWatchUrl -WatchId $Matches[1]
                if ($verifiedPpvHls) {
                    $masterStream = $verifiedPpvHls
                } elseif (-not $it.Upcoming) {
                    $keep = $false
                }
            } elseif ($it.Iframe -match '\.(?:m3u8|mpd)(?:\?|$)') {
                if (-not (Test-HlsDeepLive -Uri $it.Iframe -Referer "https://ppv.st/" -TimeoutSec 3 -SkipBlockCache)) {
                    $keep = $false
                }
            } else {
                $resolvedPpv = Resolve-EmbedAnyUrl -Url $it.Iframe -Referer "https://ppv.st/"
                if ($resolvedPpv) {
                    $masterStream = $resolvedPpv
                } elseif (-not $it.Upcoming) {
                    $embBody = Get-Utf8Content -Uri $it.Iframe -Referer "https://ppv.st/" -TimeoutSec 3
                    if (-not $embBody -or $embBody -match '(?i)404\s*Not\s*Found|STREAM\s*IS\s*OFFLINE|Evento\s*Finalizado|challenges\.cloudflare\.com') {
                        $keep = $false
                    }
                }
            }
            [PSCustomObject]@{ Item = $it; MasterUrl = $masterStream; Keep = $keep }
        }

        foreach ($pr in $ppvRes) {
            if (-not $pr.Keep) {
                $finalizedEvents += [PSCustomObject]@{ Name = $pr.Item.Name; Url = $pr.Item.Iframe; Reason = "Stream PPV sin segmentos activos" }
                continue
            }
            if (-not ($allChannels | Where-Object { $_.Name -eq $pr.Item.Name })) {
                $allChannels += [PSCustomObject]@{
                    Id          = "ppv_" + ($pr.Item.Slug -replace '[^a-zA-Z0-9]','')
                    Name        = $pr.Item.Name
                    Group       = Get-ChannelGroup $pr.Item.Name $pr.Item.Hint
                    Slug        = $pr.Item.Slug
                    MasterUrl   = $pr.MasterUrl
                    FallbackUrl = $pr.Item.Iframe
                    VpnRequired = $false
                    StartsAtUtc = $pr.Item.StartsAtUtc
                    EndsAtUtc   = $pr.Item.EndsAtUtc
                }
                Write-Host "   [+] $($pr.Item.Name) " -NoNewline -ForegroundColor Green
                if ($pr.MasterUrl -match '\.(?:m3u8|mpd)') {
                    Write-Host "[HLS Verificado | VPN No Necesaria]" -ForegroundColor DarkGreen
                } else {
                    Write-Host "[Programado / Embed | VPN No Necesaria]" -ForegroundColor DarkGreen
                }
            }
        }
    }
} catch {
    Write-Host "   [-] Servidor PPV.ST no accesible directamente: $($_.Exception.Message)" -ForegroundColor DarkGray
}

# -------------------------------------------------------------
# 3.2 SERVIDORES ABIERTOS DIRECTOS (FORMATURAMAXI CLUSTER & AZPLAY55)
# -------------------------------------------------------------
Enter-ScanPhase 'Formatura' $esModoVpn
Write-Host "`n [+] Analizando servidores multi-canal FormaturaMaxi y Azplay55 (sin VPN)..." -ForegroundColor Cyan

try {
    $openClusterItems = @(
        [PSCustomObject]@{ Id = "fmt_vix";    Name = "ViX Deportes HD";          Slug = "vix";      Src = "formaturamaxi"; Cands = @("https://admin2.formaturamaxi.com.br/vix.m3u8", "https://tedesco.formaturamaxi.com.br/vix.m3u8") },
        [PSCustomObject]@{ Id = "fmt_bein";   Name = "beIN Sports HD";           Slug = "bein";     Src = "formaturamaxi"; Cands = @("https://tedesco.formaturamaxi.com.br/bein.m3u8", "https://admin2.formaturamaxi.com.br/bein.m3u8") },
        [PSCustomObject]@{ Id = "fmt_sportv"; Name = "SporTV HD";                Slug = "sportv";   Src = "formaturamaxi"; Cands = @("https://tedesco.formaturamaxi.com.br/sportv.m3u8", "https://admin2.formaturamaxi.com.br/sportv.m3u8") },
        [PSCustomObject]@{ Id = "fmt_wwe";    Name = "WWE Network HD";           Slug = "wwe";      Src = "formaturamaxi"; Cands = @("https://admin2.formaturamaxi.com.br/wwe.m3u8", "https://tedesco.formaturamaxi.com.br/wwe.m3u8") },
        [PSCustomObject]@{ Id = "fmt_fs1";    Name = "FS1 HD (Fox Sports 1)";    Slug = "fs1";      Src = "formaturamaxi"; Cands = @("https://admin2.formaturamaxi.com.br/fs1.m3u8", "https://tedesco.formaturamaxi.com.br/fs1.m3u8") },
        [PSCustomObject]@{ Id = "fmt_fs2";    Name = "FS2 HD (Fox Sports 2)";    Slug = "fs2";      Src = "formaturamaxi"; Cands = @("https://admin2.formaturamaxi.com.br/fs2.m3u8", "https://tedesco.formaturamaxi.com.br/fs2.m3u8") },
        [PSCustomObject]@{ Id = "fmt_bbc";    Name = "BBC Sports HD";            Slug = "bbc";      Src = "formaturamaxi"; Cands = @("https://admin2.formaturamaxi.com.br/bbc.m3u8", "https://tedesco.formaturamaxi.com.br/bbc.m3u8") },
        [PSCustomObject]@{ Id = "az_ch1";     Name = "Azplay Deportes HD";       Slug = "azplay55"; Src = "azplay55";      Cands = @("https://a121.azplay55.me/hls/streama270459/index.m3u8?cst=bd218b08cab53c56f6bb20be1560042f") }
    )
    $cJoined = @($openClusterItems | ForEach-Object { ($_.Cands -join "`n") })
    $cRefs = [string[]]::new($openClusterItems.Count)
    $cOrigs = [string[]]::new($openClusterItems.Count)
    $cTms = [int[]]@(@(3500) * $openClusterItems.Count)
    $cSkip = [bool[]]@(@($true) * $openClusterItems.Count)
    $clusterLive = [AtomicFastHttp]::BatchPickFirstLive($cJoined, $cRefs, $cOrigs, $cTms, $cSkip, $UserAgent, 5)

    # Reintento suave para cualquier nodo temporalmente limitado por Cloudflare
    $retryIdx = [System.Collections.Generic.List[int]]::new()
    for ($ci = 0; $ci -lt $openClusterItems.Count; $ci++) {
        if (-not $clusterLive[$ci]) { $retryIdx.Add($ci) }
    }
    if ($retryIdx.Count -gt 0 -and $retryIdx.Count -lt $openClusterItems.Count) {
        Start-Sleep -Milliseconds 350
        $rJoined = @($retryIdx | ForEach-Object { $cJoined[$_] })
        $rRefs = [string[]]::new($retryIdx.Count)
        $rOrigs = [string[]]::new($retryIdx.Count)
        $rTms = [int[]]@(@(4200) * $retryIdx.Count)
        $rSkip = [bool[]]@(@($true) * $retryIdx.Count)
        $retryRes = [AtomicFastHttp]::BatchPickFirstLive($rJoined, $rRefs, $rOrigs, $rTms, $rSkip, $UserAgent, 3)
        for ($ri = 0; $ri -lt $retryIdx.Count; $ri++) {
            if ($retryRes[$ri]) { $clusterLive[$retryIdx[$ri]] = $retryRes[$ri] }
        }
    }

    $fmtHits = 0
    $azHits = 0
    for ($ci = 0; $ci -lt $openClusterItems.Count; $ci++) {
        $liveU = $clusterLive[$ci]
        $item = $openClusterItems[$ci]
        if (-not $liveU) { continue }
        if ($item.Src -eq "formaturamaxi") { $fmtHits++ } elseif ($item.Src -eq "azplay55") { $azHits++ }
        if (-not ($allChannels | Where-Object { $_.Name -eq $item.Name })) {
            $allChannels += [PSCustomObject]@{
                Id          = $item.Id
                Name        = $item.Name
                Group       = Get-ChannelGroup $item.Name ""
                Slug        = $item.Slug
                MasterUrl   = $liveU
                FallbackUrl = $item.Cands[0]
                VpnRequired = $false
            }
            Write-Host "   [+] $($item.Name) [HLS Directo Verificado | VPN No Necesaria]" -ForegroundColor DarkGreen
        }
    }
    if ($fmtHits -gt 0) { $script:FormaturaStatus = "ONLINE ($fmtHits HLS)" }
    if ($azHits -gt 0) { $script:AzplayStatus = "ONLINE ($azHits HLS)" }
} catch {
    Write-Host "   [-] Aviso analizando FormaturaMaxi / Azplay55: $($_.Exception.Message)" -ForegroundColor DarkGray
}

# -------------------------------------------------------------
# 4. EMISIONES OFICIALES RTVE Y TODA LA TDT ESPANA (PARALELO)
# -------------------------------------------------------------
Enter-ScanPhase 'RtveTdt' $esModoVpn
Write-Host "`n [+] Analizando y verificando toda la TDT España (RTVE, Generalistas y Autonómicas)..." -ForegroundColor Cyan

function Get-NormalizedTdtKey {
    <# Normaliza nombres de canales TDT españoles para deduplicar variantes entre fuentes. #>
    param([string]$RawName)
    if ([string]::IsNullOrWhiteSpace($RawName)) { return "" }
    $x = $RawName.ToLowerInvariant()
    $x = $x -replace '\s*\[[^\]]*\]', ''
    $x = $x -replace '\s*\((?:1080p|720p|576p|480p|360p|404p|416p|spain|originals|es|hd|sd|uhd|4k)\)', ''
    $x = $x -replace '\s*\([^)]*\)', ''
    $formD = $x.Normalize([System.Text.NormalizationForm]::FormD)
    $sb = [System.Text.StringBuilder]::new()
    foreach ($ch in $formD.ToCharArray()) {
        if ([System.Globalization.CharUnicodeInfo]::GetUnicodeCategory($ch) -ne [System.Globalization.UnicodeCategory]::NonSpacingMark) {
            [void]$sb.Append($ch)
        }
    }
    $clean = ($sb.ToString() -replace '\b(full|hd|sd|uhd|4k|tv|television|telebista|originals)\b', '' -replace '[^a-z0-9]', '')
    $clean = $clean -replace '^(?:rtveplay|rtve)(?=.{3,})', ''
    switch -Regex ($clean) {
        '^24h$|^24horas$|^canal24horas$' { return '24horas' }
        '^24hcatalunya$|^24horascatalunya$' { return '24horascatalunya' }
        '^24hcanarias$|^24horascanarias$' { return '24horascanarias' }
        '^la1$' { return 'la1' }
        '^la2$' { return 'la2' }
        '^la1catalunya$' { return 'la1catalunya' }
        '^la1canarias$' { return 'la1canarias' }
        '^la2canarias$' { return 'la2canarias' }
        '^teledeporte$|^tdp$' { return 'teledeporte' }
        '^clan$' { return 'clan' }
        '^7tv$|^7tvandalucia$' { return '7tvandalucia' }
        '^canalsurandalucia$|^canalsur$' { return 'canalsurandalucia' }
        '^canalsur2(?:accesible)?$' { return 'canalsur2' }
        '^canalsurmasnoticias$|^canalsurnoticias$' { return 'canalsurnoticias' }
        '^canal7televalencia$|^7televalencia$' { return '7televalencia' }
        '^tvg2$' { return 'tvg2' }
        '^cmm$|^castillalamanchamedia$' { return 'cmm' }
        '^tvcanaria$|^canaria$' { return 'tvcanaria' }
        '^eltoro$' { return 'eltoro' }
        '^apunt$' { return 'apunt' }
        '^telemadrid$' { return 'telemadrid' }
        '^punt3(?:valluixo)?$' { return 'punt3' }
        '^realmadrid(?:espanol|espanaabiertodeportes|english)?$' { return 'realmadrid' }
        '^larevuelta$' { return 'larevuelta' }
        '^somoscine$' { return 'somoscine' }
        '^70anos$' { return 'rtve70anos' }
        '^conciertosradio3$|^radio3$' { return 'conciertosradio3' }
        '^12(?:alicante)?$' { return '12tvalicante' }
        '^antena3$' { return 'antena3' }
        '^lasexta$|^la6$' { return 'lasexta' }
        '^neox$' { return 'neox' }
        '^nova$' { return 'nova' }
        '^mega$' { return 'mega' }
        '^atreseries$|^a3series$' { return 'atreseries' }
        '^telecinco$|^tele5$' { return 'telecinco' }
        '^cuatro$' { return 'cuatro' }
        '^fdf$|^factoriadeficcion$' { return 'fdf' }
        '^boing$' { return 'boing' }
        '^energy$' { return 'energy' }
        '^divinity$' { return 'divinity' }
        '^bemad$' { return 'bemad' }
        default { return $clean }
    }
}

$tdtDynamicMap = @{}
$tdtCatalog = [ordered]@{}

function Add-TdtCatalogEntry {
    <# Registra o combina candidatos HLS en el catálogo TDT filtrando radios y ruido extranjero. #>
    param([string]$DisplayName, [string]$GroupName, [string]$AmbitLabel, [string[]]$Urls, [bool]$AllowNew = $true)
    if ([string]::IsNullOrWhiteSpace($DisplayName) -or -not $Urls -or $Urls.Count -eq 0) { return }
    if ($DisplayName -match '(?i)^(?:Radio\s+(?:Nacional|5|4|3|Cl[aá]sica|Exterior|Castilla)|R[aà]dio\s+\d+|Canal\s+Fiesta\s+Radio|Onda\s+Madrid\b|RNE\s+para\s+todos|Castilla-La\s+Mancha\s+Radio|Euskadi\s+Irratia|Radio\s+Euskadi|Radio\s+Galega(?:\s|$))') { return }
    if (Test-IsExcludedSport $DisplayName) { return }
    if ($DisplayName -match '\((?:Germany|France|UK|US|USA|Italy|Portugal|Netherlands|LATAM|Poland|Brazil|Russia)\)') { return }

    $key = Get-NormalizedTdtKey $DisplayName
    if (-not $key) { return }
    if (-not $AllowNew -and -not $tdtCatalog.Contains($key)) { return }

    if (-not $tdtDynamicMap.ContainsKey($DisplayName.Trim())) {
        $tdtDynamicMap[$DisplayName.Trim()] = $Urls
    }
    if (-not $tdtCatalog.Contains($key)) {
        $tdtCatalog[$key] = [PSCustomObject]@{
            Key   = $key
            Name  = $DisplayName.Trim()
            Group = $GroupName
            Ambit = $AmbitLabel
            Urls  = [System.Collections.Generic.List[string]]::new()
        }
    }
    foreach ($rawU in $Urls) {
        $cleanU = ($rawU -replace '&avod=.*$', '').Trim()
        # Omitir plantillas SSAI con macros sin resolver (ej. [CACHEBUSTER], [IP]) que devuelven 400
        if ($cleanU -match '^https?://' -and $cleanU -notmatch '\[[A-Z0-9_]{2,}\]' -and $cleanU -notmatch '\.(?:mpd|mp4|mkv)(?:\?|$)' -and -not $tdtCatalog[$key].Urls.Contains($cleanU)) {
            $tdtCatalog[$key].Urls.Add($cleanU)
        }
    }
}

# 4.1 Fuente oficial TDTChannels (Nacionales, Generalistas, Informativos, Infantiles, Deportivos y 19 Autonómicas)
try {
    $tdtJsonTxt = if ($script:Prefetched["TdtJson"]) { $script:Prefetched["TdtJson"] } else { Get-Utf8Content -Uri "https://www.tdtchannels.com/lists/tv.json" -TimeoutSec 5 }
    if ($tdtJsonTxt) {
        $tdtParsed = $tdtJsonTxt | ConvertFrom-Json
        $spainCountry = $tdtParsed.countries | Where-Object { $_.name -eq "Spain" }
        foreach ($amb in $spainCountry.ambits) {
            foreach ($tc in $amb.channels) {
                $m3uOpts = @($tc.options | Where-Object { $_.format -eq "m3u8" -and $_.url -match '^https?://' } | ForEach-Object { $_.url -replace '&avod=.*$', '' })
                if ($m3uOpts.Count -gt 0 -and $tc.name) {
                    $cName = $tc.name.Trim()
                    $cGroup = if ($cName -match '(?i)Real\s*Madrid\s*TV') { "Deportes España" } else { "TDT España" }
                    Add-TdtCatalogEntry -DisplayName $cName -GroupName $cGroup -AmbitLabel $amb.name -Urls $m3uOpts -AllowNew $true
                }
            }
        }
    }
} catch {}

# 4.2 Respaldo y ampliación desde IPTV-Org España (desbloquea Telemadrid HD, DMAX, El 33, Esport3 int, TVG Europa, etc.)
try {
    $iptvEsTxt = if ($script:Prefetched["IptvEs"]) { $script:Prefetched["IptvEs"] } else { Get-Utf8Content -Uri "https://iptv-org.github.io/iptv/countries/es.m3u" -TimeoutSec 5 }
    if ($iptvEsTxt) {
        $curName = $null; $curGrp = ""
        foreach ($rawLine in ($iptvEsTxt -split "`r?`n")) {
            $ln = $rawLine.Trim()
            if ($ln -match '^#EXTINF:.*group-title="([^"]*)"[^,]*,(.*)$') {
                $curGrp = $Matches[1]; $curName = $Matches[2].Trim()
            } elseif ($ln -match '^#EXTINF:[^,]*,(.*)$') {
                $curGrp = ""; $curName = $Matches[1].Trim()
            } elseif ($ln -match '^https?://' -and $curName) {
                $dispName = ($curName -replace '\s*\[[^\]]*\]', '' -replace '\s*\((?:1080p|720p|576p|480p|360p|404p|416p|Spain|Originals)\)', '' -replace '\s{2,}', ' ').Trim()
                $dispName = $dispName -replace '(?i)\bFrance 24 Spanish\b', 'France 24 Español' -replace '(?i)\bEurosport (\d) Spain\b', 'Eurosport $1 España HD'
                $isSpainTdtExtra = $dispName -match '(?i)Telemadrid|LaOtra|DMAX|El 33|TV3CAT|Galicia TV|Arag[oó]n|IB3|\bTPA\b|CyLTV|7RM|Navarra TV|Sol M[uú]sica|Historia|BBC Drama|Cine Friki|Cine Western|Todo Novelas|France 24|FIFA\+|Red Bull|MyTime|Rakuten TV|The Pet Collective|En el punto de mira|Eurosport|Gol Play|TeleValencia'
                $tGroup = if ($dispName -match '(?i)Eurosport|Real\s*Madrid\s*TV') { "Deportes España" } else { "TDT España" }
                Add-TdtCatalogEntry -DisplayName $dispName -GroupName $tGroup -AmbitLabel ("TDT/" + $(if ($curGrp) { $curGrp } else { "España" })) -Urls @($ln) -AllowNew $isSpainTdtExtra
                $curName = $null
            }
        }
    }
} catch {}

$rtveStreams = @(
    @{ Name = "RTVE La 1 Full HD (1080p · Señal Oficial)"; Group = "TDT España"; TdtKey = "La 1"; Urls = @("https://lge-lgla2.otteravision.com/lge/lgla1/lgla1.m3u8", "https://stream.ads.ottera.tv/playlist.m3u8?network_id=15619", "https://rtvelivestream.rtve.es/rtvesec/la1/la1_main_dvr.m3u8") },
    @{ Name = "RTVE La 1 HD (Señal Oficial Multi-Audio)"; Group = "TDT España"; TdtKey = ""; Urls = @("https://rtvelivestream.rtve.es/rtvesec/la1/la1_main_dvr.m3u8", "https://ztnr.rtve.es/ztnr/1688877.m3u8") },
    @{ Name = "Teledeporte RTVE Full HD (1080p · Deportes)"; Group = "TDT España"; TdtKey = "Teledeporte"; Urls = @("https://lge-lgla2.otteravision.com/lge/lgtdp/lgtdp.m3u8", "https://stream.ads.ottera.tv/playlist.m3u8?network_id=15601", "https://rtvelivestream.rtve.es/rtvesec/tdp/tdp_main_dvr.m3u8") },
    @{ Name = "Teledeporte RTVE Full HD (Espejo Oficial Ottera)"; Group = "TDT España"; TdtKey = ""; Urls = @("https://stream.ads.ottera.tv/playlist.m3u8?network_id=15601") },
    @{ Name = "RTVE La 2 Full HD (1080p · España Directo)"; Group = "TDT España"; TdtKey = "La 2"; Urls = @("https://lge-lgla2.otteravision.com/lge/lgla2/lgla2.m3u8", "https://stream.ads.ottera.tv/playlist.m3u8?network_id=15618", "https://rtvelivestream.rtve.es/rtvesec/la2/la2_main_dvr.m3u8") },
    @{ Name = "RTVE La 2 HD (Señal Oficial Multi-Audio)"; Group = "TDT España"; TdtKey = ""; Urls = @("https://rtvelivestream.rtve.es/rtvesec/la2/la2_main_dvr.m3u8", "https://ztnr.rtve.es/ztnr/1688885.m3u8") },
    @{ Name = "RTVE Canal 24 Horas Full HD (1080p · Noticias)"; Group = "TDT España"; TdtKey = "24h"; Urls = @("https://lge-lgla2.otteravision.com/lge/lg24h/lg24h.m3u8", "https://stream.ads.ottera.tv/playlist.m3u8?network_id=15621", "https://rtvelivestream.rtve.es/rtvesec/24h/24h_main_dvr.m3u8") },
    @{ Name = "RTVE Clan Full HD (1080p · España Directo)"; Group = "TDT España"; TdtKey = "Clan"; Urls = @("https://lge-lgla2.otteravision.com/lge/lgcla/lgcla.m3u8", "https://stream.ads.ottera.tv/playlist.m3u8?network_id=15620", "https://rtvelivestream.rtve.es/rtvesec/clan/clan_main_dvr.m3u8") },
    @{ Name = "RTVE La 1 Catalunya HD"; Group = "TDT España"; TdtKey = "La 1 Catalunya"; Urls = @("https://rtvelivestream.rtve.es/rtvesec/cat/la1_cat_main_dvr.m3u8", "https://ztnr.rtve.es/ztnr/3293681.m3u8") },
    @{ Name = "RTVE 24h Catalunya HD"; Group = "TDT España"; TdtKey = "24h Catalunya"; Urls = @("https://rtvelivestream.rtve.es/rtvesec/cat/24h_cat_main_dvr.m3u8", "https://ztnr.rtve.es/ztnr/4952053.m3u8") },
    @{ Name = "RTVE La 2 Canarias HD"; Group = "TDT España"; TdtKey = "La 2 Canarias"; Urls = @("https://rtvelivestream.rtve.es/rtvesec/can/la2_can_main_dvr.m3u8", "https://ztnr.rtve.es/ztnr/5468585.m3u8") },
    @{ Name = "RTVE 24h Canarias HD"; Group = "TDT España"; TdtKey = "24h Canarias"; Urls = @("https://rtvelivestream.rtve.es/rtvesec/can/24h_can_main_dvr.m3u8", "https://ztnr.rtve.es/ztnr/5473142.m3u8") },
    @{ Name = "RTVE La 1 Canarias HD"; Group = "TDT España"; TdtKey = "La 1 Canarias"; Urls = @("https://rtvelivestream.rtve.es/rtvesec/can/la1_can_main_dvr.m3u8", "https://ztnr.rtve.es/ztnr/5190066.m3u8") },
    @{ Name = "Star TVE HD (1080p · RTVE)"; Group = "TDT España"; TdtKey = ""; Urls = @("https://rtvelivestream-rtveplayplus.rtve.es/rtvesec/int/star_main_1080.m3u8", "https://rtvelivestream.rtve.es/rtvesec/int/star_main.m3u8") },
    @{ Name = "TVE Internacional Europa HD (1080p · RTVE)"; Group = "TDT España"; TdtKey = ""; Urls = @("https://rtvelivestream-rtveplayplus.rtve.es/rtvesec/int/tvei_eu_main_1080.m3u8", "https://rtvelivestream.rtve.es/rtvesec/int/tvei_eu_main.m3u8") },
    @{ Name = "RTVE Play: Señal Eventual Directo (OCA / Eventos)"; Group = "TDT España"; TdtKey = ""; Urls = @("https://ztnr.rtve.es/ztnr/17303384.m3u8", "https://rtvelivestream.rtve.es/eventual/gofast/playm29_main_dvr.m3u8") },
    @{ Name = "RTVE Play: La Revuelta 24h HD"; Group = "TDT España"; TdtKey = "La Revuelta (RTVE)"; Urls = @("https://ztnr.rtve.es/ztnr/16464388.m3u8", "https://rtvelivestream.rtve.es/eventual/gofast/playm5_main_dvr.m3u8") },
    @{ Name = "RTVE Play: Somos Cine HD"; Group = "TDT España"; TdtKey = "Somos Cine (RTVE)"; Urls = @("https://ztnr.rtve.es/ztnr/6909845.m3u8", "https://rtvelivestream.rtve.es/eventual/gofast/playm6_main_dvr.m3u8") },
    @{ Name = "RTVE Play: RTVE 70 Años HD"; Group = "TDT España"; TdtKey = "RTVE 70 años (RTVE)"; Urls = @("https://ztnr.rtve.es/ztnr/17232941.m3u8", "https://rtvelivestream.rtve.es/eventual/gofast/playm28_main_dvr.m3u8") },
    @{ Name = "RTVE Play: Conciertos Radio 3 HD"; Group = "TDT España"; TdtKey = "Conciertos Radio 3 (RTVE)"; Urls = @("https://ztnr.rtve.es/ztnr/6924117.m3u8", "https://rtvelivestream.rtve.es/eventual/gofast/playm11_main_dvr.m3u8") },
    @{ Name = "Real Madrid TV España HD (Abierto TDT / Deportes)"; Group = "Deportes España"; TdtKey = "Real Madrid TV"; Urls = @("https://rmtv.akamaized.net/hls/live/2043153/rmtv-es-web/master.m3u8") }
)

$coveredTdtKeys = @{}
$rtveWorkItems = [System.Collections.Generic.List[PSCustomObject]]::new()

foreach ($rtve in $rtveStreams) {
    $candidates = [System.Collections.Generic.List[string]]::new()
    foreach ($u in $rtve.Urls) { if (-not $candidates.Contains($u)) { $candidates.Add($u) } }
    $kName = Get-NormalizedTdtKey $rtve.Name
    if ($kName) { $coveredTdtKeys[$kName] = $true }
    if ($rtve.TdtKey) {
        $kTdt = Get-NormalizedTdtKey $rtve.TdtKey
        if ($kTdt) {
            $coveredTdtKeys[$kTdt] = $true
            if ($tdtCatalog.Contains($kTdt)) {
                foreach ($du in $tdtCatalog[$kTdt].Urls) { if (-not $candidates.Contains($du)) { $candidates.Add($du) } }
            }
        }
        if ($tdtDynamicMap.ContainsKey($rtve.TdtKey)) {
            foreach ($du in $tdtDynamicMap[$rtve.TdtKey]) { if (-not $candidates.Contains($du)) { $candidates.Add($du) } }
        }
    }
    $rtveWorkItems.Add([PSCustomObject]@{
        Name        = $rtve.Name
        Group       = $rtve.Group
        IsCurated   = $true
        Prefix      = "rtve_"
        Slug        = "rtve"
        Ambit       = "RTVE/Curado"
        Candidates  = @($candidates)
        Referer     = $null
        Origin      = $null
        FallbackUrl = $null
    })
}

# 4.2b Canales Oficiales Atresmedia (6) y Mediaset Infinity (7) - Resolucion Directa en Paralelo
$atresMediasetDefs = @(
    @{ Name = "Antena 3 HD (Atresmedia)"; Kind = "ATRES"; ChannelId = "5a6a165a7ed1a834493ebf6a"; DashSlug = "a3"; WebUrl = "https://www.atresplayer.com/directos/antena3/"; TdtKey = "Antena 3"; Ambit = "Atresmedia" },
    @{ Name = "laSexta HD (Atresmedia)"; Kind = "ATRES"; ChannelId = "5a6a172c7ed1a834493ebf6b"; DashSlug = "la6"; WebUrl = "https://www.atresplayer.com/directos/lasexta/"; TdtKey = "laSexta"; Ambit = "Atresmedia" },
    @{ Name = "Neox HD (Atresmedia)"; Kind = "ATRES"; ChannelId = "5a6a17da7ed1a834493ebf6d"; DashSlug = "neox"; WebUrl = "https://www.atresplayer.com/directos/neox/"; TdtKey = "Neox"; Ambit = "Atresmedia" },
    @{ Name = "Nova HD (Atresmedia)"; Kind = "ATRES"; ChannelId = "5a6a180b7ed1a834493ebf6e"; DashSlug = "nova"; WebUrl = "https://www.atresplayer.com/directos/nova/"; TdtKey = "Nova"; Ambit = "Atresmedia" },
    @{ Name = "Mega HD (Atresmedia)"; Kind = "ATRES"; ChannelId = "5a6a18357ed1a834493ebf6f"; DashSlug = "mega"; WebUrl = "https://www.atresplayer.com/directos/mega/"; TdtKey = "Mega"; Ambit = "Atresmedia" },
    @{ Name = "Atreseries HD (Atresmedia)"; Kind = "ATRES"; ChannelId = "5a6a189a7ed1a834493ebf70"; DashSlug = "a3s"; WebUrl = "https://www.atresplayer.com/directos/atreseries/"; TdtKey = "Atreseries"; Ambit = "Atresmedia" },
    @{ Name = "Telecinco HD (Mediaset)"; Kind = "MEDIASET"; ChannelId = "1A_glPdnQl-73hH4bqX_qw"; TdtKey = "Telecinco"; Ambit = "Mediaset" },
    @{ Name = "Cuatro HD (Mediaset)"; Kind = "MEDIASET"; ChannelId = "Kij3D1mCTmCxREg3up5wFQ"; TdtKey = "Cuatro"; Ambit = "Mediaset" },
    @{ Name = "FDF HD (Mediaset)"; Kind = "MEDIASET"; ChannelId = "K5OUSWF1QzGErl9IuIXylQ"; TdtKey = "FDF"; Ambit = "Mediaset" },
    @{ Name = "Boing HD (Mediaset)"; Kind = "MEDIASET"; ChannelId = "QbTIwdz1RY65VnwaRUqVpw"; TdtKey = "Boing"; Ambit = "Mediaset" },
    @{ Name = "Energy HD (Mediaset)"; Kind = "MEDIASET"; ChannelId = "ZAmhN5-CSZaYSUOace_wqg"; TdtKey = "Energy"; Ambit = "Mediaset" },
    @{ Name = "Divinity HD (Mediaset)"; Kind = "MEDIASET"; ChannelId = "6VdMDLi3RguDzjhzdAmYVg"; TdtKey = "Divinity"; Ambit = "Mediaset" },
    @{ Name = "Be Mad HD (Mediaset)"; Kind = "MEDIASET"; ChannelId = "FvDPm89zStmjCBf66D5yow"; TdtKey = "Be Mad"; Ambit = "Mediaset" }
)

Write-Host "   [*] Resolviendo emisiones en directo de Atresmedia (6) y Mediaset (7)..." -ForegroundColor DarkCyan
$amResolved = Invoke-ParallelItems -Items $atresMediasetDefs -ScriptBlock {
    param($def)
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
    $ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    $urls = [System.Collections.Generic.List[string]]::new()
    $lowName = [string]$def.Name.ToLowerInvariant()
    $avatelSlug = $null
    $avatelAlt = $null
    if ($lowName -match 'antena 3') { $avatelSlug = 'antena3'; $avatelAlt = 'antena3hd' }
    elseif ($lowName -match 'lasexta') { $avatelSlug = 'lasexta' }
    elseif ($lowName -match 'neox') { $avatelSlug = 'neox' }
    elseif ($lowName -match 'nova') { $avatelSlug = 'nova' }
    elseif ($lowName -match 'mega') { $avatelSlug = 'mega' }
    elseif ($lowName -match 'atreseries') { $avatelSlug = 'atreseries' }
    elseif ($lowName -match 'telecinco') { $avatelSlug = 'telecinco'; $avatelAlt = 'telecincohd' }
    elseif ($lowName -match 'cuatro') { $avatelSlug = 'cuatrohd'; $avatelAlt = 'cuatro' }
    elseif ($lowName -match 'boing') { $avatelSlug = 'boing' }
    elseif ($lowName -match 'energy') { $avatelSlug = 'energy' }
    elseif ($lowName -match 'divinity') { $avatelSlug = 'divinity' }
    elseif ($lowName -match 'be mad|bemad') { $avatelSlug = 'bemad' }
    elseif ($lowName -match 'fdf') { $avatelSlug = 'fdf' }

    if ($avatelSlug) { $urls.Add("http://90.170.214.40:9700/stream/avatel/$avatelSlug/master.m3u8") }
    if ($avatelAlt) { $urls.Add("http://90.170.214.40:9700/stream/avatel/$avatelAlt/master.m3u8") }
    $ref = $null
    $orig = $null
    $fb = $null
    try {
        if ($def.Kind -eq "ATRES") {
            if ($def.DashSlug) {
                $urls.Add("https://ignac16.github.io/voxel-tv-streams/$($def.DashSlug).mpd")
                $urls.Add("https://cdn.jsdelivr.net/gh/Ignac16/voxel-tv@main/src/constants/channels/$($def.DashSlug).mpd")
            }
            try {
                $rawA3 = [AtomicFastHttp]::GetUtf8(("https://api.atresplayer.com/player/v1/live/" + $def.ChannelId), "https://www.atresplayer.com/", "https://www.atresplayer.com", $ua, 1800)
                if ($rawA3) {
                    $resp = $rawA3 | ConvertFrom-Json
                    foreach ($s in $resp.sourcesLive) {
                        if ($s.src -and ($s.type -match 'mpegurl|dash' -or $s.src -match '\.(?:m3u8|mpd)')) {
                            $urls.Add([string]$s.src)
                        }
                    }
                }
            } catch {}
            if ($def.WebUrl) { $fb = [string]$def.WebUrl }
        } elseif ($def.Kind -eq "MEDIASET") {
            $daiEp = "https://dai.google.com/linear/v1/hls/event/$($def.ChannelId)/stream"
            $hdr = @{ "User-Agent" = $ua; "Origin" = "https://www.mediasetinfinity.es"; "Referer" = "https://www.mediasetinfinity.es/" }
            $daiResp = Invoke-RestMethod -Uri $daiEp -Method Post -Body "" -ContentType "application/x-www-form-urlencoded" -Headers $hdr -TimeoutSec 3 -ErrorAction Stop
            if ($daiResp.stream_manifest) {
                $mUrl = [string]$daiResp.stream_manifest
                $mTxt = [AtomicFastHttp]::GetUtf8($mUrl, "https://www.mediasetinfinity.es/", "https://www.mediasetinfinity.es", $ua, 2500)
                if ($mTxt) {
                    $lines = $mTxt -split "`r?`n"
                    $bestUrl = $mUrl
                    $bestBw = -1
                    for ($i = 0; $i -lt $lines.Count; $i++) {
                        if ($lines[$i] -match '^#EXT-X-STREAM-INF:.*BANDWIDTH=(\d+)') {
                            $bw = [int64]$Matches[1]
                            if ($lines[$i] -match 'CODECS="mp4a' -and $lines[$i] -notmatch 'RESOLUTION=') { continue }
                            $nextLine = if ($i + 1 -lt $lines.Count) { $lines[$i + 1].Trim() } else { "" }
                            if ($nextLine -and $nextLine -notmatch '^#' -and $bw -gt $bestBw) {
                                $bestBw = $bw
                                $bestUrl = if ($nextLine -match '^https?://') { $nextLine } else { ([uri]::new([uri]$mUrl, $nextLine)).AbsoluteUri }
                            }
                        }
                    }
                    $urls.Add($bestUrl)
                    $ref = "https://www.mediasetinfinity.es/"
                    $orig = "https://www.mediasetinfinity.es"
                    $fb = $daiEp
                }
            }
        }
    } catch {}
    [PSCustomObject]@{ Def = $def; Urls = @($urls); Referer = $ref; Origin = $orig; FallbackUrl = $fb }
}

foreach ($amr in $amResolved) {
    $d = $amr.Def
    $cands = [System.Collections.Generic.List[string]]::new()
    foreach ($u in $amr.Urls) { if ($u -and -not $cands.Contains($u)) { $cands.Add($u) } }
    $kTdt = Get-NormalizedTdtKey $d.TdtKey
    if ($kTdt) {
        $coveredTdtKeys[$kTdt] = $true
        if ($tdtCatalog.Contains($kTdt)) {
            foreach ($du in $tdtCatalog[$kTdt].Urls) { if (-not $cands.Contains($du)) { $cands.Add($du) } }
        }
    }
    if ($cands.Count -gt 0) {
        $rtveWorkItems.Add([PSCustomObject]@{
            Name        = $d.Name
            Group       = "TDT España"
            IsCurated   = $true
            Prefix      = "tdt_"
            Slug        = "tdt"
            Ambit       = $d.Ambit
            Candidates  = @($cands)
            Referer     = $amr.Referer
            Origin      = $amr.Origin
            FallbackUrl = $amr.FallbackUrl
        })
    }
}

foreach ($entry in $tdtCatalog.Values) {
    if ($coveredTdtKeys.ContainsKey($entry.Key) -or $entry.Urls.Count -eq 0) { continue }
    $coveredTdtKeys[$entry.Key] = $true
    $sortedUrls = @($entry.Urls | Sort-Object { if ($_ -match 'getpublica\.com|ads\.ottera\.tv') { 1 } else { 0 } } | Select-Object -First 2)
    $rtveWorkItems.Add([PSCustomObject]@{
        Name        = $entry.Name
        Group       = $entry.Group
        IsCurated   = $false
        Prefix      = "tdt_"
        Slug        = "tdt"
        Ambit       = $entry.Ambit
        Candidates  = $sortedUrls
        Referer     = $null
        Origin      = $null
        FallbackUrl = $null
    })
}

Write-Host ("   [*] Validando segmentos reales en {0} canales RTVE, Atresmedia, Mediaset y TDT España..." -f $rtveWorkItems.Count) -ForegroundColor DarkCyan

$rtveN = $rtveWorkItems.Count
$rtveCands = [string[]]::new($rtveN)
$rtveRefs = [string[]]::new($rtveN)
$rtveOrigs = [string[]]::new($rtveN)
$rtveTms = [int[]]::new($rtveN)
$rtveSkips = [bool[]]::new($rtveN)
for ($ri = 0; $ri -lt $rtveN; $ri++) {
    $wit = $rtveWorkItems[$ri]
    $rtveCands[$ri] = ($wit.Candidates -join "`n")
    $rtveRefs[$ri] = [string]$wit.Referer
    $rtveOrigs[$ri] = [string]$wit.Origin
    $rtveTms[$ri] = if ($wit.IsCurated) { 2500 } else { 1700 }
    $rtveSkips[$ri] = ([bool]$wit.IsCurated -and $wit.Ambit -ne "Atresmedia")
}
$rtvePicked = [AtomicFastHttp]::BatchPickFirstLive($rtveCands, $rtveRefs, $rtveOrigs, $rtveTms, $rtveSkips, $UserAgent, 96)
$rtveRes = for ($ri = 0; $ri -lt $rtveN; $ri++) {
    [PSCustomObject]@{ Item = $rtveWorkItems[$ri]; Url = $rtvePicked[$ri] }
}

$tdtAddedCount = 0
$seenTdtOutNames = @{}
foreach ($rr in $rtveRes) {
    if ($rr.Url) {
        $chKey = $rr.Item.Name.ToLowerInvariant()
        if (-not $seenTdtOutNames.ContainsKey($chKey) -and -not ($allChannels | Where-Object { $_.Name -eq $rr.Item.Name })) {
            $seenTdtOutNames[$chKey] = $true
            $prefix = if ($rr.Item.Prefix) { $rr.Item.Prefix } elseif ($rr.Item.IsCurated) { "rtve_" } else { "tdt_" }
            $slugVal = if ($rr.Item.Slug) { $rr.Item.Slug } elseif ($rr.Item.IsCurated) { "rtve" } else { "tdt" }
            $chObj = [PSCustomObject]@{
                Id          = $prefix + ($rr.Item.Name -replace '[^a-zA-Z0-9]','')
                Name        = $rr.Item.Name
                Group       = $rr.Item.Group
                Slug        = $slugVal
                MasterUrl   = $rr.Url
                VpnRequired = $false
            }
            if ($rr.Item.FallbackUrl) {
                $chObj | Add-Member -NotePropertyName 'FallbackUrl' -NotePropertyValue $rr.Item.FallbackUrl
            }
            $allChannels += $chObj
            if ($rr.Item.IsCurated) {
                $lblKind = if ($rr.Item.Ambit -in @("Atresmedia", "Mediaset")) { $rr.Item.Ambit } else { "Sin VPN" }
                Write-Host "   [+] $($rr.Item.Name) [200 OK - Segmentos Verificados | $lblKind]" -ForegroundColor DarkGreen
            } else {
                $tdtAddedCount++
                if ($rr.Item.Ambit -in @('Generalistas', 'Informativos', 'Deportivos', 'Infantiles', 'Eventuales') -or $rr.Item.Name -match '(?i)Telemadrid|DMAX|Canal Sur|TV3|El 33|Esport3|À Punt|ETB|TVG|Galicia TV|CMM|Canaria|Extremadura|Sol M[uú]sica|Historia') {
                    Write-Host "   [+] $($rr.Item.Name) [$($rr.Item.Ambit) · 200 OK | TDT España]" -ForegroundColor DarkGreen
                }
            }
        }
    } elseif ($rr.Item.IsCurated) {
        $finalizedEvents += [PSCustomObject]@{
            Name   = $rr.Item.Name
            Url    = $rr.Item.Candidates[0]
            Reason = "Señal TDT con restricción CDN/geo desde esta IP"
        }
        Write-Host "   [-] $($rr.Item.Name) [Segmentos bloqueados (403 CDN) - Omitido]" -ForegroundColor DarkGray
    }
}
Write-Host ("   [OK] Toda la TDT España integrada: +{0} canales adicionales abiertos y autonómicos con segmentos verificados." -f $tdtAddedCount) -ForegroundColor Green

$script:RedxEsStatus = "STANDBY"
if ($true) {
    $redxOpenDefs = @(
        @{ Name = "DAZN 1 España HD"; Code = "dazn1"; Group = "Deportes España" },
        @{ Name = "Eurosport 1 España HD"; Code = "eurosport1"; Group = "Deportes España" },
        @{ Name = "Eurosport 2 España HD"; Code = "eurosport2"; Group = "Deportes España" },
        @{ Name = "M+ LaLiga"; Code = "mlaliga"; Group = "Fútbol España" },
        @{ Name = "Movistar+ Deportes"; Code = "mdeportes"; Group = "Deportes España" },
        @{ Name = "Movistar+ Golf"; Code = "mgolf"; Group = "Deportes España" },
        @{ Name = "DAZN F1 España (Opción 1)"; Code = "daznf1"; Group = "F1 España" },
        @{ Name = "Nat Geo Wild HD (España)"; Code = "natgeowild"; Group = "Documentales y Cultura España" }
    )
    $redxOpenRes = Invoke-ParallelItems -Items $redxOpenDefs -ScriptBlock {
        param($it)
        $u = Resolve-RedxEsUrl -StreamSlug $it.Code
        if ($u) { return [PSCustomObject]@{ Def = $it; Url = $u } }
        return $null
    }
    $redxOpenHits = 0
    foreach ($rx in $redxOpenRes) {
        if ($rx -and $rx.Url -and -not ($allChannels | Where-Object { $_.Name -eq $rx.Def.Name })) {
            $allChannels += [PSCustomObject]@{
                Id          = "redx_" + $rx.Def.Code
                Name        = $rx.Def.Name
                Group       = $rx.Def.Group
                Slug        = "redx_" + $rx.Def.Code
                MasterUrl   = $rx.Url
                FallbackUrl = $rx.Url
                VpnRequired = $false
            }
            $redxOpenHits++
            Write-Host "   [+] $($rx.Def.Name) [RedX HD Directo | Abierto]" -ForegroundColor DarkGreen
        }
    }
    $script:RedxEsStatus = if ($redxOpenHits -gt 0) { "ONLINE ($redxOpenHits HD)" } else { "OFFLINE" }
}

# -------------------------------------------------------------
# 4. ESCANEO DE TODOS LOS SERVIDORES Y CANALES (CON Y SIN VPN)
# -------------------------------------------------------------
if ($true) {
    Write-Host "`n [+] Sincronizando todos los servidores y canales (100% fuentes en paralelo)..." -ForegroundColor Cyan

    # Descubrimiento anticipado de host España activo (desde pre-descarga paralela)
    $workingStreamxHost = $null
    if ($script:Prefetched["ProbeSx723"]) {
        $workingStreamxHost = "streamx723.sbs"
        $global:ActiveStreamxHost = "streamx723.sbs"
    } elseif ($script:Prefetched["ProbeSx061"]) {
        $workingStreamxHost = "streamx061.sbs"
        $global:ActiveStreamxHost = "streamx061.sbs"
    } else {
        $streamxCandidates = @("streamx723.sbs", $global:ActiveStreamxHost, "streamx061.sbs") | Select-Object -Unique
        foreach ($candHost in $streamxCandidates) {
            if (-not $candHost -or ($global:BlockedHosts -and $global:BlockedHosts.ContainsKey($candHost))) { continue }
            $probeTxt = Get-Utf8Content -Uri "https://$candHost/global3.php?channel=mlaliga" -Referer "https://cdplay.live/" -TimeoutSec 2
            if ($probeTxt) {
                $workingStreamxHost = $candHost
                $global:ActiveStreamxHost = $candHost
                break
            }
        }
    }

    # 3.1 Servidor Capo Deportes / CDPlay + Extracción Directa CandyShop CDN (PARALELO)
    Enter-ScanPhase 'CdPlay' $esModoVpn
    Write-Host "   [*] Explorando servidor raíz de televisión deportiva y tokens CandyShop (CA / H)..." -ForegroundColor DarkCyan
    $cdHtml = if ($script:Prefetched["CdHtml"]) { $script:Prefetched["CdHtml"] } else { Get-Utf8Content -Uri "https://cdplay.live/" -TimeoutSec 4 }
    if ($cdHtml) {
        $cdWorkItems = [System.Collections.Generic.List[PSCustomObject]]::new()
        $blocks = [regex]::Matches($cdHtml, '(?s)<li><a href="#">([^<]+)<\/a>\s*<ul>([\s\S]*?)<\/ul>\s*<\/li>')
        foreach ($blk in $blocks) {
            $categoryTitle = $blk.Groups[1].Value.Trim()
            $optionsHtml = $blk.Groups[2].Value
            $optMatches = [regex]::Matches($optionsHtml, '<a href="([^"]+\.php)">([^<]+)<\/a>')

            foreach ($om in $optMatches) {
                $relPath = $om.Groups[1].Value.Trim()
                $optLabel = $om.Groups[2].Value.Trim()
                $finalUrl = "https://cdplay.live" + $relPath

                $chName = $null
                if ($categoryTitle -match '(?i)Formula\s*1') {
                    $chName = "__DAZN_F1__"
                } elseif ($categoryTitle -match '(?i)Capo\s*Deportes\s*2') {
                    $chName = "Capo Deportes 2 HD (Eventos En Vivo)"
                } elseif ($categoryTitle -match '(?i)Capo\s*Deportes') {
                    $chName = "Capo Deportes HD (España / Deportes)"
                } elseif ($categoryTitle -match '(?i)DSPORTS\s*2') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "DSPORTS 2 HD" } else { "DSPORTS 2 SD" }
                } elseif ($categoryTitle -match '(?i)DSPORTS\s*\+') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "DSPORTS + HD" } else { "DSPORTS + SD" }
                } elseif ($categoryTitle -match '(?i)DSPORTS') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "DSPORTS HD (DirecTV Sports)" } else { "DSPORTS SD (DirecTV Sports)" }
                } elseif ($categoryTitle -match '(?i)ESPN\s*Premium') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "ESPN Premium HD (Argentina)" } else { "ESPN Premium SD (Argentina)" }
                } elseif ($categoryTitle -match '(?i)ESPN\s*Deportes') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "ESPN Deportes HD" } else { "ESPN Deportes SD" }
                } elseif ($categoryTitle -match '(?i)ESPN\s*(\d+)') {
                    $num = [regex]::Match($categoryTitle, '(?i)ESPN\s*(\d+)').Groups[1].Value
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "ESPN $num HD" } else { "ESPN $num SD" }
                } elseif ($categoryTitle -match '(?i)ESPN') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "ESPN HD" } else { "ESPN SD" }
                } elseif ($categoryTitle -match '(?i)Liga\s*1\s*Max') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "Liga 1 Max HD" } else { "Liga 1 Max SD" }
                } elseif ($categoryTitle -match '(?i)TNT\s*Sports.*Argentina') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "TNT Sports HD (Argentina)" } else { "TNT Sports SD (Argentina)" }
                } elseif ($categoryTitle -match '(?i)TNT\s*Sports.*Chile') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "TNT Sports HD (Chile)" } else { "TNT Sports SD (Chile)" }
                } elseif ($categoryTitle -match '(?i)TUDN') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "TUDN HD" } else { "TUDN SD" }
                } elseif ($categoryTitle -match '(?i)Telemundo') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "Telemundo USA HD" } else { "Telemundo USA SD" }
                } elseif ($categoryTitle -match '(?i)Universo') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "Universo USA HD" } else { "Universo USA SD" }
                } elseif ($categoryTitle -match '(?i)Win\s*Sports\s*\+') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "Win Sports + HD" } else { "Win Sports + SD" }
                } elseif ($categoryTitle -match '(?i)Win\s*Sports') {
                    $chName = if ($relPath -match 'hd' -or $optLabel -match 'HD') { "Win Sports HD" } else { "Win Sports SD" }
                } else {
                    $chName = Translate-ToSpanish $categoryTitle
                    if ($relPath -match 'hd' -or $optLabel -match 'HD') { $chName += " HD" }
                }
                if ($chName -ne "__DAZN_F1__" -and (Test-IsExcludedSport -Name $chName)) {
                    $script:SkippedSportsCount++
                    continue
                }
                $cdWorkItems.Add([PSCustomObject]@{
                    FinalUrl = $finalUrl
                    ChName   = $chName
                    WxHost   = $workingStreamxHost
                })
            }
        }

        $cdResults = Invoke-ParallelItems -Items @($cdWorkItems) -ScriptBlock {
            param($it)
            try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
            if ($it.WxHost) { $global:ActiveStreamxHost = $it.WxHost }
            $resolvedMaster = $it.FinalUrl
            $hlsVerified = $false
            $skipDead = $false
            $isCandy = $false

            $pageHtml = Get-Utf8Content -Uri $it.FinalUrl -Referer "https://cdplay.live/" -TimeoutSec 3
            if ($pageHtml -and $pageHtml -match '<iframe[^>]+src=["'']([^"'']+)["'']') {
                $innerIframe = $Matches[1].Trim()
                if ($innerIframe -match 'capopro\.php\?stream=|104game\.click/player/capo2/|hlsspanich\.php\?stream=|livetvfx\.php\?stream=|xstream\.st/') {
                    $candyHls = Resolve-CapoCandyShop -IframeUrl $innerIframe -Referer "https://cdplay.live/"
                    if ($candyHls) {
                        $resolvedMaster = $candyHls; $hlsVerified = $true; $isCandy = $true
                    } else { $skipDead = $true }
                } elseif ($innerIframe -match 'streamx[a-z0-9]+\.sbs/global[13]\.php\?channel=([^&\s]+)') {
                    $sxSlug = $Matches[1]
                    $sxHls = $null
                    if ($it.WxHost) { $sxHls = Resolve-StreamxNodeUrl -ChannelSlug $sxSlug -HostDomain $it.WxHost -Referer "https://cdplay.live/" }
                    if (-not $sxHls) { $sxHls = Resolve-StreamXhdUrl -LivePageUrl "https://streamxhd.click/live1.php?stream=$sxSlug" -Referer "https://cdplay.live/" }
                    if (-not $sxHls) { $sxHls = Resolve-Tvf90Url -StreamSlug $sxSlug -Referer "https://cdplay.live/" }
                    if ($sxHls) { $resolvedMaster = $sxHls; $hlsVerified = $true } else { $skipDead = $true }
                } elseif ($innerIframe -match 'streamxhd\.click/channel/\?id=([a-zA-Z0-9_-]+)') {
                    $idSlug = $Matches[1]
                    $xhdHls = Resolve-StreamXhdUrl -LivePageUrl "https://streamxhd.click/live1.php?stream=$idSlug" -Referer "https://cdplay.live/"
                    if (-not $xhdHls) { $xhdHls = Resolve-Tvf90Url -StreamSlug $idSlug -Referer "https://cdplay.live/" }
                    if ($xhdHls) { $resolvedMaster = $xhdHls; $hlsVerified = $true } else { $resolvedMaster = $innerIframe }
                } elseif ($innerIframe -match 'tvf90\.com/|embedme\.st/(?:play|player)/') {
                    $emHls = Resolve-EmbedAnyUrl -Url $innerIframe -Referer "https://cdplay.live/"
                    if ($emHls) { $resolvedMaster = $emHls; $hlsVerified = $true } else { $resolvedMaster = $innerIframe }
                } elseif ($innerIframe -match '^https?://') {
                    $innerHost = Get-HostKey $innerIframe
                    if ($innerHost -and $global:BlockedHosts -and $global:BlockedHosts.ContainsKey($innerHost)) {
                        $skipDead = $true
                    } elseif ($innerHost) {
                        $resolvedMaster = $innerIframe
                    }
                }
            }
            [PSCustomObject]@{ Item = $it; MasterUrl = $resolvedMaster; HlsVerified = $hlsVerified; SkipDead = $skipDead; IsCandy = $isCandy }
        }

        foreach ($cr in $cdResults) {
            if ($cr.SkipDead) {
                $finalizedEvents += [PSCustomObject]@{ Name = $cr.Item.ChName; Url = $cr.Item.FinalUrl; Reason = "Canal CDPlay sin segmentos activos (404)" }
                continue
            }
            if ($cr.IsCandy) { $script:CandyShopActiveCount++ }
            if ($cr.Item.ChName -eq "__DAZN_F1__") {
                $f1Source = if ($cr.MasterUrl -match 'candyshop\.st') { "candyshop" } else { "cdplay" }
                $daznF1Feeds.Add([PSCustomObject]@{ Url = $cr.MasterUrl; Fallback = $cr.Item.FinalUrl; Source = $f1Source; Verified = $cr.HlsVerified })
                continue
            }
            if (-not ($allChannels | Where-Object { $_.Name -eq $cr.Item.ChName })) {
                $allChannels += [PSCustomObject]@{
                    Id          = "cd_" + ($cr.Item.ChName -replace '\+', 'Plus' -replace '[^a-zA-Z0-9]', '')
                    Name        = $cr.Item.ChName
                    Group       = Get-ChannelGroup $cr.Item.ChName
                    Slug        = "cdplay"
                    MasterUrl   = $cr.MasterUrl
                    FallbackUrl = $cr.Item.FinalUrl
                    VpnRequired = $true
                }
                Write-Host "   [+] $($cr.Item.ChName) " -NoNewline -ForegroundColor Green
                if ($cr.HlsVerified -and $cr.MasterUrl -match 'candyshop\.st') {
                    Write-Host "[HLS Verificado CandyShop | Necesita VPN]" -ForegroundColor DarkGreen
                } elseif ($cr.HlsVerified) {
                    Write-Host "[HLS Verificado | Necesita VPN]" -ForegroundColor DarkGreen
                } else {
                    Write-Host "[Embed Verificado | Necesita VPN]" -ForegroundColor Red
                }
            }
        }
    } else {
        Write-Host "       (Servidor raíz de TV deportiva no accesible en esta red)." -ForegroundColor DarkGray
    }

    # 3.2 Canales Oficiales de Televisión y Deportes de España (Sondeo Multi-Servidor PARALELO)
    Write-Host "`n   [*] Sincronizando canales España multi-servidor (streamx / streamxhd / redx-2200 / tvf90-ftlly)..." -ForegroundColor DarkCyan
    if ($workingStreamxHost) {
        $script:SpanishVipStatus = "ONLINE ($workingStreamxHost + redx-2200 + streamxhd + ftlly)"
        Write-Host "       [+] Nodo España conectado: $workingStreamxHost (respaldos HD: redx 45.134.141.161, streamxhd.click, tvf90.com)" -ForegroundColor DarkGreen
    } else {
        $script:SpanishVipStatus = "FALLBACK_MIRRORS (redx-2200 + streamxhd + ftlly)"
        Write-Host "       [!] Nodo principal $($global:ActiveStreamxHost) no accesible; sondeando redx 45.134.141.161, streamxhd y tvf90..." -ForegroundColor Yellow
    }

    $spanishChannels = @(
        @{ Name = "DAZN MotoGP España"; Code = "daznmotogp"; Aliases = @("daznmotogp", "motogp"); Group = "MotoGP España" },
        @{ Name = "M+ LaLiga"; Code = "mlaliga"; Aliases = @("mlaliga"); Group = "Fútbol España" },
        @{ Name = "DAZN LaLiga"; Code = "daznlaliga"; Aliases = @("daznlaliga"); Group = "Fútbol España" },
        @{ Name = "M+ LaLiga 2"; Code = "mlaliga2"; Aliases = @("mlaliga2"); Group = "Fútbol España" },
        @{ Name = "M+ LaLiga 3"; Code = "mlaliga3"; Aliases = @("mlaliga3"); Group = "Fútbol España" },
        @{ Name = "DAZN LaLiga 2"; Code = "daznlaliga2"; Aliases = @("daznlaliga2"); Group = "Fútbol España" },
        @{ Name = "LaLiga Hypermotion"; Code = "hypermotion"; Aliases = @("hypermotion", "laligahypermotion"); Group = "Fútbol España" },
        @{ Name = "LaLiga TV Bar"; Code = "laligabar"; Aliases = @("laligabar", "laligatvbar"); Group = "Fútbol España" },
        @{ Name = "M+ Liga de Campeones"; Code = "champions"; Aliases = @("champions", "mligadecampeones", "mcampeones"); Group = "Fútbol España" },
        @{ Name = "M+ Liga de Campeones 2"; Code = "mligadecampeones2"; Aliases = @("mligadecampeones2", "mcampeones2"); Group = "Fútbol España" },
        @{ Name = "M+ Liga de Campeones 3"; Code = "mligadecampeones3"; Aliases = @("mligadecampeones3", "mcampeones3"); Group = "Fútbol España" },
        @{ Name = "DAZN 1 España HD"; Code = "dazn1"; Aliases = @("dazn1"); Group = "Deportes España" },
        @{ Name = "DAZN 2 España"; Code = "dazn2"; Aliases = @("dazn2"); Group = "Deportes España" },
        @{ Name = "DAZN 3 España"; Code = "dazn3"; Aliases = @("dazn3"); Group = "Deportes España" },
        @{ Name = "DAZN 4 España"; Code = "dazn4"; Aliases = @("dazn4"); Group = "Deportes España" },
        @{ Name = "Movistar Plus+"; Code = "mplus"; Aliases = @("mplus", "movistarplus"); Group = "Deportes España" },
        @{ Name = "Movistar+ Deportes"; Code = "mdeportes"; Aliases = @("mdeportes"); Group = "Deportes España" },
        @{ Name = "Movistar+ Deportes 2"; Code = "mdeportes2"; Aliases = @("mdeportes2"); Group = "Deportes España" },
        @{ Name = "Movistar+ Vamos"; Code = "vamos"; Aliases = @("vamos", "mvamos"); Group = "Deportes España" },
        @{ Name = "Movistar+ Golf"; Code = "mgolf"; Aliases = @("mgolf"); Group = "Deportes España" },
        @{ Name = "Eurosport 1 España HD"; Code = "eurosport1"; Aliases = @("eurosport1", "eurosport"); Group = "Deportes España" },
        @{ Name = "Eurosport 2 España HD"; Code = "eurosport2"; Aliases = @("eurosport2"); Group = "Deportes España" },
        @{ Name = "Nat Geo Wild HD (España)"; Code = "natgeowild"; Aliases = @("natgeowild"); Group = "Documentales y Cultura España" },
        @{ Name = "Gol Play España (TDT)"; Code = "gol"; Aliases = @("gol", "golplay"); Group = "TDT España" }
    )

    $vipResultMap = @{}
    foreach ($sc in $spanishChannels) {
        $vipResultMap[$sc.Code] = [PSCustomObject]@{
            Sc           = $sc
            DirectStream = $null
            WrapUrl      = "https://$($global:ActiveStreamxHost)/global3.php?channel=$($sc.Code)"
            HitBackend   = ""
        }
    }

    # Etapa A: StreamX (alias primario y secundario en paralelo entre 48 hilos)
    Enter-ScanPhase 'EsStageA' $esModoVpn
    if ($workingStreamxHost) {
        $stageAItems = @($spanishChannels | ForEach-Object { [PSCustomObject]@{ Sc = $_; WxHost = $workingStreamxHost } })
        $stageARes = Invoke-ParallelItems -Items $stageAItems -ScriptBlock {
            param($it)
            try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
            foreach ($alias in $it.Sc.Aliases) {
                $uSx = Resolve-StreamxNodeUrl -ChannelSlug $alias -HostDomain $it.WxHost
                if ($uSx) {
                    return [PSCustomObject]@{
                        Code         = $it.Sc.Code
                        DirectStream = $uSx
                        WrapUrl      = "https://$($it.WxHost)/global3.php?channel=$alias"
                        HitBackend   = $it.WxHost
                    }
                }
            }
            return $null
        }
        foreach ($r in $stageARes) {
            if ($r -and $r.DirectStream -and $vipResultMap.ContainsKey($r.Code)) {
                $cur = $vipResultMap[$r.Code]
                $cur.DirectStream = $r.DirectStream
                $cur.WrapUrl      = $r.WrapUrl
                $cur.HitBackend   = $r.HitBackend
            }
        }
    }

    # Etapas B y C + DAZN F1 unificadas en un solo abanico paralelo
    Enter-ScanPhase 'EsStageB' $esModoVpn
    $missingAfterA = @($spanishChannels | Where-Object { -not $vipResultMap[$_.Code].DirectStream })
    $stageBcItems = [System.Collections.Generic.List[PSCustomObject]]::new()
    foreach ($mc in $missingAfterA) {
        $stageBcItems.Add([PSCustomObject]@{ Kind = "es"; Sc = $mc })
    }
    foreach ($f1Src in @("streamx", "streamxhd", "redx", "ftlly")) {
        $stageBcItems.Add([PSCustomObject]@{ Kind = "f1"; F1Src = $f1Src; WxHost = $global:ActiveStreamxHost })
    }
    $stageBcItems.Add([PSCustomObject]@{ Kind = "redx_dazn1_alt" })
    $stageBcRes = Invoke-ParallelItems -Items @($stageBcItems) -ScriptBlock {
        param($it)
        try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
        if ($it.Kind -eq "redx_dazn1_alt") {
            $uAlt = Resolve-Tvf90Url -StreamSlug "dazn1"
            if ($uAlt) { return [PSCustomObject]@{ Kind = "dazn1_alt"; Url = $uAlt; Fallback = "https://tvf90.com/5.php?stream=dazn1" } }
            return $null
        }
        if ($it.Kind -eq "f1") {
            if ($it.F1Src -eq "streamx" -and $it.WxHost) {
                $u = Resolve-StreamxNodeUrl -ChannelSlug "daznf1" -HostDomain $it.WxHost
                if ($u) { return [PSCustomObject]@{ Kind = "f1"; Feed = [PSCustomObject]@{ Url = $u; Fallback = "https://$($it.WxHost)/global3.php?channel=daznf1"; Source = "streamx"; Verified = $true } } }
            } elseif ($it.F1Src -eq "streamxhd") {
                $u = Resolve-StreamXhdUrl -LivePageUrl "https://streamxhd.click/live1.php?stream=daznf1"
                if ($u) { return [PSCustomObject]@{ Kind = "f1"; Feed = [PSCustomObject]@{ Url = $u; Fallback = "https://streamxhd.click/live1.php?stream=daznf1"; Source = "streamxhd"; Verified = $true } } }
            } elseif ($it.F1Src -eq "redx") {
                $u = Resolve-RedxEsUrl -StreamSlug "daznf1"
                if ($u) { return [PSCustomObject]@{ Kind = "f1"; Feed = [PSCustomObject]@{ Url = $u; Fallback = $u; Source = "redx-2200"; Verified = $true } } }
            } elseif ($it.F1Src -eq "ftlly") {
                $u = Resolve-Tvf90Url -StreamSlug "daznf1"
                if ($u) { return [PSCustomObject]@{ Kind = "f1"; Feed = [PSCustomObject]@{ Url = $u; Fallback = "https://tvf90.com/5.php?stream=daznf1"; Source = "ftlly"; Verified = $true } } }
            }
            return $null
        }
        foreach ($alias in $it.Sc.Aliases) {
            $xhdPage1 = "https://streamxhd.click/live1.php?stream=$alias"
            $uXhd = Resolve-StreamXhdUrl -LivePageUrl $xhdPage1
            if ($uXhd) {
                return [PSCustomObject]@{
                    Kind         = "es"
                    Code         = $it.Sc.Code
                    DirectStream = $uXhd
                    WrapUrl      = $xhdPage1
                    HitBackend   = "streamxhd/live1"
                }
            }
        }
        $uRedx = Resolve-RedxEsUrl -StreamSlug $it.Sc.Code
        if ($uRedx) {
            return [PSCustomObject]@{
                Kind         = "es"
                Code         = $it.Sc.Code
                DirectStream = $uRedx
                WrapUrl      = $uRedx
                HitBackend   = "redx-2200"
            }
        }
        $primaryAlias = $it.Sc.Aliases[0]
        $uTvf = Resolve-Tvf90Url -StreamSlug $primaryAlias
        if ($uTvf) {
            return [PSCustomObject]@{
                Kind         = "es"
                Code         = $it.Sc.Code
                DirectStream = $uTvf
                WrapUrl      = "https://tvf90.com/5.php?stream=$primaryAlias"
                HitBackend   = "tvf90/ftlly"
            }
        }
        return $null
    }
    Enter-ScanPhase 'EsStageC' $esModoVpn
    $redxHitsVpn = 0
    $dazn1AltResult = $null
    foreach ($r in $stageBcRes) {
        if (-not $r) { continue }
        if ($r.Kind -eq "dazn1_alt") {
            $dazn1AltResult = $r
        } elseif ($r.Kind -eq "f1" -and $r.Feed) {
            if ($r.Feed.Source -eq "redx-2200") { $redxHitsVpn++ }
            $daznF1Feeds.Add($r.Feed)
        } elseif ($r.Kind -eq "es" -and $r.DirectStream -and $vipResultMap.ContainsKey($r.Code)) {
            if ($r.HitBackend -eq "redx-2200") { $redxHitsVpn++ }
            $cur = $vipResultMap[$r.Code]
            $cur.DirectStream = $r.DirectStream
            $cur.WrapUrl      = $r.WrapUrl
            $cur.HitBackend   = $r.HitBackend
        }
    }
    $script:RedxEsStatus = if ($redxHitsVpn -gt 0) { "ONLINE ($redxHitsVpn HD)" } else { "OFFLINE" }

    $vipResults = @($spanishChannels | ForEach-Object { $vipResultMap[$_.Code] })

    foreach ($vr in $vipResults) {
        $sc = $vr.Sc
        if ($vr.DirectStream) {
            foreach ($al in $sc.Aliases) { $script:VipSlugCache[$al.ToLowerInvariant()] = $vr.DirectStream }
            $script:VipSlugCache[$sc.Code.ToLowerInvariant()] = $vr.DirectStream
            if (-not ($allChannels | Where-Object { $_.Name -eq $sc.Name })) {
                $needsVpnFlag = ($vr.HitBackend -ne "redx-2200")
                $allChannels += [PSCustomObject]@{
                    Id          = "es_" + ($sc.Name -replace '[^a-zA-Z0-9]','')
                    Name        = $sc.Name
                    Group       = $sc.Group
                    Slug        = "es_" + $sc.Code
                    MasterUrl   = $vr.DirectStream
                    FallbackUrl = $vr.WrapUrl
                    VpnRequired = $needsVpnFlag
                }
                Write-Host "   [+] $($sc.Name) [HLS Verificado ($($vr.HitBackend)) | $(if ($needsVpnFlag) { 'Necesita VPN' } else { 'Directo HD' })]" -ForegroundColor DarkGreen
            }
        } else {
            $finalizedEvents += [PSCustomObject]@{
                Name   = $sc.Name
                Url    = $vr.WrapUrl
                Reason = "Canal sin emisión activa (404 off-air) - Se activará automáticamente al iniciar evento y re-ejecutar .bat"
            }
            Write-Host "   [-] $($sc.Name) [Sin emisión activa ahora (404 off-air) - Omitido]" -ForegroundColor DarkGray
        }
    }
    if ($dazn1AltResult -and $dazn1AltResult.Url) {
        $primaryDazn1 = $vipResultMap["dazn1"].DirectStream
        if ($primaryDazn1 -and $dazn1AltResult.Url -ne $primaryDazn1 -and -not ($allChannels | Where-Object { $_.Name -eq "DAZN 1 España HD (Opción 2)" })) {
            $allChannels += [PSCustomObject]@{
                Id          = "es_DAZN1EspanaHDOpc2"
                Name        = "DAZN 1 España HD (Opción 2)"
                Group       = "Deportes España"
                Slug        = "es_dazn1_ftlly"
                MasterUrl   = $dazn1AltResult.Url
                FallbackUrl = $dazn1AltResult.Fallback
                VpnRequired = $true
            }
            Write-Host "   [+] DAZN 1 España HD (Opción 2) [HLS Verificado (tvf90/ftlly) | Necesita VPN]" -ForegroundColor DarkGreen
        }
    }

    # 3.3-3.5 Recolección CPU + OLA ÚNICA PARALELA (Fútbol Libre + StreamXHD + Agenda888 + EmbedMe + DeporteLibre + CandyShop/InStreams)
    Enter-ScanPhase 'FutbolLb' $esModoVpn
    Write-Host "`n   [*] Preparando agendas en tiempo real (Fútbol Libre / StreamXHD / Castellano / EmbedMe / DeporteLibre / CandyShop)..." -ForegroundColor DarkCyan
    $sxHost888 = if ($global:ActiveStreamxHost) { $global:ActiveStreamxHost } else { "streamx723.sbs" }
    $missAgList = [System.Collections.Generic.List[PSCustomObject]]::new()
    if (-not $script:Prefetched["Diaries"])     { $missAgList.Add([PSCustomObject]@{ Key = "Diaries";     Url = "https://api.wqxag.com/diaries.json"; Ref = "https://futbollibregol.org/"; Orig = "" }) }
    if (-not $script:Prefetched["XhdEv"])       { $missAgList.Add([PSCustomObject]@{ Key = "XhdEv";       Url = "https://streamxhd.click/eventos.json"; Ref = "https://streamxhd.click/"; Orig = "" }) }
    if ($sxHost888 -ne "streamx723.sbs" -or -not $script:Prefetched["Ag888"]) {
        $missAgList.Add([PSCustomObject]@{ Key = "Ag888"; Url = "https://$sxHost888/json/agenda888.json"; Ref = "https://$sxHost888/"; Orig = "" })
    }
    if (-not $script:Prefetched["FlHtml"])      { $missAgList.Add([PSCustomObject]@{ Key = "FlHtml";      Url = "https://futbollibregol.org/"; Ref = ""; Orig = "" }) }
    if (-not $script:Prefetched["EmHtml"])      { $missAgList.Add([PSCustomObject]@{ Key = "EmHtml";      Url = "https://embedme.st/"; Ref = ""; Orig = "" }) }
    if (-not $script:Prefetched["DlAgenda"])    { $missAgList.Add([PSCustomObject]@{ Key = "DlAgenda";    Url = "https://deportelibre.top/agenda-deportiva/agenda.json"; Ref = "https://deportelibre.top/agenda-deportiva/"; Orig = "" }) }
    if (-not $script:Prefetched["CandyHealth"]) { $missAgList.Add([PSCustomObject]@{ Key = "CandyHealth"; Url = "https://edge2.candyshop.st/health"; Ref = ""; Orig = "" }) }
    if ($missAgList.Count -gt 0) { Invoke-PrefetchBatch @($missAgList) }

    $uJobs = [System.Collections.Generic.List[PSCustomObject]]::new()
    $uQueuedKeys = [System.Collections.Generic.HashSet[string]]::new()
    $uQueuedSlugs = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)

    # -- Parse A: Futbol Libre API --
    $flEventsCount = 0
    $flWorkItems = [System.Collections.Generic.List[PSCustomObject]]::new()
    try {
        $flApiJson = $script:Prefetched["Diaries"]
        if ($flApiJson) {
            $script:FutbolLibreApiStatus = "ONLINE"
            $flParsed = $flApiJson | ConvertFrom-Json
            $flEvents = if ($flParsed -is [array]) { $flParsed } elseif ($flParsed.data) { $flParsed.data } else { @() }
            $flEventsCount = $flEvents.Count
            $limaTz = [TimeZoneInfo]::FindSystemTimeZoneById("SA Pacific Standard Time")
            $nowUtc = [DateTime]::UtcNow
            foreach ($evItem in $flEvents) {
                $attr = if ($evItem.attributes) { $evItem.attributes } else { $evItem }
                $rawDate = if ($attr.date_diary) { [string]$attr.date_diary } elseif ($attr.date) { [string]$attr.date } elseif ($attr.fecha) { [string]$attr.fecha } else { "" }
                $rawHour = if ($attr.diary_hour) { [string]$attr.diary_hour } elseif ($attr.hour) { [string]$attr.hour } elseif ($attr.hora) { [string]$attr.hora } else { "" }
                $rawDesc = if ($attr.diary_description) { [string]$attr.diary_description } elseif ($attr.description) { [string]$attr.description } elseif ($attr.title) { [string]$attr.title } elseif ($attr.nombre) { [string]$attr.nombre } else { "" }
                if ([string]::IsNullOrWhiteSpace($rawDesc)) { continue }

                $cleanMatch = Translate-ToSpanish $rawDesc
                if (Test-IsExcludedSport -Name $cleanMatch -LeagueOrCategory $rawDesc) { $script:SkippedSportsCount++; continue }
                $parsedUtc = $null
                if ($rawHour) {
                    try {
                        if ($rawHour -match 'T|Z') {
                            $parsedUtc = [DateTime]::Parse($rawHour).ToUniversalTime()
                        } elseif ($rawHour -match '^(\d{1,2}):(\d{2})') {
                            $hh = [int]$Matches[1]; $mm = [int]$Matches[2]
                            $baseLimaDate = [TimeZoneInfo]::ConvertTimeFromUtc($nowUtc, $limaTz).Date
                            if ($rawDate -match '^\d{4}-\d{2}-\d{2}') { $baseLimaDate = [DateTime]::ParseExact($Matches[0], "yyyy-MM-dd", $null) }
                            $todayLima = $baseLimaDate.AddHours($hh).AddMinutes($mm)
                            $parsedUtc = [TimeZoneInfo]::ConvertTimeToUtc($todayLima, $limaTz)
                            if (-not ($rawDate -match '^\d{4}-\d{2}-\d{2}')) {
                                if (($nowUtc - $parsedUtc).TotalHours -gt 16) { $parsedUtc = [TimeZoneInfo]::ConvertTimeToUtc($todayLima.AddDays(1), $limaTz) }
                                elseif (($parsedUtc - $nowUtc).TotalHours -gt 18) { $parsedUtc = [TimeZoneInfo]::ConvertTimeToUtc($todayLima.AddDays(-1), $limaTz) }
                            }
                        }
                    } catch {}
                }
                $evWin = Get-AgendaEventWindowEvaluation -Title $cleanMatch -StartUtc $parsedUtc -SportHint $rawDesc
                if ($evWin.IsConcluded) {
                    $finalizedEvents += [PSCustomObject]@{ Name = $cleanMatch; Url = "https://futbollibregol.org/agenda"; Reason = $evWin.Reason }
                    continue
                }
                if ($parsedUtc -and $parsedUtc -gt $nowUtc.AddHours(24)) { continue }
                $kickLocalTag = $evWin.KickTag
                $embedsList = @()
                if ($attr.embeds) {
                    if ($attr.embeds.PSObject.Properties['data']) { $embedsList = @($attr.embeds.data | Where-Object { $_ }) }
                    else { $embedsList = @($attr.embeds | Where-Object { $_ }) }
                }
                $optNum = 1
                foreach ($emb in $embedsList) {
                    $embAttr = if ($emb.attributes) { $emb.attributes } else { $emb }
                    $embUrl = if ($embAttr.embed_iframe) { [string]$embAttr.embed_iframe } elseif ($embAttr.url) { [string]$embAttr.url } elseif ($embAttr.link) { [string]$embAttr.link } else { "" }
                    $embName = if ($embAttr.embed_name) { [string]$embAttr.embed_name } elseif ($embAttr.name) { [string]$embAttr.name } elseif ($embAttr.nombre) { [string]$embAttr.nombre } else { "Opción $optNum" }
                    if ([string]::IsNullOrWhiteSpace($embUrl) -or $embUrl -eq "#") { continue }
                    if ($embName -match '(?i)espn|disney|tnt\s*sports|win\s*sports|vix|fox\s*sports|tudn|tyc|telemundo' -and $embName -notmatch 'Latino') {
                        $embName = "$embName · Latino"
                    } elseif ($embName -match '(?i)movistar|mlaliga|dazn\s*(?:es|laliga|[1-4]|f1)|vamos|campeones|hypermotion|gol\s*play' -and $embName -notmatch 'Castellano') {
                        $embName = "$embName · Castellano"
                    }
                    if ($embUrl -match '[?&]r=([A-Za-z0-9+/=\s]+)') {
                        try {
                            $decoded = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String(($Matches[1] -replace '\s', '')))
                            if ($decoded -match '^https?://') { $embUrl = $decoded }
                        } catch {}
                    }
                    if ($embUrl -match '/drm/') { continue }
                    $isLiveNow = (-not $parsedUtc -or $parsedUtc -le $nowUtc)
                    $needsProbe = ($embUrl -match '104game\.click/player/capo2/|capopro\.php\?stream=|livetvfx\.php\?stream=|hlsspanich\.php\?stream=|xstream\.st/|streamxhd\.click/|streamx[a-z0-9]+\.sbs/global[13]\.php|tvf90\.com/|embedme\.st/|\.m3u8(?:\?|$)')
                    $jKey = "fl_ev|$embUrl"
                    if ($needsProbe -and $uQueuedKeys.Add($jKey)) {
                        $uJobs.Add([PSCustomObject]@{ Kind = "fl_ev"; Key = $jKey; Url = $embUrl; WxHost = $sxHost888 })
                    }
                    $flWorkItems.Add([PSCustomObject]@{
                        MatchDisplay = "$cleanMatch$kickLocalTag ($embName)"
                        CleanMatch   = $cleanMatch
                        EmbUrl       = $embUrl
                        LiveNow      = $isLiveNow
                        NeedsProbe   = $needsProbe
                        JobKey       = $jKey
                        StartsAtUtc  = $evWin.StartsAtUtcStr
                        EndsAtUtc    = $evWin.EndsAtUtcStr
                    })
                    $optNum++
                }
            }
        }
    } catch { Write-Host "       [-] Aviso consultando API Fútbol Libre: $($_.Exception.Message)" -ForegroundColor DarkGray }

    # -- Parse B: StreamXHD eventos.json --
    $xhdCandidateEvents = [System.Collections.Generic.List[PSCustomObject]]::new()
    try {
        $xhdEvJson = $script:Prefetched["XhdEv"]
        if ($xhdEvJson) {
            $script:StreamXhdStatus = "ONLINE"
            $xhdObj = $xhdEvJson | ConvertFrom-Json
            $limaTzX = [TimeZoneInfo]::FindSystemTimeZoneById("SA Pacific Standard Time")
            $nowUtcX = [DateTime]::UtcNow
            foreach ($sp in $xhdObj.sports) {
                $spHint = switch -Regex ([string]$sp.id) {
                    "^(?i)football|soccer$" { "Football" }
                    "^(?i)tennis|tenis$"   { "Tennis" }
                    "^(?i)basketball$"     { "Basketball" }
                    "^(?i)nfl$"            { "NFL" }
                    default                { if ([string]$sp.name -match '(?i)tenis|tennis|atp|wta') { "Tennis" } else { "" } }
                }
                foreach ($lg in $sp.leagues) {
                    foreach ($ev in $lg.events) {
                        $rawTitle = [string]$ev.title
                        if ([string]::IsNullOrWhiteSpace($rawTitle)) { continue }
                        $cleanEvTitle = Translate-ToSpanish $rawTitle
                        if (Test-IsExcludedSport -Name $cleanEvTitle -LeagueOrCategory ([string]$lg.name) -SportId ([string]$sp.id)) { $script:SkippedSportsCount++; continue }
                        $startUtcX = $null
                        $rawTime = [string]$ev.time
                        if ($rawTime) {
                            try {
                                if ($rawTime -match '[Zz]|[+-]\d{2}:\d{2}$') { $startUtcX = [DateTimeOffset]::Parse($rawTime, [System.Globalization.CultureInfo]::InvariantCulture).UtcDateTime }
                                elseif ($rawTime -match '^\d{4}-\d{2}-\d{2}\s+\d{1,2}:\d{2}') { $startUtcX = [TimeZoneInfo]::ConvertTimeToUtc([DateTime]::Parse($rawTime, [System.Globalization.CultureInfo]::InvariantCulture), $limaTzX) }
                            } catch {}
                        }
                        $durMin = if ($ev.duration -and [int]$ev.duration -gt 0) { [int]$ev.duration } else { 0 }
                        if ($startUtcX -and $startUtcX -gt $nowUtcX.AddHours(24)) { continue }
                        $evWinX = Get-AgendaEventWindowEvaluation -Title $cleanEvTitle -StartUtc $startUtcX -ReportedDurationMinutes $durMin -SportHint ([string]$sp.id + " " + [string]$lg.name) -RawStatus ([string]$ev.status)
                        if ($evWinX.IsConcluded) {
                            $finalizedEvents += [PSCustomObject]@{ Name = $cleanEvTitle; Url = "https://streamxhd.click/"; Reason = $evWinX.Reason }
                            continue
                        }
                        foreach ($srv in $ev.servers) {
                            $srvUrl = [string]$srv.url
                            $srvName = [string]$srv.name
                            if ([string]::IsNullOrWhiteSpace($srvUrl)) { continue }
                            $srvLabel = $srvName.Trim()
                            if ($srvLabel -match '(?i)mlaliga|movistar|m\+\s*|dlaliga|dazn|hypermotion|gol\s*play|vamos|eurosport.*esp' -and $srvLabel -notmatch 'Castellano') { $srvLabel += " · Castellano" }
                            elseif ($srvLabel -match '(?i)espn|disney|tnt\s*sports|win\s*sports|vix|fox\s*one|tudn|tyc|telemundo' -and $srvLabel -notmatch 'Latino') { $srvLabel += " · Latino" }
                            $jKey = "xhd|$srvUrl"
                            if ($uQueuedKeys.Add($jKey)) {
                                $uJobs.Add([PSCustomObject]@{ Kind = "xhd"; Key = $jKey; Url = $srvUrl; WxHost = $sxHost888 })
                            }
                            $xhdCandidateEvents.Add([PSCustomObject]@{
                                Title = $cleanEvTitle; DispName = "$cleanEvTitle$($evWinX.KickTag) ($srvLabel)"; League = [string]$lg.name; Hint = $spHint
                                SrvUrl = $srvUrl; JobKey = $jKey; Upcoming = $evWinX.Upcoming; StartsAtUtc = $evWinX.StartsAtUtcStr; EndsAtUtc = $evWinX.EndsAtUtcStr
                            })
                        }
                    }
                }
            }
        }
    } catch { Write-Host "       [-] Agenda StreamXHD no disponible: $($_.Exception.Message)" -ForegroundColor DarkGray }

    # -- Parse C: Agenda888 Castellano --
    $a8Cand = [System.Collections.Generic.List[PSCustomObject]]::new()
    try {
        $ag888Txt = $script:Prefetched["Ag888"]
        if ($ag888Txt) {
            $ag888List = $ag888Txt | ConvertFrom-Json
            $limaTz8 = [TimeZoneInfo]::FindSystemTimeZoneById("SA Pacific Standard Time")
            $nowUtc8 = [DateTime]::UtcNow
            $slugLabelMap = @{
                "mlaliga" = "M+ LaLiga · Castellano"; "mlaliga2" = "M+ LaLiga 2 · Castellano"; "dlaliga" = "DAZN LaLiga · Castellano"
                "daznlaliga" = "DAZN LaLiga · Castellano"; "daznlaliga2" = "DAZN LaLiga 2 · Castellano"; "hypermotion" = "LaLiga HyperMotion · Castellano"
                "mcampeones" = "M+ Liga de Campeones · Castellano"; "vamos" = "#Vamos · Castellano"; "mdeportes" = "M+ Deportes · Castellano"
                "dazn1" = "DAZN 1 España · Castellano"; "dazn2" = "DAZN 2 España · Castellano"; "daznf1" = "DAZN F1 España · Castellano"
                "mdeportes2" = "M+ Deportes 2 · Castellano"; "eurosport1" = "Eurosport 1 España · Castellano"; "eurosport2" = "Eurosport 2 España · Castellano"
                "teledeporte" = "Teledeporte · Castellano"; "tdp" = "Teledeporte · Castellano"; "tennischannel" = "Tennis Channel"
                "gol" = "Gol Play · Castellano"; "espn" = "ESPN · Latino"; "espn2" = "ESPN 2 · Latino"; "espnplus1" = "ESPN+ · Latino"
                "espnplus2" = "ESPN+ 2 · Latino"; "espndeportes" = "ESPN Deportes · Latino"; "disney1" = "Disney+ · Latino"
                "disney2" = "Disney+ 2 · Latino"; "tntar" = "TNT Sports AR · Latino"; "tntsports" = "TNT Sports · Latino"
            }
            foreach ($ev in $ag888List) {
                $rawTitle = [string]$ev.title; $rawLink = [string]$ev.link
                if ([string]::IsNullOrWhiteSpace($rawTitle) -or [string]::IsNullOrWhiteSpace($rawLink)) { continue }
                $cleanTitle8 = Translate-ToSpanish $rawTitle
                if (Test-IsExcludedSport -Name $cleanTitle8 -LeagueOrCategory ([string]$ev.category)) { $script:SkippedSportsCount++; continue }
                $startUtc8 = $null
                if ($ev.date -and $ev.time) {
                    try { $startUtc8 = [TimeZoneInfo]::ConvertTimeToUtc([DateTime]::Parse("$($ev.date) $($ev.time)", [System.Globalization.CultureInfo]::InvariantCulture), $limaTz8) } catch {}
                }
                if ($startUtc8 -and $startUtc8 -gt $nowUtc8.AddHours(24)) { continue }
                $evWin8 = Get-AgendaEventWindowEvaluation -Title $cleanTitle8 -StartUtc $startUtc8 -SportHint ([string]$ev.category) -RawStatus ([string]$ev.status)
                if ($evWin8.IsConcluded) {
                    $finalizedEvents += [PSCustomObject]@{ Name = $cleanTitle8; Url = $rawLink; Reason = $evWin8.Reason }
                    continue
                }
                $chSlug8 = if ($rawLink -match 'channel=([a-zA-Z0-9_-]+)') { $Matches[1].ToLower() } else { "" }
                $lbl8 = if ($chSlug8 -and $slugLabelMap.ContainsKey($chSlug8)) { $slugLabelMap[$chSlug8] } elseif ($chSlug8) { $chSlug8 } else { "Stream" }
                $apiGlobal3 = if ($chSlug8) { "https://$sxHost888/global3.php?channel=$chSlug8" } else { $rawLink }
                $cKey = if ($chSlug8) { $chSlug8.ToLowerInvariant() } else { "" }
                $jKey = if ($cKey) { "slug|$cKey" } else { "ag888|$apiGlobal3" }
                if (-not ($cKey -and $script:VipSlugCache.ContainsKey($cKey))) {
                    if ($uQueuedKeys.Add($jKey)) {
                        if ($cKey) { $null = $uQueuedSlugs.Add($cKey) }
                        $uJobs.Add([PSCustomObject]@{ Kind = "ag888"; Key = $jKey; Url = $apiGlobal3; Slug = $chSlug8; WxHost = $sxHost888 })
                    }
                }
                $a8Cand.Add([PSCustomObject]@{
                    Title = $cleanTitle8; Category = [string]$ev.category; DispName = "$cleanTitle8$($evWin8.KickTag) ($lbl8)"; ApiUrl = $apiGlobal3; Fallback = $rawLink
                    Upcoming = $evWin8.Upcoming; SlugCode = $chSlug8; JobKey = $jKey; StartsAtUtc = $evWin8.StartsAtUtcStr; EndsAtUtc = $evWin8.EndsAtUtcStr
                })
            }
        }
    } catch { Write-Host "       [-] Agenda888 no disponible: $($_.Exception.Message)" -ForegroundColor DarkGray }

    # -- Parse D: Futbol Libre HTML canales --
    $flHtmlItems = [System.Collections.Generic.List[PSCustomObject]]::new()
    $flHtml = $script:Prefetched["FlHtml"]
    if ($flHtml) {
        $flMatches = [regex]::Matches($flHtml, '<a[^>]+href="([^"]*en-vivo[^"]*)"[^>]*>([\s\S]*?)<\/a>')
        foreach ($fm in $flMatches) {
            $fUrl = $fm.Groups[1].Value.Trim()
            $rawText = ($fm.Groups[2].Value -replace '<[^>]+>', ' ' -replace '\s+', ' ').Trim()
            if ($rawText -match '(?i)^ver\s*canal$') {
                $slugPart = ($fUrl -replace '^.*/en-vivo/', '' -replace '-online/?$', '' -replace '/$', '')
                $rawText = (Get-Culture).TextInfo.ToTitleCase(($slugPart -replace '-', ' '))
                $rawText = $rawText -replace '\bPlus\b', '+' -replace '(?i)\bDirectv\s*Sports\b', 'DSports' -replace '(?i)\bDirectv\b', 'DSports'
            }
            $fTitle = Translate-ToSpanish $rawText
            if (Test-IsExcludedSport -Name $fTitle) { $script:SkippedSportsCount++; continue }
            if ($fTitle.Length -gt 2 -and -not ($flHtmlItems | Where-Object { $_.Title -eq $fTitle }) -and -not ($allChannels | Where-Object { $_.Name -eq $fTitle })) {
                if ($fUrl -notmatch '^https?://') { $fUrl = "https://futbollibregol.org" + $fUrl }
                $jKey = "fl_html|$fUrl"
                if ($uQueuedKeys.Add($jKey)) {
                    $uJobs.Add([PSCustomObject]@{ Kind = "fl_html"; Key = $jKey; Url = $fUrl; WxHost = $sxHost888 })
                }
                $flHtmlItems.Add([PSCustomObject]@{ Title = $fTitle; Url = $fUrl; JobKey = $jKey })
                if ($flHtmlItems.Count -ge 15) { break }
            }
        }
    }

    # -- Parse E: EmbedMe SG_PUBLIC --
    $emGameWork = [System.Collections.Generic.List[PSCustomObject]]::new()
    $emChWork = [System.Collections.Generic.List[PSCustomObject]]::new()
    $emHtml = $script:Prefetched["EmHtml"]
    if ($emHtml -and $emHtml -match 'window\.SG_PUBLIC=(\{.*?\});') {
        try {
            $sgObj = $Matches[1] | ConvertFrom-Json
            $script:EmbedMeStatus = "ONLINE"
            if ($sgObj.games) {
                foreach ($gm in $sgObj.games) {
                    $sportName = [string]$gm.sport
                    $rawStat = ([string]$gm.status).ToLower() -replace '^status_', ''
                    $stDtEm = if ($gm.start_at) { [DateTimeOffset]::Parse([string]$gm.start_at).UtcDateTime } else { $null }
                    $repEndEm = if ($gm.end_at) { [DateTimeOffset]::Parse([string]$gm.end_at).UtcDateTime } else { $null }
                    $evTitle = if ($gm.away.name -and $gm.home.name) { "$($gm.away.name) vs $($gm.home.name)" } else { [string]$gm.custom_title }
                    $evTitle = Translate-ToSpanish $evTitle
                    if (Test-IsExcludedSport -Name $evTitle -SportId $sportName) { $script:SkippedSportsCount++; continue }
                    $evWinEm = Get-AgendaEventWindowEvaluation -Title $evTitle -StartUtc $stDtEm -ReportedEndUtc $repEndEm -SportHint $sportName -RawStatus $rawStat
                    if ($evWinEm.IsConcluded) {
                        $finalizedEvents += [PSCustomObject]@{ Name = $evTitle; Url = "https://embedme.st/"; Reason = $evWinEm.Reason }
                        continue
                    }
                    if ($stDtEm -and [DateTime]::UtcNow -ge $stDtEm.AddHours(-24) -and $stDtEm -le [DateTime]::UtcNow.AddHours(24) -and $gm.streams) {
                        $stCands = @($gm.streams | Select-Object -First 2)
                        $gHint = if ($sportName -eq 'soccer') { "Football" } elseif ($sportName -match '(?i)tenn?is|atp|wta') { "Tennis" } else { "" }
                        $dispEm = $evTitle + $evWinEm.KickTag
                        $stUrls = @()
                        foreach ($stc in $stCands) {
                            $vid = [int]$stc.variant_id
                            $prefix = if ($vid -ge 900001) { "/player/" } else { "/play/" }
                            $vsfx = if ($vid -gt 0) { "-v$vid" } else { "" }
                            $stUrls += "https://embedme.st$($prefix)game-$($stc.game_id)$vsfx.php"
                        }
                        $jKey = "em_game|" + ($stUrls -join ",")
                        if ($uQueuedKeys.Add($jKey)) {
                            $uJobs.Add([PSCustomObject]@{ Kind = "em_game"; Key = $jKey; Url = $stUrls[0]; AltUrls = $stUrls; Upcoming = $evWinEm.Upcoming; WxHost = $sxHost888 })
                        }
                        $emGameWork.Add([PSCustomObject]@{
                            Id = $gm.id; Name = $dispEm; Hint = $gHint; Url = $stUrls[0]; JobKey = $jKey
                            Upcoming = $evWinEm.Upcoming; StartsAtUtc = $evWinEm.StartsAtUtcStr; EndsAtUtc = $evWinEm.EndsAtUtcStr
                        })
                    }
                }
            }
            foreach ($ec in $sgObj.channels) {
                if ($ec.status -notin @('running', 'live')) { continue }
                $ecName = Translate-ToSpanish ([string]$ec.name)
                if ($ecName -match '(?i)DAZN\s*F1') { continue }
                if (Test-IsExcludedSport -Name $ecName) { $script:SkippedSportsCount++; continue }
                if (Test-IsEventFinalized $null $ecName $null) { continue }
                if (-not ($allChannels | Where-Object { $_.Name -eq $ecName })) {
                    $ecUrl = "https://embedme.st/play/channel-$($ec.id).php"
                    $jKey = "em_ch|$ecUrl"
                    if ($uQueuedKeys.Add($jKey)) {
                        $uJobs.Add([PSCustomObject]@{ Kind = "em_ch"; Key = $jKey; Url = $ecUrl; WxHost = $sxHost888 })
                    }
                    $emChWork.Add([PSCustomObject]@{ Id = $ec.id; Name = $ecName; Url = $ecUrl; JobKey = $jKey })
                }
            }
        } catch { Write-Host "       [-] Error analizando EmbedMe: $($_.Exception.Message)" -ForegroundColor DarkGray }
    }

    # -- Parse F: DeporteLibre agenda.json --
    $dlCandMatches = [System.Collections.Generic.List[PSCustomObject]]::new()
    $neededDlSlugs = [System.Collections.Generic.HashSet[string]]::new()
    try {
        $dlAgendaJson = $script:Prefetched["DlAgenda"]
        if ($dlAgendaJson) {
            $dlEvents = $dlAgendaJson | ConvertFrom-Json
            $nowUtcDl = [DateTime]::UtcNow
            $dlCastMap = @(
                @{ Re = '(?i)movistar\s*laliga\s*2'; Slug = 'mlaliga2'; Label = 'M+ LaLiga 2 · Castellano' },
                @{ Re = '(?i)movistar\s*la?\s*liga'; Slug = 'mlaliga'; Label = 'M+ LaLiga · Castellano' },
                @{ Re = '(?i)dazn\s*laliga\s*2'; Slug = 'daznlaliga2'; Label = 'DAZN LaLiga 2 · Castellano' },
                @{ Re = '(?i)dazn\s*laliga'; Slug = 'daznlaliga'; Label = 'DAZN LaLiga · Castellano' },
                @{ Re = '(?i)hypermotion|hipermotion'; Slug = 'hypermotion'; Label = 'LaLiga Hypermotion · Castellano' },
                @{ Re = '(?i)movistar\s*liga\s*de\s*campeones\s*2|m\.?\s*campeones\s*2'; Slug = 'mligadecampeones2'; Label = 'M+ Liga de Campeones 2 · Castellano' },
                @{ Re = '(?i)movistar\s*liga\s*de\s*campeones|m\.?\s*campeones'; Slug = 'champions'; Label = 'M+ Liga de Campeones · Castellano' },
                @{ Re = '(?i)#?vamos|movistar\s*vamos'; Slug = 'vamos'; Label = '#Vamos · Castellano' },
                @{ Re = '(?i)movistar\s*plus\+|#movistar'; Slug = 'mplus'; Label = 'Movistar Plus+ · Castellano' },
                @{ Re = '(?i)movistar\s*deportes\s*2|m\.?\s*deportes\s*2'; Slug = 'mdeportes2'; Label = 'M+ Deportes 2 · Castellano' },
                @{ Re = '(?i)movistar\s*deportes|m\.?\s*deportes'; Slug = 'mdeportes'; Label = 'M+ Deportes · Castellano' },
                @{ Re = '(?i)\bdazn\s*1\b'; Slug = 'dazn1'; Label = 'DAZN 1 España · Castellano' },
                @{ Re = '(?i)\bdazn\s*2\b'; Slug = 'dazn2'; Label = 'DAZN 2 España · Castellano' },
                @{ Re = '(?i)\bdazn\s*3\b'; Slug = 'dazn3'; Label = 'DAZN 3 España · Castellano' },
                @{ Re = '(?i)\bdazn\s*4\b'; Slug = 'dazn4'; Label = 'DAZN 4 España · Castellano' },
                @{ Re = '(?i)\bdazn\s*f1\b'; Slug = 'daznf1'; Label = 'DAZN F1 España · Castellano' },
                @{ Re = '(?i)\b(?:teledeporte|tdp)\b'; Slug = 'teledeporte'; Label = 'Teledeporte · Castellano' },
                @{ Re = '(?i)\bgol\s*play\b'; Slug = 'gol'; Label = 'Gol Play · Castellano' },
                @{ Re = '(?i)eurosport\s*1'; Slug = 'eurosport1'; Label = 'Eurosport 1 España · Castellano' },
                @{ Re = '(?i)eurosport\s*2'; Slug = 'eurosport2'; Label = 'Eurosport 2 España · Castellano' }
            )
            foreach ($ev in $dlEvents) {
                if ($ev.tipo -eq 'separador' -or -not $ev.partido -or -not $ev.canales) { continue }
                $cleanPartido = ([string]$ev.partido -replace '[\uD800-\uDBFF][\uDC00-\uDFFF]', '' -replace '\s{2,}', ' ').Trim()
                $depLabel = "$($ev.deporte) $($ev.competicion)"
                $cleanMatchTitle = Translate-ToSpanish $cleanPartido
                if (Test-IsExcludedSport -Name $cleanMatchTitle -LeagueOrCategory $depLabel -SportId ([string]$ev.deporte)) { $script:SkippedSportsCount++; continue }
                $startUtcDl = $null
                if ($ev.inicio) {
                    try { $startUtcDl = [DateTime]::Parse([string]$ev.inicio, [System.Globalization.CultureInfo]::InvariantCulture, [System.Globalization.DateTimeStyles]::AssumeUniversal).ToUniversalTime() } catch {}
                }
                if ($startUtcDl -and $startUtcDl -gt $nowUtcDl.AddHours(24)) { continue }
                $evWinDl = Get-AgendaEventWindowEvaluation -Title $cleanMatchTitle -StartUtc $startUtcDl -SportHint $depLabel -RawStatus ([string]$ev.estado)
                if ($evWinDl.IsConcluded) {
                    $finalizedEvents += [PSCustomObject]@{ Name = $cleanMatchTitle; Url = "https://deportelibre.top/agenda-deportiva/"; Reason = $evWinDl.Reason }
                    continue
                }
                $dlHint = if ($depLabel -match '(?i)tenis|tennis|atp|wta|davis|grand\s*slam|roland|wimbledon') { "Tennis" } elseif ($depLabel -match '(?i)f[uú]tbol|soccer|copa|champions|liga|premier|serie|bundesliga') { "Football" } else { "" }
                $matchedSlugsForEv = @{}
                foreach ($cn in $ev.canales) {
                    $cnName = [string]$cn.nombre
                    if (-not $cnName) { continue }
                    foreach ($cm in $dlCastMap) {
                        if ($cnName -match $cm.Re -and -not $matchedSlugsForEv.ContainsKey($cm.Slug)) {
                            $matchedSlugsForEv[$cm.Slug] = $true
                            $null = $neededDlSlugs.Add($cm.Slug)
                            $dlCandMatches.Add([PSCustomObject]@{
                                Title = $cleanMatchTitle; DispName = "$cleanMatchTitle$($evWinDl.KickTag) ($($cm.Label))"; Slug = $cm.Slug
                                Hint = $dlHint; StartsAtUtc = $evWinDl.StartsAtUtcStr; EndsAtUtc = $evWinDl.EndsAtUtcStr
                            })
                            break
                        }
                    }
                }
            }
            foreach ($sl in $neededDlSlugs) {
                $slKey = $sl.ToLowerInvariant()
                if (-not $script:VipSlugCache.ContainsKey($slKey) -and -not $uQueuedSlugs.Contains($slKey)) {
                    $jKey = "slug|$slKey"
                    if ($uQueuedKeys.Add($jKey)) {
                        $null = $uQueuedSlugs.Add($slKey)
                        $uJobs.Add([PSCustomObject]@{ Kind = "dl_slug"; Key = $jKey; Slug = $sl; WxHost = $sxHost888 })
                    }
                }
            }
        }
    } catch { Write-Host "       [-] Aviso consultando DeporteLibre agenda: $($_.Exception.Message)" -ForegroundColor DarkGray }

    # -- Parse G: CandyShop Health & SSF Probes --
    $candyOnline = $false
    $candyUptimeStr = ""
    try {
        $candyRaw = $script:Prefetched["CandyHealth"]
        if ($candyRaw) {
            $candyHealth = $candyRaw | ConvertFrom-Json
            if ($candyHealth -and $candyHealth.status -eq "ok") {
                $candyOnline = $true
                $candyUptimeStr = "$([Math]::Round($candyHealth.uptime/3600, 1))h"
            }
        }
    } catch {}
    if ($candyOnline) {
        1..12 | ForEach-Object {
            $cCode = "CA$_"
            $uJobs.Add([PSCustomObject]@{ Kind = "candy_ca"; Key = "ca|$cCode"; Code = $cCode; Url = "https://xstream.st/capopro.php?stream=$cCode"; Ref = "https://cdplay.live/" })
        }
    }
    $ssfMap = @(
        @{ Code = "SSF44"; Name = "Fox Soccer Plus HD"; Id = "1385756340" },
        @{ Code = "SSF32"; Name = "TNT Sports 1 (UK HD)"; Id = "45" },
        @{ Code = "SSF33"; Name = "TNT Sports 2 (UK HD)"; Id = "46" },
        @{ Code = "SSF34"; Name = "TNT Sports 3 (UK HD)"; Id = "47" },
        @{ Code = "SSF35"; Name = "TNT Sports 4 (UK HD)"; Id = "48" },
        @{ Code = "SSF31"; Name = "Sky Sports F1 (Directo HD)"; Id = "44" },
        @{ Code = "SSF17"; Name = "FOX Deportes HD"; Id = "30" },
        @{ Code = "SSF47"; Name = "ESPN Latino Directo"; Id = "60" },
        @{ Code = "SSF48"; Name = "ESPN 2 Latino Directo"; Id = "61" },
        @{ Code = "SSF51"; Name = "ESPN 4 Latino Directo"; Id = "64" }
    )
    @("SSF49", "SSF31", "SSF32", "SSF44", "SSF33", "SSF34", "SSF35", "SSF17", "SSF47", "SSF48", "SSF51") | ForEach-Object {
        $uJobs.Add([PSCustomObject]@{ Kind = "candy_ssf"; Key = "ssf|$_"; Code = $_; Url = "https://xstream.st/livetvfx.php?stream=$_"; Ref = "https://embedme.st/" })
    }

    # --- OLA ÚNICA PARALELA (96 hilos simultáneos) ---
    Write-Host ("   [*] Resolviendo {0} endpoints únicos de agendas y eventos en 1 sola ola paralela (96 hilos)..." -f $uJobs.Count) -ForegroundColor DarkCyan
    $uRawResults = Invoke-ParallelItems -Items @($uJobs) -ScriptBlock {
        param($j)
        try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
        if ($j.WxHost) { $global:ActiveStreamxHost = $j.WxHost }
        switch ($j.Kind) {
            "fl_ev" {
                $deep = Resolve-EmbedAnyUrl -Url $j.Url -Referer "https://futbollibregol.org/"
                return [PSCustomObject]@{ Key = $j.Key; M3u = $deep }
            }
            "xhd" {
                $m3u = Resolve-StreamXhdUrl -LivePageUrl $j.Url -Referer "https://streamxhd.click/"
                if (-not $m3u) { $m3u = Resolve-EmbedAnyUrl -Url $j.Url -Referer "https://streamxhd.click/" }
                $pageOk = if (-not $m3u) { [bool](Get-Utf8Content -Uri $j.Url -Referer "https://streamxhd.click/" -TimeoutSec 2) } else { $true }
                return [PSCustomObject]@{ Key = $j.Key; M3u = $m3u; PageOk = $pageOk }
            }
            "ag888" {
                $m3u = $null; $sl = [string]$j.Slug
                if ($j.Url -match 'https?://([^/]+)/global[13]\.php' -and $sl) {
                    $m3u = Resolve-StreamxNodeUrl -ChannelSlug $sl -HostDomain $Matches[1] -Referer "https://cdplay.live/"
                } else {
                    $m3u = Resolve-StreamXhdUrl -LivePageUrl $j.Url -Referer "https://cdplay.live/"
                }
                if (-not $m3u -and $sl) { $m3u = Resolve-StreamXhdUrl -LivePageUrl ("https://streamxhd.click/live1.php?stream=" + $sl) -Referer "https://streamxhd.click/" }
                if (-not $m3u -and $sl) { $m3u = Resolve-Tvf90Url -StreamSlug $sl }
                return [PSCustomObject]@{ Key = $j.Key; M3u = $m3u; Slug = $sl }
            }
            "fl_html" {
                $flMaster = $j.Url; $keep = $true
                $flPage = Get-Utf8Content -Uri $j.Url -Referer "https://futbollibregol.org/" -TimeoutSec 3
                if (-not $flPage) { $keep = $false }
                elseif ($flPage -match '<iframe[^>]+src=["'']([^"'']+)["'']') {
                    $rawIfr = $Matches[1].Trim()
                    $deepFl = Resolve-EmbedAnyUrl -Url $rawIfr -Referer $j.Url
                    if ($deepFl) { $flMaster = $deepFl }
                    elseif ($rawIfr -match 'tvf90\.com/(?:[a-z0-9_-]+\.php|online/canal\.php)\?stream=([^&\s]+)') {
                        $xhdBk = Resolve-StreamXhdUrl -LivePageUrl ("https://streamxhd.click/live1.php?stream=" + $Matches[1])
                        if ($xhdBk) { $flMaster = $xhdBk } else { $keep = $false }
                    } else { $flMaster = $rawIfr }
                }
                return [PSCustomObject]@{ Key = $j.Key; MasterUrl = $flMaster; Keep = $keep }
            }
            "em_game" {
                $emMaster = $null
                foreach ($candU in $j.AltUrls) {
                    $deepEm = Resolve-EmbedAnyUrl -Url $candU -Referer "https://embedme.st/"
                    if ($deepEm) { $emMaster = $deepEm; break }
                }
                if (-not $emMaster -and $j.Upcoming) {
                    $gBody = Get-Utf8Content -Uri $j.Url -Referer "https://embedme.st/" -TimeoutSec 2
                    if ($gBody) { $emMaster = $j.Url }
                }
                return [PSCustomObject]@{ Key = $j.Key; MasterUrl = $emMaster }
            }
            "em_ch" {
                $emMaster = $null
                $deepCh = Resolve-EmbedAnyUrl -Url $j.Url -Referer "https://embedme.st/"
                if ($deepCh) { $emMaster = $deepCh }
                else {
                    $emCheck = Get-Utf8Content -Uri $j.Url -Referer "https://embedme.st/" -TimeoutSec 2
                    if ($emCheck -and $emCheck -notmatch '(?i)404\s*Not\s*Found|channel\s*offline') { $emMaster = $j.Url }
                }
                return [PSCustomObject]@{ Key = $j.Key; MasterUrl = $emMaster }
            }
            "dl_slug" {
                $sl = [string]$j.Slug
                $u = Resolve-StreamxNodeUrl -ChannelSlug $sl -HostDomain $j.WxHost -Referer "https://cdplay.live/"
                if (-not $u) { $u = Resolve-StreamXhdUrl -LivePageUrl "https://streamxhd.click/live1.php?stream=$sl" -Referer "https://streamxhd.click/" }
                if (-not $u) { $u = Resolve-Tvf90Url -StreamSlug $sl }
                return [PSCustomObject]@{ Key = $j.Key; Slug = $sl; M3u = $u }
            }
            "candy_ca" {
                $h = Resolve-CapoCandyShop -IframeUrl $j.Url -Referer $j.Ref
                return [PSCustomObject]@{ Key = $j.Key; Kind = "CA"; Code = $j.Code; Url = $j.Url; Hls = $h }
            }
            "candy_ssf" {
                $h = Resolve-CapoCandyShop -IframeUrl $j.Url -Referer $j.Ref
                return [PSCustomObject]@{ Key = $j.Key; Kind = "SSF"; Code = $j.Code; Url = $j.Url; Hls = $h }
            }
        }
    }

    $uResMap = @{}
    foreach ($ur in $uRawResults) {
        if ($ur -and $ur.Key) {
            $uResMap[$ur.Key] = $ur
            if ($ur.PSObject.Properties['M3u'] -and $ur.M3u -and $ur.PSObject.Properties['Slug'] -and $ur.Slug) {
                $sk = $ur.Slug.ToLowerInvariant()
                if (-not $script:VipSlugCache.ContainsKey($sk)) { $script:VipSlugCache[$sk] = $ur.M3u }
            }
        }
    }

    $seenChanNames = [System.Collections.Generic.HashSet[string]]::new()
    foreach ($ec0 in $allChannels) { if ($ec0.Name) { $null = $seenChanNames.Add($ec0.Name) } }

    # --- Consolidación rápida (CPU) en orden exacto de prioridad ---
    # 1) Futbol Libre
    $addedDiaries = 0
    foreach ($wi in $flWorkItems) {
        $resolved = $wi.EmbUrl; $drop = $false
        if ($wi.NeedsProbe) {
            $rr = $uResMap[$wi.JobKey]
            if ($rr -and $rr.M3u) { $resolved = $rr.M3u }
            elseif ($wi.EmbUrl -match '\.m3u8(?:\?|$)' -or $wi.LiveNow) { $drop = $true }
        }
        if ($drop -or -not $seenChanNames.Add($wi.MatchDisplay)) { continue }
        $flHint = if ($wi.CleanMatch -match '(?i)\b(?:Tenis|Tennis|WTA|ATP|Roland\s*Garros|Wimbledon|Grand\s*Slam|Copa\s*Davis|Davis\s*Cup|Alcaraz|Sinner|Djokovic|Badosa|Swiatek|Sabalenka)\b') { "Tennis" } elseif ($wi.CleanMatch -match '(?i)\b(?:UFC|Boxeo|Golf|F1|MotoGP)\b') { "" } else { "Football" }
        $allChannels += [PSCustomObject]@{
            Id = "fl_ev_" + ($wi.MatchDisplay -replace '[^a-zA-Z0-9]',''); Name = $wi.MatchDisplay
            Group = Get-ChannelGroup $wi.CleanMatch $flHint; Slug = "futbollibre_event"; MasterUrl = $resolved
            FallbackUrl = $wi.EmbUrl; VpnRequired = $true; StartsAtUtc = $wi.StartsAtUtc; EndsAtUtc = $wi.EndsAtUtc
        }
        Write-Host "   [+] [Fútbol En Vivo] $($wi.MatchDisplay) " -NoNewline -ForegroundColor Cyan
        if ($resolved -match '\.m3u8') { Write-Host "[HLS Verificado | Necesita VPN]" -ForegroundColor DarkGreen } else { Write-Host "[Necesita VPN]" -ForegroundColor Red }
        $addedDiaries++
    }
    if ($flEventsCount -gt 0) { Write-Host "       [+] Agenda Fútbol Libre API: $flEventsCount eventos analizados, $addedDiaries señales añadidas." -ForegroundColor DarkGreen }

    # 2) StreamXHD eventos.json
    Enter-ScanPhase 'StreamXhd' $esModoVpn
    $addedXhdEv = 0
    foreach ($ce in $xhdCandidateEvents) {
        $cached = $uResMap[$ce.JobKey]
        $masterXhd = if ($cached -and $cached.M3u) { $cached.M3u } elseif ($ce.Upcoming -and $cached -and $cached.PageOk) { $ce.SrvUrl } else { $null }
        if ($masterXhd -and $seenChanNames.Add($ce.DispName)) {
            $allChannels += [PSCustomObject]@{
                Id = "xhd_" + ($ce.DispName -replace '[^a-zA-Z0-9]',''); Name = $ce.DispName
                Group = Get-ChannelGroup $ce.Title $ce.Hint; Slug = "streamxhd_event"; MasterUrl = $masterXhd
                FallbackUrl = $ce.SrvUrl; VpnRequired = $true; StartsAtUtc = $ce.StartsAtUtc; EndsAtUtc = $ce.EndsAtUtc
            }
            Write-Host "   [+] [Agenda StreamXHD · $($ce.League)] $($ce.DispName) " -NoNewline -ForegroundColor Cyan
            if ($cached.M3u) { Write-Host "[HLS Verificado | Necesita VPN]" -ForegroundColor DarkGreen } else { Write-Host "[Programado | Necesita VPN]" -ForegroundColor Yellow }
            $addedXhdEv++
        }
    }
    if ($xhdCandidateEvents.Count -gt 0) { Write-Host "       [+] Agenda StreamXHD: $addedXhdEv señales activas/programadas sincronizadas." -ForegroundColor DarkGreen }

    # 3) Agenda888 Castellano
    Enter-ScanPhase 'CastVip' $esModoVpn
    $added888 = 0
    foreach ($c8 in $a8Cand) {
        $cKey8 = if ($c8.SlugCode) { $c8.SlugCode.ToLowerInvariant() } else { "" }
        $resolvedM3u = if ($cKey8 -and $script:VipSlugCache.ContainsKey($cKey8)) { $script:VipSlugCache[$cKey8] } elseif ($uResMap.ContainsKey($c8.JobKey)) { $uResMap[$c8.JobKey].M3u } else { $null }
        $finalM3u = if ($resolvedM3u) { $resolvedM3u } elseif ($c8.Upcoming) { $c8.Fallback } else { $null }
        if ($finalM3u -and $seenChanNames.Add($c8.DispName)) {
            $a8Hint = if ($c8.Category -match '(?i)tenis|tennis|atp|wta' -or $c8.Title -match '(?i)tenis|tennis|atp|wta|roland\s*garros|wimbledon|davis|alcaraz|sinner|djokovic|badosa|swiatek|sabalenka') { "Tennis" } elseif ($c8.Category -match '(?i)f[uú]tbol|soccer|liga|cup|champions' -or -not $c8.Category) { "Football" } else { "" }
            $allChannels += [PSCustomObject]@{
                Id = "s888_" + ($c8.DispName -replace '[^a-zA-Z0-9]',''); Name = $c8.DispName
                Group = Get-ChannelGroup "$($c8.Title) $($c8.SlugCode)" $a8Hint; Slug = "agenda888"; MasterUrl = $finalM3u
                FallbackUrl = $c8.Fallback; VpnRequired = $true; StartsAtUtc = $c8.StartsAtUtc; EndsAtUtc = $c8.EndsAtUtc
            }
            $color8 = if ($c8.DispName -match 'Castellano') { "Green" } else { "Cyan" }
            Write-Host "   [+] [Agenda888] $($c8.DispName) " -NoNewline -ForegroundColor $color8
            if ($resolvedM3u) { Write-Host "[HLS Verificado | Necesita VPN]" -ForegroundColor DarkGreen } else { Write-Host "[Programado | Necesita VPN]" -ForegroundColor Yellow }
            $added888++
        }
    }
    if ($a8Cand.Count -gt 0) { Write-Host "       [+] Agenda888 Castellano/Deportes: $added888 señales sincronizadas." -ForegroundColor DarkGreen }

    # 4) Futbol Libre HTML canales
    foreach ($it in $flHtmlItems) {
        $fhr = $uResMap[$it.JobKey]
        $keep = ($fhr -and $fhr.Keep)
        $flMaster = if ($fhr) { $fhr.MasterUrl } else { $it.Url }
        if ($keep -and (Test-IsEventFinalized $flMaster $it.Title $null)) { $keep = $false }
        if (-not $keep) {
            $finalizedEvents += [PSCustomObject]@{ Name = $it.Title; Url = $it.Url; Reason = "Canal Fútbol Libre sin segmentos activos (404)" }
            continue
        }
        if ($seenChanNames.Add($it.Title)) {
            $allChannels += [PSCustomObject]@{
                Id = "fl_" + ($it.Title -replace '[^a-zA-Z0-9]',''); Name = $it.Title; Group = Get-ChannelGroup $it.Title
                Slug = "futbollibre"; MasterUrl = $flMaster; FallbackUrl = $it.Url; VpnRequired = $true
            }
            Write-Host "   [+] $($it.Title) " -NoNewline -ForegroundColor Green
            if ($flMaster -match '\.m3u8') { Write-Host "[HLS Verificado | Necesita VPN]" -ForegroundColor DarkGreen } else { Write-Host "[Necesita VPN]" -ForegroundColor Red }
        }
    }

    # 5) EmbedMe Partidos + Canales 24/7
    Enter-ScanPhase 'EmbedMe' $esModoVpn
    foreach ($gi in $emGameWork) {
        $gr = $uResMap[$gi.JobKey]
        if (-not $gr -or -not $gr.MasterUrl) { continue }
        if ($seenChanNames.Add($gi.Name)) {
            $allChannels += [PSCustomObject]@{
                Id = "em_" + ($gi.Id -replace '[^a-zA-Z0-9]',''); Name = $gi.Name; Group = Get-ChannelGroup $gi.Name $gi.Hint
                Slug = "embedme_game"; MasterUrl = $gr.MasterUrl; FallbackUrl = $gi.Url; VpnRequired = $true
                StartsAtUtc = $gi.StartsAtUtc; EndsAtUtc = $gi.EndsAtUtc
            }
            Write-Host "   [+] [Agenda Fútbol/Deportes] $($gi.Name) " -NoNewline -ForegroundColor Cyan
            if ($gr.MasterUrl -match '\.m3u8') { Write-Host "[HLS Verificado | Necesita VPN]" -ForegroundColor DarkGreen } else { Write-Host "[Necesita VPN]" -ForegroundColor Red }
        }
    }
    $addedEmCh = 0
    foreach ($ci in $emChWork) {
        $cr = $uResMap[$ci.JobKey]
        if ($cr -and $cr.MasterUrl -and $seenChanNames.Add($ci.Name)) {
            $allChannels += [PSCustomObject]@{
                Id = "emch_" + $ci.Id; Name = $ci.Name; Group = Get-ChannelGroup $ci.Name; Slug = "embedme_ch"
                MasterUrl = $cr.MasterUrl; FallbackUrl = $ci.Url; VpnRequired = $true
            }
            $addedEmCh++
        }
    }
    if ($addedEmCh -gt 0) { Write-Host "       [+] Añadidos $addedEmCh canales adicionales activos desde EmbedMe." -ForegroundColor DarkGreen }

    # 6) DeporteLibre Castellano
    Enter-ScanPhase 'DepLibre' $esModoVpn
    $addedDlCast = 0
    foreach ($dc in $dlCandMatches) {
        $slKey = $dc.Slug.ToLowerInvariant()
        $hlsU = if ($script:VipSlugCache.ContainsKey($slKey)) { $script:VipSlugCache[$slKey] } else { $null }
        $firstTeam = (($dc.Title -split '\s+vs\s+|\s+-\s+')[0] -replace '[^a-zA-Z0-9áéíóúÁÉÍÓÚñÑ ]','').Trim().Split(' ')[0]
        $dupMatch = if ($hlsU -and $firstTeam -and $firstTeam.Length -ge 3) {
            $allChannels | Where-Object { $_.MasterUrl -eq $hlsU -and $_.Name -match [regex]::Escape($firstTeam) }
        } else { $null }
        if ($hlsU -and -not $dupMatch -and $seenChanNames.Add($dc.DispName)) {
            $allChannels += [PSCustomObject]@{
                Id = "dlcast_" + ($dc.DispName -replace '[^a-zA-Z0-9]',''); Name = $dc.DispName
                Group = Get-ChannelGroup "$($dc.Title) $($dc.Slug)" $dc.Hint; Slug = "deportelibre_castellano"
                MasterUrl = $hlsU; FallbackUrl = "https://$sxHost888/global3.php?channel=$($dc.Slug)"; VpnRequired = $true
                StartsAtUtc = $dc.StartsAtUtc; EndsAtUtc = $dc.EndsAtUtc
            }
            Write-Host "   [+] [Castellano Directo] $($dc.DispName) [HLS Verificado | Necesita VPN]" -ForegroundColor Green
            $addedDlCast++
        }
    }
    if ($addedDlCast -gt 0) { Write-Host "       [+] DeporteLibre Agenda Castellano: $addedDlCast emisiones en español castellano añadidas." -ForegroundColor DarkGreen }

    # 7) CandyShop + InStreams
    Enter-ScanPhase 'CandySS' $esModoVpn
    if ($candyOnline) {
        Write-Host "       [+] Nodo CandyShop Edge 2: ONLINE (Uptime: $candyUptimeStr | $($script:CandyShopActiveCount) feeds HLS)" -ForegroundColor DarkGreen
    }
    $ssfCache = @{}
    foreach ($wr in $uRawResults) {
        if (-not $wr) { continue }
        if ($wr.Kind -eq "CA" -and $wr.Hls) {
            $extraName = "Capo Deportes Extra ($($wr.Code))"
            if (-not ($allChannels | Where-Object { $_.MasterUrl -eq $wr.Hls }) -and $seenChanNames.Add($extraName)) {
                $allChannels += [PSCustomObject]@{
                    Id = "candy_" + $wr.Code; Name = $extraName; Group = "Deportes España"; Slug = "candyshop"
                    MasterUrl = $wr.Hls; FallbackUrl = $wr.Url; VpnRequired = $true
                }
                $script:CandyShopActiveCount++
                Write-Host "   [+] $extraName [HLS Directo CandyShop | Necesita VPN]" -ForegroundColor DarkGreen
            }
        } elseif ($wr.Kind -eq "SSF") {
            $ssfCache[$wr.Code] = $wr.Hls
        }
    }
    $ssf49Hit = $ssfCache["SSF49"]
    if ($ssf49Hit) {
        $daznF1Feeds.Add([PSCustomObject]@{ Url = $ssf49Hit; Fallback = "https://embedme.st/play/channel-62.php"; Source = "instreams"; Verified = $true })
    }
    $anySsfHit = ($ssfCache.Values | Where-Object { $_ } | Select-Object -First 1) -or ($allChannels | Where-Object { $_.MasterUrl -match '/live3/SSF' })
    if ($anySsfHit) {
        $script:InStreamsStatus = "ONLINE"
        Write-Host "       [+] Red InStreams / CandyShop SSF ONLINE: Canales HLS directos verificados." -ForegroundColor DarkGreen
        foreach ($sm in $ssfMap) {
            $hUrl = $ssfCache[$sm.Code]
            if ($hUrl -and $seenChanNames.Add($sm.Name)) {
                $allChannels += [PSCustomObject]@{
                    Id = "in_" + $sm.Code; Name = $sm.Name; Group = Get-ChannelGroup $sm.Name; Slug = "instreams"
                    MasterUrl = $hUrl; FallbackUrl = "https://embedme.st/play/channel-$($sm.Id).php"; VpnRequired = $true
                }
                Write-Host "   [+] $($sm.Name) [HLS Directo InStreams | Necesita VPN]" -ForegroundColor DarkGreen
            }
        }
    } else {
        $script:InStreamsStatus = "STANDBY_NO_VPN"
        Write-Host "       [*] Nodo InStreams Offshore en espera de túnel VPN (Finlandia)" -ForegroundColor DarkGray
    }
    # 3.6 Consolidación y Normalización de DAZN F1 España (Opciones limpias sin SD ni HD + Segmentos verificados)
    Write-Host "`n   [*] Consolidando señales de DAZN F1 España..." -ForegroundColor DarkCyan
    if ($daznF1Feeds.Count -eq 0) {
        $daznF1Feeds.Add([PSCustomObject]@{ Url = "https://cdplay.live/formula1hd.php"; Fallback = "https://cdplay.live/formula1hd.php"; Source = "cdplay"; Verified = $false })
        $daznF1Feeds.Add([PSCustomObject]@{ Url = "https://cdplay.live/formula1.php"; Fallback = "https://cdplay.live/formula1.php"; Source = "cdplay"; Verified = $false })
    }

    $f1OptIdx = 1
    $seenF1 = [System.Collections.Generic.HashSet[string]]::new()
    foreach ($feed in $daznF1Feeds) {
        if (-not $seenF1.Contains($feed.Url)) {
            $seenF1.Add($feed.Url) | Out-Null
            if (-not $feed.Verified -and $feed.Url -match '\.m3u8(?:\?|$)' -and -not (Test-HlsDeepLive -Uri $feed.Url -Referer ($feed.Fallback) -TimeoutSec 3)) {
                $finalizedEvents += [PSCustomObject]@{ Name = "DAZN F1 España ($($feed.Source))"; Url = $feed.Url; Reason = "Señal F1 sin segmentos activos (403/404)" }
                continue
            }
            $optName = "DAZN F1 España (Opción $f1OptIdx)"
            $allChannels += [PSCustomObject]@{
                Id          = "daznf1_opt$f1OptIdx"
                Name        = $optName
                Group       = "F1 España"
                Slug        = "daznf1"
                MasterUrl   = $feed.Url
                FallbackUrl = if ($feed.Fallback) { $feed.Fallback } else { $feed.Url }
                VpnRequired = ($feed.Source -ne "f1net")
            }
            Write-Host "   [+] $optName " -NoNewline -ForegroundColor Green
            if ($feed.Source -ne "f1net") {
                Write-Host "[$($feed.Source) | Necesita VPN]" -ForegroundColor Red
            } else {
                Write-Host "[VPN No Necesaria]" -ForegroundColor DarkGreen
            }
            $f1OptIdx++
        }
    }
} else {
    # MODO ESTRICTO SIN VPN: Filtro definitivo para garantizar CERO canales de VPN
    $allChannels = @($allChannels | Where-Object { -not $_.VpnRequired })
}

# -------------------------------------------------------------
# 4. API ACESTREAM P2P ESPAÑA (https://search-ace.stream/ - Solo PC)
# -------------------------------------------------------------
function Invoke-AceStreamFreshSearchApi {
    param(
        [string[]]$Tags = @("m+", "movistar", "motogp", "f1", "formula", "dazn", "tenis", "tennis", "atp", "wta", "tennis channel", "laliga", "champions", "deportes", "eurosport", "golf", "vamos", "elcano", "shickat"),
        [int]$MaxChannels = 90
    )
    $aceRawLists = Invoke-ParallelItems -Items $Tags -ScriptBlock {
        param($q)
        try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }
        $apiUri = "https://search-ace.stream/search?query=" + [uri]::EscapeDataString($q)
        $json = Get-Utf8Content -Uri $apiUri -Referer "https://search-ace.stream/" -TimeoutSec 5
        if (-not $json) { return $null }
        try { return ($json | ConvertFrom-Json) } catch { return $null }
    }

    $cidMap = @{}
    foreach ($arr in $aceRawLists) {
        if (-not $arr) { continue }
        foreach ($item in $arr) {
            $cid = ([string]$item.content_id).Trim().ToLowerInvariant()
            if ($cid -notmatch '^[a-f0-9]{40}$') { continue }
            $rawName = ([string]$item.name).Trim()
            if ([string]::IsNullOrWhiteSpace($rawName)) { continue }
            $up = if ($null -ne $item.thumbs_up) { [int]$item.thumbs_up } else { 0 }
            $dn = if ($null -ne $item.thumbs_down) { [int]$item.thumbs_down } else { 0 }
            if ($up -eq 0 -and $dn -ge 2) { continue }
            if ($dn -gt ($up + 3)) { continue }
            $score = ($up * 3) - ($dn * 2)
            if (-not $cidMap.ContainsKey($cid) -or $score -gt $cidMap[$cid].Score) {
                $cidMap[$cid] = [PSCustomObject]@{
                    Cid     = $cid
                    RawName = $rawName
                    Score   = $score
                    Up      = $up
                    Down    = $dn
                }
            }
        }
    }

    $results = [System.Collections.Generic.List[object]]::new()
    $seenAceNames = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    $aceCandidates = @($cidMap.Values | Sort-Object -Property @{ Expression = { $_.Score }; Descending = $true }, @{ Expression = { $_.Up }; Descending = $true })
    foreach ($cand in $aceCandidates) {
        if ($results.Count -ge $MaxChannels) { break }
        $rn = $cand.RawName
        if ($rn -match '(?i)\b(?:test|promo|adult|xxx|vod)\b') { continue }
        $isMotor = ($rn -match '(?i)F1|Formula\s*1|Fórmula\s*1|Moto\s*GP|MotoGP|F1TV')
        $isTennis = ($rn -match '(?i)\b(?:Tennis\s*Channel|Tenis|Tennis|ATP|WTA|Wimbledon|Roland\s*Garros)\b' -and $cand.Score -ge 1 -and $rn -notmatch '(?i)\[(?:DE|PL|RU|IT|FR|NL|TR|PT|RO|BR|CZ|HU)\]')
        $isSpanishNet = ($rn -match '(?i)DAZN|M\+|M\.|Movistar|LaLiga|Hypermotion|Campeones|Deportes|Vamos|Golf|Estrenos|Cl[aá]sicos|Comedia|Drama|Terror|Indie|Romance|Hits|Originales|Documentales|Cine\s*Espa|Teledeporte|\bLa\s*[12]\b|Antena\s*3|Cuatro|Telecinco|La\s*Sexta' -and $rn -notmatch '(?i)\[(?:DE|PL|RU|IT|FR|NL|TR|UK|PT|RO|BR|CZ|HU)\]')
        $isCleanEurosport = ($rn -match '(?i)^Eurosport\s*[12]\b' -and $rn -notmatch '(?i)\[(?:RU|PL|NL|IT|DE|FR|TR|AR|UK|PT|RO|BR|CZ|HU)\]' -and $rn -notmatch '(?i)\b(?:RUS|POL|GER|FRA|ITA|POR|RUM|TUR)\b')
        if (-not ($isMotor -or $isTennis -or $isSpanishNet -or $isCleanEurosport)) { continue }
        if ($isMotor -and -not $isSpanishNet -and $cand.Score -lt 6) { continue }

        $clean = $rn -replace '\|.*$', '' `
                     -replace '-->?\s*NEW\s*ERA', '' `
                     -replace '(?i)\b(?:IPNS|ZeroNet)\b', '' `
                     -replace '\[[^\]]*https?[^\]]*\]', '' `
                     -replace 'https?://\S+', '' `
                     -replace '(?i)\belcano\.top\b', '(Elcano)' `
                     -replace '(?i)\bshickat\b', '(Shickat)' `
                     -replace '\s*\((?:Elcano|Shickat)\)\s*\((?:Elcano|Shickat)\)', '' `
                     -replace '(?i)\s+\bSpain\b\s*$', '' `
                     -replace '\s{2,}', ' '
        $clean = $clean.Trim(' ', '-', '|', '/')
        if ([string]::IsNullOrWhiteSpace($clean)) { continue }
        if ($clean -match '^M\.?\s+(Deportes.*)$') { $clean = "M+ $($Matches[1])" }
        elseif ($clean -match '^M\.\s*(.+)$') { $clean = "M+ $($Matches[1])" }
        if ($clean -match '(?i)^Moto\s*GP\b' -and $clean -notmatch '(?i)DAZN') { $clean = "DAZN " + $clean }
        if ($clean -match '(?i)Moto\s*GP') { $clean = ($clean -replace '(?i)Moto\s*GP', 'MotoGP') }

        $dispName = "$clean [AceStream P2P]"
        $grp = Get-ChannelGroup $dispName ""
        if ($grp -in @('Baloncesto', 'NFL')) { continue }
        if (-not $seenAceNames.Add($dispName)) { continue }

        $results.Add([PSCustomObject]@{
            Id          = "ace_" + $cand.Cid.Substring(0, 12)
            Name        = $dispName
            Group       = $grp
            Slug        = "acestream"
            MasterUrl   = "acestream://$($cand.Cid)"
            FallbackUrl = "http://127.0.0.1:6878/ace/manifest.m3u8?id=$($cand.Cid)"
            VpnRequired = $false
            Score       = $cand.Score
            Up          = $cand.Up
            Down        = $cand.Down
        })
    }
    return @($results)
}

Enter-ScanPhase 'AceStream' $esModoVpn
if ($esBuscarAceStream) {
    $script:AceStreamStatus = "OFFLINE"
    Write-Host "`n [+] Consultando API AceStream de AtomicBombTV (M+, MotoGP, Tenis, F1, DAZN)..." -ForegroundColor Cyan
    try {
        $aceChannels = Invoke-AceStreamFreshSearchApi
        $aceAdded = 0
        foreach ($ach in $aceChannels) {
            $allChannels += [PSCustomObject]@{
                Id          = $ach.Id
                Name        = $ach.Name
                Group       = $ach.Group
                Slug        = $ach.Slug
                MasterUrl   = $ach.MasterUrl
                FallbackUrl = $ach.FallbackUrl
                VpnRequired = $false
            }
            $aceAdded++
            Write-Host "   [+] $($ach.Name) [+$($ach.Up)/-$($ach.Down) | $($ach.Group)]" -ForegroundColor Magenta
        }

        if ($aceAdded -gt 0) {
            $script:AceStreamStatus = "ONLINE ($aceAdded P2P)"
            Write-Host "       [+] API AceStream sincronizada: $aceAdded canales frescos (M+, MotoGP, Tenis, F1, DAZN)" -ForegroundColor Green
        } else {
            Write-Host "       [-] AceStream P2P sin resultados activos en esta consulta." -ForegroundColor DarkGray
        }
    } catch {
        Write-Host "       [-] No se pudo consultar la API AceStream ahora." -ForegroundColor DarkGray
    }
} else {
    $script:AceStreamStatus = "OMITIDO (N)"
    Write-Host "`n [i] AceStream omitido por el usuario (N): se conservan solo los canales actuales." -ForegroundColor Yellow
}

if ($script:ParallelPool) {
    try { $script:ParallelPool.Close(); $script:ParallelPool.Dispose() } catch {}
    $script:ParallelPool = $null
}
$script:ScanTimer.Stop()

Enter-ScanPhase 'WebPurge' $esModoVpn
Invoke-WebAiEventPurge

Enter-ScanPhase 'Save' $esModoVpn
Write-Host ""
Write-Host " ========================================================" -ForegroundColor Red
Write-Host "  Modo de operacion: $(if ($esModoVpn) { 'CON VPN (Todos los servidores)' } else { 'SIN VPN (Solo canales abiertos)' })" -ForegroundColor Yellow
Write-Host "  Total canales sincronizados: $($allChannels.Count)" -ForegroundColor Green
if ($finalizedEvents.Count -gt 0) {
    Write-Host "  Eventos finalizados purgados por API/IA: $($finalizedEvents.Count)" -ForegroundColor DarkYellow
}
if ($script:SkippedSportsCount -gt 0) {
    Write-Host "  Deportes excluidos (NBA/NFL/NHL/Copa Col.): $($script:SkippedSportsCount)" -ForegroundColor DarkGray
}
Write-Host ("  Tiempo total de escaneo paralelo: {0:N1}s" -f $script:ScanTimer.Elapsed.TotalSeconds) -ForegroundColor Cyan
Write-Host " ========================================================" -ForegroundColor Red
Write-Host ""

# -------------------------------------------------------------
# 5. ORDENAR (CASTELLANO PRIMERO) Y GUARDAR PLAYLIST M3U UNIFICADA
# -------------------------------------------------------------
$allChannels = @($allChannels | Sort-Object `
    Group, `
    @{ Expression = { if ($_.MasterUrl -match '^acestream://') { 1 } else { 0 } } }, `
    @{ Expression = { if ($_.Name -match '(?i)Castellano|RTVE|M\+\s*LaLiga|DAZN.*Espa|Gol\s*Play|Teledeporte|DMAX|TRECE|El Toro|Telemadrid|Canal Sur|TV3|À Punt|ETB|TVG') { 0 } elseif ($_.Name -match 'Latino') { 2 } else { 1 } } }, `
    @{ Expression = { [regex]::Replace([string]$_.Name, '\d+', { param($m) $m.Value.PadLeft(5, '0') }) } }
)
$usedIds = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
foreach ($ch in $allChannels) {
    $rawId = if ([string]::IsNullOrWhiteSpace($ch.Id)) { "ch_" + ($ch.Name -replace '\+', 'Plus' -replace '[^a-zA-Z0-9]', '') } else { [string]$ch.Id }
    $candId = $rawId
    $suffix = 2
    while (-not $usedIds.Add($candId)) {
        $candId = "${rawId}_${suffix}"
        $suffix++
    }
    $ch.Id = $candId
}
$sorted = $allChannels
$m3uContent = "#EXTM3U url-tvg=`"`" tvg-shift=0`r`n# AtomicBombTV Estable 1.9 | Author: Faraz Arif Malik. Residencia Badalona.`r`n"

$m3uSb = [System.Text.StringBuilder]::new($m3uContent)
foreach ($c in $sorted) {
    $vpnTag = if ($c.VpnRequired) { "[Necesita VPN]" } else { "[VPN No Necesaria]" }
    [void]$m3uSb.AppendLine("#EXTINF:-1 tvg-name=`"$($c.Name)`" group-title=`"$($c.Group)`",$($c.Name) $vpnTag")
    [void]$m3uSb.AppendLine("$($c.MasterUrl)")
}
$m3uContent = $m3uSb.ToString()

    [System.IO.File]::WriteAllText($OutputFile, $m3uContent, [System.Text.UTF8Encoding]::new($true))

# -------------------------------------------------------------
# 6. GUARDAR ESTADO DE LA API LOCAL (events-status.json)
# -------------------------------------------------------------
$apiObj = [PSCustomObject]@{
    version          = "Estable 1.9"
    generated_at     = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    vpn_mode         = [bool]$esModoVpn
    total_channels   = $allChannels.Count
    purged_events    = $finalizedEvents.Count
    server_network   = [PSCustomObject]@{
        embdlol          = "ONLINE"
        ppv_st           = "ONLINE"
        f1net            = "ONLINE"
        rtve_uhd         = "ONLINE"
        formaturamaxi    = $script:FormaturaStatus
        azplay55         = $script:AzplayStatus
        candyshop        = if ($script:CandyShopActiveCount -gt 0) { "ONLINE ($($script:CandyShopActiveCount) HLS)" } else { "ONLINE" }
        instreams        = $script:InStreamsStatus
        futbollibre_api  = $script:FutbolLibreApiStatus
        streamxhd_agenda = $script:StreamXhdStatus
        embedme          = $script:EmbedMeStatus
        cdplay           = if ($esModoVpn) { "ONLINE" } else { "VPN_REQUIRED" }
        spanish_vip      = $script:SpanishVipStatus
        redx_hd          = $script:RedxEsStatus
        acestream        = $script:AceStreamStatus
        web_oracle       = $script:WebOracleStatus
        web_ai_filter    = $script:WebAiStatus
    }
    channels         = $allChannels
    finalized_events = $finalizedEvents
}

    [System.IO.File]::WriteAllText($ApiStatusFile, ($apiObj | ConvertTo-Json -Depth 6), [System.Text.UTF8Encoding]::new($true))

# -------------------------------------------------------------
# 7. INYECTAR DATOS EN TIEMPO REAL DIRECTAMENTE EN EL REPRODUCTOR HTML
# -------------------------------------------------------------
if (Test-Path $HtmlPlayer) {
    try {
        $htmlContent = [System.IO.File]::ReadAllText($HtmlPlayer, [System.Text.Encoding]::UTF8)
        $jsonChannels = $allChannels | ConvertTo-Json -Compress -Depth 5
        $jsonPurged = $finalizedEvents | ConvertTo-Json -Compress -Depth 5
        $jsonNetwork = $apiObj.server_network | ConvertTo-Json -Compress
        
        $replacementTag = @"
  <script id="atomic-live-data">
    window.ATOMIC_LIVE_DATA = {
      vpnMode: $(if ($esModoVpn) { 'true' } else { 'false' }),
      network: $jsonNetwork,
      channels: $jsonChannels,
      purgedEvents: $jsonPurged
    };
  </script>
"@
        if ($htmlContent -match '<script id="atomic-live-data">') {
            $htmlContent = [regex]::Replace($htmlContent, '(?s)<script id="atomic-live-data">.*?<\/script>', $replacementTag)
        } else {
            $htmlContent = $htmlContent -replace '(?i)<\/head>', "$replacementTag`n</head>"
        }
    [System.IO.File]::WriteAllText($HtmlPlayer, $htmlContent, [System.Text.UTF8Encoding]::new($true))
        Write-Host " Sincronizacion directa con el reproductor HTML: OK" -ForegroundColor Green
    } catch {
        Write-Host " Aviso al sincronizar con el reproductor HTML: $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

Write-Host " Resumen por categorias:" -ForegroundColor Cyan
$groups = $allChannels | Group-Object Group | Sort-Object Count -Descending
foreach ($g in $groups) {
    Write-Host "   * $($g.Name): $($g.Count)" -ForegroundColor DarkCyan
}

Write-Host ""
Write-Host " Playlist guardada con exito en:" -ForegroundColor White
Write-Host " $OutputFile" -ForegroundColor DarkGray
Write-Host " API de estado generada en:" -ForegroundColor White
Write-Host " $ApiStatusFile" -ForegroundColor DarkGray
Write-Host ""

try {
    $desktopZip = "C:\Users\javi1\OneDrive\Escritorio\AtomicBombTV 1.9.zip"
    $sourceDir = $ScriptDir
    $filesToZip = @(
        "AtomicBombTV.bat",
        "AtomicBombTV-Player.html",
        "atomicbomb_logo.png",
        "discord-config.json",
        "discord-rpc.ps1",
        "event-finish-cache.json",
        "events-status.json",
        "LEEME.txt",
        "listen",
        "logo.jpg",
        "novedades.txt",
        "playlist.m3u",
        "refresh-playlist.bat",
        "refresh-playlist.ps1"
    )
    if (Test-Path $desktopZip) { Remove-Item $desktopZip -Force -ErrorAction SilentlyContinue }
    Add-Type -AssemblyName System.IO.Compression -ErrorAction SilentlyContinue
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
    $zipArchive = [System.IO.Compression.ZipFile]::Open($desktopZip, [System.IO.Compression.ZipArchiveMode]::Create)
    foreach ($fn in $filesToZip) {
        $fp = Join-Path $sourceDir $fn
        if (Test-Path $fp) {
            [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zipArchive, $fp, $fn, [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
        }
    }
    $zipArchive.Dispose()
    Write-Host " [+] Paquete portable actualizado en el Escritorio: AtomicBombTV 1.9.zip" -ForegroundColor Green
} catch {
    Write-Host " Aviso al actualizar paquete zip portable: $($_.Exception.Message)" -ForegroundColor Yellow
}

Show-ScanProgressBar 100
Disable-QuietScanMode

# -------------------------------------------------------------
# 8. RESUMEN DE CANALES Y LANZAMIENTO DIRECTO
# -------------------------------------------------------------
$totalFound = $allChannels.Count
$totalHls = @($allChannels | Where-Object { $_.MasterUrl -match '\.(?:m3u8|mpd)' }).Count
if ($script:QuietScanActive) { Write-Host "" }
Write-Host "  +--------------------------------------------------------------+" -ForegroundColor DarkCyan
Write-Host ("  |  CANALES ENCONTRADOS: {0,-3} ({1} HLS directos en vivo)        |" -f $totalFound, $totalHls) -ForegroundColor Cyan
Write-Host "  +--------------------------------------------------------------+" -ForegroundColor DarkCyan
foreach ($grpRow in ($allChannels | Group-Object Group | Sort-Object Count -Descending)) {
    Write-Host ("    * {0,-30} : {1,3} canales" -f $grpRow.Name, $grpRow.Count) -ForegroundColor Gray
}
if ($script:QuietScanActive) {
    $purgedTxt = if ($finalizedEvents.Count -gt 0) { " | Purgados: $($finalizedEvents.Count)" } else { "" }
    $modeSummaryLabel = if ($esModoVpn) { 'COMPLETO CON VPN (Todos los canales disponibles)' } else { 'SIN VPN (Solo canales abiertos)' }
    Write-Host ("`n  [+] Modo: {0} | Tiempo: {1:N1}s{2}" -f $modeSummaryLabel, $script:ScanTimer.Elapsed.TotalSeconds, $purgedTxt) -ForegroundColor DarkCyan
    Write-Host "  [+] Playlist guardada: $OutputFile" -ForegroundColor DarkGray
}
Write-Host ""

if ([string]::IsNullOrWhiteSpace($Accion)) {
    Write-Host "  >> ¿Abrir AtomicBombTV? [Pulsa ENTER para abrir | N = Salir]: " -NoNewline -ForegroundColor Green
    if ([Console]::IsInputRedirected) {
        $respOpen = [Console]::In.ReadLine()
        $opcion = if ($null -ne $respOpen -and ($respOpen -eq '' -or $respOpen -match '^(?i)(s|si|y|yes|1)$')) { "1" } else { "3" }
    } else {
        $respOpen = Read-Host
        $opcion = if ([string]::IsNullOrWhiteSpace($respOpen) -or $respOpen -match '^(?i)(s|si|y|yes|1)$') { "1" } else { "3" }
    }
} else {
    $opcion = $Accion
    if ([string]::IsNullOrWhiteSpace($opcion)) { $opcion = "1" }
}

function Test-AtomicHttpFast {
    param([int]$Port, [int]$TimeoutMs = 150)
    if ($Port -le 0) { return $false }
    try {
        $req = [System.Net.WebRequest]::CreateHttp("http://127.0.0.1:$Port/lan-info")
        $req.Proxy = $null
        $req.Timeout = $TimeoutMs
        $req.ReadWriteTimeout = $TimeoutMs
        $resp = $req.GetResponse()
        $sr = New-Object System.IO.StreamReader($resp.GetResponseStream(), [System.Text.Encoding]::UTF8)
        $body = $sr.ReadToEnd()
        $sr.Close()
        $resp.Close()
        return ($body -and $body -match '"status"\s*:\s*"ok"' -and $body -match 'castv2')
    } catch { return $false }
}

function Get-AtomicPortState {
    param([string]$StateFile)
    try {
        if (-not (Test-Path $StateFile)) { return $null }
        $raw = ([System.IO.File]::ReadAllText($StateFile)).Trim()
        if ($raw -match '^(\d+)\|(\d+)$') {
            return [PSCustomObject]@{ Port = [int]$Matches[1]; Pid = [int]$Matches[2] }
        }
    } catch {}
    return $null
}

if ($opcion -eq "1") {
    Invoke-PeriodicListenCheckSilent
    $openSw = [Diagnostics.Stopwatch]::StartNew()
    $rpcScript = Join-Path $ScriptDir "discord-rpc.ps1"
    $portStateFile = Join-Path ([System.IO.Path]::GetTempPath()) "atomicbombtv_http_port.txt"
    $activePort = 45454
    $serverReady = $false

    $existingState = Get-AtomicPortState $portStateFile
    $probePorts = New-Object System.Collections.Generic.List[int]
    if ($existingState -and $existingState.Port -gt 0) { $probePorts.Add($existingState.Port) }
    if (-not $probePorts.Contains(45454)) { $probePorts.Add(45454) }
    foreach ($pp in $probePorts) {
        if (Test-AtomicHttpFast -Port $pp -TimeoutMs 150) {
            $activePort = $pp
            $serverReady = $true
            break
        }
    }

    if (-not $serverReady -and (Test-Path $rpcScript)) {
        $rpcProc = Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$rpcScript`"" -WindowStyle Hidden -PassThru
        $slowMsgShown = $false
        while ($openSw.Elapsed.TotalMilliseconds -lt 6500) {
            if (-not $slowMsgShown -and $openSw.Elapsed.TotalMilliseconds -ge 2200) {
                Write-Host "`n  [~] La carga está tardando más de lo esperado, por favor espera unos segundos..." -ForegroundColor Yellow
                $slowMsgShown = $true
            }

            $st = Get-AtomicPortState $portStateFile
            if ($st -and $rpcProc -and $st.Pid -eq $rpcProc.Id -and $st.Port -gt 0) {
                if (Test-AtomicHttpFast -Port $st.Port -TimeoutMs 180) {
                    $activePort = $st.Port
                    $serverReady = $true
                    break
                }
            } elseif (-not $st -or -not $rpcProc -or $st.Pid -ne $rpcProc.Id) {
                $has45454 = $false
                try {
                    foreach ($ep in [System.Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners()) {
                        if ($ep.Port -eq 45454) { $has45454 = $true; break }
                    }
                } catch {}
                if ($has45454 -and (Test-AtomicHttpFast -Port 45454 -TimeoutMs 120)) {
                    $activePort = 45454
                    $serverReady = $true
                    break
                }
            }

            if ($rpcProc -and $rpcProc.HasExited) { break }
            Start-Sleep -Milliseconds 40
        }
    }

    if ($serverReady) {
        Write-Host "`n  Iniciando AtomicBombTV (Chromecast + Web: http://localhost:$activePort/)..." -ForegroundColor Green
        Start-Process "http://localhost:$activePort/"
    } elseif (Test-Path $HtmlPlayer) {
        Write-Host "`n  Iniciando AtomicBombTV..." -ForegroundColor Green
        Start-Process $HtmlPlayer
    } else {
        Write-Host "`n  Abriendo lista en el navegador predeterminado..." -ForegroundColor Yellow
        Start-Process $OutputFile
    }
} elseif ($opcion -eq "2") {
    $vlcPaths = @(
        "${env:ProgramFiles}\VideoLAN\VLC\vlc.exe",
        "${env:ProgramFiles(x86)}\VideoLAN\VLC\vlc.exe",
        "$env:LOCALAPPDATA\Programs\VideoLAN\VLC\vlc.exe"
    )
    $vlcExe = $vlcPaths | Where-Object { Test-Path $_ } | Select-Object -First 1

    if ($vlcExe) {
        Write-Host "`n  Iniciando VLC con la lista de reproduccion..." -ForegroundColor Green
        Start-Process $vlcExe -ArgumentList "`"$OutputFile`""
    } else {
        Write-Host "`n  No se encontro VLC instalado en las rutas predeterminadas." -ForegroundColor Yellow
        Start-Process $OutputFile
    }
} else {
    $portStateFile = Join-Path ([System.IO.Path]::GetTempPath()) "atomicbombtv_http_port.txt"
    $shutPort = 45454
    $stExit = Get-AtomicPortState $portStateFile
    if ($stExit -and $stExit.Port -gt 0) { $shutPort = $stExit.Port }
    try {
        $reqExit = [System.Net.WebRequest]::CreateHttp("http://127.0.0.1:$shutPort/shutdown")
        $reqExit.Proxy = $null
        $reqExit.Timeout = 150
        $respExit = $reqExit.GetResponse()
        $respExit.Close()
    } catch {}
    Write-Host "`n  Finalizado. La lista esta lista para usar." -ForegroundColor Green
}
